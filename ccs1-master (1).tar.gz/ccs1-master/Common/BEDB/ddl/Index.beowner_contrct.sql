SET bedb.filename = 'Index.beowner_contrct.sql';

\i set_be_env.sql;

CREATE UNIQUE INDEX IF NOT EXISTS idx_extrnl_contrct_id ON beowner.contrct(extrnl_ctrct_id);

\i cleanup.sql;