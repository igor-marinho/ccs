SET bedb.filename = 'Index.beowner_hist_oem_notif_recipients.sql';

\i set_be_env.sql;

CREATE INDEX IF NOT EXISTS honr_usr_id_idx ON beowner.hist_oem_notif_recipients(usr_id);

\i cleanup.sql;