

DO 
$$
DECLARE 
 I RECORD;
 
begin  
		----------- Creating Role
		
		IF NOT EXISTS (SELECT * FROM PG_CATALOG.PG_ROLES  -- SELECT LIST CAN BE EMPTY FOR THIS
							WHERE  upper(ROLNAME) = 'READONLY') THEN
		
		      execute 'CREATE ROLE READONLY';
	   	END IF;
		   
		--------------Craeting User	   
		IF NOT EXISTS (SELECT * FROM pg_user WHERE upper(usename) = 'READ_ONLY') THEN

			     execute 'CREATE USER read_only WITH PASSWORD '||quote_literal('readonly');
		END IF;
	
		-------------Grant On Database 
		FOR I IN ( SELECT  DATNAME FROM PG_DATABASE where datname not like '%azu%' ) LOOP
				
		   EXECUTE 'GRANT CONNECT ON DATABASE '||I.DATNAME||' to READONLY';
		 
	    END LOOP;
	   
	   
		----------- Assigning Role To User
	   	execute 'GRANT readonly  TO read_only;';
END;
$$;


GRANT USAGE ON SCHEMA EMAIL TO READONLY;
GRANT USAGE ON SCHEMA BE TO READONLY;
GRANT USAGE ON SCHEMA BE_GENERIC_MAPPING TO READONLY;
GRANT USAGE ON SCHEMA BE_JOBS TO READONLY;
GRANT USAGE ON SCHEMA BE_LINKED_CREDENTIALS TO READONLY;
GRANT USAGE ON SCHEMA BE_SERVICES TO READONLY;
GRANT USAGE ON SCHEMA BE_TM TO READONLY;
GRANT USAGE ON SCHEMA BE_TOKEN TO READONLY;
GRANT USAGE ON SCHEMA EXTENSIONS TO READONLY;
GRANT USAGE ON SCHEMA BEOWNER TO READONLY;
GRANT USAGE ON SCHEMA CNST TO READONLY;
GRANT USAGE ON SCHEMA CONTRACT TO READONLY;
GRANT USAGE ON SCHEMA CRUDG_BNDLSVC TO READONLY;
GRANT USAGE ON SCHEMA CRUDG_BOD TO READONLY;
GRANT USAGE ON SCHEMA CRUDG_BUNDLE TO READONLY;
GRANT USAGE ON SCHEMA CRUDG_MAKE TO READONLY;
GRANT USAGE ON SCHEMA CRUDG_PTNR TO READONLY;
GRANT USAGE ON SCHEMA CRUDG_SUBSCRIPTION TO READONLY;
GRANT USAGE ON SCHEMA CRUDG_SVC TO READONLY;
GRANT USAGE ON SCHEMA CRUDG_SVC_URL TO READONLY;
GRANT USAGE ON SCHEMA CRUDG_USR TO READONLY;
GRANT USAGE ON SCHEMA CRUDG_USR_ACTIONS TO READONLY;
GRANT USAGE ON SCHEMA CRUDG_VIN TO READONLY;
GRANT USAGE ON SCHEMA CTX TO READONLY;
GRANT USAGE ON SCHEMA DATA_REMEDIATION TO READONLY;
GRANT USAGE ON SCHEMA FDF TO READONLY;
GRANT USAGE ON SCHEMA MESSAGES TO READONLY;
GRANT USAGE ON SCHEMA NS TO READONLY;
GRANT USAGE ON SCHEMA OEM_NOTIFICATIONS_MGT TO READONLY;
GRANT USAGE ON SCHEMA PORTAL_USER_MGT TO READONLY;
GRANT USAGE ON SCHEMA RDR TO READONLY;
GRANT USAGE ON SCHEMA SHADOW TO READONLY;
GRANT USAGE ON SCHEMA SUPPORT_TOOLS TO READONLY;
GRANT USAGE ON SCHEMA TE TO READONLY;
GRANT USAGE ON SCHEMA TRC TO READONLY;
GRANT USAGE ON SCHEMA USER_REQUESTS_MGT TO READONLY;
GRANT USAGE ON SCHEMA USER_SUBSCRIPTION TO READONLY;
GRANT USAGE ON SCHEMA UTL TO READONLY;
GRANT USAGE ON SCHEMA VIN_MANAGER TO READONLY;
 
grant select on all tables in schema email to readonly;
grant select on all tables in schema be to readonly;
grant select on all tables in schema be_generic_mapping to readonly;
grant select on all tables in schema be_jobs to readonly;
grant select on all tables in schema be_linked_credentials to readonly;
grant select on all tables in schema be_services to readonly;
grant select on all tables in schema be_tm to readonly;
grant select on all tables in schema be_token to readonly;
grant select on all tables in schema extensions to readonly;
grant select on all tables in schema beowner to readonly;
grant select on all tables in schema cnst to readonly;
grant select on all tables in schema contract to readonly;
grant select on all tables in schema crudg_bndlsvc to readonly;
grant select on all tables in schema crudg_bod to readonly;
grant select on all tables in schema crudg_bundle to readonly;
grant select on all tables in schema crudg_make to readonly;
grant select on all tables in schema crudg_ptnr to readonly;
grant select on all tables in schema crudg_subscription to readonly;
grant select on all tables in schema crudg_svc to readonly;
grant select on all tables in schema crudg_svc_url to readonly;
grant select on all tables in schema crudg_usr to readonly;
grant select on all tables in schema crudg_usr_actions to readonly;
grant select on all tables in schema crudg_vin to readonly;
grant select on all tables in schema ctx to readonly;
grant select on all tables in schema data_remediation to readonly;
grant select on all tables in schema fdf to readonly;
grant select on all tables in schema messages to readonly;
grant select on all tables in schema ns to readonly;
grant select on all tables in schema oem_notifications_mgt to readonly;
grant select on all tables in schema portal_user_mgt to readonly;
grant select on all tables in schema rdr to readonly;
grant select on all tables in schema shadow to readonly;
grant select on all tables in schema support_tools to readonly;
grant select on all tables in schema te to readonly;
grant select on all tables in schema trc to readonly;
grant select on all tables in schema user_requests_mgt to readonly;
grant select on all tables in schema user_subscription to readonly;
grant select on all tables in schema utl to readonly;
grant select on all tables in schema vin_manager to readonly;


alter default privileges in schema email grant select on tables to readonly;
alter default privileges in schema be grant select on tables to readonly;
alter default privileges in schema be_generic_mapping grant select on tables to readonly;
alter default privileges in schema be_jobs grant select on tables to readonly;
alter default privileges in schema be_linked_credentials grant select on tables to readonly;
alter default privileges in schema be_services grant select on tables to readonly;
alter default privileges in schema be_tm grant select on tables to readonly;
alter default privileges in schema be_token grant select on tables to readonly;
alter default privileges in schema extensions grant select on tables to readonly;
alter default privileges in schema beowner grant select on tables to readonly;
alter default privileges in schema cnst grant select on tables to readonly;
alter default privileges in schema contract grant select on tables to readonly;
alter default privileges in schema crudg_bndlsvc grant select on tables to readonly;
alter default privileges in schema crudg_bod grant select on tables to readonly;
alter default privileges in schema crudg_bundle grant select on tables to readonly;
alter default privileges in schema crudg_make grant select on tables to readonly;
alter default privileges in schema crudg_ptnr grant select on tables to readonly;
alter default privileges in schema crudg_subscription grant select on tables to readonly;
alter default privileges in schema crudg_svc grant select on tables to readonly;
alter default privileges in schema crudg_svc_url grant select on tables to readonly;
alter default privileges in schema crudg_usr grant select on tables to readonly;
alter default privileges in schema crudg_usr_actions grant select on tables to readonly;
alter default privileges in schema crudg_vin grant select on tables to readonly;
alter default privileges in schema ctx grant select on tables to readonly;
alter default privileges in schema data_remediation grant select on tables to readonly;
alter default privileges in schema fdf grant select on tables to readonly;
alter default privileges in schema messages grant select on tables to readonly;
alter default privileges in schema ns grant select on tables to readonly;
alter default privileges in schema oem_notifications_mgt grant select on tables to readonly;
alter default privileges in schema portal_user_mgt grant select on tables to readonly;
alter default privileges in schema rdr grant select on tables to readonly;
alter default privileges in schema shadow grant select on tables to readonly;
alter default privileges in schema support_tools grant select on tables to readonly;
alter default privileges in schema te grant select on tables to readonly;
alter default privileges in schema trc grant select on tables to readonly;
alter default privileges in schema user_requests_mgt grant select on tables to readonly;
alter default privileges in schema user_subscription grant select on tables to readonly;
alter default privileges in schema utl grant select on tables to readonly;
alter default privileges in schema vin_manager grant select on tables to readonly;