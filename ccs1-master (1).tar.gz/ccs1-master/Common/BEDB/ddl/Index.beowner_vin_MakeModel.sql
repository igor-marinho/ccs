SET bedb.filename = 'index.beowner_vin_MakeModel.sql';

\i set_be_env.sql;

create index if not exists idx_mk_mdl_vin on beowner.vin(make_id,model);

\i cleanup.sql;