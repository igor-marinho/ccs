--grant all on telogowner

DO
$$
DECLARE

I record;

BEGIN
	
	IF EXISTS (SELECT * FROM PG_CATALOG.PG_ROLES WHERE UPPER(ROLNAME) = 'TELOGOWNER' )	THEN
  
		
	FOR i IN (SELECT inhrelid::regclass AS child 
				FROM   pg_catalog.pg_inherits
				WHERE  inhparent = 'telogowner.telog'::regclass )loop 	
				
				
	    EXECUTE 'ALTER TABLE   '||i.child||' OWNER to telogowner';        
		EXECUTE 'GRANT ALL ON  '||i.child||' TO TELOGOWNER';
	
	END LOOP;
	END IF;
	 
END;
$$