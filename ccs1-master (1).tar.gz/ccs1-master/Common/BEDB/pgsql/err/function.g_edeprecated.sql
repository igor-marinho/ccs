SET bedb.filename = 'function.g_edeprecated.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION err.g_edeprecated()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'EDEPR';
END;
$function$

\i cleanup.sql;
