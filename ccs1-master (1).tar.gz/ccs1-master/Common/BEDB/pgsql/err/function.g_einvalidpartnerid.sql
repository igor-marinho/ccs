SET bedb.filename = 'function.g_einvalidpartnerid.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION err.g_einvalidpartnerid()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'EPTNR';
END;
$function$

\i cleanup.sql;
