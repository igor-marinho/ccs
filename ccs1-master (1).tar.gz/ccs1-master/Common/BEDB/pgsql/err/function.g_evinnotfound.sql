SET bedb.filename = 'function.g_evinnotfound.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION err.g_evinnotfound()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'EVINN';
END;
$function$

\i cleanup.sql;
