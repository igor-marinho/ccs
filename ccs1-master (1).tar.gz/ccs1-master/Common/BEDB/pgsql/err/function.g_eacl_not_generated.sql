SET bedb.filename = 'function.g_eacl_not_generated.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION err.g_eacl_not_generated()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'EACLG';
END;
$function$

\i cleanup.sql;
