SET bedb.filename = 'function.g_einvalidemail.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION err.g_einvalidemail()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'EEMML';
END;
$function$

\i cleanup.sql;
