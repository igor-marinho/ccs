SET bedb.filename = 'function.g_einvalidmake.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION err.g_einvalidmake()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'EMAKE';
END;
$function$

\i cleanup.sql;
