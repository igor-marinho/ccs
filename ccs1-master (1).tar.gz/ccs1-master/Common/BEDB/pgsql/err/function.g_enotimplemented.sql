SET bedb.filename = 'function.g_enotimplemented.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION err.g_enotimplemented()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'ENOTI';
END;
$function$

\i cleanup.sql;
