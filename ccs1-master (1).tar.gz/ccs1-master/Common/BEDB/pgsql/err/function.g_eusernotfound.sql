SET bedb.filename = 'function.g_eusernotfound.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION err.g_eusernotfound()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'EUSRN';
END;
$function$

\i cleanup.sql;
