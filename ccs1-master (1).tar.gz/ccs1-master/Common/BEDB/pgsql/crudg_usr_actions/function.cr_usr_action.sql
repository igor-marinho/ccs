SET bedb.filename = 'function.cr_usr_action.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS crudg_usr_actions.cr_usr_action(beowner.usr.usr_id%type,
														beowner.svc.svc_id%type,
														beowner.usr_actions.type%type,
														beowner.usr_actions.user_action%type,
														text);
DROP FUNCTION IF EXISTS crudg_usr_actions.cr_usr_action(TEXT,
														beowner.svc.svc_id%type,
														beowner.usr_actions.type%type,
														beowner.usr_actions.user_action%type,
														text);
/* Creates user actions for the provided user, service and action type.
   The number of rows to keep is determined by the configuration for the user's make for the service and type provided.
   All older additional rows are deleted

   The Make/Partner ID is expected to be set in the context before calling this function.
   The login ID/user ID can either be set in the context or the user ID can be provided here.

utl.get_constant_value('csuccess') (0) is returned if the operation was successful

Error codes returned:
cInternalError                 '1'       Unknown Internal error
c_invalid_user_Id              '287'     Invalid (or null) User ID supplied as parameter or in context
c_svc_id_is_null               '236'     Service Id is Null
c_type_is_null                 '410'     No Type was provided
c_config_missing               '411'     No configuration has been provided - used for this DI for this make, service, type combination
c_action_is_null               '412'     No Action was provided
*/
CREATE OR REPLACE FUNCTION crudg_usr_actions.cr_usr_action(i_usr_id text,
                                                           i_svc_id beowner.svc.svc_id%type,
                                                           i_type beowner.usr_actions.type%type,
                                                           i_action beowner.usr_actions.user_action%type,
                                                           i_version text DEFAULT NULL)
    RETURNS integer AS
$body$
DECLARE
    l_module_action            text;
    l_module_name              text                                 := 'cr_usr_action';
    l_make_id                  beowner.make.make_id%type;
    l_usr_id                   beowner.usr.usr_id%type              := i_usr_id::UUID;
    l_action                   beowner.usr_actions.user_action%type := trim(i_action);
    l_valid_return             integer;
    l_total_action_count       integer                              := 0;
    l_count_similar_actions    integer                              := 0;
    l_similar_guid             beowner.usr_actions.ua_guid%type;
    l_type                     beowner.usr_actions.type%type        := upper(i_type);
    l_make_user_actions_config beowner.make_user_actions_config%rowtype;
    l_exception_diagnostics    trc.exception_diagnostics;
BEGIN
    l_module_action := utl.set_module_action(l_module_name, 'Validating inputs');
    CALL crudg_usr_actions.validate_inputs(io_usr_id 	 => l_usr_id,
                                           i_svc_id 	 => i_svc_id,
                                           i_type 		 => l_type,
                                           i_action 	 => l_action,
                                           i_operation 	 => 'I',
                                           o_make_id 	 => l_make_id,
                                           o_status_code =>l_valid_return,
                                           io_make_user_actions_config => l_make_user_actions_config);

    IF l_valid_return != utl.get_constant_value('csuccess')::integer
    THEN
        RETURN l_valid_return;
    END IF;
    l_module_action := utl.set_module_action(l_module_name, 'Get counts');
    -- get total count and count and guid of any rows that have the same action (case insensitive)
    SELECT COUNT(1) total_action_count,
           SUM(CASE
                   WHEN upper(ua.user_action) = upper(l_action) THEN
                       1
                   ELSE
                       0
               END) count_similar,
           CASE
               WHEN upper(ua.user_action) = upper(l_action) THEN
                   ua_guid
               END  guid_similar
    INTO l_total_action_count,
         l_count_similar_actions,
         l_similar_guid
    FROM beowner.usr_actions ua
    WHERE usr_id = l_usr_id
      AND svc_id = i_svc_id
      AND TYPE = l_type
    GROUP BY ua.user_action, ua_guid
    ORDER BY ua_guid;

    l_total_action_count := COALESCE(l_total_action_count,0);
    l_count_similar_actions := COALESCE(l_count_similar_actions,0);

    IF l_make_user_actions_config.remove_dupes = 'Y' AND
       l_count_similar_actions > 0
    THEN
        -- case insensitive duplicate should be over-written if it exists
        -- keep the latest search case, ensure that it shows up on the top
        UPDATE beowner.usr_actions
        SET user_action      = l_action,
            last_action_date = current_timestamp,
            last_action_by   = current_user
        WHERE ua_guid = l_similar_guid;
        IF l_count_similar_actions > 1
        THEN
            CALL crudg_usr_actions.log_it('Too many similar actions found!', l_usr_id, i_svc_id, i_type, i_action);
            -- shouldn't happen, as duplicates should never be inserted PERFORM crudg_usr_actions.log_it('Too many similar actions found!');
        END IF;
    ELSE
        -- no duplicate was found or duplicates are supposed to be retained
        -- check if number of rows exceed limit
        IF l_total_action_count > l_make_user_actions_config.max_limit
        THEN
            /* Number of rows stored is greater than the max limit. Not likely to happen, but deal with it still, in case limit is lowered ever
            Delete all extra older rows */
            CALL crudg_usr_actions.delete_older_rows(l_module_name, l_usr_id, i_svc_id, i_type,
                                                     l_make_user_actions_config, l_module_action);
            l_total_action_count := l_make_user_actions_config.max_limit; -- so that normal update of oldest row still happens
        END IF;
        l_module_action := utl.set_module_action(l_module_name, 'Inserting new row');
        IF l_total_action_count < l_make_user_actions_config.max_limit
        THEN
            -- row should be inserted
            INSERT INTO beowner.usr_actions(ua_guid, usr_id, svc_id, TYPE, user_action)
            VALUES (beowner.rand_guid(), l_usr_id, i_svc_id, l_type, l_action);
        ELSIF l_total_action_count = l_make_user_actions_config.max_limit
        THEN
            l_module_action := utl.set_module_action(l_module_name, 'Updating existing row');
            -- max number of rows stored, oldest row should be updated PERFORM utl.set_operation(l_module_name,'Updating existing row');
            UPDATE beowner.usr_actions
            SET user_action      = l_action,
                last_action_date = current_timestamp,
                last_action_by   = current_user
            WHERE ua_guid = (SELECT src.ua_guid
                             FROM (SELECT ua_guid
                                   FROM beowner.usr_actions
                                   WHERE usr_id = l_usr_id
                                     AND svc_id = i_svc_id
                                     AND TYPE = l_type
                                   ORDER BY last_action_date) as src
                             LIMIT 1);

        END IF; -- check for count
    END IF; -- check for duplicates
    RETURN utl.get_constant_value('csuccess');

EXCEPTION
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_module_action;

        CALL trc.log('Something went wrong in ' || l_module_name,
                     iexception_diagnostics => l_exception_diagnostics);
        RETURN utl.get_constant_value('cinternalerror');
END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
\i cleanup.sql;
