SET bedb.filename = 'function.d_usr_action.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS crudg_usr_actions.d_usr_action(beowner.usr.usr_id%type,
                                                       beowner.svc.svc_id%type,
                                                       beowner.usr_actions.type%type,
                                                       text);

DROP FUNCTION IF EXISTS crudg_usr_actions.d_usr_action(text,
                                                       beowner.svc.svc_id%type,
                                                       beowner.usr_actions.type%type,
                                                       text);
/*
 d_usr_action function deletes all the user actions for given user id, service id, make id and type.

 The Make/Partner ID is expected to be set in the context before calling this function.
 The login ID/user ID can either be set in the context or the user ID can be provided here.

 utl.get_constant_value('csuccess') (0) is returned if the operation was successful

 Error codes returned:
 cInternalError                 '1'       Unknown Internal error
 c_invalid_user_Id              '287'     Invalid (or null) User ID supplied as parameter or in context
 c_svc_id_is_null               '236'     Service Id is Null
 c_type_is_null                 '410'     No Type was provided
 c_no_actions_found             '413'     No Actions found.
*/
CREATE OR REPLACE FUNCTION crudg_usr_actions.d_usr_action(i_usr_id  text,
                                                          i_svc_id  beowner.svc.svc_id%type,
                                                          i_type 	beowner.usr_actions.type%type,
                                                          i_version text DEFAULT NULL)
    RETURNS integer AS
$body$
DECLARE
    l_module_action            text;
    l_module_name              text                          := 'd_usr_action';
    l_make_id                  beowner.make.make_id%type;
    l_usr_id                   beowner.usr.usr_id%type       := i_usr_id::TEXT;
    l_svc_id                   beowner.svc.svc_id%type       := i_svc_id;
    l_type                     beowner.usr_actions.type%type := upper(i_type);
    l_action                   beowner.usr_actions.user_action%type;
    l_row_cnt                  integer                       := 0;
    l_valid_return             integer;
    l_make_user_actions_config beowner.make_user_actions_config%rowtype;
    l_exception_diagnostics    trc.exception_diagnostics;

BEGIN
    l_module_action := utl.set_module_action(l_module_name, 'Validating inputs');

    CALL crudg_usr_actions.validate_inputs(io_usr_id 	 => l_usr_id,
                                           i_svc_id 	 => i_svc_id,
                                           i_type 		 => l_type,
                                           i_action 	 => l_action,
                                           i_operation 	 => 'D',
                                           o_make_id 	 => l_make_id,
                                           o_status_code =>l_valid_return,
                                           io_make_user_actions_config => l_make_user_actions_config);

    IF l_valid_return != utl.get_constant_value('csuccess')::integer
    THEN
        RETURN l_valid_return;
    END IF;

    SELECT COUNT(1)
    INTO STRICT l_row_cnt
    FROM beowner.usr_actions
    WHERE usr_id = l_usr_id
      AND svc_id = l_svc_id
      AND TYPE = l_type;

    IF COALESCE(l_row_cnt, 0) = 0
    THEN
        RETURN utl.get_constant_value('c_no_actions_found');
    END IF;

    DELETE
    FROM beowner.usr_actions
    WHERE usr_id = l_usr_id
      AND svc_id = i_svc_id
      AND type = i_type;

    RETURN utl.get_constant_value('csuccess');
EXCEPTION
    WHEN OTHERS THEN
        l_module_action := utl.set_module_action(l_module_name, 'Something went really wrong in D_USR_ACTION: ');
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
        RETURN utl.get_constant_value('cinternalerror');
END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION crudg_usr_actions.d_usr_action (i_usr_id usr.usr_id%TYPE, i_svc_id svc.svc_id%TYPE, i_type usr_actions.type%TYPE, i_version text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
