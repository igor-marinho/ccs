SET bedb.filename = 'procedure.log_it.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS crudg_usr_actions.log_it(text,
    beowner.usr.usr_id%type,
    beowner.svc.svc_id%type,
    beowner.usr_actions.type%type,
    beowner.usr_actions.user_action%type);
CREATE OR REPLACE PROCEDURE crudg_usr_actions.log_it(i_text text,
                                                     i_usr_id beowner.usr.usr_id%TYPE DEFAULT NULL,
                                                     i_svc_id beowner.svc.svc_id%TYPE DEFAULT NULL,
                                                     i_type beowner.usr_actions.type%TYPE DEFAULT NULL,
                                                     i_action beowner.usr_actions.user_action%TYPE DEFAULT NULL)
AS $body$
DECLARE
    l_action TEXT;
    l_module_name TEXT := 'log_it';
    l_exception_diagnostics    trc.exception_diagnostics;
BEGIN
    l_action := utl.set_module_action(l_module_name, 'User actions log');
    l_exception_diagnostics.module_name := l_module_name;
    l_exception_diagnostics.action := l_action;
    CALL trc.log(i_text || ' for user ' || COALESCE(i_usr_id::TEXT, '-') || ', svc ' || COALESCE(i_svc_id, '-') ||', type ' || COALESCE(i_type, '-') || ', action ' || COALESCE(i_action, '-')
        , iexception_diagnostics => l_exception_diagnostics);
END;
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE crudg_usr_actions.log_it (i_text text) FROM PUBLIC;

\i cleanup.sql;
