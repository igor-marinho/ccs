SET bedb.filename = 'procedure.delete_older_rows.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS crudg_usr_actions.delete_older_rows(text,
    beowner.usr.usr_id%type,
    beowner.svc.svc_id%type,
    beowner.usr_actions.type%type,
    beowner.make_user_actions_config,
    INOUT text);
CREATE OR REPLACE PROCEDURE crudg_usr_actions.delete_older_rows(i_module_name text,
                                                                i_usr_id beowner.usr.usr_id%type,
                                                                i_svc_id beowner.svc.svc_id%type,
                                                                i_type beowner.usr_actions.type%type,
                                                                i_make_user_actions_config beowner.make_user_actions_config,
                                                                INOUT io_action text) AS
$body$
BEGIN
    io_action := utl.set_module_action(i_module_name, 'Delete older rows');
    CALL crudg_usr_actions.log_it('Rows greater than the limit were stored');
    DELETE
    FROM beowner.usr_actions dst
    WHERE usr_id = i_usr_id
      AND svc_id = i_svc_id
      AND TYPE = i_type
      AND dst.ua_guid IN (SELECT src.ua_guid
                          FROM (SELECT ua.ua_guid,
                                       rank() OVER (ORDER BY last_action_date DESC) date_rank
                                FROM beowner.usr_actions ua
                                WHERE usr_id = i_usr_id
                                  AND svc_id = i_svc_id
                                  AND TYPE = i_type) src
                          WHERE date_rank >
                                i_make_user_actions_config.max_limit);
END;


$body$
    LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE crudg_usr_actions.delete_older_rows () FROM PUBLIC;

\i cleanup.sql;
