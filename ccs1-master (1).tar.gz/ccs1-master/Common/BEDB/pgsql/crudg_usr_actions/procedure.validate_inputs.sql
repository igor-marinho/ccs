SET bedb.filename = 'procedure.validate_inputs.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS crudg_usr_actions.validate_inputs(INOUT beowner.usr.usr_id%type,
                                                           beowner.svc.svc_id%type,
                                                           beowner.usr_actions.type%type,
                                                           beowner.usr_actions.user_action%type,
                                                           text, -- I(Create)/G(Get)/D(Purge)
                                                           INOUT beowner.make.make_id%type,
                                                           integer,
                                                           INOUT beowner.make_user_actions_config);
														   
DROP PROCEDURE IF EXISTS crudg_usr_actions.validate_inputs(INOUT beowner.usr.usr_id%type,
                                                           beowner.svc.svc_id%type,
                                                           beowner.usr_actions.type%type,
                                                           beowner.usr_actions.user_action%type,
                                                           text, -- I(Create)/G(Get)/D(Purge)
                                                           INOUT beowner.make.make_id%type,
                                                           INOUT integer,
                                                           INOUT beowner.make_user_actions_config);
														   
CREATE OR REPLACE PROCEDURE crudg_usr_actions.validate_inputs(io_usr_id 				  INOUT beowner.usr.usr_id%type,
                                                              i_svc_id 					   	    beowner.svc.svc_id%type,
                                                              i_type 					   	    beowner.usr_actions.type%type,
                                                              i_action 					   	    beowner.usr_actions.user_action%type,
                                                              i_operation 				   	    text, -- I(Create)/G(Get)/D(Purge)
                                                              o_make_id 				  INOUT beowner.make.make_id%type,
                                                              o_status_code 			  INOUT integer,
                                                              io_make_user_actions_config INOUT beowner.make_user_actions_config)
AS $body$
DECLARE
    l_make_id                  beowner.make.make_id%type;
    l_usr_id                   beowner.usr.usr_id%type := io_usr_id;
BEGIN
    SELECT coalesce(io_usr_id, cd.usr_id)
    INTO STRICT l_usr_id
    FROM beowner.ctx_data cd;

    IF COALESCE(l_usr_id::TEXT, '') = ''
    THEN
        o_status_code = utl.get_constant_value('c_invalid_user_id');
        RETURN;
    END IF;

    BEGIN
        SELECT make_id
        INTO STRICT l_make_id
        FROM beowner.usr u
        WHERE u.usr_id = l_usr_id;
    EXCEPTION
        WHEN no_data_found THEN
            o_status_code = utl.get_constant_value('c_invalid_user_id');
            RETURN;
    END;

    IF coalesce(trim(i_svc_id), '') = ''
    THEN
        o_status_code = utl.get_constant_value('c_svc_id_is_null');
        RETURN;
    ELSIF NOT utl.is_service_id_valid(i_svc_id => i_svc_id)
    THEN
        o_status_code = utl.get_constant_value('c_invalid_svc_id');
        RETURN;
    END IF;

    IF coalesce(trim(i_action), '') = '' AND
       i_operation = 'I'
    THEN
        o_status_code = utl.get_constant_value('c_action_is_null');
        RETURN;
    END IF;

    io_make_user_actions_config = utl.get_user_action_config(i_make_id => l_make_id,
                                                            i_svc_id => i_svc_id,
                                                            i_action_type => i_type);

    IF io_make_user_actions_config.max_limit IS NULL
    THEN
        o_status_code = utl.get_constant_value('c_config_missing');
        RETURN;
    END IF;

    io_usr_id := l_usr_id;
    o_make_id := l_make_id;
    o_status_code = utl.get_constant_value('csuccess');
    RETURN;
END ;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION crudg_usr_actions.validate_inputs (io_usr_id INOUT usr.usr_id%TYPE, i_svc_id svc.svc_id%TYPE, i_type usr_actions.type%TYPE, i_action usr_actions.user_action%TYPE, i_operation text, o_make_id OUT make.make_id%TYPE) FROM PUBLIC;

\i cleanup.sql;
