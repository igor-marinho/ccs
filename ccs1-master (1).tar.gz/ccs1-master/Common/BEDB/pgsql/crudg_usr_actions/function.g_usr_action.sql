SET bedb.filename = 'function.g_usr_action.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS crudg_usr_actions.g_usr_action(beowner.usr.usr_id%type,
    beowner.svc.svc_id%type,
    beowner.usr_actions.type%type,
    integer,
    OUT integer,
    OUT refcursor,
    text);

DROP FUNCTION IF EXISTS crudg_usr_actions.g_usr_action(TEXT,
    beowner.svc.svc_id%type,
    beowner.usr_actions.type%type,
    integer,
    OUT integer,
    OUT refcursor,
    text);

/*
 g_usr_action function fetches all the user actions with timestamp for given user id, service id, make id and type.

 The Make/Partner ID is expected to be set in the context before calling this function.
 The login ID/user ID can either be set in the context or the user ID can be provided here.

 utl.get_constant_value('csuccess') (0) is returned if the operation was successful

 Error codes returned:
 cInternalError                 '1'       Unknown Internal error
 c_invalid_user_Id              '287'     Invalid (or null) User ID supplied as parameter or in context
 c_svc_id_is_null               '236'     Service Id is Null
 c_type_is_null                 '410'     No Type was provided
 c_no_actions_found             '413'     No Actions found.
*/

-- WARNING: parameters order has been changed by Ora2Pg to move parameters with default values at end
-- Original order was: crudg_usr_actions.g_usr_action(i_usr_id usr.usr_id%TYPE, i_svc_id svc.svc_id%TYPE, i_type usr_actions.type%TYPE, i_fetch_limit bigint, i_version text DEFAULT NULL, rslt OUT REFCURSOR)
-- You will need to manually reorder parameters in the function calls

CREATE OR REPLACE FUNCTION crudg_usr_actions.g_usr_action(i_usr_id text,
                                                          i_svc_id beowner.svc.svc_id%type,
                                                          i_type beowner.usr_actions.type%type,
                                                          i_fetch_limit integer,
                                                          OUT o_status_code integer,
                                                          OUT rslt refcursor,
                                                          i_version text DEFAULT NULL) AS
$body$
DECLARE
    l_module_action            text;
    l_module_name              text                          := 'g_usr_action';
    l_make_id                  beowner.make.make_id%type;
    l_usr_id                   beowner.usr.usr_id%type       := i_usr_id::UUID;
    l_svc_id                   beowner.svc.svc_id%type       := i_svc_id;
    l_type                     beowner.usr_actions.type%type := upper(i_type);
    l_action                   beowner.usr_actions.user_action%type;
    l_row_cnt                  integer                       := 0;
    l_valid_return             integer;
    l_make_user_actions_config beowner.make_user_actions_config%rowtype;
    l_exception_diagnostics    trc.exception_diagnostics;


BEGIN
    l_module_action := utl.set_module_action(l_module_name, 'Validating inputs');

    rslt := utl.get_dummy_cursor();

    CALL crudg_usr_actions.validate_inputs(io_usr_id => l_usr_id,
                                           i_svc_id => l_svc_id,
                                           i_type => l_type,
                                           i_action => l_action,
                                           i_operation => 'G',
                                           o_make_id => l_make_id,
                                           o_status_code =>l_valid_return,
                                           io_make_user_actions_config => l_make_user_actions_config);
    IF l_valid_return != utl.get_constant_value('csuccess')::integer
    THEN
        o_status_code := l_valid_return;
        RETURN;
    END IF;

    SELECT COUNT(1)
    INTO STRICT l_row_cnt
    FROM beowner.usr_actions
    WHERE usr_id = l_usr_id
      AND svc_id = l_svc_id
      AND TYPE = l_type;
	l_row_cnt := COALESCE(l_row_cnt, 0);
    IF l_row_cnt = 0
    THEN
        o_status_code := utl.get_constant_value('c_no_actions_found');
        RETURN;
    END IF;

    CLOSE rslt;
    OPEN rslt FOR
        SELECT user_action, last_action_date
        FROM (SELECT ua.user_action,
                     ua.last_action_date
              FROM beowner.usr_actions ua
              WHERE ua.usr_id = l_usr_id
                AND ua.svc_id = l_svc_id
                AND ua.type = l_type
              ORDER BY ua.last_action_date DESC) alias0
        LIMIT (COALESCE(i_fetch_limit, l_row_cnt));

    o_status_code := utl.get_constant_value('csuccess');
    RETURN;
EXCEPTION
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_module_action;

        CALL trc.log('Something went wrong in ' || l_module_name,
                        iexception_diagnostics => l_exception_diagnostics);
        rslt = utl.get_dummy_cursor();
        o_status_code := utl.get_constant_value('cinternalerror');
        RETURN;
END;

$body$ 
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION crudg_usr_actions.g_usr_action (i_usr_id usr.usr_id%TYPE, i_svc_id svc.svc_id%TYPE, i_type usr_actions.type%TYPE, i_fetch_limit bigint, rslt OUT REFCURSOR, i_version text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
