SET bedb.filename = 'function.log_batch_result_row.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS support_tools.log_batch_result_row(beowner.data_fix_batches.batch_guid%type,
    beowner.vin.device_id%type,
    beowner.data_fix_results.detail_guid%type,
    beowner.subscription.primary_id%type,
    beowner.subscription.subscription_id%type,
    text,
    INOUT beowner.data_fix_results);
CREATE OR REPLACE PROCEDURE support_tools.log_batch_result_row(i_batch_guid beowner.data_fix_batches.batch_guid%type,
                                                               i_old_device_id beowner.vin.device_id%type,
                                                               i_detail_guid beowner.data_fix_results.detail_guid%type,
                                                               i_primary_id beowner.subscription.primary_id%type,
                                                               i_subscription_id beowner.subscription.subscription_id%type,
                                                               i_module_name text,
                                                               INOUT io_batch_results beowner.data_fix_results) AS
$body$
BEGIN
    IF i_batch_guid IS NOT NULL
    THEN
        io_batch_results.detail_guid := i_detail_guid;
        io_batch_results.old_device_id := i_old_device_id;

        IF i_primary_id IS NOT NULL
        THEN
            SELECT login_id,
                   CASE
                       WHEN verified IS NOT NULL THEN
                           utl.get_constant_value('cstatusactive')
                       ELSE
                           utl.get_constant_value('cstatuspending')
                       END account_status
            INTO STRICT io_batch_results.user_login_id,
                io_batch_results.old_account_status
            FROM beowner.usr u
            WHERE u.usr_id = i_primary_id;
            /*   ELSE
            -- io_batch_results.old_account_status := NULL;
            io_batch_results.user_login_id := cnst.c_no_account_text; */
        END IF;
        io_batch_results.new_account_status := io_batch_results.old_account_status;

        io_batch_results.usr_id := i_primary_id;
        io_batch_results.subscription_id := i_subscription_id;
        io_batch_results.status := coalesce(io_batch_results.status,
                                            utl.get_constant_value('c_device_changed_text'));
        CALL data_remediation.log_detail_result(io_batch_results, i_module_name);
        io_batch_results := NULL;
    END IF;
END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE support_tools.log_batch_result_row () FROM PUBLIC;

\i cleanup.sql;
