SET bedb.filename = 'procedure.fix_subscription_bundle.sql';

\i set_be_env.sql;


/* Added for WI #15535 DI 1358, modified significantly for Jira CR10212-32

Fix the bundle on the VIN's subscriptions to match the device_id on the VIN.
Also fix the device ID on the VIN if it isn't same as the one passed.

They can get out of sync when an incorrectly coded FDF is sent and a subscription is created based on an RDR
  or manual subscription and the FDF is then resubmitted with the correct HU code (Device ID).

Error codes returned: (0 is returned for success)
       cInternalError                     1 Internal Error.
       cdeviceiddoesnotexist             38 The Device ID does not exist in the Device table
       c_invalid_vin                    234 VIN is null.
       cDbVinNotFound                   200 System was passed a VIN which was not found.
       c_too_many_incorrect_subs        332 There are multiple incorrect subscriptions for the same VIN and user.
       c_device_id_is_null              475 Device ID not provided
       c_device_bndl_already_correct    476 device ID on VIN and Bundle on subscription already correct
       c_device_make_is_different       477 New device ID provided for VIN is for a different make

*/

-- extend_subscription deprecated for DCS1E-802 : DB - Deprecate the indicated tables Part 1

-- Fix the subscription's bundle to match the VIN's device ID
-- This code assumes that there can only be one subscription for the same user, vin and bundle combination
-- Hence cannot be used for Fiat where we have renewals

DROP PROCEDURE IF EXISTS support_tools.fix_subscription_bundle(beowner.vin.vin%type,
    beowner.vin.device_id%type,
    INOUT integer,
    text);
CREATE OR REPLACE PROCEDURE support_tools.fix_subscription_bundle(i_vin IN beowner.vin.vin%type,
                                                                  i_device_id IN beowner.vin.device_id%type,
                                                                  io_return_code INOUT integer,
                                                                  i_batch_guid IN text DEFAULT NULL)
AS
$$
DECLARE
    l_action                   text;
    l_module_name              text    := 'fix_subscription_bundle';
    l_primary_id               beowner.subscription.primary_id%type;
    l_subscription_id          beowner.subscription.subscription_id%type;
    l_batch_guid               beowner.data_fix_batches.batch_guid%type := i_batch_guid::UUID;
    l_operation                varchar(20);
    l_subs_children_del_return integer; -- OnTime WI #15972

    -- Jira CR10212-32

    l_vin                      beowner.vin.vin%type;
    --  l_login_id       usr.login_id%TYPE;
    l_device_id                beowner.vin.device_id%type;
    l_old_device_id            beowner.vin.device_id%type;
    l_old_make_id              beowner.make.make_id%type;
    l_new_make_id              beowner.make.make_id%type;
    l_account_found            boolean = FALSE;
    l_dfd_row                  beowner.data_fix_batch_details%rowtype;
    l_batch_results            beowner.data_fix_results%rowtype;
    l_detail_guid              beowner.data_fix_results.detail_guid%type;
    l_transaction_id           beowner.subscription.transaction_id%type;
    subs_rec                   record;
    v_cnt                      integer;
    l_return_code              integer;
    l_exception_diagnostics    trc.exception_diagnostics;
BEGIN
    BEGIN
        l_action := utl.set_module_action(l_module_name, ' validating inputs ');

        l_vin := upper(i_vin);
        l_device_id := upper(i_device_id);

        -- need to keep this above the batch detail insert
        IF coalesce(l_vin, '') = ''
        THEN
            io_return_code := utl.get_constant_value('c_invalid_vin'); -- return it even if i batch guid is null, since the sproc shouldn't be called if i_VIN is null
            RETURN;
        END IF;

        IF coalesce(i_batch_guid, '') != ''
        THEN
            l_action := utl.set_module_action(l_module_name, ' inserting into batch details ');

            l_dfd_row.batch_guid := l_batch_guid;
            l_dfd_row.vin := l_vin;
            l_dfd_row.device_id := l_device_id;
            CALL data_remediation.insert_batch_details(i_dfd_row => l_dfd_row,
                                                       i_called_from => l_module_name,
                                                       o_detail_guid => l_detail_guid,
                                                       o_status_code => io_return_code);
            IF io_return_code != utl.get_constant_value('csuccess')::integer
            THEN
                RETURN; -- can't log result in this case, so has to be returned
            END IF;
        END IF;

        IF coalesce(l_device_id, '') = ''
        THEN
            l_batch_results.status := utl.get_constant_value('c_device_id_is_null');
            CALL support_tools.handle_error(l_batch_guid,
                                            l_old_device_id,
                                            l_detail_guid,
                                            l_primary_id,
                                            l_subscription_id,
                                            l_module_name,
                                            l_return_code,
                                            l_batch_results);
            RETURN;
        END IF;

        BEGIN
            SELECT v.device_id,
                   v.make_id
            INTO STRICT l_old_device_id,
                l_old_make_id
            FROM beowner.vin v,
                 beowner.device d
            WHERE v.vin = l_vin
              AND d.device_id = v.device_id;
        EXCEPTION
            WHEN no_data_found THEN
                l_batch_results.status := utl.get_constant_value('cdbvinnotfound');
                CALL support_tools.handle_error(l_batch_guid,
                                                l_old_device_id,
                                                l_detail_guid,
                                                l_primary_id,
                                                l_subscription_id,
                                                l_module_name,
                                                l_return_code,
                                                l_batch_results);
                RETURN;
        END;

        -- check for valid device id and device/make combination
        BEGIN
            SELECT d.make_id
            INTO STRICT l_new_make_id
            FROM beowner.device d
            WHERE d.device_id = l_device_id;
            IF l_old_make_id != l_new_make_id
            THEN
                l_batch_results.status := utl.get_constant_value('c_device_make_is_different');
                CALL support_tools.handle_error(l_batch_guid,
                                                l_old_device_id,
                                                l_detail_guid,
                                                l_primary_id,
                                                l_subscription_id,
                                                l_module_name,
                                                l_return_code,
                                                l_batch_results);
                RETURN;
            END IF;
        EXCEPTION
            WHEN no_data_found THEN
                l_batch_results.status := utl.get_constant_value('cdeviceiddoesnotexist');
                CALL support_tools.handle_error(l_batch_guid,
                                                l_old_device_id,
                                                l_detail_guid,
                                                l_primary_id,
                                                l_subscription_id,
                                                l_module_name,
                                                l_return_code,
                                                l_batch_results);
                RETURN;
        END;

        SELECT cd.transactionid
        INTO l_transaction_id
        FROM beowner.ctx_data cd;

        l_action := utl.set_module_action(l_module_name, ' update the vin.device_id ');

        IF l_old_device_id != l_device_id -- would only happen for CR10212
        THEN
            -- update the vin.device_id first
            UPDATE beowner.vin
            SET device_id      = l_device_id,
                transaction_id = l_transaction_id
            WHERE vin = l_vin;
            l_batch_results.status := utl.get_constant_value('c_device_changed_text');
        ELSE
            -- write to rrr
            l_batch_results.status := utl.get_constant_value('c_device_bndl_already_correct');
        END IF;

        -- find all existing subscriptions, total number of subscriptions and count of subscriptions with correct bundle
        FOR subs_rec IN (SELECT s.primary_id,
                                correct_bndl.bndl_id correct_bndl_id,
                                SUM(CASE
                                        WHEN s.bndl_id = correct_bndl.bndl_id THEN
                                            1
                                        ELSE
                                            0
                                    END)             correct_subs_count,
                                COUNT(1)             total_subs_count
                         FROM beowner.subscription s,
                              beowner.bndl correct_bndl
                         WHERE s.vin = l_vin
                           AND correct_bndl.device_id = l_device_id
                         GROUP BY s.primary_id,
                                  correct_bndl.bndl_id)
            LOOP
                l_account_found := TRUE;
                l_primary_id := subs_rec.primary_id;
                -- if all the subscriptions for this user have the right bundle, nothing needs to be done, except log into RRR
                IF subs_rec.correct_subs_count = subs_rec.total_subs_count
                THEN
                    l_batch_results.status := utl.get_constant_value('c_device_bndl_already_correct');
                ELSE
                    l_batch_results.status := utl.get_constant_value('c_device_changed_text');

                    IF subs_rec.correct_subs_count != 0
                        -- there is already a correct subscription for the primary user, so the incorrect subscription can be deleted
                    THEN
                        l_operation := 'Deleted';

                        -- OnTime WI #15972 : Delete all the children of subscriptions at the same time
                        SELECT subscription_id
                        INTO l_subscription_id
                        FROM beowner.subscription
                        WHERE primary_id = l_primary_id
                          AND vin = l_vin
                          AND bndl_id != subs_rec.correct_bndl_id;

                        l_subs_children_del_return := crudg_subscription.delete_subs_children(
                                i_subscription_id => l_subscription_id);
                        IF l_subs_children_del_return != utl.get_constant_value('csuccess')
                        THEN
                            l_exception_diagnostics.module_name := l_module_name;
                            l_exception_diagnostics.action := l_action;

                            CALL trc.log(iadditionaldata => 'Error while deleting subscription children : ' ||
                                                            l_subs_children_del_return || ' for VIN : ' ||
                                                            l_vin || ' , Primary_id : ' || l_primary_id,
                                         iexception_diagnostics => l_exception_diagnostics);

                            l_batch_results.status := l_subs_children_del_return;
                        END IF;

                        -- CR10212-32
                        -- Added conditional transaction update as part of DCS1E-1213
                        IF l_transaction_id IS NOT NULL
                        THEN
                            UPDATE beowner.subscription s
                            SET transaction_id = l_transaction_id
                            WHERE subscription_id = l_subscription_id;
                        END IF;

                        DELETE
                        FROM beowner.subscription
                        WHERE subscription_id = l_subscription_id;
                    ELSE
                        -- no correct subscription exists, so incorrect subscription should be updated with correct_bndl_id
                        l_operation := 'Updated';

                        UPDATE beowner.subscription
                        SET bndl_id        = subs_rec.correct_bndl_id,
                            transaction_id = l_transaction_id -- CR10212-32
                        WHERE primary_id = l_primary_id
                          AND vin = l_vin
                          AND bndl_id != subs_rec.correct_bndl_id
                        RETURNING subscription_id INTO l_subscription_id;

                        GET DIAGNOSTICS v_cnt = ROW_COUNT;
                        -- not likely to happen, but just in case, log it
                        IF v_cnt > 1
                        THEN
                            l_exception_diagnostics.module_name := l_module_name;
                            l_exception_diagnostics.action := l_action;

                            CALL trc.log(iadditionaldata => 'ERROR : More than 1 incorrect subscription found for VIN : ' ||
                                                            l_vin || ' , Primary_id : ' || l_primary_id,
                                         iexception_diagnostics => l_exception_diagnostics);


                            l_batch_results.status := utl.get_constant_value('c_too_many_incorrect_subs');
                        END IF;
                    END IF;

                    l_exception_diagnostics.module_name := l_module_name;
                    l_exception_diagnostics.action := l_action;

                    CALL trc.log(iadditionaldata => 'INFO : Subscription ' || l_operation ||
                                                    ' for Subscription ID : ' || l_subscription_id ||
                                                    ', VIN : ' || l_vin || ' , Primary_id : ' ||
                                                    l_primary_id,
                                 iexception_diagnostics => l_exception_diagnostics);

                END IF;
                CALL support_tools.handle_error(l_batch_guid,
                                                l_old_device_id,
                                                l_detail_guid,
                                                l_primary_id,
                                                l_subscription_id,
                                                l_module_name,
                                                l_return_code,
                                                l_batch_results);
            END LOOP;

        IF NOT l_account_found
        THEN
            -- log_batch_result_row;
            l_batch_results.user_login_id := utl.get_constant_value('c_no_account_text');
            CALL support_tools.handle_error(l_batch_guid,
                                            l_old_device_id,
                                            l_detail_guid,
                                            l_primary_id,
                                            l_subscription_id,
                                            l_module_name,
                                            l_return_code,
                                            l_batch_results);
        END IF;

    EXCEPTION
        WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
    io_return_code := utl.get_constant_value('cinvalidparams');
    CALL support_tools.handle_error(l_batch_guid,
                                    l_old_device_id,
                                    l_detail_guid,
                                    l_primary_id,
                                    l_subscription_id,
                                    l_module_name,
                                    l_return_code,
                                    l_batch_results);
    WHEN SQLSTATE 'EDEPR' THEN
    RAISE;
    WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS
        l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
        l_exception_diagnostics.column_name := COLUMN_NAME,
        l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
        l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
        l_exception_diagnostics.message_text := MESSAGE_TEXT,
        l_exception_diagnostics.table_name := TABLE_NAME,
        l_exception_diagnostics.schema_name := SCHEMA_NAME,
        l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
        l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
        l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
    l_exception_diagnostics.module_name := l_module_name;
    l_exception_diagnostics.action := l_action;

    CALL trc.log(iadditionaldata => NULL,
                 iexception_diagnostics => l_exception_diagnostics);
    io_return_code := utl.get_constant_value('cinternalerror');
    CALL support_tools.handle_error(l_batch_guid,
                                    l_old_device_id,
                                    l_detail_guid,
                                    l_primary_id,
                                    l_subscription_id,
                                    l_module_name,
                                    l_return_code,
                                    l_batch_results);
END; IF io_return_code IS NULL
      THEN
         io_return_code := utl.get_constant_value('csuccess');
      END IF;
EXCEPTION
      -- to handle exceptions raised from above exception block from handle_error
      WHEN SQLSTATE 'EDEPR' THEN
         io_return_code := l_batch_results.status;
         RETURN;
END;
$$ LANGUAGE plpgsql
SECURITY DEFINER;

END;

\i cleanup.sql;
