SET bedb.filename = 'procedure.handle_error.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS support_tools.handle_error(beowner.data_fix_batches.batch_guid%type,
    beowner.vin.device_id%type,
    beowner.data_fix_results.detail_guid%type,
    beowner.subscription.primary_id%type,
    beowner.subscription.subscription_id%type,
    text,
    INOUT integer,
    INOUT beowner.data_fix_results);
CREATE OR REPLACE PROCEDURE support_tools.handle_error(i_batch_guid beowner.data_fix_batches.batch_guid%type,
                                                       i_old_device_id beowner.vin.device_id%type,
                                                       i_detail_guid beowner.data_fix_results.detail_guid%type,
                                                       i_primary_id beowner.subscription.primary_id%type,
                                                       i_subscription_id beowner.subscription.subscription_id%type,
                                                       i_module_name text,
                                                       INOUT io_return_code integer,
                                                       INOUT io_batch_results beowner.data_fix_results) AS
$$
BEGIN
    IF io_batch_results.status = utl.get_constant_value('csuccess')
    THEN
        RETURN;
    END IF;
    IF i_batch_guid IS NOT NULL
    THEN
        io_batch_results.status := coalesce(io_batch_results.status,
                                            io_return_code::char varying);
        CALL support_tools.log_batch_result_row(i_batch_guid,
                                                i_old_device_id,
                                                i_detail_guid,
                                                i_primary_id,
                                                i_subscription_id,
                                                i_module_name,
                                                io_batch_results);
        io_return_code := utl.get_constant_value('csuccess'); -- since 0 should be returned to portal after logging into RRR
    ELSE
        RAISE EXCEPTION USING ERRCODE = utl.get_constant_value('e_deprecated');
    END IF;
END ;
$$ LANGUAGE plpgsql;

\i cleanup.sql;
