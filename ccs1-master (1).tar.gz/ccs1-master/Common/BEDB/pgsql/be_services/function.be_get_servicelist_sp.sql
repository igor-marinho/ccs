SET bedb.filename = 'function.be_get_servicelist_sp.sql';

\i set_be_env.sql;

-- Removed Function BE_GET_SERVICELIST_SP for DCS1E-419

-- when called without a serviceID then all services will be returned

CREATE OR REPLACE FUNCTION be_services.be_get_servicelist_sp ( iuserLoginId text, ipartnerId text, oResultSet OUT REFCURSOR ) AS $body$
DECLARE


         vUsrID	 beowner.usr.usr_id%type;
 	       vVIN	   beowner.vin.vin%type;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN

     oResultSet := utl.get_dummy_cursor;

     PERFORM ctx.set( iPtnrID    => ipartnerId,
              iLoginID   => trim(both iuserLoginId) );

	   select u.usr_id,v.vin into STRICT vUsrID,vVIN
	   FROM beowner.usr u
LEFT OUTER JOIN beowner.subscription2 s ON (u.usr_id = s.primary_id)
LEFT OUTER JOIN beowner.vin v ON (s.vin = v.vin)
WHERE u.usr_id  = (SELECT usr_id from ctx_data);

	   if vVIN is null then

          RAISE EXCEPTION USING errcode = utl.get_constant_value('e_vinnotfound');
           end if;

	   open oResultSet for
	           SELECT svc_id serviceID, allowed_status serviceStatus, name serviceName, description displayableName from table(beowner.user_subscription.info(vUsrID,vVIN)) alias1;

         RETURN utl.get_constant_value('csuccess');

       EXCEPTION
          WHEN SQLSTATE 'EPTNR'
          THEN
             RETURN utl.get_constant_value('cdbpartneridnotvalid');
          WHEN SQLSTATE 'EUSRN'
          THEN
             RETURN utl.get_constant_value('cnosuchuser');
          WHEN SQLSTATE 'EVINN'
          THEN
             RETURN utl.get_constant_value('cdbvinnotfound');
          WHEN OTHERS
          THEN
             GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

        perform trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
             RETURN utl.get_constant_value('cinternalerror');
    END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION be_services.be_get_servicelist_sp ( iuserLoginId text, ipartnerId text, oResultSet OUT REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
