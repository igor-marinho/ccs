SET bedb.filename = 'procedure.create_shadow_table.sql';

\i set_be_env.sql;

-------------------------------------------------------------------------------
procedure shadow.create_shadow_table( iSourceTable   in varchar2 )
is
  string long;
  cnt	 number;
begin

  select count(*)
    into cnt
    from user_tables
    where table_name = iSourceTable;

  if cnt = 0 then
    raise_application_error(-20001, 'Invalid table name. Make sure the name is proper case');
  end if;

  shadow.drop_shadow_table( iSourceTable );

  -- create the history table
  string := replace(cCreateTable, '?', iSourceTable);
  execute immediate string;

  -- alter the history table with constraints and defaults
  string := replace(cAlterTable, '?', iSourceTable);
  EXECUTE string;

  -- create the trigger on the source table
  string := shadow.trigger_text(iSourceTable);
  EXECUTE string;

END;
-------------------------------------------------------------------------------
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE shadow.drop_shadow_table ( iSourceTable text ) FROM PUBLIC;

\i cleanup.sql; 
