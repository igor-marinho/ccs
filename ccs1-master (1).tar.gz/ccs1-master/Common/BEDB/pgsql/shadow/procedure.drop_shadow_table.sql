SET bedb.filename = 'procedure.drop_shadow_table.sql';

\i set_be_env.sql;

-------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE shadow.drop_shadow_table ( iSourceTable text ) AS $body$
DECLARE

  text text;
  oldHist text;
  newHist text;

BEGIN

  -- drop existing trigger; if it's not there, ignore it --
  declare
    no_trigger exception;
    pragma exception_init(no_trigger, -04080);
  begin
    string := 'drop trigger tr_hist_'||iSourceTable;
    EXECUTE string;
  exception
    when no_trigger then null;
  end;

  oldHist := 'hist_'||iSourceTable;
  newHist := substr('h'||to_char(clock_timestamp(), 'YYMMDDHH24MISS')||iSourceTable, 1, 30);

  -- drop old constraint from existing history table --
  for cx in (SELECT constraint_name
	       from user_constraints
	       where table_name = upper(oldHist)
		 and constraint_name not like 'SYS\_%' escape '\') -- editor hack '
  loop
    string := 'alter table '||oldHist||' drop constraint '||cx.constraint_name;
    execute immediate string;
  end loop;

  -- rename existing history table; if it's not there, ignore it --
  declare
    no_table exception;
    pragma exception_init(no_table, -04043);
  begin
    string := 'rename '||oldHist||' to '||newHist;
    execute immediate string;
  exception
    when no_table then null;
  end;

end shadow.drop_shadow_table();

\i cleanup.sql; 
