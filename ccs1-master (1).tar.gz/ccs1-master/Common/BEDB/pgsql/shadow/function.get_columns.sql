SET bedb.filename = 'function.get_columns.sql';

\i set_be_env.sql;

-------------------------------------------------------------------------------
  

  -- the table template text
  

  -- the table alter text
  

  -- the trigger template text
  

  -- for the assignment list (~ and ! in the trigger)
  

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION shadow.get_columns ( iTableName text ) RETURNS TCOLLIST AS $body$
DECLARE

  rslt tColList;

BEGIN

  rslt := tColList();

  select column_name
    bulk collect into STRICT rslt
    from user_tab_columns
    where table_name = iTableName
    order by column_id;

  return rslt;

END;

$body$
LANGUAGE PLPGSQL
;

-- REVOKE ALL ON FUNCTION shadow.get_columns ( iTableName text ) FROM PUBLIC;


\i cleanup.sql; 
