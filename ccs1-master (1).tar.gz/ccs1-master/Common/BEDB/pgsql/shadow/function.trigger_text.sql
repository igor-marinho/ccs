SET bedb.filename = 'function.trigger_text.sql';

\i set_be_env.sql;

-------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION shadow.trigger_text ( iSourceTable text ) RETURNS varchar AS $body$
DECLARE

  vDelLst   text;      -- the delete field list 	(using :old)
  vUpdLst   text;      -- the insert/update field list	(using :new)
  vColLst   text;      -- the table column list used for the INSERT statement
  vRecLst   text;      -- the variable column list used for the INSERT statement
  x	    text;      -- used for a couple different things
  vColumns  tColList;  -- the column list from USER_TAB_COLUMNS
BEGIN
  vColumns := shadow.get_columns(iSourceTable);

  x := ', '; -- for comma-separated values (vColLst, vRecLst)
  <<column_loop>>
  for i in vColumns.first..vColumns.last
  loop

    vDelLst := vDelLst || replace(replace(current_setting('shadow.cassignlist')::text, '~', vColumns(i)),'!', 'old') || current_setting('shadow.lf')::varchar(2);
    vUpdLst := vUpdLst || replace(replace(current_setting('shadow.cassignlist')::text, '~', vColumns(i)),'!', 'new') || current_setting('shadow.lf')::varchar(2);

    if i = vColumns.last then
      -- we're on the last comma-separated value, so don't put a comma
      x := null;
    end if;

    vColLst := vColLst || vColumns(i) || x;
    vRecLst := vRecLst || 'z.'|| vColumns(i) || x;

  end loop column_loop;

  x := replace(current_setting('shadow.ccreatetrigger')::text, '?', iSourceTable); -- ? is the replacement character for the source table name
  x := replace(x, '~', vDelLst);		   -- ~ is the replacement character for the :old fields
  x := replace(x, '!', vUpdLst);		   -- ! is the replacement character for the :new fields
  x := replace(x, '@', vColLst);		   -- @ is the replacement character for the insert column list
  x := replace(x, '#', vRecLst);		   -- # is the replacement character for the insert variables
  return x;

END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION shadow.trigger_text ( iSourceTable text ) FROM PUBLIC;


\i cleanup.sql; 
