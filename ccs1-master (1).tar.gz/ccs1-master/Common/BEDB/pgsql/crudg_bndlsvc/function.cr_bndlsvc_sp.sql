SET bedb.filename = 'function.cr_bndlsvc_sp.sql';

\i set_be_env.sql;

   -- create bundle service association
   /* Function cr_bndlsvc_sp. Create bndlsvc row.
             in: i_bndl_id (R), i_svc_id (R), i_allowed_status (R), i_optin_level, i_avail_date, i_end_date, i_version
             out: success/failure (utl.get_constant_value('csuccess') (0), cnst.cInternalError (1) or error codes defined below )

             Error Codes returned : 
              c_bndl_id_is_null         235     Bundle Id is Null.
              c_svc_id_is_null          236     Service Id is Null.
              c_invalid_svc_id          237     Invalid Service Id.
              c_allowed_status_is_null  238     Allowed Status is Null.
              c_existing_bndl_svc       239     Bundle/Service combination already exists
              c_invalid_allowed_status  240     Allowed status is invalid
              cInvalidBundleID          270     The Supplied Bundle ID is invalid
  */   

DROP FUNCTION IF EXISTS crudg_bndlsvc.cr_bndlsvc_sp (text, 
                                                     text, 
													 text, 
													 text, 
													 text, 
													 text, 
													 text);

CREATE OR REPLACE FUNCTION crudg_bndlsvc.cr_bndlsvc_sp (i_bndl_id text, 
                                                        i_svc_id text, 
														i_allowed_status text, 
														i_optin_level text, 
														i_avail_date text, 
														i_end_date text, 
														i_version text) RETURNS INTEGER AS $body$
DECLARE

      l_action text;
      l_module_name text := 'cr_bndlsvc_sp';
      l_optin_level beowner.bndlsvc.optin_level%TYPE := coalesce(i_optin_level::integer, 0);
      l_bndl_id uuid := i_bndl_id;
      l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      
	  l_action := utl.set_module_action( l_module_name, 'Starting cr_bndlsvc_sp');
	  
	  l_action := utl.set_action('Validating inputs');

	  IF COALESCE(i_bndl_id, '') = '' 
      THEN
      RETURN utl.get_constant_value('c_bndl_id_is_null');
	  
      ELSIF NOT utl.is_bundle_id_valid(l_bndl_id)
      THEN
      RETURN utl.get_constant_value('cinvalidbundleid');
	  
      ELSIF COALESCE(i_svc_id, '') = ''
      THEN
      RETURN utl.get_constant_value('c_svc_id_is_null');
	  
      ELSIF NOT utl.is_service_id_valid(i_svc_id)
      THEN
      RETURN utl.get_constant_value('c_invalid_svc_id');
	  
      ELSIF COALESCE(i_allowed_status, '') = ''	  
      THEN
      RETURN utl.get_constant_value('c_allowed_status_is_null');
	  
      ELSIF NOT utl.is_allowed_status_valid(i_allowed_status)
      THEN
      RETURN utl.get_constant_value('c_invalid_allowed_status');
	  
      ELSE
      INSERT INTO beowner.bndlsvc(bndl_id, svc_id, allowed_status, optin_level)
      VALUES (l_bndl_id, i_svc_id, i_allowed_status, l_optin_level);

      RETURN utl.get_constant_value('csuccess');
      END IF;
	  
   EXCEPTION
      WHEN unique_violation THEN
      RETURN utl.get_constant_value('c_existing_bndl_svc');
	  
      WHEN OTHERS THEN
									
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
						
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => 'Something went really wrong in cr_bndlsvc_sp with svc_id = ' ||
                                    i_svc_id || ' bndl_id = ' ||
                                    i_bndl_id || ' i_allowed_status = ' ||
                                    i_allowed_status ||' i_optin_level = ' ||
                                    i_optin_level || ' i_avail_date = ' ||
                                    i_avail_date || ' i_end_date = ' ||
                                    i_end_date || ' i_version = ' ||
                                    i_version,
                        iexception_diagnostics => l_exception_diagnostics);
						
         RETURN utl.get_constant_value('cinternalerror');
   END;

   -- Removed Function u_bndlsvc_sp for DCS1E-605
   -- Removed Function d_bndlsvc_sp for DCS1E-605
   -- get bundle service association info
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION crudg_bndlsvc.cr_bndlsvc_sp (i_bndl_id text, i_svc_id text, i_allowed_status text, i_optin_level text, i_avail_date text, i_end_date text, i_version text) FROM PUBLIC;
 
\i cleanup.sql;
