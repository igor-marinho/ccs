SET bedb.filename = 'function.g_bndlsvc_sp.sql';

\i set_be_env.sql;


  -- Removed Function u_bndlsvc_sp for DCS1E-605
  -- Removed Function d_bndlsvc_sp for DCS1E-605

   -- get bundle service association info
   /* Function g_bndlsvc_sp. Get information from bndlsvc and svc tables. Bndl table is used to determine the bundle in case i_device_id is passed.
           in: bndl_id, svc_id
           out: success/failure (utl.get_constant_value('csuccess') (0), cnst.cInternalError (1) or error codes defined below)
           out: (refcursor) device_id, bndl_id, svc_id, svc_name, svc_description, allowed_status, optin_level, version
                 order by device_id, to_number(svc_id)

           Error Codes returned :
            cDeviceIDDoesNotExist  38      The Device ID does not exist in the Device table
            c_invalid_svc_id       237     Invalid Service Id.
            cInvalidBundleID       270     The Supplied Bundle ID is invalid
*/   


 -- get bundle service association info
CREATE OR REPLACE FUNCTION crudg_bndlsvc.g_bndlsvc_sp ( i_device_id text DEFAULT NULL, 
                                                        i_bndl_id text DEFAULT NULL, 
                                                        i_svc_id text DEFAULT NULL, 
                                                        i_version text DEFAULT NULL,
                                                        OUT o_status_code INTEGER,
                                                        OUT o_result  REFCURSOR) 
AS $body$
DECLARE 
    l_action text;
    l_module_name text := 'g_bndlsvc_sp';
BEGIN

      IF i_device_id IS NOT NULL AND
         NOT utl.is_device_id_valid(i_device_id)
      THEN
        o_status_code := utl.get_constant_value('cdeviceiddoesnotexist');
        o_result := utl.get_dummy_cursor(); -- Jira PU-391
      ELSIF i_bndl_id IS NOT NULL AND
            NOT utl.is_bundle_id_valid(i_bndl_id::uuid)
      THEN
        o_status_code := utl.get_constant_value('cinvalidbundleid');
        o_result := utl.get_dummy_cursor(); -- Jira PU-391        
      ELSIF i_svc_id IS NOT NULL AND
            NOT utl.is_service_id_valid(i_svc_id)
      THEN
        o_status_code := utl.get_constant_value('c_invalid_svc_id');
        o_result := utl.get_dummy_cursor(); -- Jira PU-391        
      ELSE
        l_action := utl.set_module_action( l_module_name, 'g_bndlsvc_sp device_id =' ||
                                          i_device_id || ' svc_id = ' ||
                                          i_svc_id || ' bndl_id = ' ||
                                          i_bndl_id);
        OPEN o_result FOR
            SELECT b.device_id,
                   bs.bndl_id,
                   bs.svc_id,
                   s.name            svc_name,
                   s.description     svc_description,
                   bs.allowed_status,
                   bs.optin_level,
                   i_version         "version"
              FROM beowner.bndlsvc bs,
                   beowner.svc     s,
                   beowner.bndl    b
             WHERE bs.bndl_id = coalesce(i_bndl_id, bs.bndl_id::text)::uuid
                   AND bs.svc_id = coalesce(i_svc_id, bs.svc_id)
                   AND b.bndl_id = bs.bndl_id
                   AND b.device_id = coalesce(i_device_id, b.device_id)
                   AND s.svc_id = bs.svc_id
             ORDER BY b.device_id,
                      (s.svc_id)::numeric;
        o_status_code := utl.get_constant_value('csuccess');

      END IF;
   END;

$body$
LANGUAGE PLPGSQL
STABLE
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION crudg_bndlsvc.g_bndlsvc_sp ( o_result OUT REFCURSOR,i_device_id text DEFAULT NULL, i_bndl_id text DEFAULT NULL, i_svc_id text DEFAULT NULL, i_version text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
