SET bedb.filename = 'function.is_vendor_tid_duplicate.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION ctx.is_vendor_tid_duplicate(IN i_vendor_tid TEXT)
RETURNS BOOLEAN
AS
$BODY$

DECLARE
    l_vendor_tid_exists VARCHAR(1);
BEGIN
    select 1
        INTO STRICT l_vendor_tid_exists
        FROM beowner.vin_sub_vendor_trans
        WHERE vendor_tid = i_vendor_tid;
    RETURN TRUE;
    EXCEPTION
        WHEN no_data_found THEN
            RETURN FALSE;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
