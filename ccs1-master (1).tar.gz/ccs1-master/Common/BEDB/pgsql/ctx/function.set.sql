SET bedb.filename = 'function.set.sql';

\i set_be_env.sql;

/***************************************************************************************
**** UNCOMMENT EACH SECTION FOR POSTGRES CONVERSION                             ********

CREATE OR REPLACE FUNCTION ctx.set(IN imakeid TEXT DEFAULT NULL,
                                   IN iusrid UUID DEFAULT NULL,                                   
                                   IN ivin TEXT DEFAULT NULL)
RETURNS void
AS
$BODY$
declare
***************************************************************************************/
-------------------------------------------------------------------------------
   /* This version of SET takes in known USR_ID, make_id and VIN parameters
      in order to set context for those parameters. It's ok to not
      specify or pass nulls for each value.

      If NULLs are present, no exception is raised, but the
      context for that parameter is set to NULL.

      It does in fact validate that the data exists in the database.
   */

/***************************************************************************************
**** UNCOMMENT EACH SECTION FOR POSTGRES CONVERSION                             ********
    vusrid BEOWNER.USR.usr_id%TYPE;
    vmakeid BEOWNER.MAKE.make_id%TYPE;
    vvin BEOWNER.VIN.vin%TYPE;
BEGIN
    
    SELECT
        cm.make_id, u.usr_id, v.vin
        INTO STRICT vmakeid, vusrid, vvin
        FROM (select null as single) r
        LEFT OUTER JOIN beowner.make AS cm
            ON cm.make_id = UPPER(TRIM(imakeid))
        LEFT OUTER JOIN beowner.usr AS u
            ON u.usr_id = iusrid
            AND u.make_id = cm.make_id
        LEFT OUTER JOIN beowner.vin AS v
            ON v.vin = UPPER(TRIM(ivin))
            AND v.make_id = cm.make_id;

    IF imakeid IS NOT NULL AND vmakeid IS NULL THEN
        raise exception using errcode=utl.get_constant_value('e_invalidmake');
    END IF;

    IF iusrid IS NOT NULL AND vusrid IS NULL THEN
        raise exception using errcode=utl.get_constant_value('e_usernotfound');
    END IF;

    IF ivin IS NOT NULL AND vvin IS NULL THEN
        raise exception using errcode=utl.get_constant_value('e_vinnotfound');
    END IF;
    
    perform set_config(ctx.g_canecorso() ||'.' || ctx.g_makeid(), vmakeid, false);
    perform set_config(ctx.g_canecorso() ||'.' || ctx.g_usrid(), vusrid::text, false);
    perform set_config(ctx.g_canecorso() ||'.' || ctx.g_vin(), vvin, false);
    
END;
$BODY$
LANGUAGE  plpgsql;

CREATE OR REPLACE FUNCTION ctx.set(IN iptnrid UUID DEFAULT NULL,
                                   IN iloginid TEXT DEFAULT NULL,
                                   IN ivin TEXT DEFAULT NULL)
RETURNS void
AS
$BODY$
DECLARE
    vmakeid BEOWNER.PTNR.make_id%TYPE;
    vusrid BEOWNER.USR.usr_id%TYPE;
    vvin BEOWNER.VIN.vin%TYPE;
BEGIN
    
    SELECT
        p.make_id, u.usr_id, v.vin
        INTO STRICT vmakeid, vusrid, vvin
        FROM (select null as single) r
        LEFT OUTER JOIN beowner.ptnr AS p
            ON p.ptnr_id = iptnrid
        LEFT OUTER JOIN beowner.usr AS u
            ON u.login_id = LOWER(TRIM(iloginid)) AND u.make_id = p.make_id
        LEFT OUTER JOIN beowner.vin AS v
            ON v.vin = UPPER(TRIM(ivin)) AND v.make_id = p.make_id;

    IF iptnrid IS NOT NULL AND vmakeid IS NULL THEN
        raise exception using errcode=utl.get_constant_value('e_invalidpartnerid');		
    END IF;

    IF iloginid IS NOT NULL AND vusrid IS NULL THEN
        raise exception using errcode=utl.get_constant_value('e_usernotfound');
    END IF;

    IF ivin IS NOT NULL AND vvin IS NULL THEN        
        raise exception using errcode=utl.get_constant_value('e_vinnotfound');
    END IF;
    
    perform set_config(ctx.g_canecorso() ||'.' || ctx.g_makeid(), vmakeid, false);
    perform set_config(ctx.g_canecorso() ||'.' || ctx.g_usrid(), vusrid::text, false);
    perform set_config(ctx.g_canecorso() ||'.' || ctx.g_vin(), vvin, false);

    exception
     when invalid_text_representation then
        raise exception using errcode=utl.get_constant_value('e_invalidpartnerid');

END;
$BODY$
LANGUAGE  plpgsql;
***************************************************************************************/
DROP FUNCTION IF EXISTS ctx.set(TEXT,TEXT,TEXT,TEXT,TEXT,TEXT,TEXT,TEXT,TEXT);
CREATE OR REPLACE FUNCTION ctx.set(IN iptnrid TEXT DEFAULT NULL,
                                   IN iloginid TEXT DEFAULT NULL,
                                   IN iusrid TEXT DEFAULT NULL,
                                   IN imakeid TEXT DEFAULT NULL,
                                   IN ivin TEXT DEFAULT NULL,
                                   IN itranid TEXT DEFAULT NULL,
                                   IN itrannm TEXT DEFAULT NULL,
                                   IN itranstepnm TEXT DEFAULT NULL,
                                   IN ivendortid TEXT DEFAULT NULL)
RETURNS INTEGER
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'set';
    vptnrid BEOWNER.PTNR.ptnr_id%TYPE;
    vloginid BEOWNER.USR.login_id%TYPE;
    vusrid BEOWNER.USR.usr_id%TYPE;
    vmakeid BEOWNER.PTNR.make_id%TYPE;
    vvin BEOWNER.VIN.vin%TYPE;
    vtranid CHARACTER VARYING(4000);
    vtrannm CHARACTER VARYING(200);
    vtranstp CHARACTER VARYING(4000);
    vvendortid BEOWNER.VIN_SUBSCRIPTION.vendor_tid%TYPE;
    -- Added for OnTime Defect 12055 (TE service using invalid partner ID comes back status 23.)
--    einvalidhex aws_oracle_ext.ora_exception := 'einvalidhex';
--    einvalidhex$code SMALLINT := - 01465;
--    cmodule CONSTANT TEXT := 'ctx.set'
    -- added for #16905 

    l_exception_diagnostics trc.exception_diagnostics;
 
BEGIN
    -- OnTime #22785
    IF iloginid IS NOT NULL AND iusrid IS NOT NULL THEN
        RETURN utl.get_constant_value('c_ctx_user_and_login_provided');
    END IF;
    vptnrid := REPLACE(TRIM(iptnrid), '-', '')::UUID;
    vloginid := LOWER(TRIM(iloginid));
    vvin := UPPER(TRIM(ivin));
    vmakeid := imakeid;
    -- OnTime #22785 

    BEGIN
        vusrid := TRIM(iusrid)::UUID;
        EXCEPTION
            WHEN invalid_text_representation THEN
                RETURN utl.get_constant_value('cinvalidctxusrid'); 
    END;
    vtranid := itranid;
    vtrannm := itrannm;
    vtranstp := itranstepnm;

    BEGIN
        IF iptnrid IS NOT NULL AND vmakeid IS NULL THEN
            SELECT
                make_id
                INTO STRICT vmakeid
                FROM beowner.ptnr
                WHERE ptnr_id = vptnrid;
        END IF;
        EXCEPTION
            WHEN no_data_found THEN
                RETURN utl.get_constant_value('cinvalidctxptnrid');
    END;

    IF iptnrid IS NULL AND vmakeid IS NOT NULL THEN
        BEGIN
            SELECT
                ptnr_id
                INTO STRICT vptnrid
                FROM beowner.ptnr
                WHERE make_id = vmakeid
                LIMIT 1;
            EXCEPTION
                WHEN no_data_found THEN
                    RETURN utl.get_constant_value('cinvalidctxmakeid');
        END;
    END IF;

    IF iloginid IS NOT NULL
    /* OnTime #22785 vusrid has to be null since both input params are not allowed any more */
    THEN
        BEGIN
            SELECT
                usr_id
                INTO STRICT vusrid
                FROM beowner.usr
                WHERE make_id = COALESCE(vmakeid, make_id)
                /* OnTime #22785 */
                AND login_id = vloginid;
            EXCEPTION
                WHEN no_data_found THEN
                    RETURN utl.get_constant_value('cinvalidctxusrlogid');
                /* OnTime #22785 */
                WHEN too_many_rows THEN
                    RETURN utl.get_constant_value('c_user_undetermined');
        END;
    END IF;

    IF imakeid IS NOT NULL AND vmakeid IS NULL THEN
        RETURN utl.get_constant_value('cinvalidctxmakeid');
    END IF
    /* OnTime #22785 */;

    IF iusrid IS NOT NULL
    /* vloginid has to be null since both input params are not allowed any more */
    THEN
        BEGIN
            SELECT
                login_id
                INTO STRICT vloginid
                FROM beowner.usr
                WHERE make_id = COALESCE(vmakeid, make_id) AND usr_id = vusrid;
            EXCEPTION
                WHEN no_data_found THEN
                    RETURN utl.get_constant_value('cinvalidctxusrid');
        END;
    END IF;

    IF ivin IS NOT NULL AND vvin IS NULL THEN
        RETURN utl.get_constant_value('cinvalidctxvin');
    END IF;

    IF vvin IS NOT NULL THEN
        BEGIN
            SELECT
                vin
                INTO STRICT vvin
                FROM beowner.vin
                WHERE vin = vvin;
            EXCEPTION
                WHEN no_data_found THEN
                    RETURN utl.get_constant_value('cinvalidctxvin');
        END;
    END IF
    /* added for #16905 */;

    BEGIN
        vvendortid := UPPER(ivendortid);

        IF vvendortid IS NOT NULL AND ctx.is_vendor_tid_duplicate(i_vendor_tid := vvendortid) THEN
            RETURN utl.get_constant_value('cduplicate_vendortid');
        END IF;
        EXCEPTION
            WHEN string_data_right_truncation THEN
                RETURN utl.get_constant_value('cinvalid_vendortid');
    end;

    select utl.set_module_action( l_module_name, 'Setting all context values')  into l_action;

    PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cpartnerid'), vptnrid::text, false);    
    PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cusrlogid'), vloginid, false);
    PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cusrid'), vusrid::text, false);
    PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cmakeid'), vmakeid, false);
    PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cvin'), vvin, false);
    PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('ctransactionid'), vtranid, false);    
    PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('ctransactionnm'), vtrannm, false);
    PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('ctransactionstepnm'), vtranstp, false);
    
    /* added for #16905 */
    IF vvendortid IS NOT NULL
    THEN
        -- don't over-write existing vendor TId if none is sent 
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cvendortid'), vvendortid, false);
    END if;
    
    select utl.set_action( 'Set all context values')  into l_action;
  
    RETURN utl.get_constant_value('csuccess');

    EXCEPTION
     WHEN invalid_text_representation then
        RAISE EXCEPTION USING errcode=utl.get_constant_value('e_invalidpartnerid');
     WHEN OTHERS THEN
    
        GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        CALL trc.log(iadditionaldata => 'Something went really wrong in BEOWNER.CTX PTNR_ID=' || iptnrid || 
                          ' login_id=' || iloginid ||
                          ' usr_id=' || iusrid || 
                          ' make_id=' ||imakeid || 
                          ' vin=' || ivin ||
                          ' iTRANID=' || itranid ||
                          ' iTranNM=' || itrannm ||
                          ' iTranStepNM=' || itranstepnm ||
                          ' ivendortid=' || ivendortid,
                    iexception_diagnostics => l_exception_diagnostics);
        RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
