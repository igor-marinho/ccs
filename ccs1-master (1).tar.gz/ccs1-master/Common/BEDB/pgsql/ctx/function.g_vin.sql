SET bedb.filename = 'function.g_vin.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION ctx.g_vin()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'VIN';
END;
$function$

\i cleanup.sql;
