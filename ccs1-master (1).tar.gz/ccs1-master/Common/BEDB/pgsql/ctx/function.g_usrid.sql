SET bedb.filename = 'function.g_usrid.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION ctx.g_usrid()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'USR_ID';
END;
$function$

\i cleanup.sql;
