SET bedb.filename = 'function.unset.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS ctx.unset(TEXT, TEXT,TEXT,TEXT,TEXT,TEXT,TEXT,TEXT,TEXT);
CREATE OR REPLACE FUNCTION ctx.unset(IN iptnrid TEXT DEFAULT NULL, IN iloginid TEXT DEFAULT NULL, IN iusrid TEXT DEFAULT NULL, IN imakeid TEXT DEFAULT NULL, IN ivin TEXT DEFAULT NULL, IN itranid TEXT DEFAULT NULL, IN itrannm TEXT DEFAULT NULL, IN itranstepnm TEXT DEFAULT NULL, IN ivendortid TEXT DEFAULT NULL)
RETURNS INTEGER
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'unset';
    cmodule CONSTANT TEXT := 'ctx.set';
    l_exception_diagnostics trc.exception_diagnostics;
begin
    
    select utl.set_module_action( l_module_name, 'Entering unset context') into l_action;

    IF (COALESCE(LENGTH(iptnrid), 0) + COALESCE(LENGTH(iloginid), 0) +
        COALESCE(LENGTH(iusrid), 0) + COALESCE(LENGTH(imakeid), 0) +
        COALESCE(LENGTH(ivin), 0) + COALESCE(LENGTH(itranid), 0) +
        COALESCE(LENGTH(itrannm), 0) + COALESCE(LENGTH(itranstepnm), 0) +
        COALESCE(LENGTH(ivendortid), 0)) = 0 THEN
        select utl.set_action( 'Unsetting all context values') into l_action;

        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cpartnerid'), null, false);
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cusrlogid'), null, false);
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cusrid'), null, false);
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cmakeid'), null, false);
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cvin'), null, false);
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('ctransactionid'), null, false);    
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('ctransactionnm'), null, false);
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('ctransactionstepnm'), null, false);
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cvendortid'), null, false); -- #16905 

        select utl.set_action( 'Unset all context values') into l_action;

        RETURN utl.get_constant_value('csuccess');
    END IF;
    select utl.set_action( 'Unset select context values') into l_action;


    IF iptnrid IS NOT NULL THEN
        select utl.set_action ( 'Unset PartnerID context') into l_action;
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cpartnerid'), null, false);
    END IF;

    IF iloginid IS NOT NULL THEN
        select utl.set_action ( 'Unset LoginID context') into l_action;
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cusrlogid'), null, false);
    END IF;

    IF iusrid IS NOT NULL THEN
        select utl.set_action ( 'Unset UsrID context') into l_action;
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cusrid'), null, false);
    END IF;

    IF imakeid IS NOT NULL THEN
        select utl.set_action ( 'Unset MakeID context') into l_action;
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cmakeid'), null, false);
    END IF;

    IF ivin IS NOT NULL THEN
        select utl.set_action ( 'Unset VIN context') into l_action;
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cvin'), null, false);
    END IF;

    IF itranid IS NOT NULL THEN
        select utl.set_action ( 'Unset TransactionID context') into l_action;
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('ctransactionid'), null, false);
    END IF;

    IF itrannm IS NOT NULL THEN
        select utl.set_action ( 'Unset TransactionNM context') into l_action;
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('ctransactionnm'), null, false);
    END IF;

    IF itranstepnm IS NOT NULL THEN
        select utl.set_action ( 'Unset TransactionStepNM context') into l_action;
        PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('ctransactionstepnm'), null, false);
    END if;

    /* #16905 */
    IF ivendortid IS NOT NULL THEN
        select utl.set_action ( 'Unset VendortTId context') into l_action;
        perform set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cvendortid'), null, false);
    END IF;
    
    RETURN utl.get_constant_value('csuccess');
EXCEPTION
    WHEN OTHERS THEN
        select utl.set_action( 'Something went really wrong in unset context') into l_action;
        GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
        RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
