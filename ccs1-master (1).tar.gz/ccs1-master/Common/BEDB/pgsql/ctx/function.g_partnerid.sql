SET bedb.filename = 'function.g_partnerid.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION ctx.g_partnerid()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'PARTNERID';
END;
$function$

\i cleanup.sql;
