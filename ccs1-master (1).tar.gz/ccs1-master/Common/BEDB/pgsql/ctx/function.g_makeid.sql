SET bedb.filename = 'function.g_makeid.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION ctx.g_makeid()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'MAKE_ID';
END;
$function$

\i cleanup.sql;
