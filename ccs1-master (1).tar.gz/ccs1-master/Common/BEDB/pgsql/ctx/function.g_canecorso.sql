SET bedb.filename = 'function.g_canecorso.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION ctx.g_canecorso()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'CANECORSO';
END;
$function$

\i cleanup.sql;
