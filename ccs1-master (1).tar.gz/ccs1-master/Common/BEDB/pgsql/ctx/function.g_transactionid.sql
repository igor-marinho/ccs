SET bedb.filename = 'function.g_transactionid.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION ctx.g_transactionid()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'TRANSACTIONID';
END;
$function$

\i cleanup.sql;
