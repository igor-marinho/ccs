SET bedb.filename = 'procedure.set.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS ctx.set (UUID, TEXT, TEXT);
CREATE OR REPLACE PROCEDURE ctx.set (IN iptnrid UUID DEFAULT NULL,
                                   IN iloginid TEXT DEFAULT NULL,
                                   IN ivin TEXT DEFAULT NULL) 
AS 
$body$
DECLARE

      vmakeid beowner.ptnr.make_id%TYPE;
      vusrid  beowner.usr.usr_id%TYPE;
      vvin    beowner.vin.vin%TYPE;

      -- Added for OnTime Defect 12055 (TE service using invalid partner ID comes back status 23.)
      
   
BEGIN
    SELECT
        p.make_id, u.usr_id, v.vin
        INTO STRICT vmakeid, vusrid, vvin
        FROM (select null as single) r
        LEFT OUTER JOIN beowner.ptnr AS p
            ON p.ptnr_id = iptnrid
        LEFT OUTER JOIN beowner.usr AS u
            ON u.login_id = LOWER(TRIM(iloginid)) AND u.make_id = p.make_id
        LEFT OUTER JOIN beowner.vin AS v
            ON v.vin = UPPER(TRIM(ivin)) AND v.make_id = p.make_id;

    IF iptnrid IS NOT NULL AND vmakeid IS NULL THEN
        raise exception using errcode=utl.get_constant_value('e_invalidpartnerid');
    END IF;

    IF iloginid IS NOT NULL AND vusrid IS NULL THEN
        raise exception using errcode=utl.get_constant_value('e_usernotfound');
    END IF;

    IF ivin IS NOT NULL AND vvin IS NULL THEN        
        raise exception using errcode=utl.get_constant_value('e_vinnotfound');
    END IF;

    PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cmakeid'), vmakeid, false);
    PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cusrid'), vusrid::text, false);
    PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cvin'), vvin, false);
    

      -- Exception block added for OnTime Defect 12055
   EXCEPTION
     when invalid_text_representation then
         RAISE EXCEPTION USING errcode = utl.get_constant_value('e_invalidpartnerid');
   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE ctx.set (iptnrid text DEFAULT NULL, iloginid text DEFAULT NULL, ivin text DEFAULT NULL) FROM PUBLIC;

   /* This version of SET takes in known USR_ID, make_id and VIN parameters
      in order to set context for those parameters. It's ok to not
      specify or pass nulls for each value.

      If NULLs are present, no exception is raised, but the
      context for that parameter is set to NULL.

      It does in fact validate that the data exists in the database.
   */

DROP PROCEDURE IF EXISTS ctx.set(TEXT, TEXT, TEXT);
CREATE OR REPLACE PROCEDURE ctx.set(i_usrid text DEFAULT NULL::text, i_makeid text DEFAULT NULL::text, i_vin text DEFAULT NULL::text)
AS $body$
DECLARE

      vusrid  beowner.usr.usr_id%TYPE;
      vmakeid beowner.make.make_id%TYPE;
      vvin    beowner.vin.vin%TYPE;
BEGIN
    SELECT
        cm.make_id, u.usr_id, v.vin
        INTO STRICT vmakeid, vusrid, vvin
        FROM (select null as single) r
        LEFT OUTER JOIN beowner.make AS cm
            ON cm.make_id = UPPER(TRIM(i_makeid))
        LEFT OUTER JOIN beowner.usr AS u
            ON u.usr_id = i_usrid::UUID
            AND u.make_id = cm.make_id
        LEFT OUTER JOIN beowner.vin AS v
            ON v.vin = UPPER(TRIM(i_vin))
            AND v.make_id = cm.make_id;

    IF i_makeid IS NOT NULL AND vmakeid IS NULL THEN
        raise exception using errcode=utl.get_constant_value('e_invalidmake');
    END IF;

    IF i_usrid IS NOT NULL AND vusrid IS NULL THEN
        raise exception using errcode=utl.get_constant_value('e_usernotfound');
    END IF;

    IF i_vin IS NOT NULL AND vvin IS NULL THEN
        raise exception using errcode=utl.get_constant_value('e_vinnotfound');
    END IF;

    PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cmakeid'), vmakeid, false);
    PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cusrid'), vusrid::text, false);
    PERFORM set_config(utl.get_constant_value('ccanecorso') ||'.' || utl.get_constant_value('cvin'), vvin, false);
    
   END;

$body$
LANGUAGE PLPGSQL
;

-- REVOKE ALL ON PROCEDURE ctx.set (iusrid text DEFAULT NULL, imakeid text DEFAULT NULL, ivin text DEFAULT NULL) FROM PUBLIC;

   /* This version of SET sets a time-stamp used in date-based queries */
/*************************************************************************************************************************************

CREATE OR REPLACE PROCEDURE ctx.set (itimestamp TIMESTAMP WITH TIME ZONE) AS $body$
BEGIN
      -- BEWARE: the time mask/format *must* be identical to the format in the view CTX_DATA
      dbms_session.set_context(ccanecorso,
                               ctimestamp,
                               to_char(itimestamp,
                                       'YYYY-MM-DD HH24:MI:SS.FF2 TZH:TZM'));
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE ctx.set (itimestamp TIMESTAMP WITH TIME ZONE) FROM PUBLIC;
*************************************************************************************************************************************/
\i cleanup.sql;
