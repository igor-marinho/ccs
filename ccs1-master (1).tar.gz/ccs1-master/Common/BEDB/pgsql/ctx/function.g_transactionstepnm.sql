SET bedb.filename = 'function.g_transactionstepnm.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION ctx.g_transactionstepnm()
 RETURNS character varying
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'TRANSACTIONSTP'; -- No Action was provided
END;
$function$

\i cleanup.sql;
