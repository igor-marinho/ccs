SET bedb.filename = 'function.g_transactionnm.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION ctx.g_transactionnm()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'TRANSACTIONNM';
END;
$function$

\i cleanup.sql;
