SET bedb.filename = 'function.g_vendortid.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION ctx.g_vendortid()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'VENDORTID';
END;
$function$

\i cleanup.sql;
