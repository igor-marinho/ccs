SET bedb.filename = 'function.g_usrlogid.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION ctx.g_usrlogid()
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
begin
  return 'USRLOGID';
END;
$function$

\i cleanup.sql;
