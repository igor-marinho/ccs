SET bedb.filename = 'procedure.dbg.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS crudg_subscription.dbg(TEXT);

CREATE OR REPLACE PROCEDURE crudg_subscription.dbg(i_text TEXT)
AS
$BODY$
BEGIN
    IF utl.get_session_variable(i_parent_namespace => 'crudg_subscription', i_child_namespace => 'dbg', i_name => 'g_debug_on') = utl.get_constant_value('c_yes')
    THEN    
        RAISE DEBUG USING MESSAGE = i_text;
    END IF;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
