SET bedb.filename = 'function.cr_subscription1.sql';

\i set_be_env.sql; 

   /*
   cr_subscription1 error codes returned:
      cInternalError                 '1'    Internal Error.
      cCTXVinNotEqPassedVin          '46'   The Context VIN does not match the VIN Passed into the function or procedure
      cDbVinNotFound                 '200'  System was passed a VIN which was not found.
      cSubscriptionAlreadyExists     '49'   The subscription already exists
      cDbSubscriberNotPrimary        '218'  The subscriber is not a primary subscriber.
      c_invalid_vin                  '234'  VIN is null.
      c_bndl_id_is_null              '235'  Bundle Id is required, but Null. Will be returned only when there is more than 1 potential bundle eligible for the VIN
      cInvalidBundleID               '270'  The Supplied Bundle ID is invalid
      c_incompatible_vin_usr         '282'  The user and VIN belong to different makes
      c_incompatible_BundleID        '284'  The Supplied Bundle ID is incompatible with the VIN
      c_subs_exceed_allowed          '285'  The Number of subscriptions exceed the number allowed for the payment type.
     In addition, if make.user_inter_relation != 'STATIC', inherit_subscriptions is called, so please refer to the error codes for the same below       
      c_subs_no_longer_allowed       '286'  The Subscription Start date is after the allowed period for this bundle type (for Trials).
      c_invalid_user_Id              '287'  Invalid (or null) User ID supplied
   
   */
CREATE OR REPLACE FUNCTION crudg_subscription.cr_subscription1(IN i_usr_id TEXT, 
                                                               IN i_vin TEXT, 
                                                               IN i_bndl_id TEXT DEFAULT NULL, 
                                                               IN i_sub_start TIMESTAMP WITH TIME ZONE DEFAULT NULL, 
                                                               IN i_version TEXT DEFAULT NULL)
RETURNS INTEGER
AS
$BODY$
/* Extensively modified this function for OnTime WI #14078, so that it can also be used for other OEMs */
DECLARE
    l_action text;
    l_module_name text := 'cr_subscription1';
    l_bndl_id BEOWNER.BNDL.bndl_id%TYPE;
    l_sub_start BEOWNER.SUBSCRIPTION.sub_start%TYPE;
    l_sub_duration BEOWNER.SUBSCRIPTION.sub_duration%TYPE;
    l_email BEOWNER.USR.login_id%TYPE;
    l_vin BEOWNER.VIN.vin%TYPE
    /* OnTime WI #14078 */;
    l_usr_id BEOWNER.USR.usr_id%TYPE;
    l_transaction_id BEOWNER.SUBSCRIPTION.transaction_id%TYPE;
    l_tmstmp BEOWNER.CTX_DATA.tmstmp%TYPE;
    l_allow_subs_after_initial BEOWNER.MAKE_PAYMENT_TYPES.allow_subs_after_initial%TYPE;
    l_no_of_subscriptions BEOWNER.MAKE_PAYMENT_TYPES.no_of_subscriptions%TYPE;
    l_count_subs INTEGER;
    l_dofu BEOWNER.VIN.dofu%TYPE;
    l_validation_return INTEGER;
    l_inherit_return INTEGER;
    o_status_code INTEGER;
    secondaries_rec RECORD;
/* OnTime WI #15750 */
/* OnTime WI #14078, #19339. Context is expected to be set before-hand */
/* beowner.ctx.SET (iusrid => i_usr_id, imakeid => NULL, ivin => i_vin); */
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    
    l_action := utl.set_module_action( l_module_name, 'Starting cr_subscription1');

    /* Common validatons, added for OnTime WI #14078 */
    select *
        FROM crudg_subscription.common_subs_validations(i_usr_id := i_usr_id, i_vin := i_vin, i_bndl_id := i_bndl_id)
        INTO l_vin, l_usr_id, l_transaction_id, l_tmstmp, o_status_code;
    l_validation_return := o_status_code;

    IF l_validation_return != utl.get_constant_value('csuccess')::INTEGER
    THEN
        RETURN l_validation_return;
    END if;
    
    l_action := utl.set_action( 'Getting final subscription information');

    BEGIN
        SELECT
            b.bndl_id, b.bundle_length, u.login_id, mpt.allow_subs_after_initial, mpt.no_of_subscriptions
            INTO STRICT l_bndl_id, l_sub_duration, l_email, l_allow_subs_after_initial, l_no_of_subscriptions
            FROM beowner.vin AS v, beowner.bndl AS b, beowner.usr AS u, beowner.make_payment_types AS mpt
            WHERE v.vin = l_vin
              AND b.bndl_id = COALESCE(i_bndl_id::uuid, b.bndl_id)
              AND b.device_id = v.device_id
              AND u.usr_id = l_usr_id
              AND mpt.make_id = v.make_id
              AND mpt.payment_type = b.payment_type;
        EXCEPTION
            WHEN too_many_rows THEN
                RETURN utl.get_constant_value('c_bndl_id_is_null');
    END;
    
    call utl.dbg(CONCAT_WS('', 'l_no_of_subscriptions = ', l_no_of_subscriptions, ', l_allow_subs_after_initial = ', l_allow_subs_after_initial));

    IF l_no_of_subscriptions IS NOT NULL OR l_allow_subs_after_initial = 'N'
    /* TBD - check if this needs to be eforced when no i_bndl_id is sent */
    THEN
        SELECT
            COUNT(s.subscription_id), MIN(v.dofu)
            INTO STRICT l_count_subs, l_dofu
            FROM beowner.vin AS v
            LEFT OUTER JOIN beowner.subscription AS s
                ON s.vin = v.vin AND s.bndl_id = i_bndl_id::uuid
            WHERE v.vin = l_vin;

        IF l_count_subs >= COALESCE(l_no_of_subscriptions, 9999)
        /* The number of existing subscriptions same as allowed for the new subscription bundle's payment type. */
        THEN
            RETURN utl.get_constant_value('c_subs_exceed_allowed');
        END IF;
        
        call crudg_subscription.dbg(CONCAT_WS('', ' dofu = ', l_dofu, ', l_sub_duration = ', l_sub_duration, ' systime = ', l_tmstmp));
        
        IF l_allow_subs_after_initial = 'N'
        AND l_dofu IS NOT null
        and l_dofu + l_sub_duration::interval < l_tmstmp
        then
          -- Subscription is being created after initial trial period
          RETURN utl.get_constant_value('c_subs_no_longer_allowed');
        END if;
    END IF;
    l_sub_start := COALESCE(i_sub_start, l_tmstmp);
    
    l_action := utl.set_action( 'Inserting into SUBSCRIPTION');    

    INSERT INTO beowner.subscription (subscription_id, primary_id, vin, bndl_id, sub_start, sub_duration, transaction_id)
    VALUES (beowner.rand_guid(), l_usr_id, l_vin, l_bndl_id, l_sub_start, l_sub_duration, l_transaction_id);
        
    IF NOT utl.is_user_relation_static()
    /* call inherit_subscriptions for all unique existing secondaries for the primary */
    THEN
        FOR secondaries_rec IN
        SELECT DISTINCT
            secondary_id
            FROM beowner.subscription_users AS su
            WHERE su.primary_id = l_usr_id AND su.vin = l_vin
        LOOP
            l_inherit_return := crudg_subscription.inherit_subscriptions(i_primary_id := l_usr_id, i_secondary_id := secondaries_rec.secondary_id, i_vin := l_vin, i_version := i_version);

            IF l_inherit_return != utl.get_constant_value('csuccess')
            THEN
                RETURN l_inherit_return;
            END IF;
        END LOOP;
    END IF;
    call utl.checkvinconflict();
    /* uses context */
    /* Jira DDCRD-405 - removed call to update event log, as trigger on subscription table will handle the insert */
    RETURN utl.get_constant_value('csuccess');
    exception
        WHEN unique_violation THEN
            RETURN utl.get_constant_value('csubscriptionalreadyexists');
        WHEN SQLSTATE 'EMAKE'
         then
           RETURN utl.get_constant_value('cinvalidctxmakeid');
        WHEN others THEN

            GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,              
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;
            call trc.log(iadditionaldata => 'i_usr_id=' || i_usr_id || ', i_vin=' || i_vin,
                            iexception_diagnostics => l_exception_diagnostics);
            RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;
\i cleanup.sql;
