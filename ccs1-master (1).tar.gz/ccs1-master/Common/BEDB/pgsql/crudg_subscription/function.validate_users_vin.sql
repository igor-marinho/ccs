SET bedb.filename = 'function.validate_users_vin.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS crudg_subscription.validate_users_vin("uuid","uuid","text","bool") ;

-- Added for OnTime WI #15750
   /* Validates both the user IDs as well as VIN (if provided)
    Both should be not null and existing in the DB and have the same make
    Also validates that the primary has at least some subscriptions
    If VIN is provided, it is also validated
         that it is a valid VIN
         that it matches the context (if populated)
         the subscription existence is checked against the VIN
   Returns the VIN upper-cased and trimmed for use in the calling sproc
    */
CREATE OR REPLACE FUNCTION crudg_subscription.validate_users_vin (i_from_user_id           text
                                                                 ,i_to_user_id             text
                                                                 ,i_vin                    text DEFAULT NULL
                                                                 ,i_check_if_primary       BOOLEAN DEFAULT FALSE
                                                                 ,o_vin                OUT text
                                                                 ,o_status_code        OUT integer)
AS
$BODY$
DECLARE
    l_module_name text := 'crudg_subscription.validate_users_vin';
    l_count_subs INTEGER;
    l_from_user_make_id BEOWNER.USR.make_id%TYPE;
    l_to_user_make_id BEOWNER.USR.make_id%TYPE;
    l_from_user_parent_id BEOWNER.USR.parent_id%TYPE;
    l_to_user_parent_id BEOWNER.USR.parent_id%TYPE;
    l_vin BEOWNER.VIN.vin%TYPE := UPPER(TRIM(i_vin));
    ct_vin BEOWNER.VIN.vin%TYPE;
    l_vin_found INTEGER;
    o_status_code_2 BOOLEAN;
    o_status_code_3 BOOLEAN;
BEGIN

 CALL crudg_subscription.dbg(l_module_name || ' called with i_from_user_id = ' || i_from_user_id ||
              ', i_to_user_id = ' || i_to_user_id || ', i_vin = ' || i_vin);

    IF i_from_user_id = i_to_user_id
    THEN
        o_status_code := utl.get_constant_value('c_both_users_are_same');
        RETURN;
    ELSE
        SELECT *
          FROM utl.is_user_valid(i_usr_id := i_from_user_id)
          INTO l_from_user_make_id, l_from_user_parent_id, o_status_code_2;
         
        SELECT *
          FROM utl.is_user_valid(i_usr_id := i_to_user_id)
          INTO strict l_to_user_make_id, l_to_user_parent_id, o_status_code_3;

        IF NOT o_status_code_2
        THEN
            o_status_code := utl.get_constant_value('c_invalid_from_user');
            RETURN;
        ELSIF NOT o_status_code_3
        THEN
            o_status_code := utl.get_constant_value('c_invalid_to_user');
            RETURN;
        END IF;

        IF l_from_user_make_id != l_to_user_make_id
        THEN
            o_status_code := utl.get_constant_value('c_incompatible_make_ids');
            RETURN;
        END IF;

        IF i_check_if_primary
        THEN
            IF l_from_user_parent_id IS NOT NULL
            THEN
                o_status_code := utl.get_constant_value('c_from_user_not_primary');
                RETURN;
            ELSIF l_to_user_parent_id IS NOT NULL 
            THEN
                o_status_code := utl.get_constant_value('c_to_user_not_primary');
                RETURN;
            END IF;
        END IF;
    END IF;

    IF i_vin IS NOT NULL
    /* validate VIN too */
    THEN
        BEGIN
            SELECT 1
              INTO STRICT l_vin_found
              FROM beowner.vin v
             WHERE v.vin = l_vin;
            
            EXCEPTION
                WHEN no_data_found
                THEN
                    o_status_code := utl.get_constant_value('cdbvinnotfound');
                    RETURN;
        END;
       
        SELECT vin
          INTO STRICT ct_vin
          FROM beowner.ctx_data;

        IF ct_vin IS NOT NULL AND l_vin != ct_vin
        THEN
            o_status_code := utl.get_constant_value('cctxvinnoteqpassedvin');
            RETURN;
        END IF;
    END IF;
   
    SELECT COUNT(1)
      INTO STRICT l_count_subs
      FROM beowner.subscription AS s
     WHERE s.primary_id = i_from_user_id::uuid
       AND vin = COALESCE(l_vin, s.vin);

    IF l_count_subs = 0 THEN
        o_status_code := utl.get_constant_value('c_primary_has_no_subscriptions');
        RETURN;
    END IF;
    o_vin := l_vin;
    o_status_code := utl.get_constant_value('csuccess');
    RETURN;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
