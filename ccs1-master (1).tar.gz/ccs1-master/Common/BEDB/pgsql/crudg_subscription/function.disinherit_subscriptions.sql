SET bedb.filename = 'function.disinherit_subscriptions.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS crudg_subscription.disinherit_subscriptions("uuid","uuid","text","text");
   /* Added for OnTime WI #15980 (DI 1473)
      Dis-inherits the subscriptions for a user (i_secondary_id) from the primary's (i_primary_id) subscriptions for the VIN provided.
   
      utl.get_constant_value('csuccess') (0) is returned if the operation was successful
      
      Error codes returned:
        cInternalError                 '1'       Unknown Internal error
        cInvalidCTXMakeID              '28'      The MakeID is null or and is trying to be used to set the context MAKE_ID     
        cCTXVinNotEqPassedVin          '46'      The Context VIN does not match the VIN Passed into the function or procedure
        cDbVinNotFound                 '200'     System was passed a VIN which was not found.
        c_invalid_vin                  '234'     VIN provided is null        
        c_primary_has_no_subscriptions '281'     Primary User has no subscriptions for the VIN      
        c_invalid_from_user            '340'     The from user ID provided is null or invalid  
        c_invalid_to_user              '341'     The to user ID provided is null or invalid  
        c_both_users_are_same          '342'     The user IDs provided are same  
        c_invalid_user_relation_config '343'     The use of this sproc is not permitted for the make's user relation config   
        c_incompatible_make_ids        '344'     The make IDs of both users are different  
        c_no_such_inheritance          '406'     No matching subscription user rows were found for the provided parameters
   */
CREATE OR REPLACE FUNCTION crudg_subscription.disinherit_subscriptions (i_primary_id     text
                                                                       ,i_secondary_id   text
                                                                       ,i_vin            text
                                                                       ,i_version        text DEFAULT NULL)
RETURNS integer
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'disinherit_subscriptions';
    l_primary_id BEOWNER.USR.usr_id%TYPE := i_primary_id;
    l_secondary_id BEOWNER.USR.usr_id%TYPE := i_secondary_id;
    l_vin BEOWNER.VIN.vin%TYPE := i_vin;
    l_validation_return TEXT;
    l_transaction_id BEOWNER.SUBSCRIPTION.transaction_id%TYPE;
    l_make_id BEOWNER.MAKE.make_id%TYPE;
    l_delete_count INTEGER := 0;
    o_status_code INTEGER;
    subs_users_rec RECORD;
    sql$rowcount BIGINT;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN    
    l_action := utl.set_module_action(l_module_name,'Validating inputs');

    IF l_vin IS NULL
    THEN
        RETURN utl.get_constant_value('c_invalid_vin');
    END IF;
   
    SELECT *
      FROM crudg_subscription.validate_users_vin(i_from_user_id := l_primary_id::text, i_to_user_id := l_secondary_id::text, i_vin := l_vin, i_check_if_primary := FALSE)
      INTO l_vin, o_status_code;
    l_validation_return := o_status_code;

    IF l_validation_return != utl.get_constant_value('csuccess')
    THEN
        RETURN l_validation_return;
    END IF;

    IF utl.is_user_relation_static()
    THEN
        RETURN utl.get_constant_value('c_invalid_user_relation_config');
    END IF;
   
    SELECT transactionid, make_id
      INTO STRICT l_transaction_id, l_make_id
     FROM beowner.ctx_data;
    FOR subs_users_rec IN
      SELECT s.subscription_id, su.su_guid
        FROM beowner.subscription AS s, beowner.subscription_users AS su
       WHERE s.primary_id = l_primary_id
         AND s.vin = l_vin
         AND su.subscription_id = s.subscription_id
         AND su.primary_id = l_primary_id
         /* just to get the index */
         AND su.secondary_id = l_secondary_id
    LOOP
        /* updating the transaction ID first, so that delete transaction ID is set correctly in history */

        -- Added conditional update as part of DCS1E-1213
        IF l_transaction_id IS NOT NULL
        THEN    
            UPDATE beowner.subscription_users AS su
                SET transaction_id = l_transaction_id
            WHERE su_guid = subs_users_rec.su_guid;
        END IF;
        BEGIN
            DELETE FROM beowner.subscription_users AS su
                WHERE su_guid = subs_users_rec.su_guid;
               
            GET DIAGNOSTICS sql$rowcount = ROW_COUNT;
           
            l_delete_count := l_delete_count + sql$rowcount;
           
            EXCEPTION
                WHEN others THEN
                    
                 GET STACKED diagnostics
                  l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
                  l_exception_diagnostics.column_name := COLUMN_NAME,
                  l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
                  l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
                  l_exception_diagnostics.message_text := MESSAGE_TEXT,
                  l_exception_diagnostics.table_name := TABLE_NAME,
                  l_exception_diagnostics.schema_name := SCHEMA_NAME,              
                  l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
                  l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
                  l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
                  l_exception_diagnostics.module_name := l_module_name;
                  l_exception_diagnostics.action := l_action;
                CALL trc.log(iadditionaldata => 'Error when deleting from subscription_users',
                        iexception_diagnostics => l_exception_diagnostics);
                       
                RETURN utl.get_constant_value('c_subs_users_delete_error');
        END;
    END LOOP;
   CALL crudg_subscription.dbg(CONCAT_WS('', l_delete_count, ': total new row/s deleted'));

    IF l_delete_count = 0
    THEN
        RETURN utl.get_constant_value('c_no_such_inheritance');
    END IF;
   
    RETURN utl.get_constant_value('csuccess');
   
    EXCEPTION
        WHEN SQLSTATE 'EMAKE' 
        THEN
            RETURN utl.get_constant_value('cinvalidctxmakeid');
            
        WHEN OTHERS
        THEN
           l_action := utl.set_module_action( l_module_name, 'Something went wrong in ' ||l_module_name);

        GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);                     
                       
            
            RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
