SET bedb.filename = 'procedure.set_make_user_rel_config.sql';

\i set_be_env.sql;

-- $Id$

-- OnTime WI #15750
CREATE OR REPLACE PROCEDURE crudg_subscription.set_make_user_rel_config () AS $body$
DECLARE

      l_make_id beowner.make.make_id%TYPE;

BEGIN
      SELECT make_id
        INTO STRICT l_make_id
        FROM beowner.ctx_data;

      IF l_make_id IS NOT NULL
      THEN
         PERFORM set_config('crudg_subscription.g_user_relation_static', (utl.get_user_relation_config(i_make_id => l_make_id) =
                                   cnst.c_user_relation_static), false);
      ELSE
         RAISE EXCEPTION USING errcode = utl.get_constant_value('e_invalidmake');
      END IF;
   END;

   -- Added vendor_tid for #16905
   -- Removed columns for DCS1E-921
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE crudg_subscription.set_make_user_rel_config () FROM PUBLIC;
 
\i cleanup.sql;
