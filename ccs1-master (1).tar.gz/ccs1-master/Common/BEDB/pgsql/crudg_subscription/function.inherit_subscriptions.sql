SET bedb.filename = 'function.inherit_subscriptions.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS crudg_subscription.inherit_subscriptions("uuid","uuid","text","text");
   /* Added for OnTime WI #15750
      Inherits the subscriptions for one user (i_primary_id) to another as a secondary user (i_secondary_id)
      If a VIN is provided (i_vin), only the subscriptions for that VIN are inherited.  
      Otherwise, ALL subscriptions that the primary has will be inherited by the new user.
   
      utl.get_constant_value('csuccess') (0) is returned if the operation was successful
      
      Error codes returned:
        cInternalError                 '1'       Unknown Internal error
        cInvalidCTXMakeID              '28'      The MakeID is null or and is trying to be used to set the context MAKE_ID     
        cCTXVinNotEqPassedVin          '46'      The Context VIN does not match the VIN Passed into the function or procedure
        cDbVinNotFound                 '200'     System was passed a VIN which was not found.
        cDb2ndrySubsLimitReached       '220'     The allowable number of secondary subscribers has been reached.     
        c_primary_has_no_subscriptions '281'     Primary User has no subscriptions (for the VIN, if provided)         
        c_invalid_from_user            '340'     The from user ID provided is null or invalid (for inheritance or transfer)
        c_invalid_to_user              '341'     The to user ID provided is null or invalid (for inheritance or transfer)
        c_both_users_are_same          '342'     The user IDs provided are same (for inheritance or transfer)
        c_invalid_user_relation_config '343'     The use of this sproc is not permitted for the make's user relation config   
        c_incompatible_make_ids        '344'     The make IDs of both users are different (for inheritance or transfer)
        c_from_user_not_primary        '345'     The from user ID provided is not a primary user (for transfer) 
        c_to_user_not_primary          '346'     The to user ID provided is not a primary user (for transfer)    
   */
CREATE OR REPLACE FUNCTION crudg_subscription.inherit_subscriptions (i_primary_id     text
                                                                    ,i_secondary_id   text
                                                                    ,i_vin            text
                                                                    ,i_version        text DEFAULT NULL :: text)
 RETURNS integer
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'inherit_subscriptions';
    l_primary_id BEOWNER.USR.usr_id%TYPE := i_primary_id::uuid;
    l_secondary_id BEOWNER.USR.usr_id%TYPE := i_secondary_id::uuid;
    l_vin BEOWNER.VIN.vin%TYPE := i_vin;
    l_validation_return text;
    l_transaction_id BEOWNER.SUBSCRIPTION.transaction_id%TYPE;
    l_make_id BEOWNER.MAKE.make_id%TYPE;
    l_secondaries_rule BEOWNER.MAKE.secondaries_rule%TYPE;
    l_current_secondaries INTEGER;
    l_insert_count INTEGER := 0;
    o_status_code INTEGER;
    primary_subs RECORD;
    sql$rowcount BIGINT;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    
    l_action := utl.set_module_action( l_module_name,' Starting inherit_subscriptions');

    IF utl.is_user_relation_static()
    THEN
        RETURN utl.get_constant_value('c_invalid_user_relation_config');
    END IF;
   
    SELECT transactionid, make_id
      INTO STRICT l_transaction_id, l_make_id
      FROM beowner.ctx_data;
       
    SELECT *     
      FROM crudg_subscription.validate_users_vin(i_from_user_id := i_primary_id, i_to_user_id := i_secondary_id, i_vin := i_vin, i_check_if_primary := TRUE)
      INTO l_vin, o_status_code;
       
    l_validation_return := o_status_code;

    IF l_validation_return != utl.get_constant_value('csuccess')
    THEN
        RETURN l_validation_return;
    END IF;
   
    SELECT m.secondaries_rule
      INTO STRICT l_secondaries_rule
      FROM beowner.make AS m
     WHERE make_id = l_make_id;
    l_action := utl.set_module_action( l_module_name, ' Looping through all primary subscriptions');

    FOR primary_subs IN
    (SELECT
        s.subscription_id, s.vin,
        CASE l_secondaries_rule
            WHEN 'SUM' THEN SUM(b.max_users - 1)
            WHEN 'MINIMUM' THEN MIN(b.max_users - 1)
            ELSE MAX(b.max_users - 1)
        END AS allowed_secondaries
        FROM beowner.subscription AS s, beowner.bndl AS b
        WHERE s.primary_id = l_primary_id AND s.vin = COALESCE(i_vin, s.vin) AND b.bndl_id = s.bndl_id
        GROUP BY subscription_id, vin)
    LOOP
    
       SELECT COUNT(su.secondary_id) AS current_sec
         INTO STRICT l_current_secondaries
         FROM beowner.subscription_users AS su
        WHERE su.subscription_id = primary_subs.subscription_id
          AND su.secondary_id != l_secondary_id;
          
        /* count different secondaries only, so as to not error out if secondary row already exists. It will not be inserted again because of the merge below in any case */
        /* if number of current secondaries for the subscription (different than the one being added) >= the number of allowed secondaries for the bundle, return cdb2ndrysubslimitreached */

        IF primary_subs.allowed_secondaries <= l_current_secondaries
        THEN
            CALL trc.log(CONCAT_WS('', 'Number of secondaries exceeded for subscription id ', primary_subs.subscription_id::text, ' for primary ', i_primary_id, ' VIN ', primary_subs.vin));
            RETURN utl.get_constant_value('cdb2ndrysubslimitreached');
        END if;
       
         l_action := utl.set_module_action( l_module_name, ' Merging into subscription_users');
       
       insert into beowner.subscription_users
                       (su_guid,
                        subscription_id,
                        primary_id,
                        vin,
                        secondary_id,
                        transaction_id)
                    (SELECT rand_guid() su_guid,
                       s.subscription_id,
                       s.primary_id,
                       s.vin,
                       l_secondary_id secondary_id,
                       l_transaction_id transaction_id
                  FROM beowner.subscription s
                 WHERE s.subscription_id = primary_subs.subscription_id)
                  on conflict (subscription_id, primary_id, secondary_id) do nothing;
        
        GET DIAGNOSTICS sql$rowcount = ROW_COUNT;
        l_insert_count := l_insert_count + sql$rowcount;

    CALL crudg_subscription.dbg(CONCAT_WS('', sql$rowcount, ' new row/s inserted for subscription_id = ', primary_subs.subscription_id::text, ', VIN = ', primary_subs.vin));

    END LOOP;
   
    CALL crudg_subscription.dbg(CONCAT_WS('', l_insert_count, ' total new row/s inserted'));
   
    RETURN utl.get_constant_value('csuccess');
   
    EXCEPTION
     when SQLSTATE 'EMAKE'
     THEN
         RETURN utl.get_constant_value('cinvalidctxmakeid');

     WHEN others THEN
            GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,              
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;
            call trc.log(iadditionaldata => NULL,
                            iexception_diagnostics => l_exception_diagnostics);
            RETURN utl.get_constant_value('cinternalerror');
END;
$body$
LANGUAGE plpgsql
SECURITY DEFINER;

\i cleanup.sql;
