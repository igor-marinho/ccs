SET bedb.filename = 'function.g_subscription1.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS crudg_subscription.g_subscription1(TEXT, TEXT, TEXT) ;
   /*
   g_subscription1 - get user/VIN based subscriptions
   Added subscription_id for WI #14511
   
   Error codes returned:
      cInternalError                 '1'    Internal Error.
      cInvalidCTXMakeID              '28'      The MakeID is null or and is trying to be used to set the context MAKE_ID         
      cCTXVinNotEqPassedVin          '46'   The Context VIN does not match the VIN Passed into the function or procedure
      cDbVinNotFound                 '200'  System was passed a VIN which was not found.
      cDbSubscriberNotPrimary        '218'  The subscriber is not a primary subscriber.
      c_invalid_vin                  '234'  VIN is null.
      c_incompatible_vin_usr         '282'  The user and VIN belong to different makes
      c_invalid_user_Id              '287'  Invalid (or null) User ID supplied
      c_no_such_Subscription_Exists  '288'  No matching subscriptions were found.
   
   Return cursor:
      bndl_id, sub_start, sub_end, subscription_id, primary_flag (Y/N)
      
   Modified for OnTime WI #15750 to include the primary flag 
   and to also return subscriptions if the provided user ID is a secondary user (if make.user_inter_relation != 'STATIC')
      
   */
CREATE OR REPLACE FUNCTION crudg_subscription.g_subscription1 (i_usr_id             text
                                                              ,i_vin                text
                                                              ,i_version            text DEFAULT NULL
                                                              ,o_status_code    OUT INTEGER
                                                              ,rslt             OUT refcursor)
AS
$BODY$
/* Code added for OnTime WI #14078 */
DECLARE
    l_action text;
    l_module_name text := 'g_subscription1';
    l_usr_id BEOWNER.USR.usr_id%TYPE;
    l_vin BEOWNER.VIN.vin%TYPE;
    l_parent_id BEOWNER.USR.parent_id%TYPE;
    l_count_subs INTEGER;
    l_transaction_id BEOWNER.SUBSCRIPTION.transaction_id%TYPE;
    l_tmstmp BEOWNER.CTX_DATA.tmstmp%TYPE;
    l_validation_return INTEGER;
    l_is_user_relation_static boolean;
    o_status_code_2 INTEGER;
    l_exception_diagnostics trc.exception_diagnostics;
/* OnTime WI #15750 */
BEGIN
    
    l_action :=  utl.set_module_action( l_module_name, 'Starting g_subscription1');
    /* Common validatons */
    rslt := utl.get_dummy_cursor();    
    SELECT *
        FROM crudg_subscription.common_subs_validations(i_usr_id := i_usr_id, i_vin := i_vin, i_bndl_id := NULL)
        INTO l_vin, l_usr_id, l_transaction_id, l_tmstmp, o_status_code_2;
       
    l_validation_return := o_status_code_2;

    IF l_validation_return != utl.get_constant_value('csuccess')::INTEGER
    THEN
        o_status_code := l_validation_return;
        RETURN;
    END IF;
   
    l_action := utl.set_module_action( l_module_name, ' Getting from SUBSCRIPTION');
    /* OnTime WI #15750 */
    
    l_is_user_relation_static := utl.is_user_relation_static();
   
    SELECT COUNT(1)
        INTO STRICT l_count_subs
        FROM (SELECT 1
            FROM beowner.subscription AS s
            WHERE s.primary_id = l_usr_id AND s.vin = l_vin
            /* OnTime WI #15750 */
            UNION ALL
            SELECT 1
            FROM beowner.subscription_users AS su
            WHERE NOT l_is_user_relation_static
              AND su.secondary_id = l_usr_id AND su.vin = l_vin) AS var_sbq;

    CLOSE rslt;
    CASE l_count_subs
        WHEN 0 THEN
            rslt := utl.get_dummy_cursor();
            o_status_code := utl.get_constant_value('c_no_such_subscription_exists');
            RETURN;
        /* Added subscription_id for WI #14511 */
        ELSE
            /*
            [5340 - Severity CRITICAL - PostgreSQL doesn't support the STANDARD.TO_DSINTERVAL(VARCHAR2) function. Use suitable function or create user defined function., 5340 - Severity CRITICAL - PostgreSQL doesn't support the STANDARD.TO_DSINTERVAL(VARCHAR2) function. Use suitable function or create user defined function., 5578 - Severity CRITICAL - Unable to automatically transform the SELECT statement. Try rewriting the statement.]
            */
        OPEN rslt FOR
           SELECT bndl_id,
                  s.sub_start,
                  s.sub_start + s.sub_duration::interval sub_end,
                  subscription_id,
                  'Y' primary_flag
             FROM beowner.subscription s
            WHERE s.primary_id = l_usr_id
              AND s.vin = l_vin
           -- OnTime WI #15750
           UNION ALL
           --  return the subscription information even if the user Id passed in is secondary on the VIN's subscription/s:
           SELECT s.bndl_id,
                  s.sub_start,
                  s.sub_start + s.sub_duration::interval sub_end,
                  s.subscription_id,
                  'N' primary_flag
             FROM beowner.subscription       s,
                  beowner.subscription_users su
            WHERE NOT l_is_user_relation_static
              AND su.secondary_id = l_usr_id
              AND su.vin = l_vin
              AND s.subscription_id = su.subscription_id;
            
            o_status_code := utl.get_constant_value('csuccess');
            RETURN;
    END CASE;
    /* OnTime WI #15750 */
    EXCEPTION
         when SQLSTATE 'EMAKE'
         THEN
           rslt := utl.get_dummy_cursor();
           o_status_code := utl.get_constant_value('cinvalidctxmakeid');
          WHEN OTHERS
        THEN
           l_action :=  utl.set_module_action( l_module_name,'G_SUBSCRIPTION1: i_usr_id=' || i_usr_id);

        GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);                
          rslt := utl.get_dummy_cursor();
          o_status_code := utl.get_constant_value('cinternalerror');
          RETURN;
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
