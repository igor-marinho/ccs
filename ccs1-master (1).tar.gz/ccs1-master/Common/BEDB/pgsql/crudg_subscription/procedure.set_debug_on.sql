SET bedb.filename = 'procedure.set_debug_on.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION crudg_subscription.set_debug_on()
RETURNS void
AS
$BODY$
BEGIN    
    PERFORM utl.set_session_variable (i_parent_namespace => 'crudg_subscription', i_child_namespace => 'dbg', i_name => 'g_debug_on', i_value => cnst.g_yes());
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
