SET bedb.filename = 'function.u_subscription1.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION crudg_subscription.u_subscription1(IN i_subscription_id TEXT DEFAULT NULL, IN i_bndl_id TEXT DEFAULT NULL, IN i_sub_start TEXT DEFAULT NULL, IN i_sub_duration TEXT DEFAULT NULL)
RETURNS NUMERIC
AS
$BODY$
DECLARE
    l_make_id BEOWNER.MAKE.make_id%TYPE;
    l_sub_duration BEOWNER.SUBSCRIPTION.sub_duration%TYPE := i_sub_duration;
    l_primary_id BEOWNER.SUBSCRIPTION.primary_id%TYPE;
    l_vin BEOWNER.SUBSCRIPTION.vin%TYPE;    
    sql$rowcount BIGINT;
/* beowner.ctx.SET (iusrid => i_usr_id, imakeid => NULL, ivin => i_vin); */
/* Added transaction id update and replaced primary_id, vin with subscription_id for WI #15266 (DI #1269) */
BEGIN
    
    SELECT make_id
      INTO STRICT l_make_id
      FROM beowner.ctx_data;

    IF l_make_id IS NULL THEN
        RETURN cnst.ginvalidmake();
    END IF;
   
    UPDATE beowner.subscription
       SET bndl_id = COALESCE(i_bndl_id::uuid, bndl_id),
           sub_start = COALESCE(i_sub_start::timestamptz, sub_start),
           sub_duration = COALESCE(l_sub_duration, sub_duration),
           transaction_id = (SELECT cd.transactionid
                               FROM beowner.ctx_data AS cd)
     WHERE subscription_id = i_subscription_id::uuid
     /* primary_id = i_usr_id AND vin = i_vin; */
     RETURNING primary_id, vin INTO l_primary_id, l_vin;
       
    GET DIAGNOSTICS sql$rowcount = ROW_COUNT;

    IF sql$rowcount = 0 THEN
        RETURN cnst.ginvalidsubscriptionid();
    ELSE
        BEGIN
            PERFORM ctx.set(iusrid => l_primary_id, imakeid => l_make_id, ivin => l_vin);

           EXCEPTION
                WHEN SQLSTATE 'EUSRN'
                THEN
                    RETURN cnbst.g_invalid_ptnr_subscription();
        END;

        PERFORM utl.checkvinconflict()
        /* uses context */;
        RETURN utl.get_constant_value('csuccess');
    END IF;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
