SET bedb.filename = 'function.delete_subs_children.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS crudg_subscription.delete_subs_children(UUID, TEXT);
   /* Deletes all subscription children i.e subs_notif and notif_location and subscription_users for provided subscription_id 
   
   Added for DI 1457
   
         Error Codes returned:
   
         cInternalError                   '1'     Internal Error.
         c_subscription_id_is_null        '297'   Subscription ID was not passed in            
         c_notif_location_delete_error    '403'   There was an error when trying to delete notification locations
         c_subs_notif_delete_error        '404'   There was an error when trying to delete subscription notifications
         c_subs_users_delete_error        '405'   There was an error when trying to delete subscription users
   */

CREATE OR REPLACE FUNCTION crudg_subscription.delete_subs_children(i_subscription_id UUID, i_transaction_id TEXT DEFAULT NULL)
RETURNS INTEGER
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'DELETE_SUBS_CHILDREN';
    l_del_subs_notif_return INTEGER;
    l_transaction_id BEOWNER.subscription.transaction_id%TYPE := i_transaction_id;
    sql$rowcount BIGINT;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN

    IF i_subscription_id IS NULL
    THEN
        RETURN utl.get_constant_value('c_subscription_id_is_null');
       
    END IF;
   
    l_del_subs_notif_return := crudg_subscription.delete_subs_notif(i_subscription_id := i_subscription_id, i_notification_id := NULL);

    IF l_del_subs_notif_return != utl.get_constant_value('csuccess')::INTEGER
    THEN
        RETURN l_del_subs_notif_return;
    END IF;

    IF l_transaction_id IS NULL THEN
        SELECT cd.transactionid
            INTO STRICT l_transaction_id
            FROM beowner.ctx_data AS cd;
    END IF;
   
    /* updating the transaction ID first, so that delete transaction ID is set correctly in history */   
    -- Added conditional update as part of DCS1E-1213
    IF l_transaction_id IS NOT NULL
    THEN
        UPDATE beowner.subscription_users AS su
        SET transaction_id = l_transaction_id
            WHERE subscription_id = i_subscription_id;
    END IF;
    
    GET DIAGNOSTICS sql$rowcount = ROW_COUNT;
    
    -- Added conditional update as part of DCS1E-1213 
    IF sql$rowcount != 0 OR
         l_transaction_id IS NULL
    /* no point in trying to delete if no rows were found */
    THEN
        BEGIN
            DELETE FROM beowner.subscription_users AS su
                WHERE subscription_id = i_subscription_id;
            EXCEPTION
                WHEN OTHERS
                THEN                    
                
                 GET STACKED diagnostics
                      l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
                      l_exception_diagnostics.column_name := COLUMN_NAME,
                      l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
                      l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
                      l_exception_diagnostics.message_text := MESSAGE_TEXT,
                      l_exception_diagnostics.table_name := TABLE_NAME,
                      l_exception_diagnostics.schema_name := SCHEMA_NAME,              
                      l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
                      l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
                      l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
                      l_exception_diagnostics.module_name := l_module_name;
                      l_exception_diagnostics.action := l_action;
                 call trc.log(iadditionaldata => 'Error when deleting from subscription_users',
                                  iexception_diagnostics => l_exception_diagnostics);
                 RETURN utl.get_constant_value('c_subs_users_delete_error');
        END;
    END IF;
    RETURN utl.get_constant_value('csuccess');
    EXCEPTION
        WHEN OTHERS
        THEN
             GET STACKED diagnostics
                  l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
                  l_exception_diagnostics.column_name := COLUMN_NAME,
                  l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
                  l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
                  l_exception_diagnostics.message_text := MESSAGE_TEXT,
                  l_exception_diagnostics.table_name := TABLE_NAME,
                  l_exception_diagnostics.schema_name := SCHEMA_NAME,              
                  l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
                  l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
                  l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
                  l_exception_diagnostics.module_name := l_module_name;
                  l_exception_diagnostics.action := l_action;
            call trc.log(iadditionaldata => CONCAT_WS('', 'Something went wrong in ', l_module_name),
                         iexception_diagnostics => l_exception_diagnostics);                                 
            RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
