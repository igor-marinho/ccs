SET bedb.filename = 'function.g_subscription.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS crudg_subscription.g_subscription (TEXT, TEXT, TEXT);
   -- Added vendor_tid for #16905
CREATE OR REPLACE FUNCTION crudg_subscription.g_subscription (isubscription_id       text DEFAULT NULL
                                                             ,ivin                   text DEFAULT NULL
                                                             ,iversion               text DEFAULT NULL
                                                             ,o_status_code      OUT INTEGER
                                                             ,rslt               OUT refcursor)
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'g_subscription';
    vvin BEOWNER.VIN.vin%TYPE;
    vusr_id BEOWNER.USR.usr_id%TYPE;
    vuserlogin BEOWNER.USR.login_id%TYPE;
    vuconid BEOWNER.USR.login_id%TYPE;
    vbndlid BEOWNER.BNDL.bndl_id%TYPE;
    vexpiration BEOWNER.SUBSCRIPTION.sub_start%TYPE;
    vdofu BEOWNER.subscription.sub_start%TYPE;
    vversion CHARACTER VARYING(100);
    vcnt INTEGER;
    ctvin BEOWNER.VIN.vin%TYPE;
    ctmakeid BEOWNER.VIN.make_id%TYPE;
    ctusrlogid BEOWNER.USR.login_id%TYPE;
    ctusrid BEOWNER.USR.usr_id%TYPE;
    l_subscription_id beowner.vin_subscription.vs_id%TYPE := isubscription_id::UUID;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    
    l_action := utl.set_module_action( l_module_name, 'Starting g_subscription');

    rslt := utl.get_dummy_cursor();
    /* #17346 : DB SProc (BEOWNER.CRUDG_SUBSCRIPTION.g_subscription) is not returning the cursor output in negative scenarios */
    
    SELECT
        vin
        INTO STRICT ctvin
        FROM beowner.ctx_data;
       
    vvin := COALESCE(UPPER(TRIM(ivin)), ctvin);
    vversion := COALESCE(iversion, '');

    IF vvin != ctvin
    THEN
        o_status_code := utl.get_constant_value('cctxvinnoteqpassedvin');
        RETURN;
    END IF;
   
    SELECT COUNT(*)
      INTO STRICT vcnt
      FROM beowner.vin
     WHERE vin = vvin;

    IF vcnt != 1
    THEN
        o_status_code := utl.get_constant_value('cdbvinnotfound');
        RETURN;
    END IF;
    
    l_action := utl.set_module_action( l_module_name, 'SELECT from VIN_SUBSCRIPTION');

    IF l_subscription_id IS NOT NULL
    THEN
        CLOSE rslt;
        OPEN rslt FOR
                    SELECT v.vs_id         AS subscription_id,
                           v.vin,
                           v.sub_startdate,
                           v.sub_duration,
                           v.sub_end_date,
                           v.bndl_id,
                           vversion,
                           utl.arr_to_cur(ARRAY(SELECT ROW(bs.svc_id, bs.allowed_status)::crudg_subscription.typ_bndlsvc
                                                      FROM beowner.bndlsvc bs 
                                                    WHERE bs.bndl_id = v.bndl_id)) svc,
                           v.vendor_tid
                      FROM beowner.vin_subscription v
                     WHERE v.vs_id = l_subscription_id
                           AND v.vin = vvin
                     ORDER BY v.vs_id;
        
    ELSE
        CLOSE rslt;
        OPEN rslt FOR
                    SELECT v.vs_id         AS subscription_id,
                           v.vin,
                           v.sub_startdate,
                           v.sub_duration,
                           v.sub_end_date,
                           v.bndl_id,
                           vversion,
                           utl.arr_to_cur(ARRAY(SELECT ROW(bs.svc_id, bs.allowed_status)::crudg_subscription.typ_bndlsvc
                                                      FROM beowner.bndlsvc bs 
                                                    WHERE bs.bndl_id = v.bndl_id)) svc,
                           v.vendor_tid
                      FROM beowner.vin_subscription v
                     WHERE v.vin = vvin
                     ORDER BY v.vs_id;
        
    END IF;
   
    o_status_code := utl.get_constant_value('csuccess');
   
    RETURN;
   
    EXCEPTION        
      WHEN others
      THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        CALL trc.log(iadditionaldata => 'Something went really wrong in G_SUBSCRIPTION vin=' || ivin ||' subscription_id=' || isubscription_id || ' version' ||vversion,
                        iexception_diagnostics => l_exception_diagnostics);
       rslt := utl.get_dummy_cursor();       
       o_status_code := utl.get_constant_value('cinternalerror');
       RETURN;
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
