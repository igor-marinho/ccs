SET bedb.filename = 'function.d_subscription.sql';

\i set_be_env.sql;


   -- Updated vendor_tid before delete for #16905

CREATE OR REPLACE FUNCTION crudg_subscription.d_subscription(IN isubscription_id TEXT DEFAULT NULL, 
                                                             IN ivin TEXT DEFAULT NULL, 
                                                             IN iversion TEXT DEFAULT NULL)
RETURNS INTEGER
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'd_subscription';
    vvin BEOWNER.VIN.vin%TYPE;
    vusr_id BEOWNER.USR.usr_id%TYPE;
    vuserlogin BEOWNER.USR.login_id%TYPE;
    vuconid BEOWNER.USR.login_id%TYPE;
    vbndlid BEOWNER.BNDL.bndl_id%TYPE;
    vexpiration BEOWNER.subscription.sub_start%TYPE;
    vdofu BEOWNER.subscription.sub_start%TYPE;
    vversion CHARACTER VARYING(100);
    vsubscription_id BEOWNER.vin_subscription.vs_id%TYPE;
    vcnt integer;
    ctvin BEOWNER.VIN.vin%TYPE;
    ctmakeid BEOWNER.VIN.make_id%TYPE;
    ctusrlogid BEOWNER.usr.login_id%TYPE;
    ctusrid BEOWNER.USR.usr_id%TYPE;
    l_vendor_tid BEOWNER.vin_subscription.vendor_tid%TYPE;    
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    l_action := utl.set_module_action( l_module_name, 'Starting d_subscription');

    SELECT vin, vendortid
      INTO STRICT ctvin, l_vendor_tid
      FROM beowner.ctx_data;
     
    vvin := COALESCE(UPPER(TRIM(ivin)), ctvin);
    vversion := iversion;
    vsubscription_id := isubscription_id::UUID;
   
    IF vvin != ctvin
    THEN
        RETURN utl.get_constant_value('cctxvinnoteqpassedvin');
    END IF;
   
    SELECT COUNT(*)
      INTO STRICT vcnt
      FROM beowner.vin
     WHERE vin = vvin;

    IF vcnt != 1 THEN
        RETURN utl.get_constant_value('cdbvinnotfound');
    END IF;
   
    SELECT COUNT(*)
      INTO STRICT vcnt
      FROM beowner.vin_subscription
     WHERE vin = vvin;

    IF vcnt = 0 THEN
        RETURN utl.get_constant_value('cvinsubscriptiondoesnotexist');
    END IF;
   
    SELECT COUNT(*)
      INTO STRICT vcnt
      FROM beowner.vin_subscription
     WHERE vin = vvin
       AND vs_id = vsubscription_id;

    IF vcnt = 0 THEN
        RETURN utl.get_constant_value('cinvalidsubscriptionid');
    END IF;
    
    /* #16905 */

    IF l_vendor_tid IS NULL
    THEN
        RETURN utl.get_constant_value('cvendortid_cannotbenull');
    END IF;
    
    l_action := utl.set_action( 'delete vin=' || vvin ||
                                   ' subscription_id=' || isubscription_id );

    /* #16905 updating first with vendor_tid, so that it is recorded in the history */
    
    UPDATE beowner.vin_subscription
    SET vendor_tid = l_vendor_tid
    WHERE vin = vvin
      AND vs_id = vsubscription_id;
       
    DELETE FROM beowner.vin_subscription
    WHERE vin = vvin
      AND vs_id = vsubscription_id;
       
    RETURN utl.get_constant_value('csuccess');
   
    EXCEPTION        
 
        WHEN invalid_text_representation
        THEN        
          RETURN utl.get_constant_value('cinvalidctxptnrid');
          
        WHEN others THEN
          GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        call trc.log(iadditionaldata => 'Something went really wrong in in D_SUBSCRIPTION vin=' || ivin ||
                              ' subscription_id=' || isubscription_id,
                        iexception_diagnostics => l_exception_diagnostics);                          
                       
        RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
