SET bedb.filename = 'function.common_subs_validations.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS crudg_subscription.common_subs_validations(uuid,text,uuid);

CREATE OR REPLACE FUNCTION crudg_subscription.common_subs_validations(IN i_usr_id TEXT, 
                                                                      IN i_vin TEXT, 
                                                                      IN i_bndl_id TEXT DEFAULT NULL, 
                                                                      OUT o_vin TEXT, 
                                                                      OUT o_usr_id TEXT, 
                                                                      OUT o_transaction_id TEXT, 
                                                                      OUT o_tmstmp TIMESTAMP WITH TIME ZONE, 
                                                                      OUT o_status_code INTEGER)
AS
$BODY$
DECLARE
    l_count smallint;
    l_vin BEOWNER.VIN.vin%TYPE
    /* OnTime WI #14078 */;
    ct_vin BEOWNER.VIN.vin%TYPE;
    ct_usr_id BEOWNER.USR.usr_id%TYPE;
	l_bndl_id BEOWNER.BNDL.bndl_id%TYPE := i_bndl_id::UUID;
    l_usr_id BEOWNER.USR.usr_id%TYPE;
    l_parent_id BEOWNER.USR.parent_id%TYPE;
    l_vin_make_id BEOWNER.VIN.make_id%TYPE;
    l_usr_make_id BEOWNER.VIN.make_id%TYPE;
BEGIN
    
    call crudg_subscription.dbg(CONCAT_WS('', 'common_subs_validations i_usr_id = ', i_usr_id, ' , i_vin = ', i_vin, ', i_bndl_id =', i_bndl_id));
    SELECT vin, transactionid, usr_id, tmstmp
        INTO STRICT ct_vin, o_transaction_id, ct_usr_id, o_tmstmp
        FROM beowner.ctx_data;
    l_vin := COALESCE(UPPER(TRIM(i_vin)), ct_vin);

    IF l_vin IS NULL THEN
        o_status_code := utl.get_constant_value('c_invalid_vin');
        RETURN;
    END IF;

    IF l_vin != ct_vin THEN
        o_status_code := utl.get_constant_value('cctxvinnoteqpassedvin');
        RETURN;
    END IF;
    SELECT
        MIN(make_id), COUNT(1)
        INTO STRICT l_vin_make_id, l_count
        FROM beowner.vin
        WHERE vin = l_vin;

    IF l_count != 1 THEN
        o_status_code := utl.get_constant_value('cdbvinnotfound');
        RETURN;
    END IF;
    l_usr_id := COALESCE(i_usr_id::UUID, ct_usr_id);

    IF l_usr_id IS NULL THEN
        o_status_code := utl.get_constant_value('c_invalid_user_id');
        RETURN;
    ELSE
        BEGIN
            SELECT
                parent_id, make_id
                INTO STRICT l_parent_id, l_usr_make_id
                FROM beowner.usr
                WHERE usr_id = l_usr_id;

            IF l_parent_id IS NOT NULL THEN
                o_status_code := utl.get_constant_value('cdbsubscribernotprimary');
                RETURN;
            ELSIF l_usr_make_id != l_vin_make_id THEN
                o_status_code := utl.get_constant_value('c_incompatible_vin_usr');
                RETURN;
            END IF;
            EXCEPTION
                WHEN no_data_found THEN
                    o_status_code := utl.get_constant_value('c_invalid_user_id');
                    RETURN;
        END;
    END IF;

    IF l_bndl_id IS NOT NULL THEN
        IF NOT utl.is_bundle_id_valid(i_bndl_id := l_bndl_id) THEN
            o_status_code := utl.get_constant_value('cinvalidbundleid');
            RETURN;
        /* check if the vin and bundle have the same device Id */
        ELSE
            SELECT
                COUNT(1)
                INTO STRICT l_count
                FROM beowner.vin AS v, beowner.bndl AS b
                WHERE v.vin = l_vin AND b.bndl_id = l_bndl_id AND v.device_id = b.device_id;

            IF l_count = 0 THEN
                o_status_code := utl.get_constant_value('c_incompatible_bundleid');
                RETURN;
            END IF;
        END IF;
    END IF;
    o_vin := l_vin;
    o_usr_id := l_usr_id::TEXT;
    call crudg_subscription.dbg(i_text := CONCAT_WS('', 'o_vin = ', o_vin, ', o_usr_id = ', o_usr_id));
    o_status_code := utl.get_constant_value('csuccess');
    RETURN;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
