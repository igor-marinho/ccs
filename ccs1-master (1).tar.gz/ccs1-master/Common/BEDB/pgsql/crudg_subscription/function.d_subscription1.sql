SET bedb.filename = 'function.d_subscription1.sql';

\i set_be_env.sql;

   /*
   d_subscription1 - Delete a user/VIN based subscription
   
   Changed parameters FOR WI #14511 - DI #1153
   
   Error codes returned:
      cInternalError                 '1'    Internal Error.
      c_no_such_Subscription_Exists  '288'  No matching subscriptions were found.
      c_subscription_id_is_null      '297'  Subscription ID was not passed in.
   */
   
CREATE OR REPLACE FUNCTION crudg_subscription.d_subscription1(IN i_subscription_id TEXT, 
                                                              IN i_version TEXT DEFAULT NULL)
RETURNS INTEGER
AS
$BODY$
/* Code added for OnTime WI #14078 */
/* Changed parameters and modified substantially for WI #14511 - DI #1153 */
DECLARE
    l_action text;
    l_module_name text := 'd_subscription1';
    l_subscription_id BEOWNER.SUBSCRIPTION.subscription_id%TYPE := i_subscription_id::UUID;
    l_count_subs INTEGER;
    l_transaction_id BEOWNER.SUBSCRIPTION.transaction_id%TYPE;
    l_subs_children_del_return INTEGER;
    l_exception_diagnostics trc.exception_diagnostics;
/* OnTime WI #15972 */
BEGIN
    l_action := utl.set_module_action( l_module_name, 'Starting d_subscription1');


    SELECT transactionid 
      INTO STRICT l_transaction_id
      FROM beowner.ctx_data;

    IF l_subscription_id IS NULL
    THEN
        RETURN utl.get_constant_value('c_subscription_id_is_null');
    END IF;
   
    l_action := utl.set_action('Deleting from SUBSCRIPTION');  
   
    SELECT COUNT(1)
        INTO l_count_subs
        FROM beowner.subscription AS s
        WHERE subscription_id = l_subscription_id;
       
    CASE l_count_subs
        WHEN 0 THEN
            RETURN utl.get_constant_value('c_no_such_subscription_exists');
        /* can't be greater than 1 since it is the primary key */
        /*
        OnTime WI #15972 : Delete all the children of subscriptions at the same time.
        Not checking for g_user_relation_static any more. If the relationship is static, no rows will be found in subscription_users anyway
        */
        ELSE
            l_subs_children_del_return := crudg_subscription.delete_subs_children(i_subscription_id := l_subscription_id, i_transaction_id := l_transaction_id);

            IF l_subs_children_del_return != utl.get_constant_value('csuccess')::INTEGER
            THEN
                RETURN l_subs_children_del_return;
            END IF;
           
            /* so that history row gets the correct transaction_id */
            -- Added conditional update as part of DCS1E-1213
            IF l_transaction_id IS NOT NULL
            THEN            
                UPDATE beowner.subscription AS s
                SET transaction_id = l_transaction_id
                    WHERE subscription_id = l_subscription_id;
                END IF;
               
            DELETE FROM beowner.subscription AS s
                WHERE subscription_id = l_subscription_id;
    END CASE;
   
    RETURN utl.get_constant_value('csuccess');
   
    /* OnTime WI #15750 */
    EXCEPTION
        WHEN SQLSTATE 'EMAKE'
        THEN
          RETURN utl.get_constant_value('cinvalidctxmakeid');

        WHEN OTHERS
        THEN
            GET STACKED diagnostics
                l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
                l_exception_diagnostics.column_name := COLUMN_NAME,
                l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
                l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
                l_exception_diagnostics.message_text := MESSAGE_TEXT,
                l_exception_diagnostics.table_name := TABLE_NAME,
                l_exception_diagnostics.schema_name := SCHEMA_NAME,              
                l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
                l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
                l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
                l_exception_diagnostics.module_name := l_module_name;
                l_exception_diagnostics.action := l_action;

            call trc.log(iadditionaldata => 'i_subscription_id=' || i_subscription_id,
                        iexception_diagnostics => l_exception_diagnostics);                       
                       
            RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
