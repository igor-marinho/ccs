SET bedb.filename = 'function.delete_subs_notif.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS crudg_subscription.delete_subs_notif(UUID, TEXT);

   /* Deletes from subs_notif and notif_location for provided subscription_id and notification_id 
      All notifications for the subscription are deleted if notification_id is not provided
   
   Added for DI 1457
   
         Error Codes returned:
   
         cInternalError                   '1'     Internal Error.
         c_subscription_id_is_null        '297'   Subscription ID was not passed in            
         c_notif_location_delete_error    '403'   There was an error when trying to delete notification locations
         c_subs_notif_delete_error        '404'   There was an error when trying to delete subscription notifications
   */

CREATE OR REPLACE FUNCTION crudg_subscription.delete_subs_notif(i_subscription_id UUID, i_notification_id TEXT DEFAULT NULL)
RETURNS INTEGER
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'delete_subs_notif';
    subs_notif_rec RECORD;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN

    l_module_name := COALESCE(current_setting('application_name',true),'') || '.' || l_module_name;

    IF i_subscription_id IS NULL
    THEN
        RETURN utl.get_constant_value('c_subscription_id_is_null');
    END IF;
    /* Loop through all subs_notif rows */

    FOR subs_notif_rec IN
     SELECT sn.subs_notif_id
       FROM beowner.subs_notif AS sn
      WHERE sn.subscription_id = i_subscription_id
        AND sn.notification_id = COALESCE(i_notification_id, sn.notification_id)
    LOOP
        BEGIN
            DELETE FROM beowner.notif_location AS nl
                WHERE nl.subs_notif_id = subs_notif_rec.subs_notif_id;
               
            EXCEPTION
                WHEN OTHERS
                THEN
                    GET STACKED diagnostics
                        l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
                        l_exception_diagnostics.column_name := COLUMN_NAME,
                        l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
                        l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
                        l_exception_diagnostics.message_text := MESSAGE_TEXT,
                        l_exception_diagnostics.table_name := TABLE_NAME,
                        l_exception_diagnostics.schema_name := SCHEMA_NAME,              
                        l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
                        l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
                        l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
                        l_exception_diagnostics.module_name := l_module_name;
                        l_exception_diagnostics.action := l_action;
                    call trc.log(iadditionaldata => 'Error when deleting from notif_location',
                                    iexception_diagnostics => l_exception_diagnostics);      
                    RETURN utl.get_constant_value('c_notif_location_delete_error');
        END;
        /* TCP-144 */

        BEGIN
            DELETE FROM beowner.subs_notif_push_handsets AS snp
                WHERE snp.subs_notif_id = subs_notif_rec.subs_notif_id;
               
            EXCEPTION
                WHEN OTHERS
                THEN
                    GET STACKED diagnostics
                        l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
                        l_exception_diagnostics.column_name := COLUMN_NAME,
                        l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
                        l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
                        l_exception_diagnostics.message_text := MESSAGE_TEXT,
                        l_exception_diagnostics.table_name := TABLE_NAME,
                        l_exception_diagnostics.schema_name := SCHEMA_NAME,              
                        l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
                        l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
                        l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
                        l_exception_diagnostics.module_name := l_module_name;
                        l_exception_diagnostics.action := l_action;
                    call trc.log(iadditionaldata => 'Error when deleting from subs_notif_push_handsets',
                                    iexception_diagnostics => l_exception_diagnostics);
                    RETURN utl.get_constant_value('c_snp_delete_error');
        END;

        BEGIN
            DELETE FROM beowner.subs_notif AS sn
                WHERE sn.subs_notif_id = subs_notif_rec.subs_notif_id;
               
            EXCEPTION
                WHEN OTHERS
                THEN
                    GET STACKED diagnostics
                        l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
                        l_exception_diagnostics.column_name := COLUMN_NAME,
                        l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
                        l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
                        l_exception_diagnostics.message_text := MESSAGE_TEXT,
                        l_exception_diagnostics.table_name := TABLE_NAME,
                        l_exception_diagnostics.schema_name := SCHEMA_NAME,              
                        l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
                        l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
                        l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
                        l_exception_diagnostics.module_name := l_module_name;
                        l_exception_diagnostics.action := l_action;
                    call trc.log('Error when deleting from subs_notif'::TEXT,
                        iexception_diagnostics => l_exception_diagnostics);
                    RETURN utl.get_constant_value('c_notif_location_delete_error');
        END;
    END LOOP;
   
    RETURN utl.get_constant_value('csuccess');
   
    EXCEPTION
        WHEN others THEN
           
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
          call trc.log(iadditionaldata => CONCAT_WS('', 'Something went wrong in ',l_module_name),
                         iexception_diagnostics => l_exception_diagnostics);
                       
           RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
