SET bedb.filename = 'function.cr_subscription.sql';

\i set_be_env.sql;

   -- Added vendor_tid for #16905
   -- Removed columns for DCS1E-921
DROP FUNCTION IF EXISTS crudg_subscription.cr_subscription (text, text, text, text);
CREATE OR REPLACE FUNCTION crudg_subscription.cr_subscription(IN ivin TEXT DEFAULT NULL, 
                                                              IN ibndlid text DEFAULT NULL, 
                                                              IN iexpiration TEXT DEFAULT NULL, 
                                                              IN iversion TEXT DEFAULT NULL)
RETURNS INTEGER
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'cr_subscription';
    vvin BEOWNER.VIN.vin%TYPE;
    vbndlid BEOWNER.BNDL.bndl_id%TYPE;
    vname BEOWNER.BNDL.name%TYPE;
    vexpiration BEOWNER.subscription.sub_start%TYPE;
    venddt BEOWNER.subscription.sub_start%TYPE;
    vversion CHARACTER VARYING(100);
    vbundle_length BEOWNER.BNDL.bundle_length%TYPE;
    vsub_startdate BEOWNER.vin_subscription.sub_startdate%TYPE;
    vsub_duration BEOWNER.VIN_SUBSCRIPTION.sub_duration%TYPE;
    vcusr CHARACTER VARYING(100);
    vcnt INTEGER;
    cintervalformat CONSTANT CHARACTER VARYING(33) := 'DD HH24:MI:SS.MS';
    ctvin BEOWNER.VIN.vin%TYPE;
    cttranid BEOWNER.vin_subscription.tranid%TYPE;
    cttrannm BEOWNER.VIN_SUBSCRIPTION.trannm%TYPE;
    cttranstepnm BEOWNER.VIN_SUBSCRIPTION.transtepnm%TYPE;
    l_vendor_tid BEOWNER.VIN_SUBSCRIPTION.vendor_tid%TYPE;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN

    l_action := utl.set_module_action( l_module_name, 'Starting cr_subscription');

    SELECT vin, transactionid, transactionnm, transactionstp, vendortid
        INTO STRICT ctvin, cttranid, cttrannm, cttranstepnm, l_vendor_tid
        FROM beowner.ctx_data;
       
    vvin := COALESCE(UPPER(TRIM(ivin)), ctvin);

    IF vvin != ctvin THEN
        RETURN utl.get_constant_value('cctxvinnoteqpassedvin');
    END IF;
   
    SELECT COUNT(*)
        INTO STRICT vcnt
        FROM beowner.vin
        WHERE vin = vvin;

    IF vcnt != 1 
    THEN
        RETURN utl.get_constant_value('cdbvinnotfound');
    END IF;
   
    SELECT COUNT(*), LOWER(TRIM(name)), bndl_id, bundle_length
      INTO vcnt, vname, vbndlid, vbundle_length
      FROM beowner.bndl
     WHERE bndl_id = ibndlid::uuid
     GROUP BY name, bndl_id, bundle_length;

    IF coalesce(vcnt,0) = 0
    THEN
        RETURN utl.get_constant_value('cinvalidbundleid');
    END IF;
    /* #16905 */

    IF l_vendor_tid IS NULL THEN
        RETURN utl.get_constant_value('cvendortid_cannotbenull');
    END IF;
   
    SELECT SESSION_USER
        INTO STRICT vcusr;
       
    vsub_startdate := clock_timestamp();

    IF iexpiration IS NULL
    THEN
        vsub_duration := vbundle_length;
        venddt := vsub_startdate + vsub_duration::INTERVAL;
    ELSE
        vsub_duration := to_char(iexpiration::timestamptz - vsub_startdate,cintervalformat);
    END IF;
    
    vexpiration := COALESCE(iexpiration::timestamptz, venddt);    
    vversion := iversion;

    l_action := utl.set_module_action( l_module_name, 'Insert in CR_SUBSCRIPTION VIN='|| ivin );


    INSERT INTO beowner.vin_subscription (vs_id, vin, bndl_id, sub_startdate, sub_duration, sub_end_date, created_user, created_date, tranid, trannm, transtepnm, vendor_tid)
    VALUES (beowner.rand_guid(), vvin, vbndlid, vsub_startdate, vsub_duration, vexpiration,  vcusr, clock_timestamp(), cttranid, cttrannm, cttranstepnm, l_vendor_tid);
   
    RETURN utl.get_constant_value('csuccess');
   
    EXCEPTION
        WHEN unique_violation THEN
            RETURN utl.get_constant_value('csubscriptionalreadyexists');
           
        WHEN OTHERS
        THEN
            GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,              
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;
           call trc.log(iadditionaldata => NULL,
                          iexception_diagnostics => l_exception_diagnostics);
           RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
