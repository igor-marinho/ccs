SET bedb.filename = 'function.transfer_vehicle.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS crudg_subscription.transfer_vehicle(text,text,text,text); 

   -- transfer_vehicle Sproc added for OnTime WI #15756 and WI # 15757
   /* Validates both the user IDs as well as VIN (if provided) using validate_users_vin
         1. Transfers 1 or ALL subscriptions associated with old vehicle owner to a new vehicle owner.
         2. Removes any relationships between the Old primary's secondaries and VIN/subscriptions.
         
     Returns status code in REFCURSOR
     Error codes returned: 
     Success                          '0'       -- Operation was successful    
     cInternalError                   '1'       -- Unknown Internal error
     c_both_users_are_same            '342'     -- The user IDs provided are same (for inheritance or transfer)
     c_invalid_from_user              '340'     -- The 'From user ID' provided is null or invalid (for inheritance or transfer)
     c_invalid_to_user                '341'     -- The 'To user ID' provided is null or invalid (for inheritance or transfer)
     c_incompatible_make_ids          '344'     -- The make Is of both users are different (for inheritance or transfer)
     c_from_user_not_primary          '345'     -- The 'From user ID' provided is not a primary user (for transfer)
     c_to_user_not_primary            '346'     -- The 'To user ID' provided is not a primary user (for transfer)  
     c_primary_has_no_subscriptions   '281'     -- Primary User has no subscriptions (for the VIN, if provided)
     cCTXVinNotEqPassedVin            '46'      -- The Context VIN does not match the VIN Passed into the function or procedure
     cDbVinNotFound                   '200'     -- System was passed a VIN which was not found.
     c_invalid_vin                    '234'     -- VIN is null
   */
CREATE OR REPLACE FUNCTION crudg_subscription.transfer_vehicle (i_from_user_id   text
                                                               ,i_vin            text
                                                               ,i_to_user_id     text
                                                               ,iversion         text DEFAULT NULL)
RETURNS INTEGER
AS
$BODY$
/* This sproc is not going to be used for TMS in its current form */
DECLARE
    l_action text;
    l_module_name text := 'transfer_vehicle';
    l_vin BEOWNER.VIN.vin%TYPE;
    l_validation_return TEXT;
    l_del_subscr_usr INTEGER;
    o_status_code TEXT;
    subscr_usr_rec RECORD;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
     l_action := utl.set_module_action( l_module_name,' Calling validate_users_vin to validate user ids and VIN');

    /* see if Old User id, New User Id and VIN exists; */
    /* Checking for valid Old user id and existing VIN */

    IF i_vin IS NOT NULL
    THEN
        SELECT *
          FROM crudg_subscription.validate_users_vin(i_from_user_id => i_from_user_id,
                                                     i_to_user_id => i_to_user_id,
                                                     i_vin => i_vin,
                                                     i_check_if_primary => True)
          INTO l_vin, o_status_code;
         
        l_validation_return := o_status_code;
    ELSE
        RETURN utl.get_constant_value('c_invalid_vin'); --234
    END IF;
   
    CALL utl.checkvinconflict();
    /* use context */

    IF l_validation_return != utl.get_constant_value('csuccess')
    THEN
        RETURN l_validation_return;
    END IF;
    l_action := utl.set_module_action( l_module_name,' Transferring VIN and related Subscriptions');

    FOR subscr_usr_rec IN
      SELECT su.subscription_id
        FROM beowner.subscription AS su
       WHERE su.primary_id = i_from_user_id::uuid
         AND su.vin = i_vin
    LOOP

        l_del_subscr_usr := crudg_subscription.delete_subs_children(subscr_usr_rec.subscription_id);
        /* DI# 1457 */

        IF l_del_subscr_usr != utl.get_constant_value('csuccess')::INTEGER
        THEN
            RETURN l_del_subscr_usr;
        END IF;
       
        UPDATE beowner.subscription
           SET primary_id = i_to_user_id::uuid,
               transaction_id = (SELECT transactionid
                                   FROM beowner.ctx_data),
               nickname = NULL
         WHERE subscription_id = subscr_usr_rec.subscription_id;
           
    END LOOP;
   
    /* Jira DDCRD-405 - removed call to update event log, as this sproc is not meant for TMS */   
    RETURN utl.get_constant_value('csuccess');
   
    EXCEPTION
        WHEN SQLSTATE 'EVINN'
        THEN
            RETURN utl.get_constant_value('cdbvinnotfound'); --200
            
        WHEN SQLSTATE 'EMAKE' 
        THEN
            RETURN utl.get_constant_value('cinvalidctxmakeid');
                
        WHEN OTHERS
        THEN
        l_action := utl.set_module_action( l_module_name, ' Something went really wrong with transfer_vehicle process:');
            GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,              
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;    
            CALL trc.log(iadditionaldata => NULL,
                            iexception_diagnostics => l_exception_diagnostics);
            RETURN utl.get_constant_value('cinternalerror'); --1
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;
\i cleanup.sql;
