SET bedb.filename = 'function.d_sub_terminate.sql';

\i set_be_env.sql; 
DROP FUNCTION IF EXISTS crudg_subscription.d_sub_terminate (TEXT,TEXT,TEXT,TEXT);

-- Updated vendor_tid for #16905

CREATE OR REPLACE FUNCTION crudg_subscription.d_sub_terminate (isubscription_id   text DEFAULT NULL
                                                              ,ivin               text DEFAULT NULL
                                                              ,iexpiration        text DEFAULT NULL
                                                              ,iversion           text DEFAULT NULL) RETURNS INTEGER
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'd_sub_terminate';
    vvin BEOWNER.VIN.vin%TYPE;
    vusr_id BEOWNER.USR.usr_id%TYPE;
    vuserlogin BEOWNER.USR.login_id%TYPE;
    vuconid BEOWNER.USR.login_id%TYPE;
    vbndlid BEOWNER.BNDL.bndl_id%TYPE;
    vexpiration BEOWNER.subscription.sub_start%TYPE;
    vdofu BEOWNER.subscription.sub_start%TYPE;
    vversion CHARACTER VARYING(100);
    vsubscription_id BEOWNER.vin_subscription.vs_id%TYPE;
    vcnt INTEGER;
    ctvin BEOWNER.VIN.vin%TYPE;
    ctmakeid BEOWNER.VIN.make_id%TYPE;
    ctusrlogid BEOWNER.USR.login_id%TYPE;
    ctusrid BEOWNER.USR.usr_id%TYPE;
    l_vendor_tid BEOWNER.vin_subscription.vendor_tid%TYPE;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    l_action := utl.set_module_action( l_module_name,'Starting g_subscription');
    
    SELECT vin, vendortid
      INTO STRICT ctvin, l_vendor_tid
      FROM beowner.ctx_data;
      
    vvin := COALESCE(UPPER(TRIM(ivin)), ctvin);
    
    vexpiration := COALESCE(iexpiration::timestamptz, date_trunc('DAY',clock_timestamp()));
    
    vversion := COALESCE(iversion, '');
    vsubscription_id := TRIM(isubscription_id)::UUID;

    IF vvin != ctvin
    THEN
        RETURN  utl.get_constant_value('cctxvinnoteqpassedvin');
    END IF;

   SELECT COUNT(*)
     INTO STRICT vcnt
     FROM beowner.vin
    WHERE vin = vvin;

    IF vcnt != 1
    THEN
        RETURN utl.get_constant_value('cdbvinnotfound');
    END IF;
   
    SELECT COUNT(*)
      INTO STRICT vcnt
      FROM beowner.vin_subscription
      WHERE vin = vvin;

    IF vcnt = 0 THEN
        RETURN utl.get_constant_value('cvinsubscriptiondoesnotexist');
    END IF;
   
    SELECT COUNT(*)
      INTO STRICT vcnt
      FROM beowner.vin_subscription
     WHERE vin = vvin
       AND vs_id = vsubscription_id;

    IF vcnt = 0 THEN
        RETURN utl.get_constant_value('cinvalidsubscriptionid');
    END IF;
   
    /* #16905 */
    IF l_vendor_tid IS NULL
    THEN
        RETURN utl.get_constant_value('cvendortid_cannotbenull');
    END IF;
   
    l_action := utl.set_module_action( l_module_name, 'Updating VIN_SUBSCRIPTION with new sub_end_date');

    UPDATE beowner.vin_subscription
       SET sub_end_date = vexpiration,
           vendor_tid = l_vendor_tid
     WHERE vin = vvin
       AND vs_id = vsubscription_id;
    
    RETURN utl.get_constant_value('csuccess');
   
    EXCEPTION
        WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation
        THEN
          RETURN utl.get_constant_value('cinvalidparams');
        WHEN OTHERS
        THEN
            GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,              
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action; 
            CALL trc.log(iadditionaldata => 'Something went really wrong in in D_SUB_TERMINATE vin=' || ivin ||' subscription_id=' || isubscription_id || ' version' || vversion,
                        iexception_diagnostics => l_exception_diagnostics);
                       
            RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
