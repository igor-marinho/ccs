SET bedb.filename = 'function.u_ptnr_sp.sql';

\i set_be_env.sql;

  /*  -- CRUDG_PTNR :Error codes returned:
      
        csuccess
        cinternalerror
        c_ptnr_id_null            '348'  -- Partner ID is null
        c_dup_ptnr_id             '349'  -- Duplicate Partner ID. Partner id exists.
        c_hu_mfr_id_null          '350'  -- HU MFR ID is null
        cinvalidmake              '222'  -- Invalid Make ID or Make Id is null 
        cdbpartneridnotvalid      '213'  -- The partnerid is not valid.
        cdbnodatafound            '210'  -- Required data was not acquired.
      
  */

drop function if exists crudg_ptnr.u_ptnr_sp (TEXT,
                                              beowner.ptnr.hu_mfr_id%TYPE, 
										      text);
												
CREATE OR REPLACE FUNCTION crudg_ptnr.u_ptnr_sp (i_ptnr_id TEXT,
                                                 i_hu_mfr_id beowner.ptnr.hu_mfr_id%TYPE, 
												 i_version text DEFAULT NULL) RETURNS INTEGER AS $body$
DECLARE
      l_action text;
      l_module_name text := 'u_ptnr_sp';
      l_is_ptnr     boolean := TRUE;
      l_ptnr_id     beowner.ptnr.ptnr_id%TYPE := i_ptnr_id::uuid;
      l_hu_mfr_id   beowner.ptnr.hu_mfr_id%TYPE;
      l_retval	    integer;
      l_exception_diagnostics trc.exception_diagnostics;

BEGIN									 
	  l_action := utl.set_module_action( l_module_name, 'Starting U_PTNR_SP');
	  
      l_retval := utl.get_constant_value('csuccess');

      l_hu_mfr_id := trim(both UPPER(i_hu_mfr_id));

   
	  IF COALESCE(l_ptnr_id::text, '') != ''
      THEN
	  l_is_ptnr := utl.is_ptnr_id_valid(l_ptnr_id);

	    IF NOT l_is_ptnr
	    THEN
	    RETURN utl.get_constant_value('cdbpartneridnotvalid');
	    END IF;		
      ELSE
	  RETURN utl.get_constant_value('c_ptnr_id_null');
      END IF;

      
	  IF COALESCE(l_hu_mfr_id, '') = ''
      THEN
	  RETURN utl.get_constant_value('c_hu_mfr_id_null');
      END IF;

      UPDATE beowner.ptnr
	  SET hu_mfr_id = l_hu_mfr_id
      WHERE ptnr_id = l_ptnr_id;

      RETURN l_retval;
	  
EXCEPTION
      WHEN OTHERS THEN
	  l_action := utl.set_action('Something went really wrong in U_PTNR_SP usr_id: ');
	  
	  GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);

	      RETURN utl.get_constant_value('cinternalerror');
END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION crudg_ptnr.u_ptnr_sp (i_ptnr_id beowner.ptnr.ptnr_id%TYPE,  i_hu_mfr_id beowner.ptnr.hu_mfr_id%TYPE, i_version text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
