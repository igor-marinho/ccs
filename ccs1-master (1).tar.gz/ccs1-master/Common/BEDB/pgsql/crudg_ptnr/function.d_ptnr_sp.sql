SET bedb.filename = 'function.d_ptnr_sp.sql';

\i set_be_env.sql;

  /*  -- CRUDG_PTNR :Error codes returned:
      
        csuccess
        cinternalerror
        c_ptnr_id_null            '348'  -- Partner ID is null
        c_dup_ptnr_id             '349'  -- Duplicate Partner ID. Partner id exists.
        c_hu_mfr_id_null          '350'  -- HU MFR ID is null
        cinvalidmake              '222'  -- Invalid Make ID or Make Id is null 
        cdbpartneridnotvalid      '213'  -- The partnerid is not valid.
        cdbnodatafound            '210'  -- Required data was not acquired.
      
  */

-- WARNING: parameters order has been changed by Ora2Pg to move parameters with default values at end
-- Original order was: crudg_ptnr.d_ptnr_sp(i_ptnr_id beowner.ptnr.ptnr_id%TYPE, i_version text DEFAULT NULL, rslt OUT REFCURSOR)
-- You will need to manually reorder parameters in the function calls
CREATE OR REPLACE FUNCTION crudg_ptnr.d_ptnr_sp (i_ptnr_id beowner.ptnr.ptnr_id%TYPE, rslt OUT REFCURSOR, --imake_id    IN beowner.make.make_id%TYPE,
		       -- ihu_mfr_id  IN beowner.ptnr.hu_mfr_id%TYP,
 i_version text DEFAULT NULL) AS $body$
DECLARE
      l_module_name text := 'd_ptnr_sp';
      l_retval	 numeric;

BEGIN
      PERFORM utl.set_module_action( l_module_name,  
                                         ' Starting d_ptnr_sp');
      l_retval := utl.get_constant_value('csuccess');


      RETURN;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION crudg_ptnr.d_ptnr_sp (i_ptnr_id beowner.ptnr.ptnr_id%TYPE, rslt OUT REFCURSOR,  i_version text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
