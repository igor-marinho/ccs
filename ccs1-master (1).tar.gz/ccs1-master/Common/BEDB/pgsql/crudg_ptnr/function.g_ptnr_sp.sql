SET bedb.filename = 'function.g_ptnr_sp.sql';

\i set_be_env.sql;

/*  -- CRUDG_PTNR :Error codes returned:

      csuccess
      cinternalerror
      c_ptnr_id_null            '348'  -- Partner ID is null
      c_dup_ptnr_id             '349'  -- Duplicate Partner ID. Partner id exists.
      c_hu_mfr_id_null          '350'  -- HU MFR ID is null
      cinvalidmake              '222'  -- Invalid Make ID or Make Id is null
      cdbpartneridnotvalid      '213'  -- The partnerid is not valid.
      cdbnodatafound            '210'  -- Required data was not acquired.

*/
-- WARNING: parameters order has been changed by Ora2Pg to move parameters with default values at end
-- Original order was: crudg_ptnr.g_ptnr_sp( i_ptnr_id beowner.ptnr.ptnr_id%TYPE DEFAULT NULL, i_make_id beowner.make.make_id%TYPE DEFAULT NULL, i_hu_mfr_id beowner.ptnr.hu_mfr_id%TYPE DEFAULT NULL, i_version text DEFAULT NULL, rslt OUT REFCURSOR)
-- You will need to manually reorder parameters in the function calls
DROP FUNCTION IF EXISTS crudg_ptnr.g_ptnr_sp(text, char varying(2), char varying(2), text);
CREATE OR REPLACE FUNCTION crudg_ptnr.g_ptnr_sp(i_ptnr_id text DEFAULT NULL,
                                                i_make_id char varying(2) DEFAULT NULL,
                                                i_hu_mfr_id char varying(2) DEFAULT NULL,
                                                i_version text DEFAULT NULL,
                                                o_status_code OUT integer,
                                                o_result OUT refcursor) AS
$body$
DECLARE
    l_action                text;
    l_module_name           text    := 'g_ptnr_sp';
    l_cnt                   integer;
    l_is_make               boolean := TRUE;
    l_is_ptnr               boolean := TRUE;
    l_ptnr_id               beowner.ptnr.ptnr_id%type;
    l_hu_mfr_id             beowner.ptnr.hu_mfr_id%type;
    l_make_id               beowner.make.make_id%type;
    --l_cnt_hu_mfr_id   INTEGER;
    l_retval                integer;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    l_action := utl.set_module_action(l_module_name,
                                      ' Starting G_PTNR_SP');

    o_result := utl.get_dummy_cursor();

    l_retval := utl.get_constant_value('csuccess');

    l_ptnr_id := trim(BOTH UPPER(i_ptnr_id))::UUID;
    l_make_id := trim(BOTH UPPER(i_make_id));
    l_hu_mfr_id := trim(BOTH UPPER(i_hu_mfr_id));

    IF coalesce(i_ptnr_id, '') != ''
    THEN
        l_is_ptnr := utl.is_ptnr_id_valid(l_ptnr_id);

        IF NOT l_is_ptnr
        THEN
            o_status_code := utl.get_constant_value('cdbpartneridnotvalid');
            RETURN;
        END IF;
    ELSE
        o_status_code :=  utl.get_constant_value('c_ptnr_id_null');
		RETURN;
    END IF;

    IF coalesce(l_make_id, '') != ''
    THEN
        l_is_make := utl.is_make_valid(l_make_id);

        IF NOT l_is_make
        THEN
            o_status_code := utl.get_constant_value('cinvalidmake');
            RETURN;
        END IF;
    END IF;


    IF coalesce(l_ptnr_id::TEXT, '') = '' AND coalesce(l_make_id, '') = '' AND coalesce(l_hu_mfr_id, '') = ''
    THEN
        o_status_code := utl.get_constant_value('cdbnodatafound')
        RETURN;
    END IF;


    SELECT COUNT(1)
    INTO STRICT l_cnt
    FROM beowner.ptnr pt
    WHERE pt.ptnr_id = coalesce(l_ptnr_id, pt.ptnr_id)
      AND pt.make_id = coalesce(l_make_id, pt.make_id)
      AND pt.hu_mfr_id = coalesce(l_hu_mfr_id, pt.hu_mfr_id);

    IF l_cnt = 0
    THEN
        o_status_code := utl.get_constant_value('cdbnodatafound')
        RETURN;
    END IF;


    CLOSE o_result;
    OPEN o_result FOR
        SELECT ptnr_id, make_id, hu_mfr_id
        FROM beowner.ptnr pt
        WHERE pt.ptnr_id = coalesce(l_ptnr_id::uuid, pt.ptnr_id)
          AND pt.make_id = coalesce(l_make_id, pt.make_id)
          AND pt.hu_mfr_id = coalesce(l_hu_mfr_id, pt.hu_mfr_id);


    o_status_code := utl.get_constant_value('csuccess');
    RETURN;
EXCEPTION
    WHEN OTHERS
        THEN
            l_action := utl.set_module_action(l_module_name,
                                          ' Something went really wrong in G_PTNR_SP usr_id: ');
            GET STACKED DIAGNOSTICS
                l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
                l_exception_diagnostics.column_name := COLUMN_NAME,
                l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
                l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
                l_exception_diagnostics.message_text := MESSAGE_TEXT,
                l_exception_diagnostics.table_name := TABLE_NAME,
                l_exception_diagnostics.schema_name := SCHEMA_NAME,
                l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
                l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
                l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
                l_exception_diagnostics.module_name := l_module_name;
                l_exception_diagnostics.action := l_action;

            CALL trc.log(iadditionaldata => NULL,
                         iexception_diagnostics => l_exception_diagnostics);
            o_result := utl.get_dummy_cursor();
            o_status_code := utl.get_constant_value('cinternalerror');
            RETURN;
END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION crudg_ptnr.g_ptnr_sp ( rslt OUT REFCURSOR, i_ptnr_id beowner.ptnr.ptnr_id%TYPE DEFAULT NULL, i_make_id beowner.make.make_id%TYPE DEFAULT NULL, i_hu_mfr_id beowner.ptnr.hu_mfr_id%TYPE DEFAULT NULL, i_version text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
