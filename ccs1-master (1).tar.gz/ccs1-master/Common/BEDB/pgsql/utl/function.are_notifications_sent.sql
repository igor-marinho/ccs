SET bedb.filename = 'function.are_notifications_sent.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS utl.are_notifications_sent(beowner.device.device_id%TYPE);
   /* Returns value of device_types.optin_notifications for the provided device ID.
   Indicates whether option notifications have been turned on for the device ID.
   If device_type on the device is null, returns N. */
CREATE OR REPLACE FUNCTION utl.are_notifications_sent (i_device_id beowner.device.device_id%TYPE) RETURNS TEXT 
AS $body$
DECLARE
      l_notifications_sent beowner.device_types.optin_notifications%TYPE;

BEGIN
      BEGIN
         SELECT coalesce(dt.optin_notifications, 'N')
           INTO STRICT l_notifications_sent
           FROM beowner.device d
            LEFT OUTER JOIN beowner.device_types dt ON (d.device_type = dt.type)
            WHERE d.device_id = i_device_id;
      EXCEPTION
         WHEN no_data_found THEN
            l_notifications_sent := 'N';
      END;

      RETURN l_notifications_sent;
   END;
$body$
LANGUAGE PLPGSQL
STABLE;
-- REVOKE ALL ON FUNCTION utl.are_notifications_sent (i_device_id device.device_id%TYPE) FROM PUBLIC;

\i cleanup.sql;
