SET bedb.filename = 'procedure.set_debug_on.sql';

\i set_be_env.sql;

   /* Added with OnTime #14781 to support debugging
   Sets debug mode to yes, resulting in sending debug messages to dbms_output for testing. By default debug mode is set to off. */

   -- Added with OnTime #14781 to support debugging  
DROP PROCEDURE IF EXISTS utl.set_debug_on();
CREATE OR REPLACE PROCEDURE utl.set_debug_on()
AS
$BODY$
BEGIN
    PERFORM utl.set_session_variable (i_parent_namespace => 'utl', i_child_namespace => 'dbg', i_name => 'g_debug_on', i_value => utl.get_constant_value('c_yes'));
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
