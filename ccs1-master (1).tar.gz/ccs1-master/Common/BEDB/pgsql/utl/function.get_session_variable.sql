SET bedb.filename = 'function.get_session_variable.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION utl.get_session_variable(IN i_parent_namespace TEXT, in i_child_namespace text ,in i_name text)
RETURNS TEXT
AS
$BODY$
DECLARE
    v_return text;
BEGIN
	
	v_return := current_setting(lower(i_parent_namespace) || '.' || lower(i_child_namespace) || '.' || lower(i_name),true);

    if v_return = ''
    then
      v_return := null;
    end if;
    
	return v_return;

END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
