SET bedb.filename = 'function.get_device_type.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS utl.get_device_type (beowner.device.device_id%TYPE, beowner.vin.vin%TYPE);
   /* Jira TCP-144 Returns device_type for the device Id, if provided. 
   If not and VIN is provided, finds the device type of the VIN */

CREATE OR REPLACE FUNCTION utl.get_device_type (i_device_id   beowner.device.device_id%TYPE DEFAULT NULL
                                               ,i_vin         beowner.vin.vin%TYPE DEFAULT NULL) RETURNS TEXT 
AS $body$
DECLARE
      l_device_type beowner.device_types.type%TYPE;
BEGIN
      BEGIN
         IF COALESCE(i_device_id, '') != ''
         THEN
            SELECT device_type
              INTO STRICT l_device_type
              FROM beowner.device
             WHERE device_id = i_device_id;
         ELSIF COALESCE(i_vin, '') != ''
         THEN
            SELECT device_type
              INTO STRICT l_device_type
              FROM beowner.vin    v,
                   beowner.device d
             WHERE v.vin = i_vin
                   AND d.device_id = v.device_id;
         END IF;
      EXCEPTION
         WHEN no_data_found THEN
            NULL;
      END;
      RETURN l_device_type;
   END;
$body$
LANGUAGE PLPGSQL
STABLE;
-- REVOKE ALL ON FUNCTION utl.get_device_type (i_device_id device.device_id%TYPE DEFAULT NULL, i_vin vin.vin%TYPE DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
