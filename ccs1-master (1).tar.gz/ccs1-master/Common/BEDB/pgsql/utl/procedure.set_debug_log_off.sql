SET bedb.filename = 'procedure.set_debug_log_off.sql';

\i set_be_env.sql;

   /*  Sets debug_log mode to off, to stop sending additional log messages to "trc" table  */
CREATE OR REPLACE PROCEDURE utl.set_debug_log_off () AS $body$
BEGIN
      g_debug_log_on := FALSE;
   END;


$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE utl.set_debug_log_off () FROM PUBLIC;

\i cleanup.sql;
