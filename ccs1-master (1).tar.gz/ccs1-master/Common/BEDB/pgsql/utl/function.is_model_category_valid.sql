SET bedb.filename = 'function.is_model_category_valid.sql';

\i set_be_env.sql;


/* DCS1REFRES-465 Returns true if the input category is present in the model_categories table, false otherwise */
DROP FUNCTION IF EXISTS utl.is_model_category_valid(text);
CREATE OR REPLACE FUNCTION utl.is_model_category_valid(IN i_category text)
    RETURNS boolean
AS
$BODY$
DECLARE
    l_found character varying(1);
BEGIN
    SELECT 1
    INTO STRICT l_found
    FROM beowner.model_categories AS mc
    WHERE mc.category = i_category
    LIMIT 1;
    RETURN TRUE;
EXCEPTION
    WHEN no_data_found THEN
        RETURN FALSE;
END;
$BODY$
    LANGUAGE plpgsql;
\i cleanup.sql;
