SET bedb.filename = 'function.is_ptnr_id_valid.sql';

\i set_be_env.sql;

   /* Returns true if the ptnr_id provided is valid, false otherwise
   Added for OnTime WI # 15627  */

drop function if exists utl.is_ptnr_id_valid(beowner.ptnr.ptnr_id%TYPE);

CREATE OR REPLACE FUNCTION utl.is_ptnr_id_valid (i_ptnr_id beowner.ptnr.ptnr_id%TYPE) RETURNS boolean AS $body$
DECLARE

      l_ptnr_id beowner.ptnr.ptnr_id%TYPE;

BEGIN
      SELECT ptnr_id
        INTO STRICT l_ptnr_id
        FROM beowner.ptnr
       WHERE ptnr_id = i_ptnr_id;

      RETURN TRUE;
   EXCEPTION
      WHEN no_data_found THEN
         RETURN FALSE;
   END;


$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION utl.is_ptnr_id_valid (i_ptnr_id ptnr.ptnr_id%TYPE) FROM PUBLIC;

\i cleanup.sql;
