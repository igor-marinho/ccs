SET bedb.filename = 'function.g_test_mode_on.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION utl.g_test_mode_on()
RETURNS BOOLEAN
AS
$BODY$

DECLARE
    l_test_mode text;
BEGIN
    SELECT COALESCE(current_setting('util.g_test_mode',true),'off') into l_test_mode;

    IF l_test_mode = 'on'
    THEN
        RETURN TRUE;
    END IF;

    RETURN FALSE;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
