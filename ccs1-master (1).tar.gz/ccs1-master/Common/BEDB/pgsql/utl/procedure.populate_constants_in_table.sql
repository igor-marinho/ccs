SET bedb.filename = 'procedure.populate_constants_in_table.sql';

\i set_be_env.sql;

   /* DCS1E-1307 Populates constants from cnst package into table constant_values. Overwrites existing values */
   -- DCS1E-1307
   -- DCS1E-1307
CREATE OR REPLACE PROCEDURE utl.populate_constants_in_table () AS $body$
BEGIN
      DELETE FROM constant_values;
      INSERT INTO constant_values(cv_guid, named_constant, VALUE, comments)
         SELECT rand_guid(),
                rtrim(substr(text, 1, end_constant)) CONSTANT,
                substr(text, begin_val, end_val - begin_val) val,
                CASE
                   WHEN comment_start > 2 THEN
                    trim(both substr(text, comment_start))
                   ELSE
                    NULL
                END comments
           FROM (SELECT trim(both text) text,
                        line,
                        position('CONSTANT' in trim(both text)) - 2 end_constant,
                        CASE
                           WHEN position('''' in trim(both text)) = 0 THEN
                            position('=' in trim(both text)) + 2
                           ELSE
                            position('''' in trim(both text)) + 1
                        END begin_val,
                        position(';' in trim(both text)) - CASE
                           WHEN position('''' in trim(both text)) = 0 THEN
                            0
                           ELSE
                            1
                        END end_val,
                        position('--' in trim(both text)) + 2 comment_start
                   FROM user_source
                  WHERE NAME = 'CNST'
                        AND line > 5
                        AND text NOT LIKE 'END%'
                        AND trim(both text) NOT LIKE '--%'
                        AND replace(trim(both text), chr(10), '') IS NOT NULL) s
          ORDER BY 2;
      -- raise any exceptions, as this would be called manually during Oracle to Postgres migration, to generate the inserts
   END;

   -- DCS1E-1307
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE utl.populate_constants_in_table () FROM PUBLIC;


\i cleanup.sql;
