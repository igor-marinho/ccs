SET bedb.filename = 'function.is_conflict_enforced.sql';

\i set_be_env.sql;

/* Returns value of device_types.conflict_enforced for the provided device Id by joining with device_types.
Indicates whether conflict is enforced for the device ID.
If device_type on the device is null, returns N. */

/* Returns value of device_types.conflict_enforced for the provided device Id by joining with device_types.
If device_type on the device is null, returns N. */
CREATE OR REPLACE FUNCTION utl.is_conflict_enforced(IN i_device_id TEXT)
RETURNS TEXT
AS
$BODY$
DECLARE
    l_conflict_enforced BEOWNER.DEVICE_TYPES.conflict_enforced%TYPE;
BEGIN
    BEGIN
        SELECT
            COALESCE(dt.conflict_enforced, 'N')
            INTO STRICT l_conflict_enforced
            FROM beowner.device_types AS dt
            RIGHT OUTER JOIN beowner.device AS d
                ON (dt.type = d.device_type)
            WHERE d.device_id = i_device_id;
        EXCEPTION
            WHEN no_data_found THEN
                l_conflict_enforced := 'N';
    END;
    RETURN l_conflict_enforced;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
