SET bedb.filename = 'function.normalize_vin.sql';

\i set_be_env.sql;

   -------------------------------------------------------------------------------
   -- Mostly this is checking for invalid data. If lowercase characters are passed
   -- in, it will uppercase them. It will also trim leading/trailing blanks.
   -- If the data is otherwise invalid, it will raise the appropriate exception.
CREATE OR REPLACE FUNCTION utl.normalize_vin (ivin tvin) RETURNS TVIN AS $body$
DECLARE

      vvin        tvin;
      vcheckdigit varchar(1);

BEGIN

      BEGIN
         vvin := upper(trim(both ivin));
      EXCEPTION
         WHEN string_data_right_truncation THEN
            RAISE EXCEPTION '%', 'VIN must be exactly 17 characters (it was too long)' USING ERRCODE = '45001';
      END;

      IF length(vvin) != 17
      THEN
         RAISE EXCEPTION '%', 'VIN must be exactly 17 characters (it was too short)' USING ERRCODE = '45001';
      END IF;

      -- check_digit will throw an exception if it encounters an invalid character
      vcheckdigit := utl.check_digit(vvin);

      IF vcheckdigit != substr(vvin, 9, 1)
      THEN
         RAISE EXCEPTION '%', 'VIN Check Digit is not correct' USING ERRCODE = '45001';
      END IF;

      RETURN vvin;
   END;

$body$
LANGUAGE PLPGSQL
 IMMUTABLE;
-- REVOKE ALL ON FUNCTION utl.normalize_vin (ivin tvin) FROM PUBLIC;


\i cleanup.sql;
