SET bedb.filename = 'function.get_user_action_config.sql';

\i set_be_env.sql;
/* Returns the config row for the provided make, service and action type.
Added for DI #1475 */
DROP FUNCTION IF EXISTS utl.get_user_action_config(beowner.make.make_id%type,
                                                   beowner.svc.svc_id%type,
                                                   beowner.usr_actions.type%type);
CREATE OR REPLACE FUNCTION utl.get_user_action_config(i_make_id beowner.make.make_id%type,
                                                      i_svc_id beowner.svc.svc_id%type,
                                                      i_action_type beowner.usr_actions.type%type)
    RETURNS beowner.make_user_actions_config AS
$body$
DECLARE

    l_make_user_actions_config beowner.make_user_actions_config;

BEGIN
    BEGIN
        SELECT *
        INTO STRICT l_make_user_actions_config
        FROM beowner.make_user_actions_config
        WHERE make_id = i_make_id
          AND svc_id = i_svc_id
          AND TYPE = i_action_type;
    EXCEPTION
        WHEN no_data_found THEN
            NULL;
    END;

    RETURN l_make_user_actions_config;
END;

    -- OnTime #23029
    --USR_CREATE_TYPES deprecated for DCS1E-803 : DB - Deprecate the indicated tables
$body$
    LANGUAGE PLPGSQL
    STABLE;
-- REVOKE ALL ON FUNCTION utl.get_user_action_config (i_make_id make.make_id%TYPE, i_svc_id svc.svc_id%TYPE, i_action_type usr_actions.type%TYPE) FROM PUBLIC;

\i cleanup.sql;
