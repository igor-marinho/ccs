SET bedb.filename = 'function.get_dummy_cursor.sql';

\i set_be_env.sql;

-------------------------------------------------------------------------------
/*
   GET_DUMMY_CURSOR: Opens up an absolutely minimal cursor to avoid data access
					 issues with the client DAO layer.
*/

CREATE OR REPLACE FUNCTION utl.get_dummy_cursor()
RETURNS REFCURSOR
AS
$BODY$
DECLARE
    rslt REFCURSOR;
BEGIN
    OPEN rslt FOR
    SELECT NULL
     WHERE NULL IS NOT NULL;
    RETURN rslt;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
