SET bedb.filename = 'function.is_device_id_valid.sql';

\i set_be_env.sql;

/* Returns true if the input device_id is a valid value in device table, false otherwise */
CREATE OR REPLACE FUNCTION utl.is_device_id_valid(IN i_device_id TEXT)
RETURNS BOOLEAN
AS
$BODY$
DECLARE
    l_found varchar(1);
BEGIN
    SELECT 1
      INTO STRICT l_found
      FROM beowner.device
     WHERE device_id = i_device_id;
    
    RETURN TRUE;
   
    EXCEPTION
        WHEN no_data_found THEN
            RETURN FALSE;
END;
$BODY$
LANGUAGE  plpgsql STABLE;

\i cleanup.sql;
