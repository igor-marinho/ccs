SET bedb.filename = 'function.dec_to_bin.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS utl.dec_to_bin(INTEGER); 
   /*  onTime Work Item#6752
       function dec_to_bin
   
       Takes the supplied day (Sunday=1 ... Saturday=64) and transforms
       it into a value in a binary format:
   
         Sunday   :  1 => 0000001
         Monday   :  2 => 0000010
         Tuesday  :  4 => 0000100
         Wednesday:  8 => 0001000
         Thursday : 16 => 0010000
         Friday   : 32 => 0100000
         Saturday : 64 => 1000000
   */
CREATE OR REPLACE FUNCTION utl.dec_to_bin (n INTEGER) RETURNS TEXT 
AS $body$
DECLARE

      binval varchar(64) := '0';
      n2     INTEGER := n;

BEGIN
      WHILE(n2 > 0)
      LOOP
         binval := MOD(n2, 2) || binval;
         n2 := trunc(n2 / 2);
      END LOOP;

      RETURN lpad(binval, 8, '0');
   END;

$body$
LANGUAGE PLPGSQL
IMMUTABLE
;
-- REVOKE ALL ON FUNCTION utl.dec_to_bin (n bigint) FROM PUBLIC;

\i cleanup.sql;
