SET bedb.filename = 'function.arr_to_cur.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS utl.arr_to_cur(anyarray);

CREATE OR REPLACE FUNCTION utl.arr_to_cur(arr anyarray) RETURNS refcursor 
AS 
$body$
DECLARE
cur refcursor;
BEGIN
    OPEN cur for 
        select * from unnest(arr);
    RETURN cur;
END;
$body$
LANGUAGE plpgsql
VOLATILE;

\i cleanup.sql;
