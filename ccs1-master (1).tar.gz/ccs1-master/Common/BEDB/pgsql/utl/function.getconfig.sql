SET bedb.filename = 'function.getconfig.sql';

\i set_be_env.sql;

/*
  CONFIG utility
  Save/Set configuration data
*/

CREATE OR REPLACE FUNCTION utl.getconfig(IN icfgname TEXT)
RETURNS TEXT
AS
$BODY$
DECLARE
    rslt TEXT;
BEGIN
    SELECT value
      INTO STRICT rslt
      FROM beowner.cfg
     WHERE name = icfgname;

    RETURN rslt;
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
