SET bedb.filename = 'function.is_usr_create_type_id_valid.sql';

\i set_be_env.sql;

-- OnTime #23029 
--USR_CREATE_TYPES deprecated for DCS1E-803 : DB - Deprecate the indicated tables  

CREATE OR REPLACE FUNCTION utl.is_usr_create_type_id_valid(IN i_usr_create_type TEXT)
RETURNS BOOLEAN
AS
$BODY$
DECLARE
    is_domain_valid BOOLEAN;
BEGIN
 
    SELECT utl.is_domain_value_valid(utl.get_constant_value('c_domain_usr_create_type'), i_usr_create_type)
     INTO STRICT is_domain_valid;
   
    RETURN is_domain_valid;
   
    EXCEPTION
        WHEN no_data_found
        THEN
            RETURN FALSE;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
