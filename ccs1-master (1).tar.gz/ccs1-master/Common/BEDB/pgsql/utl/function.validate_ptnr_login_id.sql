SET bedb.filename = 'function.validate_ptnr_login_id.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION utl.validate_ptnr_login_id(IN i_ptnr_id UUID, IN i_login_id TEXT)
RETURNS cnst.vc
AS
$BODY$
DECLARE
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN

    IF i_ptnr_id IS NULL
    THEN
        RETURN cnst.ginvalidctxptnrid();
    END IF;

    IF i_login_id IS NULL
    THEN
        RETURN cnst.g_null_login_id();
    END IF;
   
    PERFORM ctx.set(IPTNRID := i_ptnr_id, ILOGINID := i_login_id);
   
    RETURN utl.get_constant_value('csuccess');
   
    EXCEPTION
        WHEN SQLSTATE 'EPTNR'
        THEN
            RETURN utl.get_constant_value('cdbpartneridnotvalid');
                
        WHEN SQLSTATE 'EUSRN' 
        THEN
            RETURN utl.get_constant_value('cnosuchuser');
          
        WHEN OTHERS
        THEN
            GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,              
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

            perform trc.log(iadditionaldata => NULL,
                            iexception_diagnostics => l_exception_diagnostics);
                       
            RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
