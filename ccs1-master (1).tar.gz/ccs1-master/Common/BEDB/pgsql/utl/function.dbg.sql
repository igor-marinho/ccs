SET bedb.filename = 'function.dbg.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION utl.dbg(IN i_text TEXT)
RETURNS void
AS
$BODY$
BEGIN
    
    IF utl.get_session_variable(i_parent_namespace => 'crudg_subscription', i_child_namespace => 'dbg', i_name => 'g_debug_on') = cnst.g_yes()
    then    
        RAISE DEBUG USING MESSAGE = i_text;
    END IF;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
