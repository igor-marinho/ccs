SET bedb.filename = 'procedure.docommit.sql';

\i set_be_env.sql;

-------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE utl.docommit () AS $body$
BEGIN
      IF current_setting('utl.gtransactions')::boolean
      THEN
         COMMIT;
      END IF;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE utl.docommit () FROM PUBLIC;

\i cleanup.sql;
