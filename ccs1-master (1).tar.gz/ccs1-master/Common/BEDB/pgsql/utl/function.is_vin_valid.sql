SET bedb.filename = 'function.is_vin_valid.sql';

\i set_be_env.sql;

/* Jira CR10212-35 validates the VIN against VIN table. IF valid, returns dofu and make too. */
CREATE OR REPLACE FUNCTION utl.is_vin_valid(IN i_vin beowner.vin.vin%TYPE,
                                            OUT o_status_code BOOLEAN,
                                            OUT o_make_id beowner.make.make_id%TYPE,
                                            OUT o_dofu beowner.vin.dofu%TYPE)
AS
$BODY$
BEGIN
    SELECT make_id,
           dofu
    INTO STRICT o_make_id,
        o_dofu
    FROM beowner.vin
    WHERE vin = i_vin;
    o_status_code = TRUE;
    RETURN;
EXCEPTION
    WHEN no_data_found THEN
        o_status_code = FALSE;
        RETURN;
END;


$BODY$
LANGUAGE PLPGSQL
 STABLE;
-- REVOKE ALL ON FUNCTION utl.is_vin_valid (i_vin vin.vin%TYPE, o_make_id OUT make.make_id%TYPE, o_dofu OUT vin.dofu%TYPE) FROM PUBLIC;


\i cleanup.sql;
