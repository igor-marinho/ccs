SET bedb.filename = 'procedure.setconfig.sql';

\i set_be_env.sql;

   -------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE utl.setconfig (icfgname text, icfgvalue text) AS $body$
BEGIN
      MERGE INTO cfg dst
      USING(SELECT icfgname  NAME,
                    icfgvalue VALUE
               ) src
      ON (dst.name = src.name)
      WHEN MATCHED THEN
         UPDATE
            SET dst.value = src.value
      WHEN NOT MATCHED THEN
         INSERT(dst.name, dst.value)
         VALUES (src.name, src.value);
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE utl.setconfig (icfgname text, icfgvalue text) FROM PUBLIC;

\i cleanup.sql;
