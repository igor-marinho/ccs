SET bedb.filename = 'function.get_dba_errors.sql';

\i set_be_env.sql;

   -------------------------------------------------------

   -- JIRA PU-16 Oracle 12c upgrade - DB Dev work for compatibilty
CREATE OR REPLACE FUNCTION utl.get_dba_errors () RETURNS SETOF P_ROW_TAB AS $body$
DECLARE

      l_row recinfo;

      cx CURSOR FOR
         SELECT owner,
                NAME,
                TYPE,
                line,
                position,
                text
           FROM sys.dba_errors
          WHERE attribute = 'ERROR'
          ORDER BY TYPE,
                   NAME,
                   sequence;


BEGIN
      OPEN cx;
      LOOP
         FETCH cx
            INTO l_row;
         EXIT WHEN NOT FOUND; /* apply on cx */
         RETURN NEXT l_row;
      END LOOP;
      CLOSE cx;

      RETURN;
   END;
   -------------------------------------------------------
$body$
LANGUAGE PLPGSQL
 STABLE;
-- REVOKE ALL ON FUNCTION utl.get_dba_errors () FROM PUBLIC;

\i cleanup.sql;
