SET bedb.filename = 'function.get_svc_log_exclusions.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS utl.get_svc_log_exclusions() ;

CREATE OR REPLACE FUNCTION utl.get_svc_log_exclusions (o_status_code OUT INTEGER, o_result OUT refcursor)
AS
$BODY$
DECLARE
      l_action text;      
      l_module_name text := 'get_svc_log_exclusions';
      l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    l_action := utl.set_module_action( l_module_name, 'Getting list of excluded services');

    OPEN o_result FOR
    SELECT
        slc.svc_id, slc.tel_type
        FROM beowner.svc_log_exclude AS slc
        ORDER BY slc.svc_id::INTEGER;

    o_status_code := utl.get_constant_value('csuccess');
    RETURN;

    EXCEPTION
        WHEN others THEN
        GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,              
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;

            call trc.log(iadditionaldata => NULL,
                         iexception_diagnostics => l_exception_diagnostics); 
            
            o_status_code := utl.get_constant_value('cinternalerror');
            RETURN;
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;

