SET bedb.filename = 'function.set_milestone.sql';

\i set_be_env.sql;

   -- Added for OnTime WI #16083
   -- Sets the current milestone into the global variable, to be used in triggers that write to seed data history tables
drop function if exists utl.set_milestone;

CREATE OR REPLACE FUNCTION utl.set_milestone ()
returns text
 AS $body$
DECLARE

      l_milestone beowner.release_manifest.milestone%TYPE;

BEGIN
  BEGIN
    SELECT milestone
      INTO STRICT l_milestone
      FROM beowner.release_manifest
    ORDER BY created_date desc
     LIMIT 1;

  exception
    WHEN others
    then
      l_milestone := 'unset';

  END;

  PERFORM set_config('bedb.milestone', l_milestone,false);
  RETURN l_milestone;  

END;
$body$
LANGUAGE PLPGSQL;

\i cleanup.sql;
