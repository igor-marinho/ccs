SET bedb.filename = 'procedure.set_test_mode_on.sql';

\i set_be_env.sql;


/* SBM-586 Sets test mode on, which allows the caller to create a test-condition that can not be reproed */
CREATE OR REPLACE FUNCTION utl.set_test_mode_on()
RETURNS void
AS
$BODY$
BEGIN
    PERFORM utl.Init();
    PERFORM aws_oracle_ext.set_package_variable('BEOWNER', 'UTL', 'g_test_mode_on', TRUE);
    PERFORM beowner.trc$log('Test mode is on!'::TEXT);
END;
$BODY$
LANGUAGE  plpgsql;
\i cleanup.sql;
