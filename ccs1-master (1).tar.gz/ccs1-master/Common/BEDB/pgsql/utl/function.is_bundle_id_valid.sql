SET bedb.filename = 'function.is_bundle_id_valid.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS utl.is_bundle_id_valid(TEXT);
   /* Returns true if the input Bundle ID is a valid bundle in the bndl table, false otherwise */
CREATE OR REPLACE FUNCTION utl.is_bundle_id_valid (i_bndl_id UUID) RETURNS boolean AS $body$
DECLARE

      l_found varchar(1);

BEGIN
      SELECT 1
        INTO STRICT l_found
        FROM beowner.bndl
       WHERE bndl_id = i_bndl_id;

      RETURN TRUE;
   EXCEPTION
      WHEN no_data_found THEN
         RETURN FALSE;
   END;

   /* Returns true if the allowed_status is a valid value, false otherwise */
$body$
LANGUAGE PLPGSQL
 STABLE;
-- REVOKE ALL ON FUNCTION utl.is_bundle_id_valid (i_bndl_id text) FROM PUBLIC;

\i cleanup.sql;
