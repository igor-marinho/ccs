SET bedb.filename = 'function.is_trade_region_valid.sql';

\i set_be_env.sql;


   /* Returns true if the input trade region is a valid code in trade regions table, false otherwise */
CREATE OR REPLACE FUNCTION utl.is_trade_region_valid (i_trade_region text) RETURNS boolean AS $body$
DECLARE

      l_found varchar(1);

BEGIN
      SELECT 1
        INTO STRICT l_found
        FROM beowner.trade_regions
       WHERE code = i_trade_region;

      RETURN TRUE;
   EXCEPTION
      WHEN no_data_found THEN
         RETURN FALSE;
   END;


$body$
LANGUAGE PLPGSQL
 STABLE;
-- REVOKE ALL ON FUNCTION utl.is_trade_region_valid (i_trade_region text) FROM PUBLIC;

\i cleanup.sql;
