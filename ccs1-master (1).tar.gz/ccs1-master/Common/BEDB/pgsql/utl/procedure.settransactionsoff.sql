SET bedb.filename = 'procedure.settransactionsoff.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS utl.settransactionsoff ();    
CREATE OR REPLACE PROCEDURE utl.settransactionsoff () 
AS $body$
BEGIN
      PERFORM set_config('utl.gtransactions', 'FALSE', false);
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE utl.settransactionsoff () FROM PUBLIC;

\i cleanup.sql;
