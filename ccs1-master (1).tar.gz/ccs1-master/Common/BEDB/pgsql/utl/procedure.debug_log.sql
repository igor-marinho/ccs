SET bedb.filename = 'procedure.debug_log.sql';

\i set_be_env.sql;

   /* Sends additional log messages to "trc" table if g_debug_log is set to on, otherwise does nothing */
DROP PROCEDURE IF EXISTS utl.debug_log(text);
CREATE OR REPLACE PROCEDURE utl.debug_log (i_text text) 
AS 
$body$
BEGIN
      IF COALESCE(current_setting('utl.dbg.g_debug_on', 't'), utl.get_constant_value('c_no')) =  utl.get_constant_value('c_yes')
      THEN
         CALL trc.log(iadditionaldata => 'DEBUG LOG : '|| i_text);
      END IF;
   END;
   -- JIRA PU-16 Oracle 12c upgrade - DB Dev work for compatibilty
$body$
LANGUAGE PLPGSQL
;

-- REVOKE ALL ON PROCEDURE utl.debug_log (i_text text) FROM PUBLIC;

\i cleanup.sql;
