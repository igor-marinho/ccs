SET bedb.filename = 'function.get_domain_value_desc.sql';

\i set_be_env.sql;

/* Jira DCS1NOTES-37 - returns the description for the provided domain/value pair */

DROP FUNCTION IF EXISTS utl.get_domain_value_desc (TEXT,TEXT);

CREATE OR REPLACE FUNCTION utl.get_domain_value_desc(IN i_domain TEXT, 
                                                     IN i_value TEXT)
RETURNS TEXT
AS
$BODY$
DECLARE
    l_description BEOWNER.DOMAIN_VALUES.description%TYPE;
BEGIN
	
	IF COALESCE(i_domain, '') = '' OR COALESCE(i_value, '')= '' THEN
        RETURN NULL;
    ELSE
        SELECT
            description
            INTO STRICT l_description
            FROM beowner.domain_values
            WHERE domain = i_domain AND value = i_value;
        RETURN l_description;
    END IF;
    EXCEPTION
        WHEN no_data_found THEN
            RETURN NULL;
END;
$BODY$
LANGUAGE  plpgsql;
\i cleanup.sql;
