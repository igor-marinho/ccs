SET bedb.filename = 'function.day_bit.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS utl.day_bit(TIMESTAMP);
   /*  function day_bit
   
       Takes the supplied day (Sunday=1 ... Saturday=7) and transforms
       it into a value usable for a bitmap:
   
         Sunday   :  1
         Monday   :  2
         Tuesday  :  4
         Wednesday:  8
         Thursday : 16
         Friday   : 32
         Saturday : 64
   
   */
CREATE OR REPLACE FUNCTION utl.day_bit (ts TIMESTAMP DEFAULT current_timestamp) RETURNS INTEGER 
AS $body$
BEGIN
      RETURN power(2, (to_char(ts, 'D'))::INTEGER  - 1);
   END;
$body$
LANGUAGE PLPGSQL
IMMUTABLE
;
-- REVOKE ALL ON FUNCTION utl.day_bit (ts TIMESTAMP DEFAULT systimestamp) FROM PUBLIC;

\i cleanup.sql;
