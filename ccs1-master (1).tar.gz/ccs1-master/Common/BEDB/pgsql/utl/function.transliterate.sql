SET bedb.filename = 'function.transliterate.sql';

\i set_be_env.sql;

   -------------------------------------------------------------------------------
   -- Each character is converted to a specific single-digit numeric value. Only
   -- upper-case characters are computed, and the letters "I", "O", and "Q" are
   -- not allowed. If it doesn't find one of the letters, it tries to convert
   -- whatever is left to a number. If that doesn't work, we'll trap the exception
   -- and throw an error that makes more sense.
CREATE OR REPLACE FUNCTION utl.transliterate (ichar text) RETURNS NATURAL AS $body$
BEGIN
      RETURN CASE ichar WHEN 'A' THEN 1 WHEN 'B' THEN 2 WHEN 'C' THEN 3 WHEN 'D' THEN 4 WHEN 'E' THEN 5 WHEN 'F' THEN 6 WHEN 'G' THEN 7 WHEN 'H' THEN 8 WHEN 'J' THEN 1 WHEN 'K' THEN 2 WHEN 'L' THEN 3 WHEN 'M' THEN 4 WHEN 'N' THEN 5 WHEN 'P' THEN 7 WHEN 'R' THEN 9 WHEN 'S' THEN 2 WHEN 'T' THEN 3 WHEN 'U' THEN 4 WHEN 'V' THEN 5 WHEN 'W' THEN 6 WHEN 'X' THEN 7 WHEN 'Y' THEN 8 WHEN 'Z' THEN 9 ELSE (ichar)::numeric  END;
   EXCEPTION
      WHEN SQLSTATE '50013' THEN
         RAISE EXCEPTION '%', 'VIN must contain only characters 0123456789ABCDEFGHJKLMNPRSTUVWXYZ' USING ERRCODE = '45001';
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION utl.transliterate (ichar text) FROM PUBLIC;

\i cleanup.sql;
