SET bedb.filename = 'function.check_vin_external.sql';

\i set_be_env.sql;

/* TMSCR10655-5 Returns External_vin_DB_code if the VIN is present in the external_vins table, null otherwise */
/*  TMSCR10655-5 */

CREATE OR REPLACE FUNCTION utl.check_vin_external(IN i_vin TEXT)
RETURNS TEXT
AS
$BODY$
DECLARE
    l_external_vin_db_code BEOWNER.MAKE.external_vin_db_code%TYPE;
/* Modified for TMSCR10655-24 */
BEGIN
    BEGIN
        SELECT m.external_vin_db_code
          INTO STRICT l_external_vin_db_code
          FROM beowner.external_vins AS ev
          JOIN beowner.make AS m
            ON (ev.make_id = m.make_id)
         WHERE ev.vin = UPPER(TRIM(i_vin))
           AND ev.vin NOT IN (SELECT v.vin
                                FROM beowner.vin AS v
                               WHERE v.vin = ev.vin);
        EXCEPTION
            WHEN no_data_found THEN
               l_external_vin_db_code := NULL;

    END;
    RETURN l_external_vin_db_code;
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
