SET bedb.filename = 'function.generate_vin.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION utl.generate_vin (ivalue text DEFAULT NULL) RETURNS TVIN AS $body$
DECLARE

      rslt   tvin;
      vvalue text;
      vchar  varchar(1);

BEGIN
      vvalue := upper(trim(both ivalue));

      -- do the first eight letters of the vin
      <<eight>>
      FOR i IN 1 .. 8
      LOOP
         -- grab a letter from the input value at position I
         vchar := substr(vvalue, i, 1);

         -- make sure it's a valid vin number/letter; if not set to NULL
         IF vchar IS NOT NULL AND
            vchar NOT IN ('0',
                          '1',
                          '2',
                          '3',
                          '4',
                          '5',
                          '6',
                          '7',
                          '8',
                          '9',
                          'A',
                          'B',
                          'C',
                          'D',
                          'E',
                          'F',
                          'G',
                          'H',
                          'J',
                          'K',
                          'L',
                          'M',
                          'N',
                          'P',
                          'R',
                          'S',
                          'T',
                          'U',
                          'V',
                          'W',
                          'X',
                          'Y',
                          'Z')
         THEN
            vchar := NULL;
         END IF;

         -- for any NULL character positions, create a random value
         IF vchar IS NULL
         THEN
            <<inner>>
            LOOP
               vchar := dbms_random.string('X', 1);
               EXIT INNER WHEN vchar NOT IN ('I', 'O', 'Q');
            END LOOP INNER;
         END IF;

         -- append that value to the VIN
         rslt := rslt || vchar;
      END LOOP eight;

      -- this is the 9th position
      rslt := rslt || '0';

      -- this sequence generates an 8-digit value
      rslt := rslt || nextval('sq_vin_gen')::varchar;

      -- so now we have 17 digits; compute the check-digit
      vchar := utl.check_digit(rslt);

      -- return the first 8, check digit, second 8, which will be a valid VIN
      RETURN substr(rslt, 1, 8) || vchar || substr(rslt, 10);
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION utl.generate_vin (ivalue text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
