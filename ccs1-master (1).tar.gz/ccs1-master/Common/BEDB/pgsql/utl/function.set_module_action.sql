SET bedb.filename =  'function.set_module_action.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS utl.set_module_action("text","text");
CREATE OR REPLACE FUNCTION utl.set_module_action(IN i_module TEXT, IN i_action TEXT)
    RETURNS text
AS
$BODY$
BEGIN

    -- prevent data overflow in trc.action
    i_action = left(i_action,64);
    
    perform set_config('application_name'
                       --split out the components of the existing application name
                       --if the existing value of application_name is null or empty string, replace it with UNSET
                      ,coalesce(nullif(split_part(current_setting('application_name'),'|',1),''),'UNSET') || '|' || i_module
                      ,false);
                    
    PERFORM set_config('bedb.action', i_action,false);
    return i_action;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
