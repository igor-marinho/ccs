SET bedb.filename = 'function.get_constant_meaning.sql';

\i set_be_env.sql;
CREATE OR REPLACE FUNCTION utl.get_constant_meaning(i_constant_value constant_values.value %TYPE)
      RETURNS constant_values.value%TYPE 
AS $BODY$
DECLARE
      l_comments constant_values.comments %TYPE;
   BEGIN
      SELECT comments
        INTO l_comments
        FROM beowner.constant_values
       WHERE VALUE = i_constant_value
             LIMIT  1;

      RETURN l_comments;
   EXCEPTION
      WHEN no_data_found THEN
         RETURN NULL;
   END
$BODY$
LANGUAGE plpgsql;
   
\i cleanup.sql;
