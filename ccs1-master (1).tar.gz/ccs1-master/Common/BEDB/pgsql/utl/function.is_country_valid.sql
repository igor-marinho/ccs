SET bedb.filename = 'function.is_country_valid.sql';

\i set_be_env.sql;

   /* Returns true if the input country code is a valid code in countries table, false otherwise */

CREATE OR REPLACE FUNCTION utl.is_country_valid (i_country_code text) RETURNS boolean AS $body$
DECLARE

      l_found varchar(1);

BEGIN
      SELECT 1
        INTO STRICT l_found
        FROM beowner.countries
       WHERE code = i_country_code;

      RETURN TRUE;
   EXCEPTION
      WHEN no_data_found THEN
         RETURN FALSE;
   END;


$body$
LANGUAGE PLPGSQL
 STABLE;
-- REVOKE ALL ON FUNCTION utl.is_country_valid (i_country_code text) FROM PUBLIC;

\i cleanup.sql;
