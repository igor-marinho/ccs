SET bedb.filename = 'procedure.push_message_to_queue.sql';

\i set_be_env.sql;

drop function if exists utl.push_message_to_queue(TEXT, XML, TIMESTAMPTZ);

CREATE OR REPLACE FUNCTION utl.push_message_to_queue(i_make_id TEXT, i_key_values XML, i_enqueue_time TIMESTAMPTZ DEFAULT clock_timestamp())
RETURNS void
AS
$BODY$   
declare 
  c_smtp_url CONSTANT VARCHAR(50) := 'http://www.tweddletech.com/SmtpCore';
  l_module_name              text := 'push_message_to_queue';
  l_action                   text;
  l_exception_diagnostics    trc.exception_diagnostics;
BEGIN

  l_action := utl.set_module_action( l_module_name, 'Putting message in queue');
 
  perform utl.enqueue_message(i_make_id => i_make_id
                             ,i_payload => xmlroot(xmlelement(name "ns2:PushRequest",
                                                              xmlattributes(c_smtp_url AS "xmlns:ns2"),
                                                              i_key_values),
                                                   version '1.0" standalone="yes')::text
                             ,i_message_type => pi.push_queue
                             ,i_enqueue_time => i_enqueue_time)
     from beowner.pushq_info pi
    where pi.make_id = i_make_id; 

exception
  WHEN others
  then
    GET STACKED DIAGNOSTICS
      l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
      l_exception_diagnostics.column_name := COLUMN_NAME,
      l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
      l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
      l_exception_diagnostics.message_text := MESSAGE_TEXT,
      l_exception_diagnostics.table_name := TABLE_NAME,
      l_exception_diagnostics.schema_name := SCHEMA_NAME,
      l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
      l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
      l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

    l_exception_diagnostics.module_name := l_module_name;
    l_exception_diagnostics.action := l_action;

    CALL trc.log(iadditionaldata => NULL,
                 iexception_diagnostics => l_exception_diagnostics);
    RAISE;        
          
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
