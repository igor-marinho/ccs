SET bedb.filename = 'function.is_user_relation_static.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION utl.is_user_relation_static ()
RETURNS BOOLEAN
AS
$BODY$
DECLARE
    v_make_id beowner.make.make_id%TYPE;
    v_is_user_relation_static boolean;
BEGIN
	
	SELECT make_id
        INTO v_make_id
        FROM beowner.ctx_data;

      IF v_make_id IS NOT NULL
      THEN
        v_is_user_relation_static := (utl.get_user_relation_config(i_make_id => v_make_id) = utl.get_constant_value('c_user_relation_static'));
        return v_is_user_relation_static;
      ELSE
         raise exception using errcode = utl.get_constant_value('e_invalidmake');
      END IF;
END;
$BODY$
language plpgsql stable;

\i cleanup.sql;
