SET bedb.filename = 'init_push_queues.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION utl.init_push_queues()
RETURNS void
AS
$BODY$
DECLARE
    queues_rec RECORD;
BEGIN
    PERFORM utl.Init();

    FOR queues_rec IN
    SELECT
        make_id, push_queue, exception_queue
        FROM beowner.pushq_info
    LOOP
        PERFORM aws_oracle_ext.array$set_value('g_push_queues[''' || queues_rec || '''].push_queue', 'beowner.utl', queues_rec.push_queue);
        PERFORM aws_oracle_ext.array$set_value('g_push_queues[''' || queues_rec || '''].exception_queue', 'beowner.utl', queues_rec.exception_queue);
    END LOOP;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;

