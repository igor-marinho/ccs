SET bedb.filename = 'function.get_user_relation_config.sql';

\i set_be_env.sql;

/* Returns value of make.user_inter_relation for the provided make
Added for OnTime WI #15750 */

CREATE OR REPLACE FUNCTION utl.get_user_relation_config(IN i_make_id TEXT)
RETURNS TEXT
AS
$BODY$
DECLARE
    l_user_inter_relation BEOWNER.MAKE.user_inter_relation%TYPE;
BEGIN
    BEGIN
        SELECT
            user_inter_relation
            INTO STRICT l_user_inter_relation
            FROM beowner.make
            WHERE make_id = i_make_id;
        EXCEPTION
            WHEN no_data_found THEN
                NULL;
    END;
    RETURN COALESCE(l_user_inter_relation, utl.get_constant_value('c_user_relation_static'));
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
