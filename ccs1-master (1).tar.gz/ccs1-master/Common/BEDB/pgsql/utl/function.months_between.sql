SET bedb.filename = 'function.months_between.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS utl.months_between(timestamptz, timestamptz) CASCADE;

CREATE OR REPLACE FUNCTION utl.months_between(IN timestamp1 timestamptz, IN timestamp2 timestamptz)
RETURNS NUMERIC 
AS
$BODY$
DECLARE
  vage INTERVAL;
BEGIN
    vage := age(timestamp1, timestamp2);
    RETURN date_part ('year', vage) * 12 + date_part ('month', vage) + date_part ('day', vage)/31;
END;
$BODY$
LANGUAGE  plpgsql
IMMUTABLE;
\i cleanup.sql;
