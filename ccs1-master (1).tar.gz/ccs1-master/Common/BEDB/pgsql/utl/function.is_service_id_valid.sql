SET bedb.filename = 'function.is_service_id_valid.sql';

\i set_be_env.sql;

   /* Returns true if the input Service ID is a valid service in the svc table, false otherwise */

CREATE OR REPLACE FUNCTION utl.is_service_id_valid (i_svc_id text) RETURNS boolean AS $body$
DECLARE

      l_found varchar(1);

BEGIN
      SELECT 1
        INTO STRICT l_found
        FROM beowner.svc
       WHERE svc_id = i_svc_id;

      RETURN TRUE;
   EXCEPTION
      WHEN no_data_found THEN
         RETURN FALSE;
   END;


$body$
LANGUAGE PLPGSQL
 STABLE;
-- REVOKE ALL ON FUNCTION utl.is_service_id_valid (i_svc_id text) FROM PUBLIC;

\i cleanup.sql;
