SET bedb.filename = 'get_random_password.sql';

\i set_be_env.sql;

-------------------------------------
/* SBM-280 */
CREATE OR REPLACE FUNCTION utl.get_random_password()
RETURNS TEXT
AS
$BODY$
DECLARE 
  lv_cnt INTEGER; 
  lv_length INTEGER := 50;     --Password Length
  lv_out TEXT := ''; 
  i INTEGER; -- loop counter 
BEGIN
    -- Min loop count to get the desired length of chars
    lv_cnt := CEIL(lv_length/ 32.);  
	FOR i IN 1..lv_cnt 
      LOOP
        lv_out := lv_out || md5(random()::TEXT);
      END LOOP; 
  -- get the UPPER string with desired character length 
  RETURN upper(substring(lv_out,1,lv_length)); 
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
