SET bedb.filename = 'procedure.set_operation.sql';

\i set_be_env.sql;

   /* OnTime WI #15972 - should be called before any significant operation within the procedure/function
   e.g. utl.set_operation(l_module_name,'Validating inputs'); */

CREATE OR REPLACE PROCEDURE utl.set_operation (i_operation text) AS $body$
DECLARE 
      l_module_name text := 'set_operation';
BEGIN
      PERFORM utl.set_module_action( upper(coalesce(current_setting('application_name') , l_module_name) ||
                                       ':' || i_operation);
   END;

   -------------------------------------------------------------------------------
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE utl.set_operation (i_operation text, i_line bigint) FROM PUBLIC;

\i cleanup.sql;
