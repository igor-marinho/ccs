SET bedb.filename = 'procedure.log_it.sql';

\i set_be_env.sql;


/* DDCRD-576 Used mostly just for DDL scripts included in releases */
-------------------------------------   
DROP FUNCTION IF EXISTS utl.log_it( text);
CREATE OR REPLACE FUNCTION utl.log_it(IN i_text TEXT)
RETURNS void
AS
$BODY$
begin
	
    RAISE INFO USING MESSAGE = i_text::TEXT;
    call trc.log(i_text);
END;
$BODY$
LANGUAGE  plpgsql;
\i cleanup.sql;
