SET bedb.filename = 'function.get_default_usr_create_type.sql';

\i set_be_env.sql;


/* Returns the default user create type for the make, for use in legacy code
Added for OnTime #23029 */

-- OnTime #23029 

CREATE OR REPLACE FUNCTION utl.get_default_usr_create_type(IN i_make_id TEXT)
RETURNS TEXT
AS
$BODY$
DECLARE
    l_default_create_type BEOWNER.MAKE.default_usr_create_type%TYPE;
BEGIN
    
    SELECT default_usr_create_type
      INTO STRICT l_default_create_type
      FROM beowner.make
     WHERE make_id = i_make_id;
    
    RETURN COALESCE(l_default_create_type, utl.get_constant_value('c_default_create_type'));
   
    EXCEPTION
        WHEN no_data_found THEN
            RETURN utl.get_constant_value('c_default_create_type');
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
