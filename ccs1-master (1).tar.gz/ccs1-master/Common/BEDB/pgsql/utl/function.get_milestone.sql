SET bedb.filename = 'function.get_milestone.sql';

\i set_be_env.sql;

drop function if exists utl.get_milestone;

CREATE OR REPLACE function utl.get_milestone()
returns text
AS $body$
BEGIN
 return coalesce(nullif(current_setting('bedb.milestone',true),''),utl.set_milestone());
END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;

\i cleanup.sql;
