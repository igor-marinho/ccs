SET bedb.filename = 'function.enqueue_message.sql';

\i set_be_env.sql;

drop function if exists utl.enqueue_message(varchar,text,varchar,timestamptz);

CREATE OR REPLACE FUNCTION utl.enqueue_message(i_make_id beowner.message_queue.make_id%type
                                              ,i_payload beowner.message_queue.payload%type
                                              ,i_message_type beowner.message_queue.message_type%TYPE
                                              ,i_enqueue_time beowner.message_queue.enqueue_time%TYPE DEFAULT clock_timestamp())
RETURNS UUID
AS
$BODY$
declare
    l_module_name text := 'enqueue_message';
    l_action text;
    l_exception_diagnostics trc.exception_diagnostics;
    l_message_id beowner.message_queue.message_id%type;
  
BEGIN	

  l_action := utl.set_module_action( l_module_name, ' Inserting into message_queue');

  INSERT INTO beowner.message_queue (message_id, message_type, enqueue_time, make_id, payload)
  values (beowner.rand_guid(), i_message_type, i_enqueue_time, i_make_id, i_payload)
  returning message_id into l_message_id;
    
  RETURN l_message_id; 
     
EXCEPTION
  WHEN others
  THEN
     GET STACKED diagnostics
      l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
      l_exception_diagnostics.column_name := COLUMN_NAME,
      l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
      l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
      l_exception_diagnostics.message_text := MESSAGE_TEXT,
      l_exception_diagnostics.table_name := TABLE_NAME,
      l_exception_diagnostics.schema_name := SCHEMA_NAME,              
      l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
      l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
      l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
	  l_exception_diagnostics.module_name := l_module_name;
      l_exception_diagnostics.action := l_action;
      
    call trc.log(iadditionaldata => NULL,
                    iexception_diagnostics => l_exception_diagnostics);                          
                   
RAISE;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
