SET bedb.filename =  'function.set_action.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS utl.set_action("text");
CREATE OR REPLACE FUNCTION utl.set_action( IN i_action TEXT)
    RETURNS text
AS
$BODY$
BEGIN

    -- prevent data overflow in trc.action
    i_action = left(i_action,64);
    
    PERFORM set_config('bedb.action', i_action,false);
    return i_action;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
