SET bedb.filename = 'procedure.dorollback.sql';

\i set_be_env.sql;

   -------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE utl.dorollback () AS $body$
BEGIN
      IF current_setting('utl.gtransactions')::boolean
      THEN
         ROLLBACK;
      END IF;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE utl.dorollback () FROM PUBLIC;

\i cleanup.sql;
