SET bedb.filename = 'function.weight.sql';

\i set_be_env.sql;

   -------------------------------------------------------------------------------
   /*
       VIN utilities
   
       The following code specializes VIN check-sum validation.
   
       A VIN is 17 characters. The 9th character is the check-digit.
   
       Each character is transliterated to a number using the TRANSLITERATE function.
   
       Each number is multiplied by a WEIGHT value based on the position of the character.
   
       The check-digit is computed by adding the values for each character * weight,
       computing the sum *mod* 11. If the modulus is 10, then the checksum is "X"
       otherwise it's the value of the modulus.
   
   */

   -------------------------------------------------------------------------------
   -- based on the position of the character, multiply the character value by the weight.
   -- position 9 is 0, therefore this will return 0, which means position 9 does not
   -- factor into the final calculation.
CREATE OR REPLACE FUNCTION utl.weight (ichar NATURAL, ipos NATURAL) RETURNS NATURAL AS $body$
BEGIN
      RETURN ichar * CASE ipos WHEN 1 THEN 8 WHEN 2 THEN 7 WHEN 3 THEN 6 WHEN 4 THEN 5 WHEN 5 THEN 4 WHEN 6 THEN 3 WHEN 7 THEN 2 WHEN 8 THEN 10 WHEN 9 THEN 0 WHEN 10 THEN 9 WHEN 11 THEN 8 WHEN 12 THEN 7 WHEN 13 THEN 6 WHEN 14 THEN 5 WHEN 15 THEN 4 WHEN 16 THEN 3 WHEN 17 THEN 2 END;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION utl.weight (ichar NATURAL, ipos NATURAL) FROM PUBLIC;

\i cleanup.sql;
