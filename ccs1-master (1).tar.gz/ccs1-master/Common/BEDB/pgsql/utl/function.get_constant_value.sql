SET bedb.filename = 'function.get_constant_value.sql';

\i set_be_env.sql;

   /* DCS1E-1307 Get the value for the provide constant from table constant_values */
   -- DCS1E-1307
CREATE OR REPLACE FUNCTION utl.get_constant_value (i_constant beowner.constant_values.named_constant%TYPE) 
RETURNS beowner.constant_values.value%TYPE 
AS $BODY$
DECLARE

      l_value beowner.constant_values.value%TYPE;

BEGIN
      SELECT VALUE
        INTO STRICT l_value
        FROM beowner.constant_values
       WHERE named_constant = lower(i_constant);

      RETURN l_value;
   EXCEPTION
      WHEN no_data_found THEN
         RETURN - 1;
   END;
--END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
