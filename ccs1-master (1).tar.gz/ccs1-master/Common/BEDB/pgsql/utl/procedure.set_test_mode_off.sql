SET bedb.filename = 'procedure.set_test_mode_off.sql';

\i set_be_env.sql;

/* SBM-586 Sets test mode off, which disallows the caller to create a test-condition that can not be reproed */
CREATE OR REPLACE FUNCTION utl.set_test_mode_off()
RETURNS void
AS
$BODY$
BEGIN
    PERFORM utl.Init();
    PERFORM aws_oracle_ext.set_package_variable('BEOWNER', 'UTL', 'g_test_mode_on', FALSE);
    PERFORM beowner.trc$log('Test mode is off!'::TEXT);
END;
$BODY$
LANGUAGE  plpgsql;
\i cleanup.sql;
