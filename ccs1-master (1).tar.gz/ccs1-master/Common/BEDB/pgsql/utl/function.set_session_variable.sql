SET bedb.filename = 'function.set_session_variable.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION utl.set_session_variable(IN i_parent_namespace TEXT, in i_child_namespace text, in i_name text, in i_value text)
RETURNS VOID
AS
$BODY$
DECLARE
    v_return text;
BEGIN
   perform set_config(lower(i_parent_namespace) || '.' || lower(i_child_namespace) || '.' || lower(i_name), i_value, false);
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
