SET bedb.filename = 'function.check_device_external.sql';

\i set_be_env.sql;

/* TMSCR10655-6 Returns true if this device is an external device, false otherwise */
-------------------------------------
/*  TMSCR10655-6 */
DROP FUNCTION IF EXISTS utl.check_device_external(text);
CREATE OR REPLACE FUNCTION utl.check_device_external(IN i_device_id TEXT)
RETURNS TEXT
AS
$BODY$
DECLARE
    l_external CHARACTER VARYING(1);
BEGIN
    SELECT
        1
        INTO STRICT l_external
        FROM beowner.external_device_classes
        WHERE i_device_id LIKE CONCAT_WS('', device_init_char, '%');
    RETURN utl.get_constant_value('c_yes');
    EXCEPTION
        WHEN no_data_found THEN
            RETURN utl.get_constant_value('c_no');
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
