 SET bedb.filename = 'procedure.checkvinconflict.sql';

\i set_be_env.sql;

-------------------------------------------------------------------------------
/*
  CheckVinConflict - This is called *after* a subscription record has changed.
	- Checks the subscription data for a given VIN (or CTX_DATA.VIN)
	- If there is only one record for the VIN and it is marked as CONFLICT, then remove the conflict.
	- If there are multiple records for the VIN and the record(s) are not currently
	  marked as CONFLICT, then set the conflict date
*/
DROP FUNCTION IF EXISTS utl.checkvinconflict(TEXT);

CREATE OR REPLACE PROCEDURE utl.checkvinconflict(ivin TEXT DEFAULT NULL)
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'checkvinconflict';
    vcount INTEGER;
    vev INTEGER;
    vrslt INTEGER;
    vvin BEOWNER.VIN.vin%TYPE;
BEGIN
    l_action := utl.set_module_action( l_module_name, 'utl.checkVinConflict');

    /* get the VIN we're going to use -- */
    SELECT
        COALESCE(ivin, cd.vin)
        INTO STRICT vvin
        FROM beowner.ctx_data AS cd;
    
    l_action := utl.set_action('check for conflict records for vin ' || vvin);

    /* check for conflict records -- */
    SELECT
        COUNT(*)
        INTO STRICT vcount
        FROM beowner.subscription AS s
        WHERE s.vin = vvin;

    IF vcount = 1
    /* we have no conflict, so make sure that particular record is cleared */
    THEN
        UPDATE beowner.subscription
           SET conflict = NULL
         WHERE vin = vvin
           AND conflict IS NOT NULL;
    ELSIF vcount > 1 THEN
     l_action := utl.set_action(' ' || vcount || ' Conflict records for vin ' || vvin);

        /* we have a conflict, so make sure all records currently not marked are set */
        UPDATE beowner.subscription
        SET conflict = clock_timestamp()
            WHERE vin = vvin
           AND conflict IS NULL;
           
     l_action := utl.set_action('Check if there is EV/FCV Conflict on vin ' || vvin);
                                                  
 
        /* check to see if we have an EV/FCV device. Modified for OnTime WI #15529 */
        SELECT
            COUNT(*)
            INTO STRICT vev
            FROM beowner.vin
            WHERE utl.is_conflict_enforced(device_id) = 'Y'
              AND vin = vvin;

        IF vev > 0 THEN
            CALL utl.dbg('Invalidating contract');
     l_action := utl.set_action('Invalidate contract for as subscriptions for vin ' || vvin);

            /* Note: if the invalidation failed it will be written to trc by contract.invalidate_contract */
            vrslt := contract.invalidate_contract(vvin);
        END IF;
    END IF;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;

