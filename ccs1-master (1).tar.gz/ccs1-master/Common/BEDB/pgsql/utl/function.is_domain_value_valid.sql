SET bedb.filename = 'function.is_domain_value_valid.sql';

\i set_be_env.sql;

   /* Jira TCP-144 validates the provided domain and value against new generic table domain_values */
   ------------------------------------------------------   
CREATE OR REPLACE FUNCTION utl.is_domain_value_valid (i_domain beowner.domain_values.domain%TYPE, i_value beowner.domain_values.value%TYPE) RETURNS boolean 
AS 
$body$
DECLARE

      l_found varchar(1);

BEGIN
      IF i_domain IS NULL OR
         i_value IS NULL
      THEN
         RETURN FALSE;
      ELSE
         SELECT 1
           INTO STRICT l_found
           FROM beowner.domain_values
          WHERE domain = i_domain
                AND VALUE = i_value;
         RETURN TRUE;
      END IF;
   EXCEPTION
      WHEN no_data_found THEN
         RETURN FALSE;
   END;
   -------------------
$body$
LANGUAGE PLPGSQL
 STABLE;
-- REVOKE ALL ON FUNCTION utl.is_domain_value_valid (i_domain domain_values.domain%TYPE, i_value domain_values.value%TYPE) FROM PUBLIC;

\i cleanup.sql;
