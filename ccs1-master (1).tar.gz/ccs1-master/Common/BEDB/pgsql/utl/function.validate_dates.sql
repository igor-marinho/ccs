SET bedb.filename = 'function.validate_dates.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS utl.validate_dates(timestamp, timestamp);

   /* CR10303 basic validation for from and to dates */
CREATE OR REPLACE FUNCTION utl.validate_dates(i_from_date timestamp, i_to_date timestamp) RETURNS TEXT AS $body$
BEGIN
      IF i_from_date IS NULL OR
         i_to_date IS NULL
      THEN
         RETURN utl.get_constant_value('c_from_to_dates_required');
      ELSIF i_from_date >= i_to_date
      THEN
         RETURN utl.get_constant_value('c_to_date_not_after_from_date');
      ELSE
         RETURN utl.get_constant_value('csuccess');
      END IF;
   END;
   -- Jira SBM-124
$body$
LANGUAGE PLPGSQL
IMMUTABLE;
-- REVOKE ALL ON FUNCTION utl.validate_dates (i_from_date timestamp, i_to_date timestamp) FROM PUBLIC;

\i cleanup.sql;
