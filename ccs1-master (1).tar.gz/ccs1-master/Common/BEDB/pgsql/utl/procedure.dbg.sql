SET bedb.filename = 'procedure.dbg.sql';

\i set_be_env.sql;

/* Sends the messages to dbms_output if debugg is set to on, otherwise does nothing */
CREATE OR REPLACE PROCEDURE utl.dbg(IN i_text TEXT)
AS
$BODY$
BEGIN
    
    IF utl.get_session_variable(i_parent_namespace => 'utl', i_child_namespace => 'dbg', i_name => 'g_debug_on') = utl.get_constant_value('c_yes')
    then    
        RAISE DEBUG USING MESSAGE = i_text;
    END IF;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;

