SET bedb.filename = 'procedure.set_debug_off.sql';

\i set_be_env.sql;

/*  Sets debug mode to no, to stop sending debug messages to dbms_output  */  
DROP PROCEDURE IF EXISTS utl.set_debug_off();
CREATE OR REPLACE PROCEDURE utl.set_debug_off()
AS
$BODY$
BEGIN
    PERFORM utl.set_session_variable (i_parent_namespace => 'utl', i_child_namespace => 'dbg', i_name => 'g_debug_on', i_value => utl.get_constant_value('c_no') );
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
