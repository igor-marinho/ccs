SET bedb.filename = 'function.check_digit.sql';

\i set_be_env.sql;

   -------------------------------------------------------------------------------
   -- Compute the check-digit. It's simple enough: add up the 17 character values
   -- that are transliterated and multiplied by weight. Then take the result MOD 11
   -- and return the check-digit character.
CREATE OR REPLACE FUNCTION utl.check_digit (ivin tvin) RETURNS varchar AS $body$
DECLARE

      vsum NATURAL := 0;

BEGIN
      FOR i IN 1 .. 17
      LOOP
         vsum := vsum + utl.weight(utl.transliterate(substr(ivin, i, 1)), i);
      END LOOP;

      vsum := MOD(vsum, 11);

      RETURN CASE vsum WHEN 10 THEN 'X' ELSE vsum::varchar END;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION utl.check_digit (ivin tvin) FROM PUBLIC;

\i cleanup.sql;
