SET bedb.filename = 'function.gen_bi_script.sql';

\i set_be_env.sql;

   /* Utility to generate scripts for BI reporting */

CREATE OR REPLACE FUNCTION utl.gen_bi_script (i_table_name text) RETURNS text AS $body$
DECLARE


      c_line_ret CONSTANT varchar(1) := chr(10);

      l_script text;


BEGIN

      SELECT '--' || c_line_ret || tc2.hdr || c_line_ret || '/' || c_line_ret || '--' ||
             c_line_ret || tc2.bdy || c_line_ret || '/' || c_line_ret ||
             'EXIT;' AS script
        INTO STRICT l_script
        FROM (SELECT tc.table_name,
                     q'[select '"]' || REPLACE(col_list, ',', '","') ||
                       q'["']' || c_line_ret || 'from dual' AS hdr,
                     q'[select '"'||]' ||
                     REPLACE(col_list, ',', q'[||'","'||]' || c_line_ret) ||
                     q'[||'"']' || c_line_ret || 'from beowner.' ||
                     lower(table_name) AS bdy
                FROM (SELECT utc.table_name,
                             rtrim(xmlagg(XMLELEMENT(name colname, utc.column_name || ',') ORDER BY utc.column_id)
                                   .extract('//text()'),
                                   ',') AS col_list
                        FROM user_tab_cols utc
                       WHERE utc.table_name = upper(i_table_name)
                             AND utc.virtual_column <> 'YES'
                       GROUP BY utc.table_name) tc) tc2;

      RETURN l_script;

   END;

$body$
LANGUAGE PLPGSQL
 STABLE;
-- REVOKE ALL ON FUNCTION utl.gen_bi_script (i_table_name text) FROM PUBLIC;

\i cleanup.sql;
