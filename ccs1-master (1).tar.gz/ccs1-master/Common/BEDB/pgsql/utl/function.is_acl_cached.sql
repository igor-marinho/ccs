SET bedb.filename = 'function.is_acl_cached.sql';

\i set_be_env.sql;

/* SBM-124 Merge ACL caching changes to Common branch
  ctx must be set before using this
*/
drop function if exists utl.is_acl_cached();

CREATE OR REPLACE FUNCTION utl.is_acl_cached()
RETURNS TEXT
AS
$BODY$
DECLARE
    l_acl_cached BEOWNER.MAKE.acl_cached%TYPE;
    l_count_diff_values INTEGER;
BEGIN

  SELECT m.acl_cached
    INTO STRICT l_acl_cached
    FROM beowner.make AS m
   WHERE m.make_id = (SELECT c.make_id
                        FROM beowner.ctx_data AS c);

  RETURN l_acl_cached;
/* Modified for Jira SBM-329 */
EXCEPTION
  WHEN no_data_found
  THEN
    -- If all makes in the DB have the same value, use it
    SELECT COUNT(DISTINCT m.acl_cached), MIN(m.acl_cached)
      INTO STRICT l_count_diff_values, l_acl_cached
      FROM beowner.make AS m;

    IF l_count_diff_values = 1
    THEN
      RETURN l_acl_cached;
    ELSE
      CALL trc.log (iadditionaldata => 'Cannot determine if ACL should be cached.');
      RETURN utl.get_constant_value('c_no');
    END IF;
END;
$BODY$
LANGUAGE plpgsql;

\i cleanup.sql;
