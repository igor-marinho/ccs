SET bedb.filename = 'function.convert_flag_to_number.sql';

\i set_be_env.sql;

   /* CR10303 Convert +/- to 1/0 */
CREATE OR REPLACE FUNCTION utl.convert_flag_to_number (i_flag text) RETURNS integer 
AS $body$
BEGIN
      RETURN CASE WHEN i_flag = '+' THEN 1 ELSE 0 END;
   EXCEPTION
      WHEN OTHERS THEN
         RETURN NULL;
   END;
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION utl.convert_flag_to_number (i_flag text) FROM PUBLIC;

\i cleanup.sql;
