SET bedb.filename = 'procedure.set_debug_log_on.sql';

\i set_be_env.sql;


   /* Added with OnTime #23373 to support additional trace logging
   Sets debug_log mode to yes, resulting in sending logging messages to "trc" table for trouble-shooting. By default debug log mode is set to off. */
   ------------------------------------------------------
   -- OnTime #23373  
CREATE OR REPLACE PROCEDURE utl.set_debug_log_on () AS $body$
BEGIN
      g_debug_log_on := TRUE;
   END;


$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE utl.set_debug_log_on () FROM PUBLIC;

\i cleanup.sql;
