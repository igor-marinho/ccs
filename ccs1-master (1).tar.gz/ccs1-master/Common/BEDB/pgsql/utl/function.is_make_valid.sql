SET bedb.filename = 'function.is_make_valid.sql';

\i set_be_env.sql;

/* Returns true if the input make_id is a valid value in make table, false otherwise */
CREATE OR REPLACE FUNCTION utl.is_make_valid(IN i_make_id TEXT)
RETURNS BOOLEAN
AS
$BODY$
DECLARE
    l_found VARCHAR(1);
BEGIN
    SELECT 1
      INTO STRICT l_found
      FROM beowner.make
     WHERE make_id = i_make_id;
    
    RETURN TRUE;

   EXCEPTION
        WHEN no_data_found
        THEN
            RETURN FALSE;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
