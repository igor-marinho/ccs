SET bedb.filename = 'procedure.get_email_info.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS utl.get_email_info(beowner.make.make_id%TYPE
                                           ,beowner.email_info.name%TYPE
                                           ,beowner.device.device_id%TYPE
                                           ,beowner.vin.vin%TYPE
                                           ,beowner.subscription.subscription_id%TYPE
                                           ,beowner.email_info.subject%TYPE
                                           ,beowner.email_info.template_name%TYPE);


/* Returns the subject and template name for the provided make, email name and device_id by joining with device_types.
If device.device_type is not null and no row is found in email_info for that device_type, returns the row for null device_type.
i_vin and i_subscription_id are not being used currently. Have been added to accommodate potential requirements in the future. */

CREATE OR REPLACE PROCEDURE utl.get_email_info (i_make_id               beowner.make.make_id%TYPE
                                               ,i_email_name            beowner.email_info.name%TYPE
                                               ,i_device_id             beowner.device.device_id%TYPE
                                               ,i_vin                   beowner.vin.vin%TYPE
                                               ,i_subscription_id       beowner.subscription.subscription_id%TYPE
                                               ,o_subject         INOUT beowner.email_info.subject%TYPE
                                               ,o_template_name   INOUT beowner.email_info.template_name%TYPE)
AS $body$
DECLARE
      l_subject       email_info.subject%TYPE;
      l_template_name email_info.template_name%TYPE;

BEGIN
      BEGIN
         -- Modified for PHVPRIME-12 to include join for newly added ei.device_id
         SELECT subject,
                template_name
           INTO STRICT l_subject,
                l_template_name
           FROM (SELECT subject,
                        template_name,
                        ei.device_type
                   FROM beowner.email_info ei,
                        beowner.device     d
                  WHERE ei.make_id = i_make_id
                        AND NAME = i_email_name
                        AND (i_device_id IS NULL OR d.device_id = i_device_id)
                        AND (ei.device_type IS NULL OR
                        ei.device_type = d.device_type)
                        AND (ei.device_id IS NULL OR ei.device_id = i_device_id)
                  ORDER BY ei.device_type NULLS LAST,
                           ei.device_id   NULLS LAST) alias3 LIMIT 1;
      EXCEPTION
         WHEN no_data_found THEN
            NULL;
      END;
      o_subject := l_subject;
      o_template_name := l_template_name;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE utl.get_email_info (i_make_id make.make_id%TYPE, i_email_name email_info.name%TYPE, i_device_id device.device_id%TYPE, i_vin vin.vin%TYPE, i_subscription_id subscription.subscription_id%TYPE, o_subject OUT email_info.subject%TYPE, o_template_name OUT email_info.template_name%TYPE) FROM PUBLIC;

\i cleanup.sql;
