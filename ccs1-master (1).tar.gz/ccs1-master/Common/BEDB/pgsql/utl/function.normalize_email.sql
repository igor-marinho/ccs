SET bedb.filename = 'function.normalize_email.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS utl.normalize_email(TEXT, TEXT);
/*
   EMAIL utility: receive an email and return a "normalized" email.
   If iRaiseIfError is NULL, then no exception will be thrown; the function will return NULL if the email is invalid.
   If iRaiseIfError has *any* value and the email is invalid, an exception will be thrown.
*/
CREATE OR REPLACE FUNCTION utl.normalize_email(IN iemailaddr TEXT, IN iraiseiferror TEXT DEFAULT NULL)
RETURNS TEXT
AS
$BODY$
DECLARE
    vrslt VARCHAR(200);
    vmatch boolean;
    /* this is a relatively simple email expression validator. It should validate syntactically correct email addresses, even though they may not be valid. */
    /* don't edit this line if you don't really know Regular Expressions */
    /* so, instead of using real email validation, TMS wants something different... */    
    cexpr CONSTANT text := '([!-~]+@[!-~]+\.[!-~]{2,})';
/* keep this regex just in case we can use "real" email validation in the future */
/* cExpr    constant long := q'<^([-a-z0-9_\.+]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-z0-9\-]+\.)+))([a-z]{2,6}|[0-9]{1,3})(\]?)$>'; */
BEGIN
    vrslt := LOWER(TRIM(iemailaddr));
   
    SELECT iemailaddr ~ cexpr
      INTO strict vmatch;
   
    IF iraiseiferror IS NOT NULL
    AND NOT vmatch
    THEN
        raise exception using errcode=utl.get_constant_value('e_invalidemail');
    END IF;
   
    IF vmatch
    THEN
        RETURN vrslt;
    ELSE
        RETURN NULL;
    END IF;
   
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
