SET bedb.filename = 'function.is_allowed_status_valid.sql';

\i set_be_env.sql;

   /* Returns true if the allowed_status is a valid value, false otherwise */
   
DROP FUNCTION IF EXISTS utl.is_allowed_status_valid(text);

CREATE OR REPLACE FUNCTION utl.is_allowed_status_valid (i_allowed_status text) RETURNS boolean AS $body$

BEGIN
      -- for now, these are the only valid values for bndlsvc.allowed_status. might change in the future
      
	  
   RETURN(i_allowed_status IN ('1', '2', '3'));
   
END;

   /* Returns value of device_types.conflict_enforced for the provided device Id by joining with device_types.
   If device_type on the device is null, returns N. */
$body$
LANGUAGE PLPGSQL
 STABLE;
-- REVOKE ALL ON FUNCTION utl.is_allowed_status_valid (i_allowed_status text) FROM PUBLIC;

\i cleanup.sql;
