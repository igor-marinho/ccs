SET bedb.filename = 'function.is_user_valid.sql';

\i set_be_env.sql;
   /* Returns true if the usr_id provided is valid, false otherwise
   If true, also return the user's make_id
   Added for OnTime WI #15750 */

DROP FUNCTION IF EXISTS utl.is_user_valid(UUID);

CREATE OR REPLACE FUNCTION utl.is_user_valid(i_usr_id TEXT, OUT o_make_id TEXT, OUT o_parent_id TEXT, OUT o_status_code BOOLEAN)
AS
$BODY$
BEGIN
    SELECT make_id::TEXT, parent_id::TEXT
      INTO STRICT o_make_id, o_parent_id
      FROM beowner.usr
     WHERE usr_id = i_usr_id::uuid;
    
    o_status_code := TRUE;
   
    RETURN;
   
    EXCEPTION
        WHEN no_data_found
        THEN
            o_status_code := FALSE;
            RETURN;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
