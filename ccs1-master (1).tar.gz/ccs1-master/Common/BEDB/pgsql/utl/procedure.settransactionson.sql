SET bedb.filename = 'procedure.settransactionson.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS utl.settransactionson ();
CREATE OR REPLACE PROCEDURE utl.settransactionson ()
AS $body$
BEGIN
      PERFORM set_config('utl.gtransactions', 'TRUE', false);
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE utl.settransactionson () FROM PUBLIC;

\i cleanup.sql;
