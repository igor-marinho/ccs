SET bedb.filename = 'function.set_transaction_status.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS utl.set_transaction_status(TEXT);
   /*  Title:        SET_TRANSACTION_STATUS
       Description:  The purpose of this function is to set the transaction status as specified
                     and pass back the previous and current transaction status
       Developed for OnTime WI #8416 ([DB - 424] Build CreateAccount API)
   
           Input parameter :
             i_on_off         - The desired Transaction Status (ON/OFF).
                                Constants cnst.c_status_on/cnst.c_status_off
   
          Output parameters :
   
          o_result      - Ref cursor with two columns : previous transaction status, current (new) transaction status
   
          Return value : integer
          Expected Return Values:
            0     : Success                                (utl.get_constant_value('csuccess'))
            1     : Unhandled Error                        (cnst.cInternalError)
            4     : Invalid Parameters                     (utl.get_constant_value('cinvalidparams'))
   */

CREATE OR REPLACE FUNCTION utl.set_transaction_status(i_on_off IN TEXT,
                                                      o_status_code OUT INTEGER,
                                                      o_result OUT REFCURSOR)  
AS
$body$
DECLARE
      l_action text;
      l_module_name text := 'set_transaction_status';
      l_on_off     TEXT := upper(i_on_off);
      l_old_status TEXT;  
      l_new_status TEXT;
	  c_status_on  TEXT := utl.get_constant_value('c_status_on');
	  c_status_off TEXT := utl.get_constant_value('c_status_off');
	  
      l_exception_diagnostics trc.exception_diagnostics;
   BEGIN
      o_status_code := utl.get_constant_value('csuccess');
	  l_old_status := CASE
						WHEN current_setting('utl.gtransactions', TRUE) = 'TRUE' THEN
						 c_status_on
						ELSE
						 c_status_off
					  END;
      BEGIN
         IF l_on_off = utl.get_constant_value('c_status_on')
         THEN
            CALL utl.settransactionson();
         ELSIF l_on_off = utl.get_constant_value('c_status_off')
         THEN
            CALL utl.settransactionsoff();
         ELSE
            RAISE invalid_text_representation;
         END IF;

         l_new_status := CASE
                            WHEN current_setting('utl.gtransactions', TRUE) = 'TRUE' THEN
                              c_status_on
                            ELSE
                              c_status_off
                         END;
      EXCEPTION
         WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
            o_status_code := utl.get_constant_value('cinvalidparams');
            l_new_status := l_old_status;
         WHEN OTHERS THEN
             GET STACKED diagnostics
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,              
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;
        
            CALL trc.log(iadditionaldata => NULL,
                         iexception_diagnostics => l_exception_diagnostics);
                
            o_status_code := utl.get_constant_value('cinternalerror');
            l_new_status := l_old_status;
      END;
      
      OPEN o_result FOR
         SELECT l_old_status,
                l_new_status;
      RETURN;
   END;
$body$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
