SET bedb.filename = 'function.cr_bod.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS crudg_bod.cr_bod("text","varchar","varchar","varchar","text","text");
    /*
   cr_bod: Create a row in BO_DOCUMENTS table for the Business Object Document pertaining to Star schema

   Error Codes returned:
        cInternalError            constant vc := '1'    -- Internal Error.
        cInvalidParams            constant vc := '4'    -- Invalid Parameters - if any of the parameters passed in(besides i_version) are null
        cInvalidCTXPtnrID         constant vc := '30'   -- The partnerid is not valid.
        c_duplicate_bod           constant vc := '289'  -- The BOD already exists for this partner ID
   */
   
CREATE OR REPLACE FUNCTION crudg_bod.cr_bod (i_ptnr_id             text
                                            ,i_bod_id              bo_documents.bod_id%TYPE
                                            ,i_business_activity   bo_documents.business_activity%TYPE
                                            ,i_transaction_id      bo_documents.transaction_id%TYPE
                                            ,i_bod_xml             bo_documents.bod_xml%TYPE
                                            ,i_version             text DEFAULT NULL)
    RETURNS INTEGER AS $body$
DECLARE
      l_action text;
      l_module_name text := 'cr_bod';
      l_ctx_return  text;
      l_business_activity   bo_documents.business_activity%TYPE
                               := UPPER(i_business_activity);
      l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      l_action := utl.set_module_action( l_module_name, ' Starting CR_BOD');

      IF    i_ptnr_id IS NULL
         OR i_bod_id IS NULL
         OR i_transaction_id IS NULL
         OR i_business_activity IS NULL
         OR i_bod_xml IS NULL
      THEN
         RETURN utl.get_constant_value('cinvalidparams');
      END IF;

      l_ctx_return := ctx.set(iptnrid => i_ptnr_id, itranid => i_transaction_id);

      IF l_ctx_return != utl.get_constant_value('csuccess')
      THEN
         RETURN l_ctx_return;
      END IF;

      INSERT INTO beowner.bo_documents(transaction_id,
                                        ptnr_id,
                                        business_activity,
                                        bod_xml,
                                        bod_id,
                                        bod_guid)
           VALUES (i_transaction_id,
                   i_ptnr_id::uuid,
                   l_business_activity,
                   i_bod_xml,
                   i_bod_id,
                   rand_guid());

      RETURN utl.get_constant_value('csuccess');
   EXCEPTION
      WHEN unique_violation
      THEN
         CALL trc.log(
            'Duplicate BOD_ID ' || i_bod_id || ' for partner ' || i_ptnr_id);
         RETURN utl.get_constant_value('c_duplicate_bod');
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
      
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        
         CALL trc.log(iadditionaldata => 'Internal error in CRUDG_BOD.CR_BOD()'
                    ,iexception_diagnostics => l_exception_diagnostics);      
         RETURN utl.get_constant_value('cinternalerror');
   END;

   -- Removed Function g_bod for DCS1E-605
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION crudg_bod.cr_bod ( i_ptnr_id ptnr.ptnr_id%TYPE, i_bod_id bo_documents.bod_id%TYPE, i_business_activity bo_documents.business_activity%TYPE, i_transaction_id bo_documents.transaction_id%TYPE, i_bod_xml bo_documents.bod_xml%TYPE, i_version text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
