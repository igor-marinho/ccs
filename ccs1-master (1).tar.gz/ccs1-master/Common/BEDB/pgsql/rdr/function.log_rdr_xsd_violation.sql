SET bedb.filename = 'function.log_rdr_xsd_violation.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS rdr.log_rdr_xsd_violation (TEXT, beowner.rdr_job_log.rjl_xsd_failure_code%TYPE);
DROP FUNCTION IF EXISTS rdr.log_rdr_xsd_violation (TEXT, INTEGER);

   -- CR10303 changes begin --
   /* log_rdr_xsd_violation
    To be used to log any RDRs that fail XSD validation and hence cannot be processed.
    be_log_rdr_sp should be called first. be_load_rdr_sp should/will not be called in this case.
        
    Return : integer (status code) - 0 if success
    Error codes : 
      4 : Invalid Parameter (value too long for failure code)
    257 : The Job Log ID provided was not found in rdr_job_log table
    523 : Invalid current Processed Flag (should be '-')
    524 : Failure code is required 
   */
CREATE OR REPLACE FUNCTION rdr.log_rdr_xsd_violation (i_job_log_id         TEXT
                                                     ,i_xsd_failure_code   INTEGER)
    RETURNS INTEGER 
AS $body$
DECLARE
    l_action TEXT; 
    l_module_name text := 'log_rdr_xsd_violation';
    l_rjl_processed_flag beowner.rdr_job_log.rjl_processed_flag%TYPE;
    l_job_log_id beowner.rdr_job_log.rjl_job_log_id%TYPE := i_job_log_id::UUID;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    
    l_action := utl.set_module_action(l_module_name, 'Validating inputs');

      IF i_xsd_failure_code IS NULL
      THEN
         RETURN utl.get_constant_value('c_failure_code_is_required');
      END IF;

 -- rjl_xsd_failure_code is a 2 digit code. 
      IF i_xsd_failure_code NOT BETWEEN -99 AND 99
      THEN
          RETURN utl.get_constant_value('cinvalidparams');
      END IF;
       
      BEGIN
         SELECT r.rjl_processed_flag
           INTO STRICT l_rjl_processed_flag
           FROM beowner.rdr_job_log r
          WHERE r.rjl_job_log_id = l_job_log_id;
      EXCEPTION
         WHEN no_data_found THEN
            RETURN utl.get_constant_value('cinvalid_rdr_job_log_id');
      END;

      IF l_rjl_processed_flag != utl.get_constant_value('c_rdr_not_parsed')
      THEN
         RETURN utl.get_constant_value('c_invalid_rdr_current_flag');
      END IF;

    l_action := utl.set_action('Updating rdr_job_log');
      -- Jira CR10303-24
      UPDATE beowner.rdr_job_log r
         SET rjl_processed_flag   = utl.get_constant_value('c_rdr_rejected'),
             rjl_xsd_failure_code = i_xsd_failure_code
       WHERE r.rjl_job_log_id = l_job_log_id;

      RETURN utl.get_constant_value('csuccess');
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
         CALL  trc.log('Something went wrong in ' || l_module_name,
                        iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');
   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION rdr.log_rdr_xsd_violation (i_job_log_id rdr_job_log.rjl_job_log_id%TYPE, i_xsd_failure_code rdr_job_log.rjl_xsd_failure_code%TYPE) FROM PUBLIC;

\i cleanup.sql;
