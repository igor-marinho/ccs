SET bedb.filename = 'function.is_individual.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS rdr.is_individual(TEXT, TEXT);
   -------------------------------------------------------------------------------
   -- Added new function for defect#11824
   /*
     Title:        is_individual
     Date:         01/10/2012
     Author:       Junifer Priatna
     Work Item #:  defect#11824
   
     Description:  to check email (buyer or org) rather than company name to determine individual or organization/company.
     Logic: will return true if buyer email is NOT null, or false if org email is not null or both are null or an error is occurred.
   
     Input parameters:
       p_buyer_email        Buyer/Individual email
       p_org_email          Organization email
   
     Output parameters:
       boolean
   
     Revision History:
   
       DATE             AUTHOR        DESCRIPTION
       01/10/2012       JPriatna      Created this function
   */

CREATE OR REPLACE FUNCTION rdr.is_individual (p_buyer_email text, p_org_email text) RETURNS boolean 
AS $body$
BEGIN
      -- check the buyer email, if it's not null which mean individual
      IF COALESCE(p_buyer_email, '') != ''
      THEN
         RETURN TRUE;
         -- check the org email, if it's not null which mean organization
      ELSIF COALESCE(p_org_email, '') != ''
      THEN
         RETURN FALSE;
      ELSE
         -- if both are null then default it to false
         RETURN FALSE;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
         -- if error occur then default it to false
         RETURN FALSE;
   END;
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION rdr.is_individual (p_buyer_email text, p_org_email text) FROM PUBLIC;

\i cleanup.sql;
