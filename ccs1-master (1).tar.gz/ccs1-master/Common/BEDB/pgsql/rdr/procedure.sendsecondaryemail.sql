SET bedb.filename = 'procedure.sendsecondaryemail.sql';

\i set_be_env.sql;

DROP PROCEDURE if exists rdr.sendsecondaryemail (text, uuid);

CREATE OR REPLACE PROCEDURE rdr.sendsecondaryemail (iemail text, iparentid usr.usr_id%TYPE) AS $body$
DECLARE

      vnamefirst    text;
      vnamelast     text;
      vkeyvalues    xml;
      vmakeid       beowner.make.make_id%TYPE;
      vsubject      beowner.email_info.subject%TYPE; -- Modified for WI #15530
      vtemplatename beowner.email_info.template_name%TYPE; -- Added for WI #15530
BEGIN
      -- No longer restrict if non-Toyota. Send email for Toyota and Lexus now.
      SELECT cd.make_id
        INTO STRICT vmakeid
        FROM beowner.ctx_data cd;

      IF vmakeid IN ('TM', 'LX')
      THEN
         -- get the name of the primary
         SELECT name_first,
                name_last
           INTO STRICT vnamefirst,
                vnamelast
           FROM beowner.usr_basic_info
          WHERE usr_id = iparentid;

         -- create a key/value pair for the email template
         vkeyvalues := XMLELEMENT(name "entry",
                           XMLELEMENT(name "key", 'subscriberName'),
                           XMLELEMENT(name "value", vnamefirst || ' ' || vnamelast));

         -- Modified for OnTime WI #15530
         CALL utl.get_email_info(i_make_id         => vmakeid
                                ,i_email_name      => 'SECONDARY_SUBSCRIBER_PROMOTION'
                                ,i_device_id       => NULL
                                ,i_vin             => NULL
                                ,i_subscription_id => NULL
                                ,o_subject         => vsubject
                                ,o_template_name   => vtemplatename);

         PERFORM email.send(ito           => iemail,
                            isubject      => vsubject,
                            itemplatename => vtemplatename,
                            ikeyvalues    => vkeyvalues);
      END IF;
END;
$body$
LANGUAGE PLPGSQL
;

\i cleanup.sql;
