SET bedb.filename = 'procedure.scrub.sql';
\i set_be_env.sql;

DROP PROCEDURE IF EXISTS rdr.scrub(beowner.rdr_staging, BOOLEAN);

CREATE OR REPLACE PROCEDURE rdr.scrub(r INOUT beowner.rdr_staging, o_vin_found INOUT BOOLEAN) 
AS $body$
DECLARE
   -- added o_vin_found for OnTime #14781, since a different return value is sent if vin was not found
    l_action TEXT;
    l_module_name text := 'scrub';
    cfalse VARCHAR(1) := utl.get_constant_value ('crdrfalse');
    ctrue  VARCHAR(1) := utl.get_constant_value ('crdrtrue');
    g_am_phone_number TEXT;    -- stores the concatenated AM phone number values for validation
    g_pm_phone_number TEXT;    -- stores the concatenated PM phone number values for validation
    g_am_phone_valid  BOOLEAN;
    g_pm_phone_valid  BOOLEAN;
    g_insert_am_phone BOOLEAN := FALSE; -- indicates if AM phone number provided should be inserted in H1 phone row
    g_insert_pm_phone BOOLEAN := FALSE; -- indicates if PM phone number provided should be inserted in H1 phone row
	g_rjl_processed_flag rdr_job_log.rjl_processed_flag%TYPE;
    vcount      INTEGER;
    vinvalidvin TEXT;
    vnotfndvin  TEXT;
BEGIN
      l_action := utl.set_module_action( l_module_name, ' Normalizing Data');
   
      r.rs_buyer_email_id := utl.normalize_email(r.rs_buyer_email_id);
      r.rs_org_email_id := utl.normalize_email(r.rs_org_email_id);
   
      r.rs_vin := upper(TRIM(r.rs_vin));
      r.rs_company_name := upper(TRIM(r.rs_company_name));
      r.rs_buyer_first_name := upper(TRIM(r.rs_buyer_first_name));
      r.rs_buyer_middle_initial := upper(TRIM(r.rs_buyer_middle_initial));
      r.rs_buyer_last_name := upper(TRIM(r.rs_buyer_last_name));
      r.rs_buyer_name_suffix := upper(TRIM(r.rs_buyer_name_suffix));
      r.rs_buyer_line1 := upper(TRIM(r.rs_buyer_line1));
      r.rs_org_line1 := upper(TRIM(r.rs_org_line1));
      r.rs_buyer_line2 := upper(TRIM(r.rs_buyer_line2));
      r.rs_org_line2 := upper(TRIM(r.rs_org_line2));
      r.rs_buyer_city := upper(TRIM(r.rs_buyer_city));
      r.rs_org_city := upper(TRIM(r.rs_org_city));
      r.rs_buyer_state := upper(TRIM(r.rs_buyer_state));
      r.rs_org_state := upper(TRIM(r.rs_org_state));
      r.rs_buyer_zip_code := upper(TRIM(r.rs_buyer_zip_code));
      r.rs_org_zip_code := upper(TRIM(r.rs_org_zip_code));
   
      r.rs_buyer_phone_am_areacode := upper(TRIM(r.rs_buyer_phone_am_areacode));
      r.rs_org_phone_am_areacode := upper(TRIM(r.rs_org_phone_am_areacode));
      r.rs_buyer_phone_am_exchange := upper(TRIM(r.rs_buyer_phone_am_exchange));
      r.rs_buyer_phone_am_linenumber := upper(TRIM(r.rs_buyer_phone_am_linenumber));
      r.rs_org_phone_am_exchange := upper(TRIM(r.rs_org_phone_am_exchange));
      r.rs_org_phone_am_line_number := upper(TRIM(r.rs_org_phone_am_line_number));
      r.rs_buyer_phone_am_extension := upper(TRIM(r.rs_buyer_phone_am_extension));
      r.rs_org_phone_am_extension := upper(TRIM(r.rs_org_phone_am_extension));
      r.rs_buyer_phone_pm_areacode := upper(TRIM(r.rs_buyer_phone_pm_areacode));
      r.rs_org_phone_pm_areacode := upper(TRIM(r.rs_org_phone_pm_areacode));
      r.rs_buyer_phone_pm_exchange := upper(TRIM(r.rs_buyer_phone_pm_exchange));
      r.rs_buyer_phone_pm_linenumber := upper(TRIM(r.rs_buyer_phone_pm_linenumber));
      r.rs_org_phone_pm_exchange := upper(TRIM(r.rs_org_phone_pm_exchange));
      r.rs_org_phone_pm_line_number := upper(TRIM(r.rs_org_phone_pm_line_number));
      r.rs_buyer_phone_pm_extension := upper(TRIM(r.rs_buyer_phone_pm_extension));
      r.rs_org_phone_pm_extension := upper(TRIM(r.rs_org_phone_pm_extension));

      l_action :=  utl.set_action(' Scrubbing VIN');
   
      -- inverse logic: -- field names are "..invalid..flag"
      -- therefore False is good, True is bad
      -- logic checks for "good" stuff (when condition=true then good)
   
      -- Jira CR10303-39 : RDR is put in pending state with an Vin longer than 17-char
      --   modified to check for precise length of 17 instead of at least 17.
   
      vinvalidvin := CASE
                        WHEN r.rs_vin ~ '^[A-Z0-9]{17}$' 
                        THEN
                         cfalse
                        ELSE
                         ctrue
                     END;
   
      SELECT COUNT(*)
        INTO vcount
        FROM beowner.vin
       WHERE vin = r.rs_vin;
 
      CALL utl.dbg('vcount = ' || vcount);
      vnotfndvin := CASE
                       WHEN vcount != 0 THEN
                        cfalse
                       ELSE
                        ctrue
                    END;
      CALL utl.dbg('vnotfndvin = ' || vnotfndvin);
      o_vin_found := CASE
                        WHEN vcount != 0 THEN
                         TRUE
                        ELSE
                         FALSE
                     END; -- OnTime #14781 - to return to calling function
   
      l_action :=  utl.set_action(' Scrubbing Other Information');
   
      -- Modified for OnTime #14781. If vin was not found, rjl_num_vin_not_found_indb will be set
      r.rs_invalid_vin_flag := CASE
                                  WHEN vinvalidvin = cfalse THEN
                                   cfalse
                                  ELSE
                                   ctrue
                               END;
      -- Modified for OnTime #14781. If either email is sent, it should not be treated as invalid
      r.rs_invalid_email_flag := CASE
                                    WHEN coalesce(r.rs_buyer_email_id, '') != '' OR
                                         coalesce(r.rs_org_email_id, '') != '' THEN
                                     cfalse
                                    ELSE
                                     ctrue
                                 END;
   
      -- Removed population of rs_invalid_phone_flag for OnTime #22159 as it is no longer needed
   
      /*  below logic added for OnTime #22159
      Requirement is to put the non-null non-zeros number into the AM (H1) phone row, even if that happens to be the PM number.
      If none of the numbers is valid, put any non-null value into AM phone.
      If PM phone number is put in AM phone, PM phone does not need to be inserted in addition
      */
      IF coalesce(r.rs_buyer_email_id, '') != ''
      THEN
         -- validate using buyer phone info
         CALL rdr.validate_phone(r.rs_buyer_phone_am_areacode,
                                r.rs_buyer_phone_am_exchange,
                                r.rs_buyer_phone_am_linenumber,
                                g_am_phone_number,
                                g_am_phone_valid);
         CALL rdr.validate_phone(r.rs_buyer_phone_pm_areacode,
                                r.rs_buyer_phone_pm_exchange,
                                r.rs_buyer_phone_pm_linenumber,
                                g_pm_phone_number,
                                g_pm_phone_valid);
      ELSIF coalesce(r.rs_org_email_id, '') != ''
      THEN
         -- validate using org phone info
         CALL rdr.validate_phone(r.rs_org_phone_am_areacode,
                                r.rs_org_phone_am_exchange,
                                r.rs_org_phone_am_line_number,
                                g_am_phone_number,
                                g_am_phone_valid);
         CALL rdr.validate_phone(r.rs_org_phone_pm_areacode,
                                r.rs_org_phone_pm_exchange,
                                r.rs_org_phone_pm_line_number,
                                g_pm_phone_number,
                                g_pm_phone_valid);
      END IF;
	
     -- insert AM phone into H1 phone if it is a valid value (not null, non-zeroes)
      g_insert_am_phone := g_am_phone_valid;
   
      IF NOT g_insert_am_phone
      THEN
         -- if PM phone is valid, insert it into H1 phone
         IF g_pm_phone_valid
         THEN
            g_insert_pm_phone := TRUE;
         ELSE
            -- if none of them are valid, use the one that is not null (even if it is all non-zeroes)
            IF g_am_phone_number IS NOT NULL
            THEN
               g_insert_am_phone := TRUE;
            ELSIF g_pm_phone_number IS NOT NULL
            THEN
               g_insert_pm_phone := TRUE;
            END IF;
         END IF;
      END IF;

      CALL utl.dbg('g_am_phone_valid is ' || CASE WHEN g_am_phone_valid THEN
              'TRUE' ELSE 'FALSE' END);
      CALL utl.dbg('g_pm_phone_valid is ' || CASE WHEN g_pm_phone_valid THEN
              'TRUE' ELSE 'FALSE' END);
   
      /* Added for OnTime #14781
      '-' : Initial state - set by be_log_rdr_sp, 'P' : Pending (VIN not in DB), 'N' : Not processed yet, 'R' - rejected, 'Y' - processed successfully */
      
	  g_rjl_processed_flag := CASE
                                  WHEN (vinvalidvin = ctrue OR
                                       r.rs_invalid_vin_flag = ctrue) -- OR r.rs_invalid_phone_flag = ctrue) -- OnTime #22159
                                   THEN
                                   utl.get_constant_value ('c_rdr_rejected')
                                  WHEN NOT o_vin_found THEN
                                   utl.get_constant_value ('c_rdr_pending')
                                  ELSE
                                   utl.get_constant_value ('c_rdr_not_processed')
                              END;
													 
      l_action := utl.set_action(' Updating Scrubbed Data');
   
      UPDATE beowner.rdr_job_log
         SET rjl_num_invalid_vins       = CASE vinvalidvin
                                             WHEN ctrue THEN
                                              1
                                             ELSE
                                              0
                                          END,
             rjl_num_invalid_make       = 0, -- this isn't really used
             rjl_num_invalid_email      = CASE r.rs_invalid_email_flag
                                             WHEN ctrue THEN
                                              1
                                             ELSE
                                              0
                                          END,
             rjl_num_vin_not_found_indb = CASE vnotfndvin
                                             WHEN ctrue THEN
                                              1
                                             ELSE
                                              0
                                          END,
             -- OnTime #14781
             rjl_num_invalid_phone = CASE r.rs_invalid_phone_flag
                                        WHEN ctrue THEN
                                         1
                                        ELSE
                                         0
                                     END,
             rjl_processed_flag    = g_rjl_processed_flag
       WHERE rjl_job_log_id = r.rs_job_log_id;

	-- These variables are used in rdr.manage_user
	PERFORM set_config('rdr.g_am_phone_number', g_am_phone_number::TEXT , false);
	PERFORM set_config('rdr.g_pm_phone_number', g_pm_phone_number::TEXT , false);
	PERFORM set_config('rdr.g_insert_am_phone', g_insert_am_phone::TEXT , false);
	PERFORM set_config('rdr.g_insert_pm_phone', g_insert_pm_phone::TEXT , false);
	PERFORM set_config('rdr.g_rjl_processed_flag', g_rjl_processed_flag::TEXT, false);
	
END
$body$
LANGUAGE PLPGSQL
;
\i cleanup.sql;
