SET bedb.filename = 'procedure.initotherdata.sql';
\i set_be_env.sql;

DROP PROCEDURE IF EXISTS rdr.initotherdata (beowner.usr.usr_id%TYPE, TEXT, beowner.usr_email, TEXT, beowner.usr_demog, TEXT, beowner.usr_phone, TEXT, beowner.usr_phone);

CREATE OR REPLACE PROCEDURE rdr.initotherdata (iusrid               beowner.usr.usr_id%TYPE
                                              ,e_upd_ind     IN OUT text
                                              ,e             IN OUT beowner.usr_email
                                              ,d_upd_ind     IN OUT text
                                              ,d             IN OUT beowner.usr_demog
                                              ,pam_upd_ind   IN OUT text
                                              ,pam           IN OUT beowner.usr_phone
                                              ,ppm_upd_ind   IN OUT text
                                              ,ppm           IN OUT beowner.usr_phone)                                              
AS $body$
BEGIN
      -- USR_EMAIL
      BEGIN
         SELECT *
           INTO STRICT e
           FROM beowner.usr_email
          WHERE usr_id = iusrid
                AND email_type_id = 'H1';
        e_upd_ind := utl.get_constant_value('c_yes');
      EXCEPTION
         WHEN no_data_found THEN
            e.usr_id := iusrid;
            e.email_type_id := 'H1';
            e.status := 'N'; -- #15365
        e_upd_ind := utl.get_constant_value('c_no');            
      END;

      -- USR_DEMOG
      BEGIN
         SELECT *
           INTO STRICT d
           FROM beowner.usr_demog
          WHERE usr_id = iusrid;
      d_upd_ind := utl.get_constant_value('c_yes');
      EXCEPTION
         WHEN no_data_found THEN
            d.usr_id := iusrid;
        d_upd_ind := utl.get_constant_value('c_no');
      END;

      -- USR_PHONE (AM = H1)
      BEGIN
         SELECT *
           INTO STRICT pam
           FROM beowner.usr_phone
          WHERE usr_id = iusrid
                AND phone_type_id = 'H1';
        pam_upd_ind := utl.get_constant_value('c_yes');
      EXCEPTION
         WHEN no_data_found THEN
            pam.usr_id := iusrid;
            pam.phone_type_id := 'H1';
        pam_upd_ind := utl.get_constant_value('c_no');
      END;

      -- USR_PHONE (PM = O1) "Other 1"
      BEGIN
         SELECT *
           INTO STRICT ppm
           FROM beowner.usr_phone
          WHERE usr_id = iusrid
                AND phone_type_id = 'O1';
        ppm_upd_ind := utl.get_constant_value('c_yes');
      EXCEPTION
         WHEN no_data_found THEN
            ppm.usr_id := iusrid;
            ppm.phone_type_id := 'O1';
        	ppm_upd_ind := utl.get_constant_value('c_no');
      END;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE rdr.initotherdata (iusrid usr.usr_id%TYPE, erow INOUT text, e INOUT usr_email, drow INOUT text, d INOUT usr_demog, pamrow INOUT text, pam INOUT usr_phone, ppmrow INOUT text, ppm INOUT usr_phone) FROM PUBLIC;
 
\i cleanup.sql;
