SET bedb.filename = 'function.get_pending_rdrs.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS rdr.get_pending_rdrs("timestamp","timestamp");
   /*
    Returns a list of all pending RDRs created between the date range provided
   
    Return cursor :
    rjl_job_log_id, vin, rjl_processed_flag, rjl_parsed_flag, rjl_num_invalid_vins, rjl_num_invalid_make, rjl_num_invalid_email, rjl_num_invalid_phone, 
    rjl_num_vin_not_found_indb, rjl_duplicate_flag, rjl_created_by, rjl_created_date, device_id (will be null as VIN is invalid)
   
    Return value :
        0 : Success (utl.get_constant_value('csuccess'))
        1 : Internal (unhandled) Error
   */
   -- Deleted get_rdr_job_log as a part of DCS1E-1482
   -- Added for OnTime #14781 to return a list of all pending RDRs

CREATE OR REPLACE FUNCTION rdr.get_pending_rdrs (i_from_date         beowner.rdr_job_log.rjl_created_date%TYPE
                                                ,i_to_date           beowner.rdr_job_log.rjl_created_date%TYPE
                                                ,o_status_code   OUT INTEGER
                                                ,rslt            OUT refcursor)
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'get_pending_rdrs';
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    l_action := utl.set_module_action(l_module_name,'Returning results');

        OPEN rslt FOR
         SELECT rjl.rjl_job_log_id             rjl_job_log_id,
                rs.rs_vin                      vin,
                rjl.rjl_processed_flag         rjl_processed_flag,
                rjl.rjl_parsed_flag            rjl_parsed_flag,
                rjl.rjl_num_invalid_vins       rjl_num_invalid_vins,
                rjl.rjl_num_invalid_make       rjl_num_invalid_make,
                rjl.rjl_num_invalid_email      rjl_num_invalid_email,
                rjl.rjl_num_invalid_phone      rjl_num_invalid_phone,
                rjl.rjl_num_vin_not_found_indb rjl_num_vin_not_found_indb,
                rjl.rjl_duplicate_flag         rjl_duplicate_flag,
                rjl.rjl_created_by             rjl_created_by,
                rjl.rjl_created_date           rjl_created_date,
                NULL                           device_id
           FROM beowner.rdr_job_log rjl,
                beowner.rdr_staging rs
          WHERE rs.rs_job_log_id = rjl.rjl_job_log_id
                AND rjl.rjl_processed_flag = utl.get_constant_value('c_rdr_pending')
                AND rjl.rjl_created_date >= i_from_date
                AND rjl.rjl_created_date <= i_to_date
          ORDER BY rjl.rjl_created_date;

       o_status_code := utl.get_constant_value('csuccess');
   RETURN;
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
        rslt := utl.get_dummy_cursor();
        o_status_code :=  utl.get_constant_value('cinternalerror');
                
    RETURN;
   END;
   -- Added for OnTime #14781 to update the RDR status in rdr_job_log with a valid value
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION rdr.get_pending_rdrs (i_from_date rdr_job_log.rjl_created_date%TYPE, i_to_date rdr_job_log.rjl_created_date%TYPE, rslt OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
