SET bedb.filename = 'procedure.create_subscription.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS rdr.create_subscription (beowner.rdr_staging, beowner.vin.dofu%TYPE);

CREATE OR REPLACE PROCEDURE rdr.create_subscription (r INOUT beowner.rdr_staging, i_dofu beowner.vin.dofu%TYPE) 
AS $body$
DECLARE
    l_action TEXT;
    l_module_name text := 'create_subscription';

      vbndlid       beowner.bndl.bndl_id%TYPE;
      vsubstart     beowner.subscription.sub_start%TYPE;
      vsubduration  beowner.subscription.sub_duration%TYPE;
      vemail        beowner.usr.login_id%TYPE;
      vmakeid       beowner.make.make_id%TYPE;
      vdeviceid     beowner.vin.device_id%TYPE; -- Added for WI 6088/Defect 11115
      vmodel        beowner.vin.model%TYPE; -- Added for WI 6088/Defect 11115
      vtemplatename beowner.email_info.template_name%TYPE; -- Added for WI 6088/Defect 11115, modified for WI #15530
      vrslt         text;
      vcount        smallint;
      vtoken        text;
      l_verified    beowner.usr.verified%TYPE;
      l_subject     beowner.email_info.subject%TYPE; -- Modified for WI #15530
      l_usr_id      beowner.usr.usr_id%TYPE;
      l_vin         beowner.vin.vin%TYPE;

BEGIN
      l_action := utl.set_module_action( l_module_name, ' Getting final subscription information');

      -- Modified for merging with WI #14078, so that context name is removed where it's not necessary
      SELECT b.bndl_id,
             cd.tmstmp,
             b.bundle_length,
             u.login_id,
             cd.make_id,
             v.device_id,
             v.model,
             u.verified,
             u.usr_id,
             v.vin
        INTO STRICT vbndlid,
             vsubstart,
             vsubduration,
             vemail,
             vmakeid,
             vdeviceid,
             vmodel,
             l_verified,
             l_usr_id,
             l_vin
        FROM beowner.ctx_data cd
        JOIN beowner.vin v
          ON v.vin = cd.vin
        JOIN beowner.bndl b
          ON b.payment_type = 'S'
             AND b.device_id = v.device_id
        JOIN beowner.usr u
          ON u.usr_id = cd.usr_id;

      l_action := utl.set_action(' Merging into SUBSCRIPTION');

      -- get COUNT for use in event log call
      SELECT COUNT(*)
        INTO STRICT vcount
        FROM beowner.ctx_data cd
        JOIN beowner.subscription s
          ON s.primary_id = cd.usr_id
             AND s.vin = cd.vin;

    WITH 
    src AS 
        (SELECT
              beowner.rand_guid()::UUID subscription_id,
              usr_id primary_id,
              vin,
              vbndlid bndl_id,
              vsubstart sub_start,
              vsubduration sub_duration 
           FROM beowner.ctx_data)
    ,sub_update AS 
        (UPDATE
          beowner.subscription as dst 
        SET
          bndl_id = src.bndl_id,
          sub_start = src.sub_start,
          sub_duration = src.sub_duration 
        FROM src 
        WHERE
          dst.primary_id = src.primary_id AND dst.vin = src.vin 
          returning dst.primary_id, dst.vin)
    INSERT INTO beowner.subscription(subscription_id, primary_id, vin, bndl_id, sub_start, sub_duration) 
        SELECT subscription_id,
               primary_id,
               vin,
               bndl_id,
               sub_start,
               sub_duration 
        FROM src 
       WHERE 
          NOT EXISTS  
          (SELECT * FROM sub_update as u 
             WHERE
                u.primary_id = src.primary_id 
                AND u.vin = src.vin);

      CALL utl.checkvinconflict(); -- uses context

      -- record event for reporting
      IF i_dofu IS NULL AND
         vcount != 0
      THEN
         -- Modified logic for DDCRD-407
         -- Dofu was null before this RDR came in
         -- Only considering pre-existing subscription, since new subscripion inserts into event_log are handled by trigger on subscription table
        CALL beowner.tg_update_event_log_sp(itype       => utl.get_constant_value ('c_event_log_type_subscription'),
                                            iusrid      => l_usr_id,
                                            ivin        => l_vin,
                                            istatus     => utl.get_constant_value ('c_new_active_subs_status'),
                                            ostatusrslt => vrslt,
                                            iold_status => utl.get_constant_value ('c_new_grace_subs_status'));
      END IF;

      IF l_verified IS NULL
      THEN
         IF vmakeid IN ('TM', 'LX')
         THEN
            l_action := utl.set_action(' Creating token for email');

            vtoken := encode(extensions.digest(to_char(CURRENT_TIMESTAMP,'YYYYMMDDHH24MISSUS') ||vemail, 'sha1'), 'hex');
            
            INSERT INTO beowner.validation_token(encoded_token, usr_id, vt_type, expire)
               SELECT upper(vtoken),
                      cd.usr_id,
                      'VALIDATE_EMAIL',
                      CURRENT_TIMESTAMP + (7 * ('1'||'DAY')::interval)
                 FROM beowner.ctx_data cd;

            l_action :=  utl.set_action(' Sending Subscription email');

            DECLARE
               vkeyvalues xml;
            BEGIN
               -- Modified for Jira PHVPRIME-125, since non-EV devices e.g. E06 also need model now.
               -- It doesn't hurt other devices emails to have model parameter sent.
               SELECT xmlconcat(XMLELEMENT(name "entry",
                                           XMLELEMENT(name "key", 'token'),
                                           XMLELEMENT(name "value", vtoken)),
                                XMLELEMENT(name "entry",
                                           XMLELEMENT(name "key", 'vehicleModel'),
                                           XMLELEMENT(name "value", vmodel)))
                 INTO STRICT vkeyvalues;

               -- Modified for OnTime WI #15530
               CALL utl.get_email_info(i_make_id => vmakeid
                                      ,i_email_name => 'SUBSCRIBER_SIGNUP'
                                      ,i_device_id => vdeviceid
                                      ,i_vin => l_vin
                                      ,i_subscription_id => NULL
                                      ,o_subject => l_subject
                                      ,o_template_name => vtemplatename);

               PERFORM email.send(ito           => vemail,
                                  isubject      => l_subject,
                                  itemplatename => vtemplatename,
                                  ikeyvalues    => vkeyvalues);
            END;
         END IF;
      END IF;
   END;
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE rdr.create_subscription (r INOUT rdr_staging, i_dofu vin.dofu%TYPE) FROM PUBLIC;

\i cleanup.sql;
