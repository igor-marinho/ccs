SET bedb.filename = 'procedure.clean_pending_primary_accounts.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS rdr.clean_pending_primary_accounts (beowner.vin.vin%TYPE, beowner.usr.usr_id%TYPE);

CREATE OR REPLACE PROCEDURE rdr.clean_pending_primary_accounts (ivin beowner.vin.vin%TYPE, inotusrid beowner.usr.usr_id%TYPE)
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'clean_pending_primary_accounts';

    rowcount integer;
    l_result integer;
    l_usrid  usr.usr_id%TYPE;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN

    l_action :=  utl.set_module_action( l_module_name, ' Cleaning Pending Primary accounts');
      -- clean up any potential mess
    CREATE TEMPORARY TABLE IF NOT EXISTS gt_usr(USR_ID UUID);
	DELETE FROM gt_usr WHERE 1=1;
      /*
        The following query gets all of the primary usr_id's related
        to any subscriptions of iVIN, and where the user's accounts
        are not verified (i.e. PENDING)

        Ontime 24747: Updated query to not look at secondary accounts
      */
      INSERT INTO gt_usr
         SELECT u.usr_id
           FROM beowner.subscription s
           JOIN beowner.usr u
             ON u.usr_id = s.primary_id
          WHERE s.vin = ivin
                AND u.verified IS NULL
                AND u.usr_id != inotusrid;

      GET DIAGNOSTICS rowcount = ROW_COUNT;
        IF rowcount = 0
        THEN
           -- there isn't any work to be done
           RETURN;
        END IF;

      SELECT DISTINCT usr_id
        INTO STRICT l_usrid
        FROM gt_usr;

      --DI 1475
      --using crudg_usr.d_usr_sp to delete usr info and child records
      l_result := crudg_usr.d_usr_sp(iusr_id           => l_usrid::TEXT,
                                     i_uc_id           => NULL,
                                     iuserlogin        => NULL,
                                     ipwd              => NULL,
                                     ifirst_name       => NULL,
                                     ilast_name        => NULL,
                                     iversion          => NULL,
                                     i_delete_children => 'Y');
      IF l_result != utl.get_constant_value('csuccess')::INTEGER
      THEN
      GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
         CALL trc.log(iadditionaldata => 'Error while deleting user and children : ' || l_result,
                      iexception_diagnostics => l_exception_diagnostics);
         RAISE 'Error while deleting user and children' USING ERRCODE = utl.get_constant_value('e_delete_usr_children');
      END IF;

      CALL utl.checkvinconflict(ivin);
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE rdr.clean_pending_primary_accounts (ivin vin.vin%TYPE, inotusrid usr.usr_id%TYPE) FROM PUBLIC;

\i cleanup.sql;
