SET bedb.filename = 'function.load_rdr.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS rdr.load_rdr (beowner.rdr_staging);
   /* Return value :
        0 : Success (utl.get_constant_value('csuccess'))
      256 : VIN not found in DB  (cnst.cdbrdrprocessvinnotfound)
        2 : RDR rejected because of invalid VIN format or AM or PM phone number missing  (cnst.c_rdr_processing_error)
        1 : Internal (unhandled) Error
   
      r.rjl_processed_flag is set as below:
         'P' : Pending (VIN not in DB) (cnst.c_RDR_pending)
         'N' : Not processed yet       (cnst.c_RDR_not_processed)
         'R' : rejected                (cnst.c_RDR_rejected)
         'Y' : processed successfully  (cnst.c_RDR_successful)
   
   */
CREATE or REPLACE FUNCTION rdr.load_rdr (o_status_code OUT INTEGER, r INOUT beowner.rdr_staging)
AS $body$
DECLARE   
    l_action TEXT;
    l_module_name text := 'load_rdr';   
    vcount INTEGER;
    isreversal  VARCHAR(1) := utl.get_constant_value('crdrfalse');
    cfalse VARCHAR(1) := utl.get_constant_value ('crdrfalse');
    ctrue  VARCHAR(1) := utl.get_constant_value ('crdrtrue');
    l_vin_found BOOLEAN;
    l_dofu      beowner.vin.dofu%TYPE; -- Jira DDCRD-407
    l_exception_diagnostics trc.exception_diagnostics;
    l_ctx_status INTEGER;
   BEGIN
      l_action := utl.set_module_action(l_module_name, ' Validating RS_JOB_LOG_ID');

      CALL utl.dbg('r.rs_job_log_id = ' || r.rs_job_log_id);
   
      IF r.rs_job_log_id IS NULL
      THEN
         o_status_code := utl.get_constant_value('cdbemptyjobidexception');
         RETURN; 
      END IF;
   
      SELECT COUNT(*)
        INTO vcount
        FROM beowner.rdr_job_log
       WHERE rjl_job_log_id = r.rs_job_log_id;

      IF vcount = 0
      THEN
         l_action := utl.set_action(' Don''t have a record in RDR_JOB_LOG');
         l_exception_diagnostics.module_name := l_module_name;
         l_exception_diagnostics.action := l_action;
         CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
         -- don't really have a code for this, so use Empty Job ID
         o_status_code := utl.get_constant_value('cdbemptyjobidexception');
         RETURN; 
      END IF;

      l_action := utl.set_action(' Looking for duplicate RDR_STAGING record');
   
      SELECT COUNT(*)
        INTO vcount
        FROM beowner.rdr_staging
       WHERE rs_job_log_id = r.rs_job_log_id;

    CALL rdr.scrub(r, l_vin_found);

      IF vcount = 0
      THEN
         -- the row already exists if vcount > 0, so don't insert it again
         l_action := utl.set_action(' Saving row in RDR_STAGING');
      
         INSERT INTO beowner.rdr_staging
         VALUES (r.rs_job_log_id
                ,r.rs_vin
                ,r.rs_used_ind
                ,r.rs_retail_date_time
                ,r.rs_reversal_ind
                ,r.rs_reversal_type
                ,r.rs_company_name
                ,r.rs_org_line1
                ,r.rs_org_line2
                ,r.rs_org_city
                ,r.rs_org_state
                ,r.rs_org_zip_code
                ,r.rs_org_phone_am_areacode
                ,r.rs_org_phone_am_exchange
                ,r.rs_org_phone_am_line_number
                ,r.rs_org_phone_am_extension
                ,r.rs_org_phone_pm_areacode
                ,r.rs_org_phone_pm_exchange
                ,r.rs_org_phone_pm_line_number
                ,r.rs_org_phone_pm_extension
                ,r.rs_org_email_id
                ,r.rs_buyer_first_name
                ,r.rs_buyer_middle_initial
                ,r.rs_buyer_last_name
                ,r.rs_buyer_name_suffix
                ,r.rs_buyer_line1
                ,r.rs_buyer_line2
                ,r.rs_buyer_city
                ,r.rs_buyer_state
                ,r.rs_buyer_zip_code
                ,r.rs_buyer_phone_am_areacode
                ,r.rs_buyer_phone_am_exchange
                ,r.rs_buyer_phone_am_linenumber
                ,r.rs_buyer_phone_am_extension
                ,r.rs_buyer_phone_pm_areacode
                ,r.rs_buyer_phone_pm_exchange
                ,r.rs_buyer_phone_pm_linenumber
                ,r.rs_buyer_phone_pm_extension
                ,r.rs_buyer_email_id
                ,r.rs_invalid_vin_flag
                ,r.rs_invalid_make_flag
                ,r.rs_invalid_email_flag
                ,r.rs_invalid_phone_flag
                ,r.rs_invalid_name_flag
                ,r.rs_invalid_address_flag
                ,r.rs_vin_not_found_indb_flag
                ,r.rs_created_date);
         -- RETURN cnst.cdbdupjobidexception;  -- commented out for OnTime #14781 to allow for reprocessing a Pending RDR
      END IF;

      -- OnTime #14781
      CASE current_setting('rdr.g_rjl_processed_flag')
         WHEN utl.get_constant_value('c_rdr_pending') THEN
            o_status_code := utl.get_constant_value('cdbrdrprocessvinnotfound');
            RETURN;
         WHEN utl.get_constant_value('c_rdr_not_processed') THEN
            NULL; -- not in pending or rejected state, will be processed below
         ELSE
            -- 'R' only for now
            o_status_code :=  utl.get_constant_value('c_rdr_processing_error');
            RETURN;
      END CASE;
   
      l_action := utl.set_action(' Determining Flags');
    /* Not used, hence commenting out, as it is confusing  
           isrereport := CASE
                             WHEN r.rs_reversal_ind = 'Y' AND
                                  r.rs_reversal_type = 'R' THEN
                              ctrue
                             ELSE
                              cfalse
                          END;
      */
      isreversal := CASE
                       WHEN r.rs_reversal_ind = 'Y' AND
                            r.rs_reversal_type != 'R' THEN
                        ctrue
                       ELSE
                        cfalse
                    END;
   
      IF isreversal = cfalse
      THEN
         DECLARE
            vmakeid beowner.make.make_id%TYPE;
            vusrid  beowner.usr.usr_id%TYPE;
            --
            -- Added for OneTime defect#11824
            -- variable that hold return value from is_individual function
            vind BOOLEAN;
            -- variable that hold email ID (either buyer or organization)
            vemail TEXT;
         BEGIN
            IF l_vin_found -- OnTime #14781 Cannot update VIN if it doesn't exist in DB
            THEN
               SELECT o_makeid INTO vmakeid FROM rdr.load_vin(r); -- Jira DDCRD-407
            END IF;
            --
            -- Added for OneTime defect#11824
            vind := rdr.is_individual(p_buyer_email => r.rs_buyer_email_id,
                                      p_org_email   => r.rs_org_email_id);

            vemail := CASE
                         WHEN vind THEN
                          r.rs_buyer_email_id
                         ELSE
                          r.rs_org_email_id
                      END;
 
    /* OnTime #14781 If VIN doesn't exist in DB, subscription cannot be created. User cannot be created either since make is retrieved from the VIN */
            IF l_vin_found AND
               COALESCE(vemail, '') != ''
            THEN
               --
               -- Added for OneTime defect#11822
               -- Set context based on Make ID (TM/LX) and VIN only
               CALL utl.dbg('vmakeid= ' || vmakeid || ', r.rs_vin=' || r.rs_vin);
               l_ctx_status := ctx.set(iloginid => NULL, imakeid => vmakeid, ivin => r.rs_vin);

               vusrid := rdr.manage_user(r, vmakeid, r.rs_vin);
               
               IF vusrid is NULL
               THEN  
               o_status_code := utl.get_constant_value('csuccess');
               RETURN;
               END IF;
 
               CALL utl.dbg('vusrid = ' || vusrid);
                l_ctx_status := ctx.set(iloginid => NULL,
                                        iusrid  => vusrid::TEXT,
                                        imakeid => vmakeid,
                                        ivin    => r.rs_vin);
               CALL rdr.create_subscription(r, i_dofu => l_dofu); -- Jira DDCRD-407
               -- Added for OneTime defect#11824

            END IF;
         END;
      END IF;
     
      -- If it reached this point, it means the RDR was processed successfully.
      UPDATE beowner.rdr_job_log
         SET rjl_processed_flag = utl.get_constant_value('c_rdr_successful')
       WHERE rjl_job_log_id = r.rs_job_log_id
             AND rjl_processed_flag = utl.get_constant_value('c_rdr_not_processed');

    o_status_code := utl.get_constant_value('csuccess');
    RETURN;
   EXCEPTION
      WHEN OTHERS THEN
          GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;
            CALL trc.log(iadditionaldata => NULL,
                            iexception_diagnostics => l_exception_diagnostics);

         o_status_code := utl.get_constant_value('cinternalerror');
         RETURN;
END
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
\i cleanup.sql;
