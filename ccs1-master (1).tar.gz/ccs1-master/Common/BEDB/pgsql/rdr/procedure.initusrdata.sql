SET bedb.filename = 'procedure.initusrdata.sql';
\i set_be_env.sql;

DROP PROCEDURE IF EXISTS rdr.initusrdata (text, text, TEXT, beowner.usr);
  -------------------------------------------------------------------------------
   -- Removed columns TOS_FLAG,DWNLD_APP_FLAG for DCS1E-921

CREATE OR REPLACE PROCEDURE rdr.initusrdata (iemail           text
                                            ,imakeid          text
                                            ,upd_ind   INOUT  text
                                            ,ousrrow   INOUT  beowner.usr)
AS $body$
BEGIN
      SELECT *
        INTO STRICT ousrrow
        FROM beowner.usr
       WHERE login_id = iemail
             AND make_id = imakeid;
        
upd_ind := utl.get_constant_value('c_yes');     
             
   EXCEPTION
      WHEN no_data_found THEN
         ousrrow.usr_id := beowner.rand_guid();
         ousrrow.login_id := iemail;
         ousrrow.make_id := imakeid;
         ousrrow.pwd := 'q9FRF9FI3vQ6lDV9kG/enOYRvGT6C+sAf4/NvYYTGTE=';
         ousrrow.created := CURRENT_TIMESTAMP;
         ousrrow.lang_id := utl.get_constant_value('clangenus'); -- added for language changes, checked in for OnTime 5979 (DB Id 121
         ousrrow.locked := ' ';
         ousrrow.lvl := '0';
         ousrrow.parent_id := NULL;
         ousrrow.parentlvl := NULL;
         -- OnTime #16641 : TMS 3PP Reports: The current code excludes all 2011 model year vehicles as test vins from the reports
         ousrrow.test_user := 'N';
         ousrrow.create_type := 'O'; -- Jira SBM-112
         
         upd_ind := utl.get_constant_value('c_no');
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE rdr.initusrdata (iemail text, imakeid text, orowid INOUT text, ousrrow INOUT usr) FROM PUBLIC;

\i cleanup.sql;
