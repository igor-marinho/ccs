SET bedb.filename = 'function.get_pending_rdr_summary.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS rdr.get_pending_rdr_summary(beowner.rdr_job_log.rjl_created_date%TYPE, beowner.rdr_job_log.rjl_created_date%TYPE);
   /* get_pending_rdr_summary
     Out : rslt - ref cursor with columns: 
     Total_RDR_pending, New_RDR_Pending
   
   Return : integer (status code) - 0 if success
   Error codes : 
   520 : From and To date are both required
   521 : To date must be greater than From date
   */
CREATE OR REPLACE FUNCTION rdr.get_pending_rdr_summary (i_from_date         beowner.rdr_job_log.rjl_created_date%TYPE
                                                       ,i_to_date           beowner.rdr_job_log.rjl_created_date%TYPE
                                                       ,o_status_code   OUT INTEGER
                                                       ,rslt            OUT refcursor) 
AS $body$
DECLARE
      l_action text;
      l_module_name text := 'get_pending_rdr_summary';
      l_date_validation_return text;
      l_exception_diagnostics trc.exception_diagnostics;
BEGIN
      l_action := utl.set_module_action(l_module_name,'Validating inputs');
      rslt := utl.get_dummy_cursor();

      l_date_validation_return := utl.validate_dates(i_from_date => i_from_date,
                                                     i_to_date   => i_to_date);
                                                 
      IF l_date_validation_return != utl.get_constant_value ('csuccess')
      THEN
         o_status_code := l_date_validation_return;
         RETURN;
      END IF;

      l_action := utl.set_action('Returning results');
      CLOSE rslt;
      OPEN rslt FOR
         SELECT COUNT(1) total_rdr_pending,
                SUM(CASE
                       WHEN rjl.rjl_created_date >= i_from_date AND
                            rjl.rjl_created_date < i_to_date THEN
                        1
                       ELSE
                        0
                    END) new_rdr_pending
           FROM beowner.rdr_job_log rjl
          WHERE rjl.rjl_processed_flag = utl.get_constant_value('c_rdr_pending');
      o_status_code := utl.get_constant_value('csuccess');
      RETURN;
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
         CALL trc.log('Something went wrong in ' || l_module_name,
                        iexception_diagnostics => l_exception_diagnostics);
         rslt := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cinternalerror');
     RETURN;
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION rdr.get_pending_rdr_summary (i_from_date rdr_job_log.rjl_created_date %TYPE, i_to_date rdr_job_log.rjl_created_date %TYPE, rslt OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
