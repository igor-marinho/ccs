SET bedb.filename = 'function.manage_user.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS rdr.manage_user(beowner.rdr_staging, beowner.make.make_id%TYPE, beowner.vin.vin%TYPE);
-- Added new function for defect#11824
CREATE OR REPLACE FUNCTION rdr.manage_user (r         IN beowner.rdr_staging
                                           ,imakeid   IN beowner.make.make_id%TYPE
                                           ,ivin      IN beowner.vin.vin%TYPE) RETURNS beowner.usr.usr_id%TYPE
AS $body$
DECLARE
    l_action  TEXT;
    l_module_name text := 'manage_user';
    rowcount smallint;

    u_upd_ind text;
    u    beowner.usr;

    e_upd_ind text;
    e    beowner.usr_email;

    d_upd_ind text;
    d    beowner.usr_demog;

    pam_upd_ind text;
    pam    beowner.usr_phone;

    ppm_upd_ind text;
    ppm    beowner.usr_phone;

    problem CONSTANT text := 'This is a problem';

    vind   boolean;
    vemail text;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
      --
      -- updated the logic for defect #11824
      -- new logic: based on email (buyer/organization) to determine individual or organization
      vind := rdr.is_individual(p_buyer_email => r.rs_buyer_email_id,
                                p_org_email   => r.rs_org_email_id);
      -- old logic: based on company name
      -- vInd := r.rs_company_name is null;
      --
      vemail := CASE
                   WHEN vind THEN
                    r.rs_buyer_email_id
                   ELSE
                    r.rs_org_email_id
                END;

      l_action := utl.set_module_action( l_module_name, ' Retrieving Data');

      -- USR: get existing data; if not there, initialize the USR record for insertion
      CALL rdr.initusrdata(vemail, imakeid, u_upd_ind, u);

      IF u.parent_id IS NOT NULL
      THEN
         l_action := utl.set_action('Specified User is a secondary');
	     CALL rdr.sendsecondaryemail(vemail, u.parent_id);
         RETURN NULL;
      END IF;

      -- the following retrieves existing data; if data isn't there, it initializes necessary fields
      CALL rdr.initotherdata(u.usr_id, e_upd_ind, e, d_upd_ind, d, pam_upd_ind, pam, ppm_upd_ind, ppm);

      -- clean out any pending accounts on this VIN  (but not for u.usr_id!)
      CALL rdr.clean_pending_primary_accounts(ivin => ivin, inotusrid => u.usr_id);

      l_action := utl.set_action(' Setting All Data');

      /* moving below assignments to initusrdata for Jira SBM-112.
        Locked is already assigned there too and is mandatory
      u.create_type := 'O';
       u.locked := nvl(u.locked, ' '); */
      -- the rest gets updated only when there isn't any info there to begin with
      e.email := coalesce(e.email, vemail);
      d.name_first := coalesce(d.name_first,
                          CASE
                             WHEN vind THEN
                              r.rs_buyer_first_name
                             ELSE
                              '@ORGANIZATION'
                          END);
      d.name_mi := coalesce(d.name_mi,
                       CASE
                          WHEN vind THEN
                           r.rs_buyer_middle_initial
                          ELSE
                           NULL
                       END);
      d.name_last := coalesce(d.name_last,
                         CASE
                            WHEN vind THEN
                             r.rs_buyer_last_name
                            ELSE
                             r.rs_company_name
                         END);
      d.name_suffix := coalesce(d.name_suffix,
                           CASE
                              WHEN vind THEN
                               r.rs_buyer_name_suffix
                              ELSE
                               NULL
                           END);
      d.addr1 := coalesce(d.addr1,
                     CASE
                        WHEN vind THEN
                         r.rs_buyer_line1
                        ELSE
                         r.rs_org_line1
                     END);
      d.addr2 := coalesce(d.addr2,
                     CASE
                        WHEN vind THEN
                         r.rs_buyer_line2
                        ELSE
                         r.rs_org_line2
                     END);
      d.city := coalesce(d.city,
                    CASE
                       WHEN vind THEN
                        r.rs_buyer_city
                       ELSE
                        r.rs_org_city
                    END);
      d.state := coalesce(d.state,
                     CASE
                        WHEN vind THEN
                         r.rs_buyer_state
                        ELSE
                         r.rs_org_state
                     END);
      d.postal_code := coalesce(d.postal_code,
                           CASE
                              WHEN vind THEN
                               r.rs_buyer_zip_code
                              ELSE
                               r.rs_org_zip_code
                           END);
      pam.ac := coalesce(pam.ac,
                    CASE
                       WHEN vind THEN
                        r.rs_buyer_phone_am_areacode
                       ELSE
                        r.rs_org_phone_am_areacode
                    END);
      pam.phone := coalesce(pam.phone,
                       CASE
                          WHEN vind THEN
                           r.rs_buyer_phone_am_exchange ||
                           r.rs_buyer_phone_am_linenumber
                          ELSE
                           r.rs_org_phone_am_exchange ||
                           r.rs_org_phone_am_line_number
                       END);
      pam.ext := coalesce(pam.ext,
                     CASE
                        WHEN vind THEN
                         r.rs_buyer_phone_am_extension
                        ELSE
                         r.rs_org_phone_am_extension
                     END);
      ppm.ac := coalesce(ppm.ac,
                    CASE
                       WHEN vind THEN
                        r.rs_buyer_phone_pm_areacode
                       ELSE
                        r.rs_org_phone_pm_areacode
                    END);
      ppm.phone := coalesce(ppm.phone,
                       CASE
                          WHEN vind THEN
                           r.rs_buyer_phone_pm_exchange ||
                           r.rs_buyer_phone_pm_linenumber
                          ELSE
                           r.rs_org_phone_pm_exchange ||
                           r.rs_org_phone_pm_line_number
                       END);
      ppm.ext := coalesce(ppm.ext,
                     CASE
                        WHEN vind THEN
                         r.rs_buyer_phone_pm_extension
                        ELSE
                         r.rs_org_phone_pm_extension
                     END);

      l_action := utl.set_action(' Updating USR');

  
--UPDATE beowner.usr
      IF u_upd_ind = utl.get_constant_value('c_yes')
      THEN
         UPDATE beowner.usr dst
             SET (usr_id,pwd,created,parent_id,verified,lang_id,create_type,"locked",lvl,parentlvl,test_user,transaction_id) 
                = (u.usr_id, u.pwd, u.created, u.parent_id, u.verified, u.lang_id, u.create_type, u."locked", u.lvl, u.parentlvl, u.test_user, u.transaction_id)
            WHERE dst.login_id  = u.login_id
                AND dst.make_id = u.make_id;

         GET DIAGNOSTICS rowcount = ROW_COUNT;
        
         IF rowcount != 1
         THEN
            RAISE EXCEPTION '%', problem USING ERRCODE = '45001';
         END IF;
      ELSE
         INSERT INTO 
            beowner.usr(usr_id,login_id,make_id,pwd,created,parent_id,verified,lang_id,create_type,"locked",lvl,parentlvl,test_user,transaction_id)
            VALUES (u.usr_id, u.login_id, u.make_id, u.pwd, u.created, u.parent_id, u.verified, u.lang_id, u.create_type, u."locked", u.lvl, u.parentlvl, u.test_user, u.transaction_id);

         DECLARE
            vdummystatus text;
         BEGIN
            PERFORM ctx.set(iloginid => NULL, iusrid => u.usr_id::TEXT, imakeid => imakeid);
            vdummystatus := beowner.tg_create_stockpref_sp();
         END;
      END IF;
--UPDATE beowner.usr_email
      l_action := utl.set_action(' Updating USR_EMAIL');

      IF e_upd_ind = utl.get_constant_value('c_yes')
      THEN
         UPDATE beowner.usr_email dst
            SET (email, status, status_date) = (e.email, e.status, e.status_date)
          WHERE dst.usr_id = u.usr_id
                AND dst.email_type_id = 'H1';

         GET DIAGNOSTICS rowcount = ROW_COUNT;
         IF rowcount != 1
         THEN
            RAISE EXCEPTION '%', problem USING ERRCODE = '45001';
         END IF;
      ELSE
         INSERT INTO beowner.usr_email(usr_id, email_type_id, email, status, status_date)
         VALUES (e.usr_id, e.email_type_id, e.email, e.status, e.status_date);
      END IF;

      l_action := utl.set_action(' Updating USR_DEMOG');
--UPDATE beowner.usr_demog
      IF d_upd_ind = utl.get_constant_value('c_yes')
      THEN
         UPDATE beowner.usr_demog dst
         SET (name_first, name_mi, name_last, name_suffix, addr1, addr2, city, state, postal_code, country)
            = (d.name_first, d.name_mi, d.name_last, d.name_suffix, d.addr1, d.addr2, d.city, d.state, d.postal_code, d.country)
          WHERE dst.usr_id = u.usr_id;

         GET DIAGNOSTICS rowcount = ROW_COUNT;
         IF rowcount != 1
         THEN
            RAISE EXCEPTION '%', problem USING ERRCODE = '45001';
         END IF;
      ELSE
         INSERT INTO beowner.usr_demog(usr_id,  name_first,  name_mi,  name_last,  name_suffix,  addr1,  addr2,  city,  state,  postal_code,  country) 
         VALUES (d.usr_id, d.name_first, d.name_mi, d.name_last, d.name_suffix, d.addr1, d.addr2, d.city, d.state, d.postal_code, d.country);
      END IF;
 
--UPDATE beowner.usr_phone PAM
      BEGIN
         l_action := utl.set_action(' Updating USR_PHONE (H1)');

         IF pam_upd_ind = utl.get_constant_value('c_yes')
         THEN
            UPDATE beowner.usr_phone dst
               SET (cc, ac, phone, ext)  = (pam.cc, pam.ac, pam.phone, pam.ext)
             WHERE dst.usr_id = u.usr_id
                AND dst.phone_type_id = 'H1';

            GET DIAGNOSTICS rowcount = ROW_COUNT;
            
            IF rowcount != 1
            THEN
               RAISE EXCEPTION '%', problem USING ERRCODE = '45001';
            END IF;
         ELSE
            -- OnTime #22159 : Try to insert AM phone only if it is provided (valid)
            IF current_setting('rdr.g_insert_am_phone')::boolean
            THEN
               INSERT INTO beowner.usr_phone(usr_id, phone_type_id, cc, ac, phone, ext)
               VALUES (pam.usr_id, pam.phone_type_id, pam.cc, pam.ac, pam.phone, pam.ext);
            ELSIF current_setting('rdr.g_insert_pm_phone')::boolean
            THEN
               -- OnTime #22159 : if AM phone is invalid, but PM phone is valid, insert PM phone instead of AM phone as H1
               ppm.phone_type_id := 'H1';

               INSERT INTO beowner.usr_phone(usr_id, phone_type_id, cc, ac, phone, ext)
               VALUES (ppm.usr_id, ppm.phone_type_id, ppm.cc, ppm.ac, ppm.phone, ppm.ext);
            END IF;
         END IF;

         l_action :=  utl.set_action(' Updating USR_PHONE (O1)');

         CALL utl.dbg('g_insert_pm_phone is ' || CASE WHEN current_setting('rdr.g_insert_pm_phone')::boolean THEN
                 'TRUE' ELSE 'FALSE' END);
         CALL utl.dbg('g_pm_phone_number = ' || current_setting('rdr.g_pm_phone_number')::varchar(100));

--UPDATE beowner.usr_phone PPM
         IF ppm_upd_ind = utl.get_constant_value('c_yes')
         THEN
            UPDATE beowner.usr_phone dst
               SET (cc, ac, phone, ext) = (ppm.cc, ppm.ac, ppm.phone, ppm.ext)
             WHERE dst.usr_id = u.usr_id
                AND dst.phone_type_id = 'O1';

            GET DIAGNOSTICS rowcount = ROW_COUNT;
            IF rowcount != 1
            THEN
               RAISE EXCEPTION '%', problem USING ERRCODE = '45001';
            END IF;
         ELSIF (NOT current_setting('rdr.g_insert_pm_phone')::boolean AND current_setting('rdr.g_pm_phone_number')::varchar(100) IS NOT NULL) OR
               pam_upd_ind = utl.get_constant_value('c_yes')
         THEN
            /* OnTime #22159 if PM phone is inserted into AM phone, then don't add the non-null PM phone again
            If AM row already exists for the user and PM phone is valid, insert PM row */
            INSERT INTO beowner.usr_phone(usr_id, phone_type_id, cc, ac, phone, ext)
            VALUES (ppm.usr_id, ppm.phone_type_id, ppm.cc, ppm.ac, ppm.phone, ppm.ext);
         END IF;
      EXCEPTION
         WHEN OTHERS THEN
            /* catchall, for phone numbers. For whatever reason, if the phone numbers cannot be inserted,
            it should not prevent the users from being created or the DOFU from being updated */
            GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
      END;

      RETURN u.usr_id;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION rdr.manage_user (r INOUT rdr_staging, imakeid make.make_id%TYPE, ivin vin.vin%TYPE) FROM PUBLIC;

\i cleanup.sql;
