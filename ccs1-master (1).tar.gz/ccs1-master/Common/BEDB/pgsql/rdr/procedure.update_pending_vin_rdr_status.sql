SET bedb.filename = 'procedure.update_pending_vin_rdr_status.sql';

\i set_be_env.sql;

   /*
   update_pending_vin_rdr_status
   
   Updates the RDR status in rdr_job_log for all RDRs in Pending state for the provided VIN.
   Processed flag/Status is set to R (Rejected), if no status is provided.
   Otherwise, it is updated to the value sent, as long as it is a valid value (R/Y/N).
   
   These are the error messages that are sent to the dbms output as long as serverout is set to ON :
    If no VIN is provided :   Please provide a VIN
    If an invalid status is provided : Invalid new RDR status - has to be either R/Y/N.
    If no pending RDRs were found for the VIN : No Pending RDRs found for VIN {i_vin}.
   
    On success : {n} RDR/s updated from Pending to Rejected/Successful/Not Processed (depending on i_new_status).
    This message is also logged in "trc" table.
   */


   ------------------------------------------------------------------------------------------------
   -- Added for OnTime #14781 to update the RDR status in rdr_job_log with a valid value
   
drop procedure if exists rdr.update_pending_vin_rdr_status (beowner.rdr_staging.rs_vin%TYPE, 
                                                            beowner.rdr_job_log.rjl_processed_flag%TYPE
															);

CREATE OR REPLACE PROCEDURE rdr.update_pending_vin_rdr_status (i_vin        beowner.rdr_staging.rs_vin%TYPE, 
                                                               i_new_status beowner.rdr_job_log.rjl_processed_flag%TYPE DEFAULT utl.get_constant_value('c_rdr_rejected')
															   ) AS $body$
DECLARE

      l_action                text;
      l_module_name           text := 'update_pending_vin_rdr_status';
      l_count                 INTEGER;
      l_rjl_processed_flag    beowner.rdr_job_log.rjl_processed_flag%TYPE := upper(i_new_status);
      l_text                  text;
      l_vin                   beowner.rdr_staging.rs_vin%TYPE := upper(i_vin);
      l_exception_diagnostics trc.exception_diagnostics;
	
BEGIN
									   
      l_action := utl.set_module_action( l_module_name, 'update_pending_vin_rdr_status');									   
      
	  IF COALESCE(l_vin, '') = ''
      THEN
         RAISE NOTICE 'Please provide a VIN.';
         RETURN;
      ELSIF coalesce(l_rjl_processed_flag, '!') NOT IN (utl.get_constant_value('c_rdr_rejected'), utl.get_constant_value('c_rdr_successful'),utl.get_constant_value('c_rdr_not_processed'))
      THEN
         RAISE NOTICE 'Invalid new RDR status - has to be either %/%/%.', utl.get_constant_value('c_rdr_rejected'), utl.get_constant_value('c_rdr_successful'),utl.get_constant_value('c_rdr_not_processed');
         RETURN;
      END IF;

      UPDATE beowner.rdr_job_log rjl
      SET rjl_processed_flag = l_rjl_processed_flag
      WHERE rjl.rjl_job_log_id IN (SELECT rs.rs_job_log_id
                                   FROM beowner.rdr_staging rs
                                   WHERE rs_vin = l_vin)
      AND rjl.rjl_processed_flag = utl.get_constant_value('c_rdr_pending');

      GET DIAGNOSTICS l_count = ROW_COUNT;
	  
IF l_count = 0
      THEN
         RAISE NOTICE 'No Pending RDRs found for VIN %.', l_vin;
         RETURN;
      ELSE
          l_text = l_count || ' RDR/s updated from Pending to ' ||
                   CASE l_rjl_processed_flag
                      WHEN utl.get_constant_value('c_rdr_rejected') THEN
                       'Rejected'
                      WHEN utl.get_constant_value('c_rdr_successful') THEN
                       'Successful'
                      WHEN utl.get_constant_value('c_rdr_not_processed') THEN
                       'Not Processed'
                      END || ' for VIN ' || l_vin || '.';
         RAISE NOTICE '%', l_text;

         
         CALL trc.log(l_text);
         RETURN;
      END IF;
EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;


          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
						
          RAISE NOTICE 'An unexpected error occurred. Please check trace log.';
END;
   
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE rdr.update_pending_vin_rdr_status (i_vin rdr_staging.rs_vin%TYPE, i_new_status rdr_job_log.rjl_processed_flag%TYPE DEFAULT cnst.c_rdr_rejected) FROM PUBLIC;

\i cleanup.sql;
