SET bedb.filename = 'function.get_pending_rdr_details.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS rdr.get_pending_rdr_details(); 
   /* get_pending_rdr_details
   Out : rslt - ref cursor with columns: 
       job_log_id, created_date, vin, pending_days
      
    No Input parameters, since the 'from date' is irrelevant, as regardless of when the Pending RDR was received, 
    it needs to be included. 
    Cannot take 'to date' into consideration, since we don't have a history of when a RDR converted 
    from Pending to non-pending state. Hence the data returned is for point-in-time.
   */
CREATE OR REPLACE FUNCTION rdr.get_pending_rdr_details (o_status_code   OUT INTEGER, rslt OUT REFCURSOR) 
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'get_pending_rdr_details';
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
      l_action := utl.set_module_action(l_module_name,'Returning results');

      OPEN rslt FOR
         SELECT rjl.rjl_job_log_id job_log_id,
                rjl.rjl_created_date created_date,
                (SELECT rs.rs_vin
                   FROM beowner.rdr_staging rs
                  WHERE rs.rs_job_log_id = rjl.rjl_job_log_id) rs_vin,
                   CURRENT_DATE - date_trunc('day', rjl.rjl_created_date)::DATE pending_days
           FROM beowner.rdr_job_log rjl
          WHERE rjl.rjl_processed_flag = utl.get_constant_value('c_rdr_pending')
          ORDER BY pending_days DESC,
                   rs_vin;
        o_status_code := utl.get_constant_value('csuccess');
      RETURN;
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
         CALL trc.log('Something went wrong in ' || l_module_name,
                        iexception_diagnostics => l_exception_diagnostics);
         rslt := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cinternalerror');
     RETURN;
   END;
   -- CR10303 changes end --
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION rdr.get_pending_rdr_details (rslt OUT REFCURSOR) FROM PUBLIC;
   -- CR10303 changes end --

\i cleanup.sql;
