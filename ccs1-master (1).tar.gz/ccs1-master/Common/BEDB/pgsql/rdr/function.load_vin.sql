SET bedb.filename = 'function.load_vin.sql';

\i set_be_env.sql;

   
DROP function if exists rdr.load_vin (beowner.rdr_staging);

CREATE OR REPLACE FUNCTION rdr.load_vin (r INOUT beowner.rdr_staging, o_dofu OUT beowner.vin.dofu%TYPE, o_makeid OUT beowner.make.make_id%TYPE)
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'load_vin';

    vdofu   beowner.vin.dofu%TYPE;
    --vrowid  oid;
    
BEGIN
      l_action := utl.set_module_action( l_module_name,' Setting DOFU');

      vdofu := to_timestamp(NULLIF(r.rs_retail_date_time,''), 'YYYY-MM-DD HH24:MI:SS:');

      l_action := utl.set_action(' Retrieving VIN (including MAKE_ID)');

      SELECT v.make_id,
             v.dofu
        INTO STRICT o_makeid,
             o_dofu
        FROM beowner.vin v
       WHERE v.vin = r.rs_vin;

      l_action := utl.set_action(' Updating VIN');

      UPDATE beowner.vin v
         SET dealer_flag = '1',
             dofu = CASE
                         WHEN COALESCE(r.rs_used_ind, '') = '' AND
                              vdofu IS NOT NULL THEN
                          vdofu
                         WHEN r.rs_used_ind = 'Y' AND
                              vdofu IS NOT NULL AND
                              v.dofu is NULL THEN
                          vdofu -- WI#13773: Used RDR accepted only if no RDR has already been received for VIN
                         ELSE
                          v.dofu
                      END
       WHERE v.vin = r.rs_vin;

      RETURN;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION rdr.load_vin (r INOUT rdr_staging, o_dofu OUT vin.dofu%TYPE) FROM PUBLIC;

\i cleanup.sql;
