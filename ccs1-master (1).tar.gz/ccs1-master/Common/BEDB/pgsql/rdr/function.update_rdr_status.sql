SET bedb.filename = 'function.update_rdr_status.sql';
\i set_be_env.sql;

DROP FUNCTION IF EXISTS rdr.update_rdr_status (TEXT, beowner.rdr_job_log.rjl_processed_flag%TYPE);
   /*
    Updates the RDR status in rdr_job_log with the provided value.
   
    Return value :
        0 : Success (utl.get_constant_value('csuccess'))
      258 : Invalid value provided for new status - has to be P,R,Y or N (cnst.cinvalid_rdr_process_flag)
      257 : Invalid Job Log ID  (cnst.cinvalid_rdr_job_log_id)
        1 : Internal (unhandled) Error
   */

   ------------------------------------------------------------------------------------------------
   -- Added for OnTime #14781 to update the RDR status in rdr_job_log with a valid value
CREATE OR REPLACE FUNCTION rdr.update_rdr_status (i_job_log_id   TEXT
                                                 ,i_new_status   beowner.rdr_job_log.rjl_processed_flag%TYPE) 
                                                 RETURNS  INTEGER 
AS $body$
DECLARE
    l_action TEXT;     
    l_module_name text := 'update_rdr_status';
    rowcount int;
    l_rjl_processed_flag beowner.rdr_job_log.rjl_processed_flag%TYPE := upper(i_new_status);
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
      IF coalesce(l_rjl_processed_flag, '!') NOT IN ( utl.get_constant_value('c_rdr_pending'),
                                                      utl.get_constant_value('c_rdr_rejected'),
                                                      utl.get_constant_value('c_rdr_successful'),
                                                      utl.get_constant_value('c_rdr_not_processed'))
      THEN
         RETURN utl.get_constant_value('cinvalid_rdr_process_flag');
      END IF;

      UPDATE beowner.rdr_job_log
         SET rjl_processed_flag = l_rjl_processed_flag
       WHERE rjl_job_log_id = i_job_log_id::UUID;

      GET DIAGNOSTICS rowcount = ROW_COUNT;
    IF rowcount = 0
      THEN
         RETURN utl.get_constant_value('cinvalid_rdr_job_log_id');
      ELSE
         RETURN utl.get_constant_value('csuccess');
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION rdr.update_rdr_status (i_job_log_id rdr_job_log.rjl_job_log_id%TYPE, i_new_status rdr_job_log.rjl_processed_flag%TYPE) FROM PUBLIC;

\i cleanup.sql;
