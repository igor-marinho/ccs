SET bedb.filename = 'procedure.validate_phone.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS rdr.validate_phone(TEXT, TEXT, TEXT, TEXT, boolean );

CREATE OR REPLACE PROCEDURE rdr.validate_phone(i_area        IN     TEXT,
                                               i_exchange    IN     TEXT,
                                               i_line_number IN     TEXT,
                                               o_phone       INOUT  TEXT,
                                               o_phone_valid INOUT  BOOLEAN)
AS $body$
 DECLARE
         l_phone TEXT;
      BEGIN
         l_phone := i_area || i_exchange || i_line_number;
         o_phone := l_phone;
         -- see if there is anything besides 0 in the phone number
         l_phone := REPLACE(l_phone, '0', '');
      
         o_phone_valid := COALESCE(l_phone, '') != '' AND
                          NOT (COALESCE(i_area, '') = '' OR
                           TRIM(COALESCE(i_exchange, '')|| COALESCE(i_line_number, '')) = '');
         /* second condition is different than the concatenated string being null, since even if exchange or line_number is populated,
         unless the area code is also populated, the phone number is considered invalid, based on usr_phone mandatory columns */
      END;
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE rdr.clean_pending_primary_accounts (ivin vin.vin%TYPE, inotusrid usr.usr_id%TYPE) FROM PUBLIC;

\i cleanup.sql;
