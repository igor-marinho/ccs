SET bedb.filename = 'function.rdr_vin.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS vin_manager.rdr_vin(text,text);
   /*  RDR_VIN
   
       Sets up the VIN as if it were RDRed i.e. sets the dealer flag and DOFU
       Added for SM19.1/OnTime Defect 11560 - Error launching Bing in Enform with account with L01 VIN
   
       All fields are strings
   
       -----
       Expected Return Values:
         0     : Success
         1     : Unknown Error
         200   : Invalid VIN                    (cnst.cdbvinnotfound)
         213   : Invalid Partner ID             (cnst.cDbPartneridNotValid)
         226   : VIN has already been RDRed     (cnst.c_vin_already_rdred)
   */
CREATE OR REPLACE FUNCTION vin_manager.rdr_vin (i_partner_id text, i_vin text)RETURNS INTEGER 
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'rdr_vin';
    l_dofu      beowner.vin.dofu%TYPE;
    l_dealer_flag beowner.vin.dealer_flag%TYPE;
    l_vin       beowner.vin.vin%TYPE := upper(trim(both i_vin));
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    l_action := utl.set_module_action(l_module_name, 'Setting Context');

      CALL ctx.set(iptnrid => i_partner_id::UUID, ivin => l_vin);

    l_action := utl.set_action('Getting VIN Info');

      SELECT dealer_flag,
         dofu
        INTO STRICT l_dealer_flag,
         l_dofu
     FROM beowner.vin v
       WHERE v.vin = l_vin;

      IF l_dealer_flag != '0' AND
        l_dofu IS NOT NULL
      THEN
     RETURN utl.get_constant_value('c_vin_already_rdred');
      END IF;

    l_action := utl.set_action('Updating VIN');

      UPDATE beowner.vin
     SET dealer_flag = '1',
         dofu    = coalesce(dofu, clock_timestamp())
       WHERE vin = l_vin;

      RETURN utl.get_constant_value('csuccess');
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
     RETURN utl.get_constant_value('cdbpartneridnotvalid');
      WHEN SQLSTATE 'EVINN' THEN
     RETURN utl.get_constant_value('cdbvinnotfound');
      WHEN OTHERS THEN
     GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
     RETURN utl.get_constant_value('cinternalerror');
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION vin_manager.rdr_vin (i_partner_id text, i_vin text) FROM PUBLIC;

\i cleanup.sql;
