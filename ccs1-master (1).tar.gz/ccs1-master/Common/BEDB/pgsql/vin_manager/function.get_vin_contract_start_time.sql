SET bedb.filename = 'function.get_vin_contract_start_time.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS vin_manager.get_vin_contract_start_time(text,text);
   /*  get_contract_start_time
   
     Gets the Contract Start Time for TM
     Added for OnTime WI 6115 - [EV1] Opt IN/Opt OUT Imp Phase 2 (DB ID 124 F.ID 3046)
   
     Inputs:
        i_Partner_Id   Partner Id for the VIN
        i_Vin          VIN that contract start time applies to
   
     Output:
        o_start_time   Contract Start time with timezone
   
     Expected Return Values:
            0     : success
            1     : Unknown Error
            7     : No such User found           (cnst.cNoSuchUser)
            200   : VIN not found (not your VIN) (cnst.cDbVinNotFound)
            213   : Partner Id is not valid      (cnst.cDbPartneridNotValid)
   */

CREATE OR REPLACE FUNCTION vin_manager.get_vin_contract_start_time (i_partner_id text, i_vin text, o_start_time OUT text)
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'get_vin_contract_start_time';
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    l_action := utl.set_module_action( l_module_name, 'Calling be_tm');

    select z.o_start_time into o_start_time 
        from be_tm.get_vin_contract_start_time(i_partner_id => i_partner_id,
                                               i_login_id   => NULL,
                                               i_vin        => i_vin) z;
      
      RETURN;
   EXCEPTION
      -- Most exceptions are handled in be_tm. If any other unexpected exception, raise here.
      WHEN OTHERS THEN
     GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
     RETURN;
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION vin_manager.get_vin_contract_start_time (i_partner_id text, i_vin text, o_start_time OUT text) FROM PUBLIC;

\i cleanup.sql;
