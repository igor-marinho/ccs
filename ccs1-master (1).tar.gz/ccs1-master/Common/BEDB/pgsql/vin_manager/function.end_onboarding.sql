SET bedb.filename = 'function.end_onboarding.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS vin_manager.end_onboarding(text);
   /*  END_ONBOARDING
     Calls fdf.received, which inserts good VINs found in fdf_staging for the given job log Id.
     Any VINs found in error are moved to fdf_staging_ques
     Also RDRs the VIN - i.e sets the dealer_flag and dofu
        - added for SM19.1/OnTime Defect 11560 - Error launching Bing in Enform with account with L01 VI
   
    Expected Return Values:
     0    : Success
     1    : Unknown Error
     254  : There was no valid data in the feed/transaction
     255  : There were one or more rows that did not validate, hence no VIN added for that row/s
   */
CREATE OR REPLACE FUNCTION vin_manager.end_onboarding (i_job_log_id text) RETURNS integer
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'end_onboarding';
    l_return INTEGER;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
      l_action := utl.set_module_action(l_module_name, 'Updating job log with number of records');
      
     UPDATE beowner.fdf_job_log
     SET fjl_num_of_records = current_setting('vin_manager.g_line_number')::INTEGER
       WHERE fjl_staging_job_log_guid = i_job_log_id::UUID;

      l_action := utl.set_action('Calling fdf received');

      l_return := fdf.received(ifilename => NULL, ijoblogid => i_job_log_id);

      --  Added for SM19.1/OnTime Defect 11560 - Error launching Bing in Enform with account with L01 VI
      l_action := utl.set_action('Updating VIN');
      IF l_return = utl.get_constant_value('csuccess')::INTEGER
      THEN
            -- Update the VIN if dealer_flag is not set already
        UPDATE beowner.vin
           SET dealer_flag = '1',
               dofu        = coalesce(dofu, CLOCK_TIMESTAMP())
         WHERE vin in (select vin from vin_tt)
           AND dealer_flag = '0';
      ELSE

        l_exception_diagnostics.action := l_action;
        l_exception_diagnostics.module_name:= l_module_name;
        CALL trc.log(iadditionaldata => 'FDF returned ' || l_return || ' for job log id ' || i_job_log_id,
                     iexception_diagnostics => l_exception_diagnostics);
      END IF;

      RETURN l_return;
   EXCEPTION
      WHEN OTHERS THEN
     GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.action := l_action;
          l_exception_diagnostics.module_name:= l_module_name;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
     RETURN utl.get_constant_value('cinternalerror');
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION vin_manager.end_onboarding (i_job_log_id text) FROM PUBLIC;

\i cleanup.sql;
