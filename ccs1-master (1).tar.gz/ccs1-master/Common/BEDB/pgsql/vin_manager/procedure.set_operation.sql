SET bedb.filename = 'procedure.set_operation.sql';

\i set_be_env.sql;

CREATE OR REPLACE PROCEDURE vin_manager.set_operation (i_operation text) AS $body$
DECLARE
      l_module_name text := 'set_operation';
BEGIN
      PERFORM utl.set_module_action( l_module_name,  
				       i_operation);
   END;


$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE vin_manager.set_operation (i_operation text, i_line bigint) FROM PUBLIC;

\i cleanup.sql;
