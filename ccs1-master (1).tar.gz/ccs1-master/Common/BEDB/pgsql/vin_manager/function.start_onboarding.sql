SET bedb.filename = 'function.start_onboarding.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS vin_manager.start_onboarding (text); 

   /*  START_ONBOARDING
        Starts the VIN onboarding transaction by logging the xml provided into fdf_job_log with a newly generated Job log GUID, which is returned
   
       -----
       Expected Return Values:
         0     : Success
         1     : Unknown Error
   */

CREATE OR REPLACE FUNCTION vin_manager.start_onboarding (i_xml               text
                                                        ,o_status_code   OUT integer
                                                        ,o_job_log_id    OUT text) 
AS $body$
DECLARE
    l_action                text;
    l_module_name           text := 'start_onboarding';
    l_job_log_guid 			beowner.fdf_job_log.fjl_staging_job_log_guid%TYPE;
    l_date       			beowner.fdf_job_log.fjl_cycle_date%TYPE := to_char(clock_timestamp(), 'DD-MON-YY');
    l_exception_diagnostics trc.exception_diagnostics;
    
    c_record_id 		CONSTANT fdf_staging.fs_record_id%TYPE := '010'; -- to differentiate from FDF Batch processing
    c_transaction_id 	CONSTANT fdf_job_log.fjl_transaction_id%TYPE := 'LEXVINONB'; -- TBD
    c_process_msg 		CONSTANT fdf_job_log.fjl_process_msg%TYPE := 'Pending';
    c_trading_partner 	CONSTANT fdf_job_log.fjl_trading_partner%TYPE := 'TGT'; -- TBD
BEGIN
      l_action := utl.set_module_action(l_module_name, 'Starting Transaction');
      l_job_log_guid := beowner.rand_guid();

      l_action := utl.set_action('Inserting into fdf_job_log');
      
    INSERT INTO beowner.fdf_job_log (fjl_staging_job_log_guid
                                    ,fjl_record_id
                                    ,fjl_interface_unique_id
                                    ,fjl_trading_partner
                                    ,fjl_transaction_id
                                    ,fjl_cycle_date
                                    ,fjl_interface_create_date
                                    ,fjl_num_of_records
                                    ,fjl_interface_hash_amt
                                    ,fjl_source_load_date
                                    ,fjl_process_msg
                                    ,fjl_source)
            (SELECT l_job_log_guid      fjl_staging_job_log_guid
                   ,c_record_id         fjl_record_id
                   ,NULL                fjl_interface_unique_id
                   ,c_trading_partner   fjl_trading_partner
                   ,c_transaction_id    fjl_transaction_id
                   ,l_date              fjl_cycle_date
                   ,l_date              fjl_interface_create_date
                   ,0                   fjl_num_of_records
                   ,0                   fjl_interface_hash_amt
                   ,clock_timestamp()   fjl_source_load_date
                   ,c_process_msg       fjl_process_msg
                   ,i_xml);

    DROP  TABLE IF EXISTS vin_tt;
    PERFORM set_config('vin_manager.g_line_number', '0', false);

      o_job_log_id := l_job_log_guid::TEXT;
      o_status_code := utl.get_constant_value('csuccess');
      RETURN;
   EXCEPTION
      WHEN OTHERS THEN
        GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.action := l_action;
          l_exception_diagnostics.module_name := l_module_name;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
     o_status_code := utl.get_constant_value('cinternalerror');
     RETURN;
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION vin_manager.start_onboarding (i_xml text, o_job_log_id OUT text) FROM PUBLIC;

\i cleanup.sql;
