SET bedb.filename = 'function.add_vin.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS vin_manager.add_vin(text,text,text,text,text,text,text,text);
   /*  ADD_VIN
        Accepts the job GUID and VIN information and stores it in the fdf_staging table.
        Updates fdf_job_log with the number of records in the transaction so far
   
       Expected Return Values:
         0     : Success
         1     : Unknown Error
   */
CREATE OR REPLACE FUNCTION vin_manager.add_vin (i_job_log_id   text
                                               ,i_partner_id   text
                                               ,i_vin          text
                                               ,i_model_code   text
                                               ,i_model        text
                                               ,i_year         text
                                               ,i_color        text
                                               ,i_device_id    text) RETURNS INTEGER
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'add_vin';
    l_vin beowner.vin.vin%TYPE := upper(trim(both i_vin));
    l_exception_diagnostics trc.exception_diagnostics;
    c_record_id CONSTANT beowner.fdf_staging.fs_record_id%TYPE := '010';
    l_line_number beowner.fdf_staging.fs_interface_line_number%TYPE := COALESCE(current_setting('vin_manager.g_line_number', true)::INTEGER, 0);
BEGIN
      l_action := utl.set_module_action(l_module_name, 'Inserting VIN into Staging');
      l_line_number = l_line_number + 1;
      CREATE TEMPORARY TABLE IF NOT EXISTS vin_tt(vin TEXT) ON COMMIT PRESERVE ROWS;
  
      INSERT INTO beowner.fdf_staging(fs_record_id,
      fs_vin,
      fs_interface_unique_id,
      fs_interface_line_number,
      fs_headunit_code,
      fs_headunit_desc,
      fs_make,
      fs_model,
      fs_model_code,
      fs_model_year,
      fs_vehicle_color,
      fs_source_load_date,
      fs_staging_job_log_guid,
      fs_meid)
     (SELECT 
         c_record_id,
         l_vin fs_vin,
         NULL fs_interface_unique_id,
         l_line_number fs_interface_line_number,
         i_device_id fs_headunit_code,
         i_device_id fs_headunit_desc,
         (SELECT p.make_id
            FROM beowner.ptnr p
           WHERE p.ptnr_id =
             replace(trim(both i_partner_id), '-', '')::UUID) fs_make,
         i_model fs_model,
         i_model_code fs_model_code,
         i_year fs_model_year,
         i_color fs_vehicle_color,
         clock_timestamp() fs_source_load_date,
         i_job_log_id::UUID fs_staging_job_log_guid,
         NULL fs_meid
        );

    BEGIN
    INSERT INTO vin_tt(vin) VALUES (l_vin); --  Added for SM19.1/OnTime Defect 11560
    END;
    l_action := utl.set_action('Updating fdf_job_log');
    PERFORM set_config('vin_manager.g_line_number', l_line_number::TEXT, false);

      RETURN utl.get_constant_value('csuccess');
  
   EXCEPTION
      WHEN OTHERS THEN
     GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
     RETURN utl.get_constant_value('cinternalerror');
    END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION vin_manager.add_vin (i_job_log_id text, i_partner_id text, i_vin text, i_model_code text, i_model text, i_year text, i_color text, i_device_id text) FROM PUBLIC;

\i cleanup.sql;
