SET bedb.filename = 'function.get_vin_details.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS vin_manager.get_vin_details(text, text);

   /*  GET_VIN_DETAILS
   
       For the given PartnerID/VIN, return the VIN details. The ref-cursor is formatted as follows:
   
         VIN, MAKE, MODEL, YEAR, COLOR, DEVICE_ID, DEVICE_TYPE
   
       All fields are strings
   
       -----
       Expected Return Values:
         0     : Success
         1     : Unknown Error
         200   : Invalid VIN               (cnst.cdbvinnotfound)
         213   : Invalid Partner ID        (cnst.cDbPartneridNotValid)
   */

CREATE OR REPLACE FUNCTION vin_manager.get_vin_details (i_partner_id        text
                                                       ,i_vin               text
                                                       ,o_status_code   OUT INTEGER
                                                       ,o_result        OUT refcursor)
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'get_vin_details';
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    o_result := utl.get_dummy_cursor();
    l_action := utl.set_module_action( l_module_name, ' Setting Context');

    CALL ctx.set(iptnrid => i_partner_id::UUID, ivin => i_vin);

    l_action := utl.set_action('Fetching VIN data');
      
      -- Added join with device and device_type as last column for Jira PHVPRIME-19
    CLOSE o_result;
    OPEN o_result FOR
     SELECT v.vin,
        v.make_id,
        v.model,
        v.year,
        v.color,
        v.device_id,
        d.device_type
       FROM beowner.vin    v,
        beowner.device d
      WHERE v.vin = upper(trim(both i_vin))
        AND d.device_id = v.device_id;

      o_status_code := utl.get_constant_value('csuccess');
  RETURN;
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
	     o_result := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cdbpartneridnotvalid');
         RETURN;
      WHEN SQLSTATE 'EVINN' THEN
	     o_result := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cdbvinnotfound');
         RETURN;
      WHEN OTHERS THEN
     GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
	 o_result := utl.get_dummy_cursor();
     o_status_code := utl.get_constant_value('cinternalerror');
     RETURN;
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;

-- REVOKE ALL ON FUNCTION vin_manager.get_vin_details (i_partner_id text, i_vin text, o_result OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
