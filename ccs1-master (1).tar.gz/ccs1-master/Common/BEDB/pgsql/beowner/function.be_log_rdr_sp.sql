SET bedb.filename = 'function.be_log_rdr_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.be_log_rdr_sp(text);

CREATE OR REPLACE FUNCTION beowner.be_log_rdr_sp ( rdr_record_xml_i text, recordset_o out REFCURSOR ) 
AS $body$
DECLARE
 /*  Title: BE_LOG_RDR_SP
  Version:  4.0
  Date:     9/30/ 2010
  Author:   Michelle Lu
  Work Item #:  2368

  Description:  This stored procedure is called by API to log RDR vehicle sell
    data from Toyota. The store procedure contains the following steps:
    1.    Insert an new entry in the RDR_Log table. (RDR_Job_ID, RDR_Record_XML,
    Created_Data, Created_By, Duplicate_flag)
    2.    Return status code. 0 means successful,  otherwise error or exception
    happens. Also RDR_Job_Log_ID is returned.

    ** JLH - The record is stored in the database for future use or troublshooting.

  Input parameters:
    Rdr_Record_Xml_I  incoming record in XML format

  Output parameters:
    recordset_o       OUT SYS_REFCURSOR

  Revision History:

  DATE      AUTHOR    DESCRIPTION

  10/07/10  MLU       remove commit / rollback cluse. Java API will open trans
  10/27/10  MLU       INSERT RJL_CREATED_DATA IN CASE OF DEFAULT FAILURE.
  12/07/10  MLU       Added comments. Logged errors in the sql_error_log table.
  12/29/10  mlu       changed the column name from RJL_DEPULICATE_FLAG to RJL_DUPLICATE_FLAG
  01/04/11  mlu       Jeff requested to return only status code back.
  01/17/11  Bob B     add partner_uid per task #3820 - NO CHANGES NEEDED
  04/18/11  Bob B     DB Changes in work items 4580, 4509, 4510, 4511
              *** NO CHANGES NEEDED ***
*/
  l_action TEXT;
  l_module_name TEXT := 'be_log_rdr_sp';   
  vJobLogID       beowner.rdr_job_log.rjl_job_log_id%type;
  l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    l_action := utl.set_module_action(l_module_name, ' Validating Inputs');
  
  if rdr_record_xml_i is null or length(rdr_record_xml_i) < 3 then
    open recordset_o for
      SELECT utl.get_constant_value ('cDbEmptyDocumentException'), cast(null as text);
      RETURN;
  end if;

    l_action := utl.set_action(' Insert into rdr_job_log');

  vJobLogID := beowner.rand_guid();

  insert into beowner.rdr_job_log( rjl_job_log_id, rjl_rdr_record_xml, rjl_processed_flag, rjl_parsed_flag, rjl_duplicate_flag, rjl_created_date )
  values ( vJobLogID, rdr_record_xml_i , '-', '-', '-', clock_timestamp());

  open recordset_o for
    SELECT utl.get_constant_value('csuccess'), vJobLogID::TEXT job_log_id;

exception
  when others then
    GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
    open recordset_o for
      SELECT utl.get_constant_value('cinternalerror'),
         cast(null as text);

end;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_log_rdr_sp ( rdr_record_xml_i text, recordset_o out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
