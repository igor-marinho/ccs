SET bedb.filename = 'function.be_update_transfervin_sp.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS beowner.be_update_transfervin_sp(text, text, text, text, text, text);
CREATE OR REPLACE FUNCTION beowner.be_update_transfervin_sp(userloginid_i text,
                                                            userpassword_i text,
                                                            vin_i text,
                                                            newuser_i text,
                                                            url_i text,
                                                            partnerid_i text,
                                                            status_code_o OUT refcursor) AS
$BODY$
DECLARE
    l_action                text;
    l_module_name           text := 'be_update_transfervin_sp';
    v_src_usrid             beowner.usr.usr_id%type;
    v_dst_usrid             beowner.usr.usr_id%type;
    v_status                text := utl.get_constant_value('csuccess');
    v_count                 integer;
    -- onTime defect#13058
    v_subscription_id       beowner.subscription.subscription_id%type;
    l_vin                   beowner.vin.vin%type;
    subs_id                 record;
    l_exception_diagnostics trc.exception_diagnostics;
    -- Replace the goto clause in oracle
BEGIN

    l_action := utl.set_module_action(l_module_name,
                                      ' Looking for target user');

    -- see if DST user exists; if not, vDstUsrID remains NULL
    -- if it's not there, don't create it yet...
    BEGIN
        CALL ctx.set(iptnrid => partnerid_i::uuid, iloginid => newuser_i);

        SELECT usr_id
        INTO STRICT v_dst_usrid
        FROM beowner.ctx_data;

    EXCEPTION
        WHEN SQLSTATE 'EUSRN' THEN
            NULL;
    END;

    l_action := utl.set_module_action(l_module_name,
                                      ' Setting Context');

    -- set the SRC user context; this will throw an error if it can't find everything
    CALL ctx.set(iptnrid => partnerid_i::uuid, iloginid => userloginid_i, ivin => vin_i);

    -- convenience (vSrcUsrID)
    -- Added vin for merging with WI #14078, so that context name is removed where it's not necessary
    SELECT usr_id,
           vin
    INTO STRICT v_src_usrid,
        l_vin
    FROM beowner.ctx_data;

    -- if the destination and source are the same, return error "15"
    IF v_src_usrid = v_dst_usrid
    THEN
        OPEN status_code_o FOR
            SELECT utl.get_constant_value('cuseralreadyexists');
        RETURN;
    END IF;

    l_action := utl.set_module_action(l_module_name,
                                      ' Seeing if source is in Grace');

    v_status := beowner.check_dofu();
    IF v_status != utl.get_constant_value('csuccess') THEN
        OPEN status_code_o FOR
            SELECT v_status;
        RETURN;
    END IF;


    /* Work Item 5291: temporarily ignore conflict. Leave code here for now in case we turn it back on.

    PERFORM utl.set_module_action( l_module_name,  ' Seeing if VIN is in conflict');

    vStatus := check_conflict();
    if vStatus != utl.get_constant_value('csuccess') then
      goto fiji;
    end if;

    */
    l_action := utl.set_module_action(l_module_name,
                                      ' Create user or check if Primary');

    CALL beowner.manage_target_user(v_src_usrid,
                                    newuser_i,
                                    vin_i,
                                    partnerid_i,
                                    v_dst_usrid,
                                    v_count,
                                    v_status);
    IF v_status != utl.get_constant_value('csuccess')
    THEN
        OPEN status_code_o FOR
            SELECT v_status;
        RETURN;
    END IF;

    l_action := utl.set_module_action(l_module_name,
                                      ' Resetting Context');

    -- Reset the SRC user context; may have been updated by manage_target_user()
    CALL ctx.set(iptnrid => partnerid_i::uuid, iloginid => userloginid_i, ivin => vin_i);

    l_action := utl.set_module_action(l_module_name,
                                      ' Transferring VIN');

    -- check the existence of a subscription record for the destination user
    SELECT COUNT(*)
    INTO STRICT v_count
    FROM beowner.ctx_data cd
             JOIN beowner.subscription s
                  ON s.primary_id = v_dst_usrid -- destination user, not ctx_data.usr_id
                      AND s.vin = cd.vin;

    IF v_count = 0
    THEN
        -- the DST user does not have a subscription, we're going to transfer the subscription.
        -- nullified nickname for #12623 (Vehicle nickname is retained when transferring vehicle)
        UPDATE beowner.subscription
        SET primary_id = v_dst_usrid,
            nickname   = NULL
        WHERE (primary_id, vin) = (SELECT usr_id,
                                          vin
                                   FROM beowner.ctx_data)
              -- onTime defect#13058
        RETURNING subscription_id INTO STRICT v_subscription_id;


        -- if the user transfers ownership of the EV then the user's settings for the EV Unplugged Notification feature shall be cleared.
        -- Sproc delete_subs_notif added for DI#1457
        v_status := crudg_subscription.delete_subs_notif(v_subscription_id);

        IF v_status != utl.get_constant_value('csuccess')
        THEN
            OPEN status_code_o FOR
                SELECT v_status;
            RETURN;
        END IF;

        -- Jira DDCRD-408 : Log new subscription for destination user and deleted subscription for old user, even though there was no physical insert/delete
        --                  so that event_log reflects the right data for each subscription
        CALL beowner.tg_update_event_log_sp(
                itype => utl.get_constant_value('c_event_log_type_subscription')::text,
                iusrid => v_src_usrid::uuid,
                ivin => l_vin::text,
                istatus => utl.get_constant_value('c_cancelled_subs_status')::text,
                ostatusrslt => v_status,
                iold_status => utl.get_constant_value('c_new_active_subs_status')::text
            );

        CALL beowner.tg_update_event_log_sp(
                itype => utl.get_constant_value('c_event_log_type_subscription')::text,
                iusrid => v_dst_usrid::uuid,
                ivin => l_vin::text,
                istatus => utl.get_constant_value('c_new_active_subs_status')::text,
                ostatusrslt => v_status,
                iold_status => NULL::text);

    ELSE
        -- the DST user already has a subscription, we'll just delete the SRC user's subscription.
        FOR subs_id IN (SELECT subscription_id
                        FROM beowner.subscription
                        WHERE (primary_id, vin) =
                              (SELECT usr_id,
                                      vin
                               FROM beowner.ctx_data))
            LOOP

                v_status := crudg_subscription.delete_subs_children(subs_id.subscription_id);

                IF v_status != utl.get_constant_value('csuccess')
                THEN
                    OPEN status_code_o FOR
                        SELECT v_status;
                    RETURN;
                END IF;

                DELETE
                FROM beowner.subscription
                WHERE subscription_id = subs_id.subscription_id;

            END LOOP;

    END IF;

    CALL utl.checkvinconflict();
    -- use context
    -- record transfer event for reporting
    -- WI #14078, so that context name is removed where it's not necessary
    -- Jira DDCRD-408 : modified the below to include old_status and named parameters
    CALL beowner.tg_update_event_log_sp(itype => utl.get_constant_value('c_event_log_type_subscription')::text,
                                        iusrid => v_src_usrid,
                                        ivin => l_vin::text,
                                        istatus => utl.get_constant_value('c_transferred_subs_status')::text,
                                        iold_status => utl.get_constant_value('c_new_active_subs_status')::text,
                                        ostatusrslt => v_status);

    OPEN status_code_o FOR
        SELECT v_status;

EXCEPTION
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
      OPEN status_code_o FOR
         SELECT utl.get_constant_value('cinvalidparams');

   WHEN SQLSTATE 'EPTNR' THEN
      OPEN status_code_o FOR
         SELECT utl.get_constant_value('cdbpartneridnotvalid');

   WHEN SQLSTATE 'EUSRN'  THEN
      OPEN status_code_o FOR
         SELECT utl.get_constant_value('cnosuchuser');

   WHEN SQLSTATE 'EVINN' THEN
      OPEN status_code_o FOR
         SELECT utl.get_constant_value('cdbvinnotfound');

    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
        OPEN status_code_o FOR
            SELECT utl.get_constant_value('cinternalerror');

END;
$BODY$ LANGUAGE PLPGSQL
    SECURITY DEFINER;
-- REVOKE ALL ON PROCEDURE be_update_transfervin_sp ((userloginid_i text, userpassword_i text, vin_i text, newuser_i text, url_i text, partnerid_i text, status_code_o OUT REFCURSOR) AS vsrcusrid usr.usr_id%TYPE) FROM PUBLIC;

\i cleanup.sql;
