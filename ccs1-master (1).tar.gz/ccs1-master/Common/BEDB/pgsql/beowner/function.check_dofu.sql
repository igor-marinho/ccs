SET bedb.filename = 'function.check_dofu.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS beowner.check_dofu();
CREATE OR REPLACE FUNCTION beowner.check_dofu() RETURNS text AS
$BODY$
DECLARE
    vdofu beowner.vin.dofu%type;
    rslt  text;
BEGIN
    SELECT v.dofu
    INTO vdofu
    FROM beowner.ctx_data cd
             JOIN beowner.vin v
                  ON v.vin = cd.vin;

    RETURN CASE
               WHEN vdofu IS NULL THEN
                   utl.get_constant_value('cdbtransfernotallowedgraced')
               ELSE utl.get_constant_value('csuccess') END;
END;
$BODY$
    LANGUAGE PLPGSQL

\i cleanup.sql;
