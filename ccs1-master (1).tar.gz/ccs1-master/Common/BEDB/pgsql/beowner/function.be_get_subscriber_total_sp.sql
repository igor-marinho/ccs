SET bedb.filename = 'function.be_get_subscriber_total_sp.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS beowner.be_get_subscriber_total_sp(text, text);
CREATE OR REPLACE FUNCTION beowner.be_get_subscriber_total_sp(partnerid_i text,
                                                              subscriber_email_i text,
                                                              recordset_o OUT refcursor) AS
$body$
DECLARE
    l_action                text;
    l_module_name           text := 'be_get_subscriber_total_sp';
    vUsrCount               integer;
    vMaxCount               integer;
    vAvailCount             integer;
    vIsPrimary              text;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN

    l_action := utl.set_module_action(l_module_name, ' Setting Context');

    CALL ctx.set(iPtnrID => partnerid_i::uuid,
                 iLoginID => subscriber_email_i);

    l_action := utl.set_module_action(l_module_name, ' Getting Counts');

    WITH a1 AS (SELECT count(*) + 1 current_user_count
                FROM beowner.ctx_data cd
                         JOIN beowner.usr u
                              ON u.parent_id = cd.usr_id),
         a2 AS (SELECT CASE WHEN u.parent_id IS NOT NULL THEN '0' ELSE '1' END is_primary,
                       coalesce(u.parent_id, u.usr_id)                         primary_id
                FROM beowner.ctx_data cd
                         JOIN beowner.usr u
                              ON u.usr_id = cd.usr_id),
         a3 AS (SELECT coalesce(sum(b.max_users), 0) max_allowed_users
                FROM a2
                         JOIN beowner.subscription s
                              ON s.primary_id = a2.primary_id
                         JOIN beowner.bndl b
                              ON b.bndl_id = s.bndl_id)
    SELECT a1.current_user_count, a2.is_primary, a3.max_allowed_users
    INTO STRICT vUsrCount, vIsPrimary, vMaxCount
    FROM a1,
         a2,
         a3;

    l_action := utl.set_module_action(l_module_name, ' Returning Data');

    vAvailCount := vMaxCount - vUsrCount;

    IF vAvailCount < 0 THEN
        vAvailCount := 0;
    END IF;

    OPEN recordset_o FOR
        SELECT utl.get_constant_value('csuccess') status,
               vMaxCount                          allowed_count,
               vAvailCount                        available_count,
               cast(vIsPrimary AS varchar(1))     is_primary;

EXCEPTION
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cinvalidparams');

    WHEN SQLSTATE 'EPTNR' THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cdbpartneridnotvalid');

    WHEN SQLSTATE 'EUSRN' THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cnosuchuser');

    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cinternalerror');

END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_get_subscriber_total_sp ( partnerid_i text, subscriber_email_i text, recordset_o out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
