SET bedb.filename = 'function.be_create_user_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.be_create_user_sp(text, text, text, text);

DROP FUNCTION IF EXISTS beowner.be_create_user_sp(text, text, text, text, boolean);

CREATE OR REPLACE FUNCTION beowner.be_create_user_sp (userloginid_i       text
                                                     ,vin_i               text
                                                     ,partnerid_i         text
                                                     ,create_type_i       text DEFAULT null
                                                     ,check_email         boolean DEFAULT TRUE
                                                     ,status_code_o   OUT refcursor)
AS $body$
DECLARE
   l_action text;   
   l_module_name text := 'be_create_user_sp';
   vusr       beowner.usr%ROWTYPE;
   vcount     INTEGER;
   vemailaddr text;
   vvin       beowner.vin.vin%TYPE;
   vrslt      text;
   -- OnTime #23029
   vcreate_type beowner.usr.create_type%TYPE := upper(create_type_i);
   l_exception_diagnostics trc.exception_diagnostics;
  
BEGIN   
    -- Removed column TOS_FLAG,DWNLD_APP_FLAG for DCS1E-921
    l_action := utl.set_module_action( l_module_name, ' Setting Context');
  
   vvin := upper(trim(vin_i));

   CALL ctx.set(iptnrid  => partnerid_i::UUID,
                iloginid => NULL, -- don't set this yet since USR may not exist: userloginid_i
                ivin     => vvin);

   -- it's conceivable that this could *not* be an email address,
   -- so don't check for validity here.
   vusr.login_id := lower(trim(userloginid_i));

   -- however, the actual email we save must be valid.
   -- Raise an error if it is invalid.
   IF check_email THEN
   vemailaddr := utl.normalize_email(vusr.login_id, 'yes');
   END IF;

   SELECT make_id
     INTO vusr.make_id
     FROM beowner.ctx_data;

    l_action := utl.set_action('Checking for existing user');

   SELECT COUNT(*)
     INTO STRICT vcount
     FROM beowner.usr
    WHERE login_id = vusr.login_id
      AND make_id = vusr.make_id;

   IF vcount > 0
   THEN
      OPEN status_code_o FOR
        SELECT utl.get_constant_value('cuseralreadyexists');
      RETURN;
   END IF;
   
    l_action := utl.set_action('Creating User');
    vusr.usr_id := beowner.rand_guid();
    vusr.lang_id := utl.get_constant_value('clangenus'); -- modified for language changes, checked in for OnTime 5979 (DB Id 121)

   -- OnTime #23029
   IF vcreate_type IS NOT NULL AND NOT utl.is_usr_create_type_id_valid(vcreate_type)
   THEN      
      raise exception using errcode=utl.get_constant_value('e_invalid_create_type');
   END IF;
  
   IF check_email THEN
   vusr.create_type := coalesce(vcreate_type, utl.get_default_usr_create_type(i_make_id => vusr.make_id));
   ELSE
   --Create type set to 'O' for OneApp flow.
   vusr.create_type := coalesce(vcreate_type, 'O'); 
   END IF;
   

   vusr.locked := ' ';
   vusr.lvl := '0';
   vusr.created := clock_timestamp();
   vusr.test_user := 'N'; -- OnTime #16641 : TMS 3PP Reports: The current code excludes all 2011 model year vehicles as test vins from the reports
   vusr.pwd := utl.get_random_password(); -- Jira DCS1REFRES-1570

   INSERT INTO beowner.usr
   SELECT vusr.*;
  
    l_action := utl.set_action(' Resetting Context');
 
   CALL ctx.set(i_usrid => vusr.usr_id::TEXT, i_makeid => vusr.make_id, i_vin => vvin);

    l_action := utl.set_action(' Creating Default Email');

   IF check_email THEN
   INSERT INTO beowner.usr_email (usr_id, email_type_id, email)
       VALUES (vusr.usr_id, 'H1', vemailaddr);
   END IF;
   
   l_action := utl.set_action('Creating Default StockPrefs');

   vrslt := beowner.tg_create_stockpref_sp();

   OPEN status_code_o FOR
      SELECT vrslt;

EXCEPTION

   -- we don't have an "Invalid eMail" status, so for now throw as "Invalid Param"
   WHEN SQLSTATE 'EEMML'
   THEN
   
      OPEN status_code_o FOR
     SELECT utl.get_constant_value('cinvalidparams');

   WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation
   THEN
   
      OPEN status_code_o FOR
     SELECT utl.get_constant_value('cinvalidparams');

   WHEN SQLSTATE 'EPTNR'
   THEN
      OPEN status_code_o FOR
     SELECT utl.get_constant_value('cdbpartneridnotvalid');

   WHEN SQLSTATE 'EUSRN'
   THEN
      OPEN status_code_o FOR
     SELECT utl.get_constant_value('cnosuchuser');

   WHEN SQLSTATE 'EVINN'
   THEN
      OPEN status_code_o FOR
     SELECT utl.get_constant_value('cdbvinnotfound');

   -- OnTime #23029
   WHEN SQLSTATE 'ECREA' THEN
      OPEN status_code_o FOR
     SELECT utl.get_constant_value('c_invalid_create_type');

   WHEN OTHERS
   THEN
   
      GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
                       
      OPEN status_code_o FOR
     SELECT utl.get_constant_value('cinternalerror') ;
END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION be_create_user_sp (userloginid_i text, vin_i text, partnerid_i text, status_code_o OUT SYS_REFCURSOR, create_type_i text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
