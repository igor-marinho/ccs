SET bedb.filename = 'function.be_token_get_sp.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS beowner.be_token_get_sp(text, text);
CREATE OR REPLACE FUNCTION beowner.be_token_get_sp(iEncodedToken text,
                                                   iPartnerID text,
                                                   OUT oResultSet refcursor) AS
$body$
DECLARE
    l_action                text;
    l_module_name           text := 'be_token_get_sp';
    vLoginID                beowner.usr.login_id%type;
    vUsrID                  beowner.usr.usr_id%type;
    vAcctStatus             varchar(60);
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN

    BEGIN
        SELECT usr_id
        INTO STRICT vUsrID
        FROM beowner.validation_token
        WHERE encoded_token = iEncodedToken;
    EXCEPTION
        WHEN no_data_found THEN
            OPEN oResultSet FOR
                SELECT utl.get_constant_value('cDbNoDataFound');
            RETURN;
    END;

    l_action := utl.set_module_action(l_module_name, ' Setting Context');

    CALL ctx.set(iPtnrID => iPartnerID::uuid);

    SELECT DISTINCT login_id, acct_status
    INTO STRICT vLoginID, vAcctStatus
    FROM user_subscription.info(vUsrID, NULL::text) alias1
    LIMIT 1;

    l_action := utl.set_module_action(l_module_name, ' Returning Data');
    OPEN oResultSet FOR
        SELECT utl.get_constant_value('csuccess') status,
               vt.encoded_token,
               vLoginID                           login_id,
               vt.vt_type,
               CASE
                   WHEN vt.expire < CURRENT_TIMESTAMP
                       THEN 1
                   ELSE 0
                   END                            expired,
               CASE
                   WHEN vt.resolved < CURRENT_TIMESTAMP
                       THEN 1
                   ELSE 0
                   END                            resolved,
               vAcctStatus
        FROM beowner.validation_token vt
        WHERE vt.encoded_token = iEncodedToken;

EXCEPTION
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
        OPEN oResultSet FOR
            SELECT utl.get_constant_value('cinvalidparams');

    WHEN SQLSTATE 'EPTNR' THEN
        OPEN oResultSet FOR
            SELECT utl.get_constant_value('cdbpartneridnotvalid');

    WHEN SQLSTATE 'EUSRN' THEN
        OPEN oResultSet FOR
            SELECT utl.get_constant_value('cnosuchuser');

    WHEN SQLSTATE 'EVINN' THEN
        OPEN oResultSet FOR
            SELECT utl.get_constant_value('cdbvinnotfound');

    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
        OPEN oResultSet FOR
            SELECT utl.get_constant_value('cinternalerror');
END;
$body$ LANGUAGE PLPGSQL
    SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_token_get_sp ( iEncodedToken text, iPartnerID text, oResultSet out REFCURSOR ) FROM PUBLIC;


\i cleanup.sql;
