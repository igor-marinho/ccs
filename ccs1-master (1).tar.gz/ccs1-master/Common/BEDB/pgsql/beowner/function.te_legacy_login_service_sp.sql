SET bedb.filename = 'function.te_legacy_login_service_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.te_legacy_login_service_sp(TEXT,TEXT,TEXT,TEXT);

CREATE OR REPLACE FUNCTION beowner.te_legacy_login_service_sp (userloginid_i        text
                                                              ,userpassword_i       text
                                                              ,serviceid_i          text
                                                              ,partnerid_i          text
                                                              ,recordset_o      OUT refcursor) 
AS
$BODY$
/*
Input parameters:
  userLoginId   - subscriber email address
  userPassword  - subscriber password
  serviceid     - Service ID
  partnerid_i   - partner id

Output parameters:
  recordset_0    -
  success - '0' - Login to this service is valid.
  failure - '1' - An unexpected error occurred.
            '2' - Failed login authentication.
            '3' - User does not have subscription to service
                  or allowed status not 1.
            '4' - Bad parameter.
            '7' - userid not on file
*/
DECLARE
    l_action text;
    l_module_name text := 'te_legacy_login_service_sp';
    vpwd TEXT;
    vsvcid TEXT;
    vcount INTEGER;
    vcount_svc_expired INTEGER;
    vrslt TEXT := utl.get_constant_value('csuccess');
    vsc_code beowner.status_code.code%TYPE;
    l_exception_diagnostics trc.exception_diagnostics;
   
begin

    <<fiji>>
    BEGIN
        l_action := utl.set_module_action( l_module_name, 'Setting Context');

       call ctx.set(iptnrid := partnerid_i::uuid, iloginid := userloginid_i); /* could throw err.eUserNotFound */
        
       l_action := utl.set_action( 'Getting Password');

        SELECT pwd
          INTO STRICT vpwd
          FROM beowner.usr
          WHERE usr_id = (SELECT usr_id FROM beowner.ctx_data);
        l_action := utl.set_action('Validating Password');

        IF COALESCE(vpwd, '!') != COALESCE(TRIM(userpassword_i), '!')
        /* Jira DCS1REFRES-1570 */
        THEN
            vrslt := utl.get_constant_value('cfailedauthpwd');
            EXIT fiji;
        END IF;

        vsvcid := TRIM(serviceid_i);

        IF vsvcid IS NOT null
        THEN
             l_action := utl.set_action( 'Getting Service Allowed Status');
            /*
            DDCRD-525
            When getting ACL information only get data for the given service if one is provided.

            Modified for DOTD-19 to take deprecated services into account
            NVL before SUM is required for cases when service is not returned by ACL at all
            */
            WITH a1 AS
                   (SELECT DISTINCT first_value(svc_id) over(PARTITION BY svc_id ORDER BY ordered_allowed_status) svc_id,
                                    first_value(allowed_status) over(PARTITION BY svc_id ORDER BY ordered_allowed_status) allowed_status

                      FROM user_subscription.info_ctx(isvcid => vsvcid))

                  SELECT COALESCE(SUM(CASE
                                    WHEN allowed_status = utl.get_constant_value('c_allowed_service_status') THEN
                                     1
                                    ELSE
                                     0
                                 END),
                             0) count_status_1,
                         COALESCE(SUM(CASE
                                    WHEN allowed_status = utl.get_constant_value('c_deprecated_service_status') THEN
                                     1
                                    ELSE
                                     0
                                 END),
                             0) count_status_9
                    INTO vcount,
                         vcount_svc_expired,
                         vsc_code
                    FROM a1
                   WHERE svc_id = vsvcid;
       
            IF vcount = 0 THEN
                IF vcount_svc_expired = 0 THEN
                    vrslt := utl.get_constant_value('cfailedauthsvc');
                ELSE
                    vrslt := utl.get_constant_value('c_deprecated_service_error');
                END IF;
                EXIT fiji;
            END IF;
        END IF;
    END;
	
	/*If login is success and send push notification is ON, create a new push notification for this user*/
	IF vrslt = utl.get_constant_value('csuccess') AND utl.getconfig('Send Push Message') = 'ON' THEN
    
    CALL oem_notifications_mgt.legacy_usr_push_notif();
    
    END IF;

    OPEN recordset_o FOR
    SELECT
        vrslt;
    
    EXCEPTION
    
        WHEN SQLSTATE 'EPTNR'
        then
           OPEN recordset_o FOR
              SELECT utl.get_constant_value('cdbpartneridnotvalid');
        
        WHEN SQLSTATE 'EUSRN'
        THEN
           OPEN recordset_o FOR
              SELECT utl.get_constant_value('cnosuchuser');
        
        WHEN OTHERS THEN     
                GET STACKED diagnostics
                  l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
                  l_exception_diagnostics.column_name := COLUMN_NAME,
                  l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
                  l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
                  l_exception_diagnostics.message_text := MESSAGE_TEXT,
                  l_exception_diagnostics.table_name := TABLE_NAME,
                  l_exception_diagnostics.schema_name := SCHEMA_NAME,              
                  l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
                  l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
                  l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
                  l_exception_diagnostics.module_name := l_module_name;
                  l_exception_diagnostics.action := l_action;
                call trc.log(iadditionaldata => NULL,
                                iexception_diagnostics => l_exception_diagnostics);
                
           OPEN recordset_o FOR
              SELECT utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
