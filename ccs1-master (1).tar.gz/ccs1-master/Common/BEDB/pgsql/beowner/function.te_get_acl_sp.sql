SET bedb.filename = 'function.te_get_acl_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.te_get_acl_sp(text, text, text, text); 

DROP FUNCTION IF EXISTS beowner.te_get_acl_sp(text, text, text, text, text); 

CREATE OR REPLACE FUNCTION beowner.te_get_acl_sp (userloginid_i        text
                                                 ,userpassword_i       text
                                                 ,token_i              text
                                                 ,partnerid_i          text
                                                 ,makeid_i             text DEFAULT null
                                                 ,recordset_o      OUT refcursor)
AS
$BODY$
/*
Title:        TE_GET_ACL_SP
Version:      4.1
Date:         08/30/2010
Author:       Bob Binger
Description:  This stored procedure is used to retrieve the subscriber ACL
    in XML format. The returned XML will come from the usr_acl table if it
    exists. If the XML does not exist in in usr_acl, it will be first cached
    in the table, and returned.

    If the token passed in matches, the existing cached XML, the
    returned XML will be null.

    Returned from this procedure is the xml and a status
    code of success (0) if either a valid XML is returned.
    If not successful, pass back a status code of
    general failure (1), bad parameters (4),
    invalid subscriber (2), user not on file (7),
    or acl xml unchanged (203).

Input parameters:
  userloginid_i   IN  VARCHAR2
  userpassword_i  IN  VARCHAR2
  token_i         IN  VARCHAR2
  partnerid_i     IN  VARCHAR2

Output parameters:
  recordset_o     OUT SYS_REFCURSOR
       >> contains the following columns:
           - status (typically '0' or utl.get_constant_value('csuccess'))
           - token (could be the same or different as the passed-in token)
           - ACL (a CLOB of XML)
*/
DECLARE
    l_action  TEXT;
    l_module_name text := 'te_get_acl_sp';
    v_acl_rec beowner.usr_acl;
    v_acl_cache_status TEXT;
    o_get_acl_rec RECORD;  
    l_makeid TEXT;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    
    l_action := utl.set_module_action( l_module_name, ' Setting Context');
   
    /* OneApp changes to switch partner id based on the make*/
   
    IF partnerid_i::uuid = utl.getconfig('Oneapp PTNR ID')::uuid then
    
       l_makeid := trim(both(makeid_i));
    
       IF l_makeid = 'LX' THEN partnerid_i := utl.getconfig('Lexus PTNR ID');
       
       ELSIF l_makeid = 'TM' THEN partnerid_i := utl.getconfig('Toyota PTNR ID');
      
       ELSE OPEN recordset_o FOR SELECT utl.get_constant_value('cinvalidmake'); 
       RETURN;
      
       END IF;
     
    END IF;
    
    CALL ctx.set(iptnrid := partnerid_i::uuid, iloginid := userloginid_i);
    l_action := utl.set_module_action( l_module_name, ' Getting ACL XML');

    /*
    JIRA SBM-110
    Use the ACL cache instead of generating the ACL
    at runtime for each call.
    */
    SELECT *
      FROM user_subscription.get_acl(i_acl_token := token_i::BYTEA)
      INTO o_get_acl_rec;

    v_acl_rec := o_get_acl_rec.O_ACL_REC;

    v_acl_cache_status := o_get_acl_rec.O_STATUS;
    
    IF v_acl_cache_status = utl.get_constant_value('csuccess')
       THEN
          OPEN recordset_o FOR
             SELECT CASE
                       WHEN v_acl_rec.acl_xml IS NOT NULL
                       THEN utl.get_constant_value('csuccess')
                       ELSE  utl.get_constant_value('cdbsubscriberaclunchanged')
                    END status,           
                    encode(v_acl_rec.acl_token::BYTEA, 'hex') as acl_token,
                    v_acl_rec.acl_xml acl;
    
       ELSE          
          RAISE EXCEPTION USING errcode = utl.get_constant_value('e_acl_not_generated');
       END IF;
    
    EXCEPTION
       WHEN invalid_text_representation OR invalid_parameter_value
       THEN
          OPEN recordset_o FOR
             SELECT utl.get_constant_value('cinvalidparams');
    
       WHEN SQLSTATE 'EPTNR'       
       THEN
          OPEN recordset_o FOR
             SELECT utl.get_constant_value('cdbpartneridnotvalid');
    
       WHEN SQLSTATE 'EUSRN' THEN
          OPEN recordset_o FOR
             SELECT utl.get_constant_value('cnosuchuser');
    
    /*
    Letting when others deal with this exception
    WHEN user_subscription.e_acl_no_data_found THEN
    handle_internal_error;
    */
    WHEN OTHERS
    then
      GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,              
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;
     CALL beowner.handle_internal_error(userloginid_i => userloginid_i, partnerid_i => partnerid_i, exception_diagnostics_i => l_exception_diagnostics);
      OPEN recordset_o FOR
             SELECT utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;
\i cleanup.sql;
