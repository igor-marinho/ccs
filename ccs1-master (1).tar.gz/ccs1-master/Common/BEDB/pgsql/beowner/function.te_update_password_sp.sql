SET bedb.filename = 'function.te_update_password_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS BEOWNER.TE_UPDATE_PASSWORD_SP(TEXT, TEXT, TEXT, TEXT);

CREATE OR REPLACE FUNCTION beowner.te_update_password_sp(IN userloginid_i TEXT, 
                                                         IN userpassword_i TEXT, 
                                                         IN newpassword_i TEXT, 
                                                         IN partnerid_i TEXT, 
                                                         OUT o_status_code REFCURSOR)
AS
$BODY$
/*
Title:    TE_UPDATE_PASSWORD_SP
    Version:      4.0
    Date:     August 16, 2010
    Author:   Bob Binger
    Description:  The purpose is to update the user password in the subscribers
          table based upon the email_address1, current password, and
          new password.

    Input parameters:
      userLoginId    - subscriber email address
      userPassword   - subscriber password
      newPassword    - new subscriber password
      partnerid      - partner id

    Output parameters:
      status_code_0   - Output variable
      success -  status_code of '0' - If the new record is updated.
      failure - '1' - if there is a problem with updating the record.
      failure - '4' - invalid parameter(s)
      failure - '2' - user does not exist
      failure - '7' - userid not on file

    NOTE:  This routine renamed to indicate primary use by TE.

    Revision History:

    DATE      AUTHOR    DESCRIPTION

    09/10/2010  Bob B     Change output paramater to sys_recursor
    09/29/2010  Bob B     Resolved defect #3556 (upper case email comparison)
    11/26/2010  Bob B     General cleanup and call new tg_validate_user_sp
    01/17/2011  Bob B     add partner_uid per task #3797
    04/12/2011  Bob B     Normalize per work item #4507
    04/18/2011  Bob B     DB Changes in work items 4580, 4509, 4510, 4511
    06/01/2011  djb       rework for new schema
*/
BEGIN
    o_status_code := beowner.be_update_password_sp(userloginid_i := userloginid_i, newpassword_i := newpassword_i, partnerid_i := partnerid_i);
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
