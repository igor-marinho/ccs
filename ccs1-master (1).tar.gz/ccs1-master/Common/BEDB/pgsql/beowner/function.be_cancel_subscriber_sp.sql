SET bedb.filename = 'function.be_cancel_subscriber_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.be_cancel_subscriber_sp(text, text, text);
CREATE OR REPLACE FUNCTION beowner.be_cancel_subscriber_sp(userloginid_i text,
                                                           userpassword_i text,
                                                           partnerid_i text,
                                                           OUT recordset_o refcursor)
    -- $Id$
    -- delete all user account information for the specified user --
    -- v1.1 - modified for OnTime #9781
    -- v1.2 - modified for OnTime #18647
AS
$BODY$
DECLARE
    l_action                   text;
    l_module_name              text := 'be_cancel_subscriber_sp';
    vusrid                     beowner.usr.usr_id%type;
    vparentid                  beowner.usr.parent_id%type;
    l_result                   integer;
    v_vins                     refcursor;
    v_vin_rcd                  record;
    l_make_id                  beowner.make.make_id%type;
    l_sec_users_tab            refcursor;
    l_sec_users_rcd            record;
    l_subs_children_del_return integer; -- OnTime WI #15972
    l_exception_diagnostics    trc.exception_diagnostics;

BEGIN
    l_action := utl.set_module_action(l_module_name,
                                  ' Setting Context');

    CALL ctx.set(iptnrid => partnerid_i::uuid, iloginid => userloginid_i);

    SELECT usr_id,
           make_id
    INTO STRICT vusrid,
        l_make_id
    FROM beowner.ctx_data;

    -- get parent id for event log status
    SELECT parent_id
    INTO STRICT vparentid
    FROM beowner.usr
    WHERE usr_id = vusrid;

    -- save off VINs in the subscriptions we're deleting
    OPEN v_vins FOR
        SELECT vin
        FROM beowner.subscription
        WHERE primary_id IN (SELECT usr_id
                             FROM beowner.usr
                             WHERE parent_id = vusrid
                             UNION ALL
                             SELECT vusrid);

    -- #9781 : collect information necessary to send secondary user emails
    -- case where the usr is a secondary is not included since email should only be sent
    -- when secondaries are deleted because primary is being deleted
    OPEN l_sec_users_tab FOR
        SELECT us.usr_id usr_id,
               us.login_id login_id,
               uds.name_first || ' ' || uds.name_last sec_name,
               udp.name_first || ' ' || udp.name_last primary_name
        FROM beowner.usr us
                 LEFT OUTER JOIN beowner.usr_demog uds ON (us.usr_id = uds.usr_id)
                 LEFT OUTER JOIN beowner.usr_demog udp ON (us.parent_id = udp.usr_id)
        WHERE us.parent_id = vusrid;


    l_action := utl.set_module_action(l_module_name, ' Deleting Data');

    -- the sub-query takes care of secondary users if
    -- vUsrID is a primary.
    -- DI 1475
    --using crudg_usr.d_usr_sp to delete usr info and child records
    l_result := crudg_usr.d_usr_sp(iusr_id => vusrid::text,
                                   i_uc_id => NULL::text,
                                   iuserlogin => NULL::text,
                                   ipwd => NULL::text,
                                   ifirst_name => NULL::text,
                                   ilast_name => NULL::text,
                                   iversion => NULL::text,
                                   i_delete_children => 'Y'::text);

    IF l_result != utl.get_constant_value('csuccess')::integer
    THEN
        OPEN recordset_o FOR
            SELECT l_result;
    END IF;

    -- resolve VIN conflicts for all the prior subscription records
    LOOP
        FETCH v_vins INTO v_vin_rcd;
        EXIT WHEN NOT FOUND;
        CALL utl.checkvinconflict(v_vin_rcd.vin);
    END LOOP;

    -- #9781, send emails to secondaries
    -- included after the deletes to ensure that the emails are only sent when the delete has been successful
    LOOP
        FETCH l_sec_users_tab INTO l_sec_users_rcd;
        EXIT WHEN NOT FOUND;
        -- Make of the primary and secondary would be the same, hence it's ok to use the context make in this procedure as well as in email.send
        CALL beowner.send_secondary_delete_email(i_usr_id => l_sec_users_rcd.usr_id::text,
                                                 i_email_id => l_sec_users_rcd.login_id::text,
                                                 i_secondary_name => l_sec_users_rcd.sec_name::text,
                                                 i_primary_name => l_sec_users_rcd.primary_name::text,
                                                 i_make_id => l_make_id::text);
    END LOOP;

    -- Jira DDCRD-405 - removed call to update event log, as trigger on usr and subscription tables will handle the insert

    OPEN recordset_o FOR
        SELECT utl.get_constant_value('csuccess');
EXCEPTION
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cinvalidparams');

    WHEN SQLSTATE 'EPTNR' THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cdbpartneridnotvalid');

    WHEN SQLSTATE 'EUSRN' THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cnosuchuser');

    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                            iexception_diagnostics => l_exception_diagnostics);

        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cinternalerror');
END;
$BODY$ LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_cancel_subscriber_sp ((userloginid_i text, userpassword_i text, partnerid_i text, recordset_o OUT REFCURSOR) IS  vusrid usr.usr_id%TYPE) FROM PUBLIC;

\i cleanup.sql;
