SET bedb.filename = 'function.be_get_subscriber_sp.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION beowner.be_get_subscriber_sp (userloginid_i       text
                                                        ,partnerid_i         text
                                                        ,recordset_o     OUT refcursor)
AS $body$
DECLARE

/*  Title:    BE_GET_SUBSCRIBER_SP
    Version:      4.0
    Date:     January 27, 2011
    Author:   Bob B
    Description:  This procedure was created to validate if a subscriber record
          is on file based on only the email address.  It extracts the
          user's password and account status and passes them back
          to the API.

    Input parameters:
      userLoginId_i   - subscriber email address
      partnerid_i     - partner uid

    Output parameters:
      status_code_o   - status code

      success       - status_code of '0' if there is success in validating
              the subscriber.
      failure       - '2' if no record found,
              '4' if value error (usually bad parameters),
              '7' user id not on file, and
              '1' if general failure in the routine.

    Revision History:

    DATE      AUTHOR    DESCRIPTION
    02/06/11  Bob B rework status/conflict logic per task #3799
    02/14/11  Bob B Code to activate user and perform conflict check
            moved to new sproc BE_ACTIVATE_USER_SP per defect #6348
    04/12/11  Bob B Normalize per work item #4507
    04/18/11  Bob B DB Changes in work items 4580, 4509, 4510, 4511
    04/25/11  Bob B Add columns to recordset per work item 4694
    06/16/11  djb   Rework for new schema
    09/19/12  NMS   Modified cursor for WI #8415 ([DB - 383] UP: Build revised registration process for Entune)
            - added columns email_status and email_status_date
            - no longer calling user_subscription package as no subscription data was being returned
*/
      l_action TEXT;      
      l_module_name text := 'be_get_subscriber_sp';
      l_exception_diagnostics trc.exception_diagnostics;
BEGIN
   l_action := utl.set_module_action( l_module_name, ' Setting Context');

   CALL ctx.SET(iptnrid => partnerid_i::UUID, iloginid => userloginid_i);

   l_action := utl.set_module_action( l_module_name, ' Executing query');


   OPEN recordset_o FOR
      SELECT utl.get_constant_value ('csuccess')
      ,pwd
      ,CASE
           WHEN u.verified IS NOT NULL THEN utl.get_constant_value ('cstatusactive')
           ELSE utl.get_constant_value ('cstatuspending')
       END                                                    acct_status
      ,u.login_id
      ,CASE WHEN u.parent_id IS NULL THEN '1' ELSE '0' END    is_primary
      ,CASE ue.status
           WHEN 'V' THEN utl.get_constant_value ('cstatusvalid')
           WHEN 'I' THEN utl.get_constant_value ('cstatusinvalid')
           WHEN 'N' THEN utl.get_constant_value ('cstatusnotvalidated')
           ELSE NULL
       END                                                    email_status
      ,ue.status_date                                         email_status_date
  FROM beowner.usr u LEFT JOIN beowner.usr_email ue ON ue.usr_id = u.usr_id AND ue.email_type_id = 'H1'
 WHERE u.usr_id = (SELECT c.usr_id
                     FROM beowner.ctx_data c);
EXCEPTION
   WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation
   THEN
      OPEN recordset_o FOR SELECT utl.get_constant_value('cinvalidparams');
   WHEN SQLSTATE 'EPTNR'
   THEN
      OPEN recordset_o FOR SELECT utl.get_constant_value('cdbpartneridnotvalid');
   WHEN SQLSTATE 'EUSRN'
   THEN
      OPEN recordset_o FOR SELECT utl.get_constant_value('cnosuchuser');
   WHEN OTHERS
   THEN
      GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);

      OPEN recordset_o FOR SELECT utl.get_constant_value('cinternalerror');
END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_get_subscriber_sp ( userloginid_i text, partnerid_i text, recordset_o OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
