SET bedb.filename = 'function.be_cancel_2nd_subscriber_sp.sql';

\i set_be_env.sql;
/*
    Title:            BE_CANCEL_2ND_SUBSCRIBER_SP
    Version:          4.1
    Date:             04/14/2011
    Author:           Bob Binger
    Description:      Cancels secondary subscribers account.

    Input parameters:
      Partnerid_i                   IN  VARCHAR2,
      Secondary_Subscriber_Email_i  IN  VARCHAR2,

    Output parameters:
       recordset_o   status code plus data if applicable

       status code '0' - Success
                   '1' - Undefined exception logged in sql_error_log
                   '4' - value error which is normally invalid parameter(s)

    NOTE:  This routine will need to be modified to include better exception
           handling that is data driven and use of different variables if deemed
           necessary.  There will need to be more logic added to ensure that
           this is a unique record.  There also may be a need in the future to
           make this procedure more dynamic so that the input is data driven.
           There will also need to be logic added for the return status codes so
           they can be data driven.

    Revision History:

    DATE              AUTHOR    DESCRIPTION
    05/12/11  Bob B     Work Item 4846 - secondary acl rework
    05/19/11  Dean B    rework for new schema
*/
DROP FUNCTION IF EXISTS beowner.be_cancel_2nd_subscriber_sp(text, text);
CREATE OR REPLACE FUNCTION beowner.be_cancel_2nd_subscriber_sp(partnerid_i text,
                                                               secondary_subscriber_email_i text,
                                                               OUT recordset_o refcursor) AS
$body$
DECLARE

BEGIN
    recordset_o := beowner.be_cancel_subscriber_sp(secondary_subscriber_email_i, NULL, partnerid_i);
    -- the above procedure does the commit
END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_cancel_2nd_subscriber_sp ( partnerid_i text, secondary_subscriber_email_i text, recordset_o out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
