SET bedb.filename = 'function.be_get_2nd_subscribers_sp.sql';

\i set_be_env.sql;
/*
    Title:	      BE_GET_2ND_SUBSCRIBERS_SP
    Version:	      4.0
    Date:	      04/14/2011
    Author:	      Bob Binger
    Description:      Get first name, last name, and phone number for all
		      secondary subscribers tied to primary account.

    Input parameters:
      Partnerid_i		    IN	VARCHAR2,
      Primary_Subscriber_Email_i    IN	VARCHAR2,

    Output parameters:
       recordset_o   status code plus data if applicable

       status code '0' - Success
		   '1' - Undefined exception logged in sql_error_log
		   '4' - value error which is normally invalid parameter(s)

    Revision History:

    DATE	      AUTHOR	DESCRIPTION
    06/16/2011	      djb	Rework for New Schema

*/
DROP FUNCTION IF EXISTS beowner.be_get_2nd_subscribers_sp(text, text);
CREATE OR REPLACE FUNCTION beowner.be_get_2nd_subscribers_sp(partnerid_i text,
                                                             primary_subscriber_email_i text,
                                                             OUT recordset_o refcursor) AS
$body$
DECLARE
    l_action text;
    l_module_name           text := 'be_get_2nd_subscribers_sp';
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN

    l_action := utl.set_module_action(l_module_name, ' Setting Context');

    CALL ctx.set(iptnrid => partnerid_i::uuid,
                    iloginid => primary_subscriber_email_i);

    l_action := utl.set_module_action(l_module_name, ' Executing query');

    OPEN recordset_o FOR
        SELECT CASE
                   WHEN ub.usr_id IS NOT NULL
                       THEN utl.get_constant_value('csuccess')
                   ELSE utl.get_constant_value('cDbUserSubsDataNotFound')
                   END status,
               ub.name_first,
               ub.name_last,
               ub.ac,
               ub.phone,
               ub.email,
               CASE
                   WHEN ub.verified IS NOT NULL
                       THEN utl.get_constant_value('cStatusActive')
                   ELSE utl.get_constant_value('cStatusPending')
                   END acct_status
        FROM beowner.ctx_data cd
                 JOIN beowner.usr u
                      ON u.usr_id = cd.usr_id
                 LEFT JOIN beowner.usr_basic_info_ctx_2nd ub
                           ON NULL IS NULL;

EXCEPTION
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
    OPEN recordset_o FOR
      SELECT utl.get_constant_value('cinvalidparams');

  WHEN SQLSTATE 'EPTNR' THEN
    OPEN recordset_o FOR
      SELECT utl.get_constant_value('cdbpartneridnotvalid');

  WHEN SQLSTATE 'EUSRN' THEN
    OPEN recordset_o FOR
      SELECT utl.get_constant_value('cnosuchuser');

  WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cinternalerror');

END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_get_2nd_subscribers_sp ( partnerid_i text, primary_subscriber_email_i text, recordset_o out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
