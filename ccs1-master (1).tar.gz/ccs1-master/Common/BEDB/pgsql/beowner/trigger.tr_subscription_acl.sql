SET bedb.filename = 'trigger.tr_subscription_acl.sql';

\i set_be_env.sql;

drop FUNCTION if exists beowner.trigger_fct_tr_subscription_acl cascade;

CREATE OR REPLACE FUNCTION beowner.trigger_fct_tr_subscription_acl() RETURNS trigger AS $BODY$
DECLARE
   l_uncache_old_user_acl BOOLEAN := FALSE;
   l_uncache_new_user_acl BOOLEAN := FALSE;
   l_exception_diagnostics trc.EXCEPTION_DIAGNOSTICS;
BEGIN

   /*
     Take special care when performing bulk DML against the subscription table. These DML changes
     may remove ACL cache entries for a large number of users and will require the cache to
     be repopulated.
   */

   /*  If Subscription is added/deleted, user updated (transfer), contract assignment changed, optin_level changed,
   the corresponding usr_Acl row/s need to be uncached */
   CASE
      WHEN TG_OP = 'INSERT' THEN
         l_uncache_new_user_acl := TRUE;
      WHEN TG_OP = 'DELETE' THEN
         l_uncache_old_user_acl := TRUE;
      ELSE
         -- updating
         CASE
            WHEN old.primary_id != new.primary_id THEN
               l_uncache_new_user_acl := TRUE;
               l_uncache_old_user_acl := TRUE;
            WHEN old.bndl_id != new.bndl_id THEN
               l_uncache_new_user_acl := TRUE;
            WHEN old.optin_level != new.optin_level THEN
               l_uncache_new_user_acl := TRUE;
            WHEN ((old.contract_id IS NOT NULL AND nullif(new.contract_id,'') IS NULL) OR -- if an old contract id was replaced with a new one, ACL shouldn't be affected
                  (nullif(old.contract_id,'') IS NULL AND new.contract_id IS NOT NULL)) -- but if a contract ID was added or removed, ACL does get affected
             THEN
               l_uncache_new_user_acl := TRUE;
            ELSE
               NULL; -- Jira SBM-197
         END CASE;
   END CASE;

   IF l_uncache_old_user_acl
   THEN
      call user_subscription.uncache_acl(i_usr_id => old.primary_id);
   END IF;
   IF l_uncache_new_user_acl
   THEN
      call user_subscription.uncache_acl(i_usr_id => new.primary_id);
   END IF;


  IF TG_OP = 'DELETE'
  THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;


EXCEPTION
   WHEN OTHERS
    then
    GET STACKED diagnostics
      l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
      l_exception_diagnostics.column_name := COLUMN_NAME,
      l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
      l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
      l_exception_diagnostics.message_text := MESSAGE_TEXT,
      l_exception_diagnostics.table_name := TABLE_NAME,
      l_exception_diagnostics.schema_name := SCHEMA_NAME,
      l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
      l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
      l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

      CALL trc.log(iadditionaldata => 'Error in tr_subscription_acl - subscription id ' || coalesce(new.subscription_id, old.subscription_id),
               iexception_diagnostics => l_exception_diagnostics);
end
$BODY$
 LANGUAGE 'plpgsql';

CREATE TRIGGER tr_subscription_acl
  AFTER INSERT OR DELETE OR UPDATE ON beowner.subscription
  FOR EACH ROW
  EXECUTE PROCEDURE beowner.trigger_fct_tr_subscription_acl();

\i cleanup.sql;
