SET bedb.filename = 'procedure.send_secondary_delete_email.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS beowner.send_secondary_delete_email(text, text, text, text, text);
CREATE OR REPLACE PROCEDURE beowner.send_secondary_delete_email(i_usr_id IN text,
                                                                i_email_id IN text,
                                                                i_secondary_name IN text,
                                                                i_primary_name IN text,
                                                                i_make_id IN text) AS
$BODY$
DECLARE
    l_key_values             xml;
    c_template_name CONSTANT text = 'cancelSecondarySubscriber';
    c_tm_subject    CONSTANT text = 'Toyota Entune App Suite Account Update';
    c_lx_subject    CONSTANT text = 'Lexus Enform Account Update';
    l_subject                text;
BEGIN
    IF i_make_id IN ('TM', 'LX')
    THEN
        IF i_make_id = 'TM'
        THEN
            l_subject := c_tm_subject;
        ELSE
            l_subject := c_lx_subject;
        END IF;

        -- create a key/value pair for the email template for primary and secondary names
        l_key_values := xmlconcat(xmlelement(NAME entry,
                                             xmlelement(NAME KEY, 'subscriberName'),
                                             xmlelement(NAME VALUE, i_secondary_name)),
                                  xmlelement(NAME entry,
                                             xmlelement(NAME KEY, 'parentSubscriberName'),
                                             xmlelement(NAME VALUE, i_primary_name)));

        -- throw the email over the fence
/*        CALL email.send(i_to => i_email_id,
                        i_subject => l_subject,
                        i_templatename => c_template_name,
                        i_key_values => l_key_values);*/
    END IF;
END;
$BODY$ LANGUAGE plpgsql;

\i cleanup.sql;
