SET bedb.filename = 'function.run_maintenance_proc';
\i set_be_env.sql;

DROP PROCEDURE IF EXISTS beowner.run_maintenance_proc (INTEGER, BOOLEAN, BOOLEAN, BOOLEAN, INTEGER);

DROP FUNCTION IF EXISTS beowner.run_maintenance_proc (INTEGER, BOOLEAN, BOOLEAN, BOOLEAN);

CREATE OR REPLACE FUNCTION beowner.run_maintenance_proc (p_wait        INTEGER DEFAULT 0
                                                         ,p_analyze     BOOLEAN DEFAULT NULL::BOOLEAN
                                                         ,p_jobmon      BOOLEAN DEFAULT TRUE
                                                         ,p_debug       BOOLEAN DEFAULT FALSE
                                                         ,o_status_code OUT INTEGER)
AS $body$
DECLARE
    l_con_count    integer;
    l_module_name text := 'run_maintenance_proc';
    l_action text;
    l_CallQuery   text := format('CALL extensions.run_maintenance_proc (p_wait => %L
                                    ,p_analyze => %L
                                    ,p_jobmon  => %L
                                    ,p_debug   => %L)', p_wait, p_analyze, p_jobmon, p_debug
                                  );
    l_exception_diagnostics trc.exception_diagnostics;                                
BEGIN

    SELECT COUNT (1)
    INTO l_con_count
    FROM extensions.dblink_get_connections()
    WHERE coalesce(array_position(dblink_get_connections, 'extconn'),0) > 0;
   
    IF l_con_count = 0 then 
      PERFORM extensions.dblink_connect('extconn','fdlog');
    END IF;

    l_action := utl.set_module_action( l_module_name, ' Calling maint: ' || l_CallQuery);
    
    PERFORM extensions.dblink_exec('extconn', l_CallQuery );
  
    PERFORM extensions.dblink_disconnect('extconn');
  
    o_status_code := utl.get_constant_value('csuccess');  
    
    RETURN;

EXCEPTION
    WHEN OTHERS THEN
   
      GET STACKED diagnostics
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;

      CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);

      o_status_code := utl.get_constant_value('cinternalerror');
       
      RETURN;

END
$body$
LANGUAGE plpgsql
SECURITY DEFINER
;

\i cleanup.sql;
