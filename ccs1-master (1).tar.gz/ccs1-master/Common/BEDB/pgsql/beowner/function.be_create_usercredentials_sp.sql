SET bedb.filename = 'function.be_create_usercredentials_sp.sql';

\i set_be_env.sql;

/*  Title:        BE_CREATE_USERCREDENTIALS_SP
    Version:      4.1
    Date:         August 5, 2010
    Author:       Jeff H
    Description:  The purpose is to create a new record in the
                  credentials and subscribers_Credentials tables to reflect the
                  information passed to this procedure from the calling
                  application.  There is first a validation of the email_address
                  and the password in the subscribers table.  Then a record is
                  created in the credentials table, next a record is created in
                  the subscribers_credentials table to create the relationship.

    Input parameters:
      userLoginId       - subscriber email address
      userPassword      - subscriber password
      service_loginid   - user id for the given service
      service_password  - password for the given service
      token             - token for the given service if necessary
      service_api_number- This is the api number of the service.  The API number
                          is data driven and will be from the services table in
                          the future.
      partnerid_i       - partner id

    Output parameters:
      status_code_0     - Output variable
      success -  status_code of '0' if there is success in creating the new
                 records in the credentials and subscribers_credentials tables.
      failure - '1' if there is failure in the routine.
      failure - '4' - invalid parameter(s)
      failure - '2' - user does not exist
      failure - '7' - userid not on file

    Revision History:

    DATE      AUTHOR    DESCRIPTION

    08/31/10  Jeff H    Change to add the update of the credentials information
                        as long as the subscriber information is validated.

    08/31/10  Jeff H    Added check for status and delete flag in the
                        subscribers table adn status for credentials table.

    09/10/10  Bob B     Change output paramater to sys_recursor

    09/29/10  Bob B     Resolved defect #3556 (u pper case email comparison)
    11/26/10  Bob B     General cleanup and call new tg_validate_user_sp
    01/17/11  Bob B     add partner_uid per task #3797
    03/17/11  Bob B     Work Item #4362 expanded ACL status codes
    04/12/11  Bob B     Normalize per work item #4507
    04/18/11  Bob B     DB Changes in work items 4580, 4509, 4510, 4511
    04/26/11  Bob B     Validate service id for this user defect 6733
    04/29/11  Bob B     Allow secondary user to create credential if
                        primary user has access to service - defect 7848
    05/01/11  Bob B     Defect #7859 and 7849 deal with primary and secondary
                        subscribers differently
    05/04/11  Bob B     Defect 7968 set switch to toggle on/off
    05/12/11  Bob B     Work Item 4846 - secondary acl rework
    05/19/11  Dean B    rework with new schema
*/

DROP FUNCTION IF EXISTS beowner.be_create_usercredentials_sp (text, text, text, text, text, text, text);
CREATE OR REPLACE FUNCTION beowner.be_create_usercredentials_sp(userloginid_i text,
                                                                userpassword_i text,
                                                                service_loginid_i text,
                                                                service_password_i text,
                                                                token_i text,
                                                                serviceid_i text,
                                                                partnerid_i text,
                                                                status_code_o OUT refcursor) AS
$BODY$
DECLARE

    l_action                text;
    l_module_name           text := 'be_create_usercredentials_sp';
    v_usr_id                beowner.usr.usr_id%type;
    v_cnt                   integer;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN

    l_action := utl.set_module_action(l_module_name, ' Setting Context');

    CALL ctx.set(iptnrid => partnerid_i::uuid,
                 iloginid => userloginid_i);

    SELECT usr_id
    INTO STRICT v_usr_id
    FROM beowner.ctx_data;

    l_action := utl.set_module_action(l_module_name, ' Merging Credentials');

    -- WI-7808 - Dashboard item 204 Implement encrypted 3rd party credentials
    v_cnt := be_linked_credentials.be_set_linked_credentials_sp(userloginid_i,
                                                                partnerid_i,
                                                                serviceid_i,
                                                                service_loginid_i,
                                                                service_password_i,
                                                                token_i);


    IF v_cnt = 0 THEN

        OPEN status_code_o FOR
            SELECT utl.get_constant_value('csuccess');

    ELSE

        OPEN status_code_o FOR SELECT v_cnt;

    END IF;

EXCEPTION
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
    OPEN status_code_o FOR
      SELECT utl.get_constant_value('cinvalidparams');

  WHEN SQLSTATE 'EPTNR' THEN
    OPEN status_code_o FOR
      SELECT utl.get_constant_value('cdbpartneridnotvalid');

  WHEN SQLSTATE 'EUSRN' THEN
    OPEN status_code_o FOR
      SELECT utl.get_constant_value('cnosuchuser');

  WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
    OPEN status_code_o FOR
      SELECT utl.get_constant_value('cinternalerror');

END;
$BODY$ LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_create_usercredentials_sp ( userloginid_i text, userpassword_i text, service_loginid_i text, service_password_i text, token_i text, serviceid_i text, partnerid_i text, status_code_o out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
