SET bedb.filename = 'trigger.tr_hist_bndlsvc.sql';

\i set_be_env.sql;

drop FUNCTION if exists beowner.trigger_fct_tr_hist_bndlsvc cascade;

CREATE OR REPLACE FUNCTION beowner.trigger_fct_tr_hist_bndlsvc() RETURNS trigger AS $BODY$
DECLARE
   l_act      VARCHAR(1);
   l_hist_row beowner.bndlsvc;
BEGIN
  l_act := CASE
             WHEN TG_OP = 'INSERT' THEN
               'I'
             WHEN TG_OP = 'UPDATE' THEN
              'U'
             WHEN TG_OP = 'DELETE' THEN
              'D'
          END;

  IF TG_OP = 'DELETE'
  then
      l_hist_row.bndl_id := old.bndl_id;
      l_hist_row.svc_id := old.svc_id;
      l_hist_row.allowed_status := old.allowed_status;
      l_hist_row.optin_level := old.optin_level;
   ELSE
      l_hist_row.bndl_id := new.bndl_id;
      l_hist_row.svc_id := new.svc_id;
      l_hist_row.allowed_status := new.allowed_status;
      l_hist_row.optin_level := new.optin_level;
   END IF;

   INSERT INTO beowner.hist_bndlsvc
      (act,
       hist_bndlsvc_guid,
       milestone,
       bndl_id,
       svc_id,
       allowed_status,
       optin_level)
   VALUES
      (l_act,
       beowner.rand_guid(),
       utl.get_milestone(),
       l_hist_row.bndl_id,
       l_hist_row.svc_id,
       l_hist_row.allowed_status,
       l_hist_row.optin_level);

IF TG_OP = 'DELETE' THEN
  RETURN OLD;
ELSE
  RETURN NEW;
END IF;

END
$BODY$
 LANGUAGE 'plpgsql';

CREATE TRIGGER tr_hist_bndlsvc
  AFTER INSERT OR UPDATE OR DELETE ON beowner.bndlsvc FOR EACH ROW
  EXECUTE PROCEDURE beowner.trigger_fct_tr_hist_bndlsvc();

\i cleanup.sql;
