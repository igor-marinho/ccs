SET bedb.filename = 'function.te_get_servicedata_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.te_get_servicedata_sp();
CREATE OR REPLACE FUNCTION beowner.te_get_servicedata_sp(OUT recordset_o refcursor)
 RETURNS refcursor
AS $body$
DECLARE

/*  Title:    TE_GET_SERVICEDATA_SP
    Version:      4.0
    Date:     December 21, 2010
    Author:   Bob Binger
    Description:  This function is used to query the services tbale
          and pass back all valid services to the API as a recordset.

    Input parameters:
    None

    Output parameters:
    recordset_o - services table serviceids.

    Revision History:

    DATE      AUTHOR    DESCRIPTION
    01/17/11  Bob B 	add partner_uid per task #3797
    04/18/11  Bob B 	DB Changes in work items 4580, 4509, 4510, 4511
    06/02/11  djb   	rework for new schema
	04/01/20  Dinesh	Changed the object to function to avoid INOUT parameters.	
*/
BEGIN

  open recordset_o for
    SELECT utl.get_constant_value('ccodesuccess'),
       svc_id
      from beowner.svc;

  RETURN;
end;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE te_get_servicedata_sp ( recordset_o out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
