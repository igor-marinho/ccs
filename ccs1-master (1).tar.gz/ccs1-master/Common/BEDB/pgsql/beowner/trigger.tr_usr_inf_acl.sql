SET bedb.filename = 'trigger.tr_usr_inf_acl.sql';

\i set_be_env.sql;

drop FUNCTION if exists beowner.trigger_fct_tr_usr_inf_acl cascade;

CREATE OR REPLACE FUNCTION beowner.trigger_fct_tr_usr_inf_acl() RETURNS trigger AS $BODY$
declare
  l_exception_diagnostics trc.EXCEPTION_DIAGNOSTICS;
BEGIN
  call user_subscription.uncache_acl(i_usr_id => coalesce (new.usr_id, old.usr_id),
                                     i_include_secondary => FALSE);

  IF TG_OP = 'DELETE'
  THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;

EXCEPTION
  WHEN others
  then
    GET STACKED diagnostics
      l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
      l_exception_diagnostics.column_name := COLUMN_NAME,
      l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
      l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
      l_exception_diagnostics.message_text := MESSAGE_TEXT,
      l_exception_diagnostics.table_name := TABLE_NAME,
      l_exception_diagnostics.schema_name := SCHEMA_NAME,
      l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
      l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
      l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

      CALL trc.log(iadditionaldata => 'Error in tr_usr_inf_acl - usr_ id ' || coalesce (new.usr_id, old.usr_id),
               iexception_diagnostics => l_exception_diagnostics);
END
$BODY$
 LANGUAGE 'plpgsql';

CREATE TRIGGER tr_usr_inf_acl_ins
  AFTER INSERT ON beowner.usr_inf FOR EACH ROW
   WHEN (new.key_id = 'loginID')
  EXECUTE PROCEDURE beowner.trigger_fct_tr_usr_inf_acl();

CREATE TRIGGER tr_usr_inf_acl_del
  AFTER DELETE ON beowner.usr_inf FOR EACH ROW
   WHEN (old.key_id = 'loginID')
  EXECUTE PROCEDURE beowner.trigger_fct_tr_usr_inf_acl();

\i cleanup.sql;
