SET bedb.filename = 'function.be_create_services_sp.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS beowner.be_create_services_sp(text, text, text, text);
CREATE OR REPLACE FUNCTION beowner.be_create_services_sp(IN userloginid_i text,
                                                         IN vin_i text,
                                                         IN bundleid_i text,
                                                         IN partnerid_i text,
                                                         OUT status_code_o refcursor)
AS
$body$
DECLARE
  l_action      text;
  l_module_name text := 'be_create_services_sp';
  vRslt    text;
  vBndlID  beowner.bndl.bndl_id%type;
  vCount   integer;
  v_make_id beowner.vin.make_id%type;
  l_exception_diagnostics trc.exception_diagnostics;

BEGIN

    l_action := utl.set_module_action(l_module_name, 'Setting Context'); 
   
    if  partnerid_i::uuid = utl.getconfig('Oneapp PTNR ID')::uuid then 
   
         select  make_id 
          into v_make_id 
          from beowner.vin 
         where vin = trim(vin_i);
       
        if v_make_id = 'TM' then   
		   	partnerid_i := utl.getconfig('Toyota PTNR ID');
	    end if;
  
	    if  v_make_id = 'LX' then  
		     partnerid_i := utl.getconfig('Lexus PTNR ID');
	    end if;
  end if;
 
     CALL ctx.set(iPtnrID => partnerid_i::uuid, 
   				 iLoginID => userloginid_i,  
   				 iVIN => vin_i);
    
     SELECT count(*)
    INTO vCount
    FROM beowner.bndl
    WHERE bndl_id = bundleid_i::uuid;

    IF vCount = 0 THEN
        OPEN status_code_o FOR
            SELECT utl.get_constant_value('cinvalidbundleid');
        RETURN;
    END IF;

    vRslt := beowner.tg_create_subbundles_sp(bundleid_i => bundleid_i);

   
    open status_code_o for
    SELECT utl.get_constant_value('csuccess');

exception
   WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation
   THEN
    open status_code_o for
      SELECT utl.get_constant_value('cinvalidparams');

  when SQLSTATE 'EPTNR'
  then
    open status_code_o for
      SELECT utl.get_constant_value('cdbpartneridnotvalid');

  when SQLSTATE 'EUSRN'
  then
    open status_code_o for
      SELECT utl.get_constant_value('cnosuchuser');

  when SQLSTATE 'EVINN'
  then
    open status_code_o for
      SELECT utl.get_constant_value('cdbvinnotfound');

  WHEN OTHERS  THEN
    GET STACKED DIAGNOSTICS
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

     CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);

    OPEN status_code_o FOR
      SELECT utl.get_constant_value('cinternalerror');

END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER ;
-- REVOKE ALL ON FUNCTION be_create_services_sp ( userloginid_i text, vin_i text, bundleid_i text, partnerid_i text, status_code_o out sys_refcursor ) FROM PUBLIC;

\i cleanup.sql;