SET bedb.filename = 'telogowner_grants.sql';

\i set_env.sql;

GRANT telogowner to beowner;

\i cleanup.sql;
