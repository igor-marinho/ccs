SET bedb.filename = 'function.be_get_usersubscriptiondata_sp.sql';

\i set_be_env.sql;
/*  Title:	  BE_GET_USERSUBSCRIPTIONDATA_SP
    Version:	  4.0
    Date:	  September 7, 2010
    Author:	  Bob B
    Description:
      The purpose is to get subscription data from the subscribers bundle
      table based upon subscriber id.  A cursor containing the data is returned.

    Input parameters:
      userLoginId   - subscriber email address
      userPassword  - subscriber password
      partnerid     - partner id

    Output parameters:
      recordset_0   - subscriber subscription data in a refcursor
      success - concatanation of the status_code of '0' and subscription data
      failure - status code of '1' = general failure, '2' = failed validation,
		'7' = user not on file, '4' = bad parameter, or '202 =
		no subscription data found.

    Revision History:

    DATE      AUTHOR	DESCRIPTION

    09/29/10  Bob B	Resolved defect #3556 (u pper case email comparison)
    11/02/10  Bob B	Completely changed to return data in subscriber
			bundle records
    11/26/10  Bob B	General cleanup and call new tg_validate_user_sp
    01/17/11  Bob B	add partner_uid per task #3793
    03/06/11  Bob B	Deprecated sb_dofu, sb_demo_code per task #4276
    04/12/11  Bob B	Normalize per work item #4507
    04/18/11  Bob B	DB Changes in work items 4580, 4509, 4510, 4511
*/
DROP FUNCTION IF EXISTS beowner.be_get_usersubscriptiondata_sp(text, text, text);
CREATE OR REPLACE FUNCTION beowner.be_get_usersubscriptiondata_sp(userloginid_i text,
                                                                  userpassword_i text,
                                                                  partnerid_i text,
                                                                  OUT recordset_o refcursor) AS
$BODY$
DECLARE
    l_action                text;
    l_module_name           text := 'be_get_usersubscriptiondata_sp';
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN

    l_action := utl.set_module_action(l_module_name, ' Setting Context');

    CALL ctx.set(iPtnrID => partnerid_i::uuid,
                 iLoginID => userloginid_i);

    l_action := utl.set_module_action(l_module_name, ' Returning Dataset');

    OPEN recordset_o FOR
        SELECT DISTINCT utl.get_constant_value('csuccess'),
                        CASE payment_type
                            WHEN 'S' THEN 'SUBSIDIZED'
                            WHEN 'P' THEN 'PAID'
                            ELSE 'Unknown'
                            END,
                        NULL,
                        to_char(sub_start, 'YYYYMMDD'),
                        to_char(sub_end, 'YYYYMMDD'),
                        NULL,
                        vin
        FROM user_subscription.info_ctx() alias2;

EXCEPTION
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cinvalidparams');

    WHEN SQLSTATE 'EPTNR' THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cdbpartneridnotvalid');

    WHEN SQLSTATE 'EUSRN' THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cnosuchuser');

    WHEN SQLSTATE 'EVINN' THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cdbvinnotfound');

    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL, iexception_diagnostics => l_exception_diagnostics);
        OPEN recordset_o FOR
        SELECT utl.get_constant_value('cinternalerror');

END;
$BODY$
    LANGUAGE PLPGSQL
    SECURITY DEFINER;
-- REVOKE ALL ON PROCEDURE be_get_usersubscriptiondata_sp ( userloginid_i text, userpassword_i text, partnerid_i text, recordset_o out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
