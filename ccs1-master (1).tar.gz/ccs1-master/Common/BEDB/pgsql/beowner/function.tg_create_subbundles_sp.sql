SET bedb.filename = 'function.tg_create_subbundles_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.tg_create_subbundles_sp(text);
CREATE OR REPLACE FUNCTION beowner.tg_create_subbundles_sp(IN bundleid_i text,
                                                           OUT status_code_o text)
AS
$BODY$
DECLARE
    l_action      text;
    l_module_name text := 'tg_create_subbundles_sp';
    vcount        integer;
    /* WI #14078 */
    l_usr_id      beowner.usr.usr_id%type;
    l_vin         beowner.vin.vin%type;
BEGIN

    status_code_o := utl.get_constant_value('csuccess');
    l_action := utl.set_module_action(l_module_name,
                                  ' Checking Existing subscription');

    /* modified to include bndl_id for #19640 */
    SELECT COUNT(*)
    INTO STRICT vcount
    FROM beowner.subscription
    WHERE (primary_id, vin, bndl_id) = (SELECT usr_id, vin, bundleid_i::uuid
                                        FROM beowner.ctx_data);

    IF vcount > 0
    THEN
        RETURN;
    END IF;

    /* WI #14078 */
    SELECT usr_id, vin
    INTO STRICT l_usr_id, l_vin
    FROM beowner.ctx_data;

    l_action := utl.set_module_action(l_module_name,
                                  ' Creating Subscription');

    INSERT INTO beowner.subscription (subscription_id, primary_id, vin, bndl_id, sub_start, sub_duration)
    SELECT beowner.rand_guid(), cd.usr_id, cd.vin, bundleid_i::uuid, cd.tmstmp, b.bundle_length
    FROM beowner.ctx_data AS cd
             JOIN beowner.bndl AS b
                  ON b.bndl_id = bundleid_i::uuid;

    CALL utl.checkvinconflict();
    /* use context vin */
    /* Jira DDCRD-405 - removed call to update event log, as trigger on subscription table will handle the insert */
END;
$BODY$
    LANGUAGE plpgsql;

\i cleanup.sql;
