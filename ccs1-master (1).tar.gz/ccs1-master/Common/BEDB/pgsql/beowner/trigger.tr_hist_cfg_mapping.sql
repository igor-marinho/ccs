SET bedb.filename = 'trigger.tr_hist_cfg_mapping.sql';

\i set_be_env.sql;

drop FUNCTION if exists beowner.trigger_fct_tr_hist_cfg_mapping cascade;

CREATE OR REPLACE FUNCTION beowner.trigger_fct_tr_hist_cfg_mapping() RETURNS trigger AS $BODY$
declare
  l_act varchar(1);
  l_hist_row cfg_mapping;
begin                                       --SM29 WI 12160
  l_act := CASE
             WHEN TG_OP = 'INSERT' THEN
               'I'
             WHEN TG_OP = 'UPDATE' THEN
              'U'
             WHEN TG_OP = 'DELETE' THEN
              'D'
          END;

  IF TG_OP = 'DELETE'
  then
    l_hist_row.MAPPING_ID := old.MAPPING_ID;
    l_hist_row.PROGRAM := old.PROGRAM;
    l_hist_row.NAME := old.NAME;
    l_hist_row.KEY := old.KEY;
    l_hist_row.VALUE := old.VALUE;
    l_hist_row.DESCRIPTION := old.DESCRIPTION;

  else
    l_hist_row.MAPPING_ID := new.MAPPING_ID;
    l_hist_row.PROGRAM := new.PROGRAM;
    l_hist_row.NAME := new.NAME;
    l_hist_row.KEY := new.KEY;
    l_hist_row.VALUE := new.VALUE;
    l_hist_row.DESCRIPTION := new.DESCRIPTION;

  end if;

  insert into hist_cfg_mapping
      (act, HIST_MAPPING_ID, MAPPING_ID, PROGRAM, NAME, KEY, VALUE, DESCRIPTION)
    values
      (l_act, beowner.rand_guid(), l_hist_row.MAPPING_ID, l_hist_row.PROGRAM, l_hist_row.NAME, l_hist_row.KEY, l_hist_row.VALUE, l_hist_row.DESCRIPTION);

IF TG_OP = 'DELETE'
THEN
  RETURN OLD;
ELSE
  RETURN NEW;
END IF;

END
$BODY$
 LANGUAGE 'plpgsql';

CREATE TRIGGER tr_hist_cfg_mapping
  AFTER INSERT OR UPDATE OR DELETE ON beowner.cfg_mapping FOR EACH ROW
  EXECUTE PROCEDURE beowner.trigger_fct_tr_hist_cfg_mapping();

\i cleanup.sql;
