SET bedb.filename = 'trigger.tr_hist_device.sql';

\i set_be_env.sql;

drop FUNCTION if exists beowner.trigger_fct_tr_hist_device cascade;

CREATE OR REPLACE FUNCTION beowner.trigger_fct_tr_hist_device() RETURNS trigger AS $BODY$
DECLARE
   l_act      VARCHAR(1);
   l_hist_row beowner.device;
BEGIN
  l_act := CASE
             WHEN TG_OP = 'INSERT' THEN
               'I'
             WHEN TG_OP = 'UPDATE' THEN
              'U'
             WHEN TG_OP = 'DELETE' THEN
              'D'
          END;

  IF TG_OP = 'DELETE'
  then
      l_hist_row.device_id := old.device_id;
      l_hist_row.description := old.description;
      l_hist_row.device_type := old.device_type;
      l_hist_row.make_id := old.make_id;
   ELSE
      l_hist_row.device_id := new.device_id;
      l_hist_row.description := new.description;
      l_hist_row.device_type := new.device_type;
      l_hist_row.make_id := new.make_id;
   END IF;

   INSERT INTO beowner.hist_device
      (act,
       hist_device_guid,
       milestone,
       device_id,
       description,
       device_type,
       make_id)
   VALUES
      (l_act,
       beowner.rand_guid(),
       utl.get_milestone(),
       l_hist_row.device_id,
       l_hist_row.description,
       l_hist_row.device_type,
       l_hist_row.make_id);

IF TG_OP = 'DELETE' THEN
  RETURN OLD;
ELSE
  RETURN NEW;
END IF;

END
$BODY$
 LANGUAGE 'plpgsql';

CREATE TRIGGER tr_hist_device
  AFTER INSERT OR UPDATE OR DELETE ON beowner.device FOR EACH ROW
  EXECUTE PROCEDURE beowner.trigger_fct_tr_hist_device();

\i cleanup.sql;
