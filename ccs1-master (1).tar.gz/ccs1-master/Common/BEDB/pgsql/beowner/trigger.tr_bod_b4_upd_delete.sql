SET bedb.filename = 'trigger.tr_bod_b4_upd_delete.sql';

\i set_be_env.sql;

DROP FUNCTION IF exists trigger_fct_tr_bo_documents CASCADE;

CREATE OR REPLACE function beowner.trigger_fct_tr_bo_documents()
RETURNS trigger as
$BODY$
DECLARE
BEGIN

  RAISE EXCEPTION 'BODs cannot be modified or deleted after creation' USING ERRCODE = 'P0001';

END
$BODY$
 LANGUAGE 'plpgsql';

CREATE TRIGGER tr_bod_b4_upd_delete
  BEFORE UPDATE OR DELETE ON beowner.bo_documents FOR EACH ROW
  EXECUTE PROCEDURE beowner.trigger_fct_tr_bo_documents();

\i cleanup.sql;
