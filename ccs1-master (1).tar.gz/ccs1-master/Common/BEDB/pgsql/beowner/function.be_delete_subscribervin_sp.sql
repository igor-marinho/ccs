SET bedb.filename = 'function.be_delete_subscribervin_sp.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS beowner.be_delete_subscribervin_sp(text, text, text, text);
CREATE OR REPLACE FUNCTION beowner.be_delete_subscribervin_sp(userloginid_i text,
                                                              userpassword_i text,
                                                              vin_i text,
                                                              partnerid_i text,
                                                              status_code_o OUT refcursor) AS
$body$
DECLARE
    l_action                   text;
    l_module_name              text := 'be_delete_subscribervin_sp';
    v_subscription_id          beowner.subscription.subscription_id%type;
    v_subs_children_del_return integer;
    l_makeid                   text;
    l_exception_diagnostics    trc.exception_diagnostics;
BEGIN

    l_action := utl.set_module_action(l_module_name, ' Setting Context');
   
    /*For OneApp partner id, swap to Toyota or Lexus partner id based on VIN*/
                                     
    IF partnerid_i::uuid = utl.getconfig('Oneapp PTNR ID')::uuid THEN
    
    SELECT make_id INTO l_makeid FROM beowner.vin WHERE vin = trim(both(vin_i));
   
       IF l_makeid = 'LX' THEN partnerid_i := utl.getconfig('Lexus PTNR ID');
       
       ELSIF l_makeid = 'TM' THEN partnerid_i := utl.getconfig('Toyota PTNR ID');   
      
       ELSE OPEN status_code_o FOR
            SELECT utl.get_constant_value('cinvalidmake');
      
       RETURN;
      
       END IF;
    
    END IF;

    CALL ctx.set(iptnrid => partnerid_i::uuid, iloginid => userloginid_i, ivin => vin_i);

    l_action := utl.set_module_action(l_module_name, ' Deleting Data');

    SELECT subscription_id
    INTO STRICT v_subscription_id
    FROM beowner.subscription
    WHERE (primary_id, vin) = (SELECT usr_id, vin
                               FROM beowner.ctx_data);

    -- OnTime WI #15972 : Delete all the children of subscriptions at the same time
    v_subs_children_del_return := crudg_subscription.delete_subs_children(i_subscription_id => v_subscription_id);
    IF v_subs_children_del_return != utl.get_constant_value('csuccess')::integer THEN
        OPEN status_code_o FOR
            SELECT v_subs_children_del_return;
        RETURN;
    END IF;
    DELETE
    FROM beowner.subscription
    WHERE subscription_id = v_subscription_id;

    CALL utl.checkvinconflict(); -- use context

    OPEN status_code_o FOR
        SELECT utl.get_constant_value('csuccess');

EXCEPTION

    WHEN no_data_found THEN
        OPEN status_code_o FOR
            SELECT utl.get_constant_value('cdbsubscribervinnotfound');

    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
      OPEN status_code_o FOR
	 SELECT utl.get_constant_value('cinvalidparams');

   WHEN SQLSTATE 'EPTNR' THEN
      OPEN status_code_o FOR
	 SELECT utl.get_constant_value('cdbpartneridnotvalid');

   WHEN SQLSTATE 'EUSRN' THEN
      OPEN status_code_o FOR
	 SELECT utl.get_constant_value('cnosuchuser');

   WHEN SQLSTATE 'EVINN' THEN
      OPEN status_code_o FOR
	 SELECT utl.get_constant_value('cdbvinnotfound');

   WHEN OTHERS THEN
      GET STACKED DIAGNOSTICS
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
        OPEN status_code_o FOR
	        SELECT utl.get_constant_value('cinternalerror');

END;
$body$ LANGUAGE PLPGSQL
    SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_delete_subscribervin_sp ((userloginid_i text, userpassword_i text, vin_i text, partnerid_i text, status_code_o OUT REFCURSOR) AS vsubscriptionid subscription.subscription_id%TYPE) FROM PUBLIC;

\i cleanup.sql;
