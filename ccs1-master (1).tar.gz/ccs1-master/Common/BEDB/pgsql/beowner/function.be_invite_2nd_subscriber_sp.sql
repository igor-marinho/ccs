SET bedb.filename = 'function.be_invite_2nd_subscriber_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.be_invite_2nd_subscriber_sp(text, text, text, text);
CREATE OR REPLACE FUNCTION beowner.be_invite_2nd_subscriber_sp(partnerid_i text,
                                                               primary_subscriber_email_i text,
                                                               secondary_subscriber_email_i text,
                                                               relationship_type_i text,
                                                               OUT recordset_o refcursor) AS
$body$
/*
       Title:            BE_INVITE_2ND_SUBSCRIBER_SP
       Version:          4.1
       Date:             04/14/2011
       Author:           Bob Binger
       Description:      Create secondary account for subscriber tied to
                         primary account.  BE middle tier sends email.

       Input parameters:
         Partnerid_i                   IN  VARCHAR2,
         Primary_Subscriber_Email_i    IN  VARCHAR2,
         Secondary_Subscriber_Email_i  IN  VARCHAR2,
         Relationship_Type_i           IN  VARCHAR2,

       Output parameters:
          recordset_o   status code plus data if applicable

          status code '0' - Success
                      '1' - Undefined exception logged in sql_error_log
                      '4' - value error which is normally invalid parameter(s)

       Revision History:

       DATE              AUTHOR    DESCRIPTION
       04/18/11  Bob B     DB Changes in work items 4580, 4509, 4510, 4511
       04/26/11  Dean B    Work Item 4274 create default stock preference
       05/11/11  Bob B     Work Item 4290 technical cleanup
       05/12/11  Bob B     Work Item 4846 - secondary acl rework
       05/19/11  Dean B    rework for new schema
   */
DECLARE
    l_action                text;
    l_module_name           text := 'be_invite_2nd_subscriber_sp';
    v_pri_usr_id            beowner.usr.usr_id%type;
    v_sec_usr_id            beowner.usr.usr_id%type;
    v_make_id               beowner.make.make_id%type;
    vemail                  text;
    vparentid               beowner.usr.usr_id%type;
    v_is_primary            integer;
    v_allowed_2nds          integer;
    v_2nd_ary_count         integer;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN

    -- Removed column tos_flag,dwnld_app_flag for DCS1E-921
    l_action := utl.set_module_action(l_module_name,
                                      ' Setting Context');

    CALL ctx.set(iptnrid => partnerid_i::uuid,
                 iloginid => primary_subscriber_email_i);
    
    vemail := utl.normalize_email(secondary_subscriber_email_i);

    SELECT usr_id,
           make_id
    INTO STRICT v_pri_usr_id,
        v_make_id
    FROM beowner.ctx_data;

    BEGIN
        SELECT usr_id,
               parent_id
        INTO STRICT v_sec_usr_id,
            vparentid
        FROM beowner.usr
        WHERE login_id = vemail
          AND make_id = v_make_id;

        OPEN recordset_o FOR
            SELECT CASE
                       WHEN vparentid IS NOT NULL THEN
                           utl.get_constant_value('cdb2ndrysubsalreadyinvited')
                       ELSE
                           utl.get_constant_value('cuseralreadyexists')
                       END;

        RETURN;

    EXCEPTION
        WHEN no_data_found THEN
            NULL;
    END;

    l_action := utl.set_module_action(l_module_name,
                                      ' Verifying Data');

    /* We need to find the following:

       1) is the primary really a primary?                          :: cCodeDbSubscriberNotPrimary

       2) does the 2ndary exist under another account, or is a
          primary of their own? (TODO) This is not checked in
          the old code. Should it be?

       3) how many 2ndaries is the primary allowed to have?         :: see next
       4) how many 2ndaries does the primary currently have?        :: cCodeDb2ndSubsLimitReached

       5) is the secondary already invited?                         :: cCodeDb2ndSubsAlreadyInvited

    */
    SELECT x1.isprimary,
           x3.maxallowed,
           x4.subusercount
    INTO STRICT v_is_primary,
        v_allowed_2nds,
        v_2nd_ary_count
    FROM ( -- 1  vIsPrimary
             SELECT COUNT(*) isprimary
             FROM beowner.usr
             WHERE usr_id = v_pri_usr_id
               AND lvl = '0') x1,
         ( -- 3  vAllowed2nds
             SELECT (SUM(b.max_users) - 1) maxallowed
             FROM beowner.usr u
                      JOIN beowner.subscription s
                           ON u.usr_id = s.primary_id
                      JOIN beowner.bndl b
                           ON b.bndl_id = s.bndl_id
             WHERE u.usr_id = v_pri_usr_id) x3,
         ( -- 4  v2ndaryCount
             SELECT COUNT(*) subusercount
             FROM beowner.usr
             WHERE parent_id = v_pri_usr_id) x4;

    l_action := utl.set_module_action(l_module_name,
                                      ' Validating Data');

    IF v_is_primary = 0
    THEN
        -- user is not a primary
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cdbsubscribernotprimary') rslt;
        RETURN;
    END IF;

    IF v_2nd_ary_count >= v_allowed_2nds
    THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cdb2ndrysubslimitreached') rslt;
        RETURN;
    END IF;

    l_action := utl.set_module_action(l_module_name,
                                      ' Inserting USR');

    v_sec_usr_id := beowner.rand_guid();

    INSERT INTO beowner.usr(usr_id,
                            login_id,
                            make_id,
                            pwd,
                            created,
                            parent_id,
                            lang_id,
                            create_type,
                            lvl,
                            parentlvl)
    VALUES (v_sec_usr_id,
            vemail,
            v_make_id,
            utl.get_random_password(), --SBM-280: provide a default password for secondary users
            CURRENT_TIMESTAMP,
            v_pri_usr_id,
            utl.get_constant_value('clangenus'),
            'I',
            '1',
            '0'); -- modified for language changes, checked in for OnTime 5979 (DB Id 121)
    INSERT INTO beowner.usr_email(usr_id, email_type_id, email)
    VALUES (v_sec_usr_id, 'H1', vemail);


    OPEN recordset_o FOR
        SELECT utl.get_constant_value('csuccess');

EXCEPTION

    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cinvalidparams');

    WHEN SQLSTATE 'EPTNR' THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cdbpartneridnotvalid');

    WHEN SQLSTATE 'EUSRN' THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cnosuchuser');

    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cinternalerror');

END;
$body$ LANGUAGE PLPGSQL
    SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_invite_2nd_subscriber_sp (partnerid_i text, primary_subscriber_email_i text, secondary_subscriber_email_i text, relationship_type_i text, recordset_o OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
