SET bedb.filename = 'function.be_update_userdata_sp.sql';

\i set_be_env.sql;

/*  Title:	  BE_UPDATE_USERDATA_SP
    Version:	  4.0
    Date:	  August 5, 2010
    Author:	  Jeff H
    Description:  This stored procedure was created for the August 16, 2010
		  milestone.  The purpose is to update subscriber data in the
		  subscribers table based upon the email_address1
		  and the password.

    Input parameters:
      userLoginId     - subscriber email address
      userPassword    - subscriber password
      primaryphonecc  - Country Code - 3 char
      primaryphoneac  - Area Code - 3 char
      primaryphonenum - Main phone number - 7 char
      primaryphoneext - Phone extention - 5 char
      firstname       - First name - 128 char
      lastname	      - Last name - 128 char
      partnerid_i     - partner id - 50 char

    Output parameters:
      status_code_0	 - Output variable - 400 char
      success -  status_code of '0' - if there is a success in updating the
		 subscriber record.
      failure - '1' if there are any failures.
      failure - '4' - invalid parameter(s)
      failure - '2' - user does not exist
      failure - '7' - userid not on file

    Revision History:

    DATE      AUTHOR	DESCRIPTION

    09/09/10  Jeff H	Change the name and also added the rest of the fields
			for updating the user data in the subscribers table.

    09/29/10  Bob B	Resolved defect #3556 (u pper case email comparison)
    11/26/10  Bob B	General cleanup and call new tg_validate_user_sp
    01/17/11  Bob B	add partner_uid per task #3796
    04/12/11  Bob B	Normalize per work item #4507
    04/18/11  Bob B	DB Changes in work items 4580, 4509, 4510, 4511
    06/03/11  djb	rework for new schema
*/
DROP FUNCTION IF EXISTS beowner.be_update_userdata_sp(text, text, text, text, text, text, text, text, text, text, text, text,
    text, text, text);
CREATE OR REPLACE FUNCTION beowner.be_update_userdata_sp(userloginid_i text,
                                                          userpassword_i text,
                                                          primaryphonecc_i text,
                                                          primaryphoneac_i text,
                                                          primaryphonenum_i text,
                                                          primaryphoneext_i text,
                                                          firstname_i text,
                                                          lastname_i text,
                                                          street_address1_i text,
                                                          street_address2_i text,
                                                          city_i text,
                                                          state_i text,
                                                          postal_code_i text,
                                                          country_i text,
                                                          partnerid_i text,
                                                          OUT status_code_o refcursor) AS
$BODY$
DECLARE
    l_action                text;
    l_module_name           text := 'be_update_userdata_sp';
    vUsrID                  beowner.usr.usr_id%type;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN

    l_action := utl.set_module_action(l_module_name, ' Setting Context');

    CALL ctx.set(iptnrid => partnerid_i::uuid,
                 iloginid => userloginid_i);

    SELECT usr_id
    INTO STRICT vUsrID
    FROM beowner.ctx_data;

    l_action := utl.set_module_action(l_module_name, ' Merging into USR_DEMOG');

    INSERT INTO beowner.usr_demog (usr_id, name_first, name_last,
                                   addr1, addr2, city, state,
                                   postal_code, country)
    VALUES (vUsrID, firstname_i, lastname_i,
            street_address1_i, street_address2_i, city_i, state_i,
            postal_code_i, country_i)
    ON CONFLICT ON CONSTRAINT pk_usrdemog DO UPDATE SET name_first  = firstname_i,
                                                        name_last   = lastname_i,
                                                        addr1       = street_address1_i,
                                                        addr2       = street_address2_i,
                                                        city        = city_i,
                                                        state       = state_i,
                                                        postal_code = postal_code_i,
                                                        country     = country_i;


    l_action := utl.set_module_action(l_module_name, ' Merging into USR_PHONE');

    IF coalesce(trim(BOTH primaryphonenum_i), '')  != '' AND
       coalesce(trim(BOTH primaryphoneac_i), '') != '' THEN

        INSERT INTO beowner.usr_phone (usr_id, phone_type_id, cc, ac, phone, ext)
        VALUES (vUsrID, 'H1', TRIM(BOTH primaryphonecc_i), TRIM(BOTH primaryphoneac_i), TRIM(BOTH primaryphonenum_i),
                TRIM(BOTH primaryphoneext_i))
        ON CONFLICT ON CONSTRAINT pk_usr_phone
            DO UPDATE SET cc    = TRIM(BOTH primaryphonecc_i),
                          ac    = TRIM(BOTH primaryphoneac_i),
                          phone = TRIM(BOTH primaryphonenum_i),
                          ext   = TRIM(BOTH primaryphoneext_i);

    ELSE
        DELETE
        FROM beowner.usr_phone
        WHERE usr_id = vUsrID
          AND phone_type_id = 'H1';
    END IF;

    OPEN status_code_o FOR
        SELECT utl.get_constant_value('csuccess');

EXCEPTION

    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
    OPEN status_code_o FOR
      SELECT utl.get_constant_value('cinvalidparams');

  WHEN SQLSTATE 'EPTNR' THEN
    OPEN status_code_o FOR
      SELECT utl.get_constant_value('cdbpartneridnotvalid');

  WHEN SQLSTATE 'EUSRN'  THEN
    OPEN status_code_o FOR
      SELECT utl.get_constant_value('cnosuchuser');

  WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;


          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
    OPEN status_code_o FOR
      SELECT utl.get_constant_value('cinternalerror');

END;
$BODY$ LANGUAGE PLPGSQL
    SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_update_userdata_sp ( userloginid_i text, userpassword_i text, primaryphonecc_i text, primaryphoneac_i text, primaryphonenum_i text, primaryphoneext_i text, firstname_i text, lastname_i text, street_address1_i text, street_address2_i text, city_i text, state_i text, postal_code_i text, country_i text, partnerid_i text, status_code_o out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
