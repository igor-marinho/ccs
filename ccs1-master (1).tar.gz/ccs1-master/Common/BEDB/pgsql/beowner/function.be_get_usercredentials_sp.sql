SET bedb.filename = 'function.be_get_usercredentials_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.be_get_usercredentials_sp(text, text, text, text); -- old proc
DROP FUNCTION IF EXISTS beowner.be_get_usercredentials_sp(text, text, text);
CREATE OR REPLACE FUNCTION beowner.be_get_usercredentials_sp(IN userloginid_i text,
                                                             IN serviceid_i text,
                                                             IN partnerid_i text,
                                                             OUT recordset_o refcursor)
AS
$BODY$
/*  Title:	  BE_GET_USERCREDENTIALS_SP
    Version:	  4.0
    Date:	  August 5, 2010
    Author:	  Jeff H
    Description:  This stored procedure was created for the August 16, 2010
		  milestone.
		  The purpose is to get the subscriber credentials from the
		  credentials table, based upon the validation of the
		  email_address1 and the password that are passed into the
		  procedure.  There is also the matching of the
		  sub_subscriber_id in the subscribers table to the
		  sc_subscriber_id in the subscribers_credentials table and the
		  matching of the sc_credentials_id in the
		  subscribers_credentials table to the cre_credentials_id in
		  the credentials table.

    Input parameters:
      userLoginId   - subscriber email address
      userPassword  - subscriber password
      serviceId     - api_number for the service
      partnerid_i   - partner id

    Output parameters:
      recordset_o - sys_refcursor.  Returns all the information in the select
		    statement.	If there are exceptions the status code is
		    placed in the output.
      Success -  status_code of '0',
      failure - '1' - if there is an unexpected error.
      failure - '4' - invalid parameter(s)
      failure - '2' - user does not exist
      failure - '7' - userid not on file

    NOTE:  This routine will need to be modified to include better exception
	   handling that is data driven and use of different variables if deemed
	   necessary.  There will need to be more logic added to this procedure
	   to validate the different fields in the different tables to ensure
	   the returned information is valid.  There will also need to be logic
	   added for the return status codes so they can be data driven.

    NOTE:  This routine renamed to indicate primary use by TE and BE.

    Revision History:

    DATE      AUTHOR	DESCRIPTION

    09/03/10  Jeff H	Added checks for status and delete flag in the
			subscribers table and status in the credentails table.
			Also changed the output to a refcursor.  Also added code
			to either pass back one or more records based upon the
			input value.  If serviceid is null.

    09/27/10  Bob B	Changed exception to pass back code 18 if no data found.

    09/29/10  Bob B	Resolved defect #3556 (u pper case email comparison)
			Resolved defect #3350 (code 18 if no credential found).
    10/25/10  Bob B	Resolved defect #3902 (must raise no_data_found)
    10/27/10  Bob B	Resolved defect #3983 (return code 2 if subscriber
					       not valid)
    11/26/10  Bob B	General cleanup and call new tg_validate_user_sp
    12/28/10  Jeff	Change the email-address and password to userloginid
			and userpassword
    01/17/11  Bob B	add partner_uid per task #3797
    04/12/11  Bob B	Normalize per work item #4507
    04/18/11  Bob B	DB Changes in work items 4580, 4509, 4510, 4511
    06/02/11  djb	rework for new schema
    02/25/14  NSaluja	Fix for defect #20020
*/
DECLARE
    l_action                text;
    l_module_name           text            := 'be_get_usercredentials_sp';
    v_cnt                   bigint;
    v_svc_id                text;
    v_const                 char varying(1) := '+';
    o_result_set            refcursor;
    pwd                     beowner.usr_inf.val%type;
    token                   beowner.usr_inf.val%type;
    loginid                 beowner.usr_inf.val%type;
    svcid                   beowner.usr_inf.svc_id%type;
    l_provider              beowner.usr_inf.provider%type;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN

    l_action := utl.set_module_action(l_module_name, ' Setting Context');


    CALL ctx.set(iPtnrID => partnerid_i::uuid,
                 iLoginID => userloginid_i);

    v_svc_id := CASE
                    WHEN coalesce(trim(BOTH serviceid_i), '') = '' THEN
                        NULL
                    ELSE
                        trim(BOTH serviceid_i)
                    END;

    l_action := utl.set_module_action(l_module_name, ' Checking for existing credentials');


    SELECT count(*)
    INTO STRICT v_cnt
    FROM beowner.creds
    WHERE CASE
              WHEN v_svc_id IS NULL
                  THEN v_const
              ELSE svc_id
              END = CASE
                        WHEN v_svc_id IS NULL
                            THEN v_const
                        ELSE v_svc_id
              END;

    IF v_cnt = 0
    THEN
        l_action := utl.set_module_action(l_module_name, ' Returning no credentials');
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cusersnocredentials');

        RETURN;
    END IF;


    l_action := utl.set_module_action(l_module_name, ' Returing credentials');


    -- WI-7098 - Dashboard Item 204 implement encrypted 3rd party credentials
    -- Defect 13552 the User Portal passes in a null service ID when it wants all the credentials for all of the users services
    -- passed back.  So the null is exchanged for a plus sign below to indicate that the request as the result is passed back in
    -- a refcursor with the status as the first column.

    IF v_svc_id IS NOT NULL THEN
        SELECT o_status_code, oresultset
        INTO v_cnt, o_result_set
        FROM be_linked_credentials.be_get_linked_credentials_sp(iuserloginid := userloginid_i,
                                                                ipartnerid := partnerid_i,
                                                                iserviceid := serviceid_i);

        -- OnTime #20020 - added provider
        IF v_cnt = 0
        THEN

            FETCH o_result_set INTO svcid,loginid,pwd,token,l_provider;
            CLOSE o_result_set;

            OPEN recordset_o FOR
                SELECT '0', svcid, loginid, pwd, token, l_provider;

        ELSE

            OPEN recordset_o FOR SELECT v_cnt ;

        END IF;

    ELSE

        SELECT o_status_code, oresultset
        INTO v_cnt, o_result_set
        FROM be_linked_credentials.be_get_linked_credentials_sp(iuserloginid := userloginid_i,
                                                                ipartnerid := partnerid_i,
                                                                iserviceid := '+');

        IF v_cnt = 0
        THEN

            recordset_o := o_result_set;

        ELSE
            OPEN recordset_o FOR SELECT v_cnt ;
        END IF;

    END IF;

EXCEPTION

  WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation  THEN
    OPEN recordset_o FOR
      SELECT utl.get_constant_value('cinvalidparams');

  WHEN SQLSTATE 'EPTNR'  THEN
    OPEN recordset_o FOR
      SELECT utl.get_constant_value('cdbpartneridnotvalid');

  WHEN SQLSTATE 'EUSRN'  THEN
    OPEN recordset_o FOR
      SELECT utl.get_constant_value('cnosuchuser');

  WHEN OTHERS THEN
     GET STACKED DIAGNOSTICS
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

     CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
                    
    OPEN recordset_o FOR
      SELECT utl.get_constant_value('cinternalerror');

END;
$BODY$ LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION be_get_usercredentials_sp ( userloginid_i text,  service_serviceid_i text, partnerid_i text, recordset_o out sys_refcursor ) FROM PUBLIC;

\i cleanup.sql;
