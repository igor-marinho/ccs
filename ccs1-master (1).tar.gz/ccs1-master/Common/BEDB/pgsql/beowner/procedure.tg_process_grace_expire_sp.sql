SET bedb.filename = 'procedure.tg_process_grace_expire_sp.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS beowner.tg_process_grace_expire_sp ();

CREATE OR REPLACE PROCEDURE beowner.tg_process_grace_expire_sp () AS $body$
DECLARE

   /*
     Version:	   release SM14
     Date:	   July 7, 2011
     Author:	   djb
     Description:  Get all expiring "grace" accounts and send them an email.

		   This is intended to be run at (or just after) midnight every day,
		   which is why there are no input or output parameters.

     Input parameters: none

     Output parameters: none
       the completion of this procedure records a record in the "trc" table.

     Revision History:
     DATE	 AUTHOR    DESCRIPTION
     07/07/2011  djb	   initial revision
     02/04/2013  nsaluja   Modified to set context and email subject correctly within the loop for defects :
			   #16915 : DB - Entune graceExpire email is sent to Enform account.
			   #16917 : DB - Toyota graceExpired email is not sent from database.
   */
   
   l_action          text;
   l_module_name     text := 'tg_process_grace_expire_sp';   
   vcounter	         INTEGER := 0;
   l_subject	     beowner.email_info.subject%TYPE;	     -- Modified for WI #15530
   l_template_name   beowner.email_info.template_name%TYPE;	-- Added for WI #15530
   c                 RECORD;
   l_exception_diagnostics trc.exception_diagnostics;

BEGIN
										 
   l_action := utl.set_module_action( l_module_name, 'Processing Grace Expired');
										 
   FOR c
      IN (WITH tm
	       AS (  SELECT CURRENT_TIMESTAMP curtime		
		   ORDER BY 1),
	       q1
	       AS (SELECT coalesce(e.email, u.login_id) emailaddr,
			  d.name_first || ' ' || d.name_last thename,
			  -- sub-start + (grace length - 1 day)
			  DATE(
			       s.sub_start
			     + (  CAST(b.grace_length as INTERVAL)
				+ CAST('-1 0:0:0' as INTERVAL)))
			     enddate,
			  date_trunc('day', tm.curtime) curtime,
			  v.vin,
			  v.make_id,
			  u.usr_id,
			  s.subscription_id,
			  v.device_id
		     FROM tm
			 JOIN beowner.usr u
			    ON NULL IS NULL
			 JOIN beowner.subscription s
			    ON s.primary_id = u.usr_id
			 JOIN beowner.bndl b
			    ON b.bndl_id = s.bndl_id
			 JOIN beowner.vin v
			    ON v.vin = s.vin
			 LEFT JOIN beowner.usr_email e
			    ON e.usr_id = u.usr_id AND e.email_type_id = 'H1'
			 LEFT JOIN beowner.usr_demog d
			    ON d.usr_id = u.usr_id
		    WHERE v.dofu IS NULL)
	  SELECT emailaddr,
		 XMLELEMENT(name "entry",
			     XMLELEMENT(name "key", 'subscriberName'),
			     XMLELEMENT(name "value", thename))
		    keyvalues,
		 vin,
		 make_id,
		 usr_id,
		 subscription_id,
		 device_id
	    FROM q1
	    WHERE enddate = curtime
	   )
   LOOP
      -- modified for WI #15530
      CALL utl.get_email_info(i_make_id         => c.make_id, 
	                          i_email_name      => 'GRACE_EXPIRE', 
							  i_device_id       => c.device_id, 
							  i_vin             => c.vin, 
							  i_subscription_id => c.subscription_id,
							  o_subject         => l_subject,
							  o_template_name   => l_template_name);  
									   
      IF l_subject IS NOT NULL
      THEN		   -- don't send any email if make other than TM or LX
	 ---
	 PERFORM ctx.SET(iusrid => c.usr_id::text, 
	                 imakeid => c.make_id, 
				     ivin => c.vin);
	 
	--email.send to be converted to PG
	
	 PERFORM email.send(ito	 => c.emailaddr,
		                isubject	 => l_subject,
		                itemplatename => l_template_name,
		                ikeyvalues  => c.keyvalues); 
						
	 vcounter := vcounter + 1;
      END IF;
   END LOOP;
										 
   l_action := utl.set_module_action( l_module_name, 'Finished Processing Grace Expired');
   
   l_exception_diagnostics.module_name := l_module_name;
   l_exception_diagnostics.action := l_action;
   
   CALL trc.LOG(
	 'Successfully Processed Grace Expire: number of email''s sent: '
      || vcounter);
	
   
EXCEPTION
   WHEN OTHERS
   THEN
      GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
         
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

         CALL trc.LOG(iadditionaldata =>'Error processing Grace Expire: count=' || vcounter,
                        iexception_diagnostics => l_exception_diagnostics);
END;
$body$
LANGUAGE PLPGSQL
security definer 
;
-- REVOKE ALL ON PROCEDURE tg_process_grace_expire_sp () FROM PUBLIC;

\i cleanup.sql;
