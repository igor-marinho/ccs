SET bedb.filename = 'trigger.tr_hist_ptnr.sql';

\i set_be_env.sql;

DROP FUNCTION IF exists trigger_fct_tr_hist_ptnr CASCADE;

CREATE OR REPLACE FUNCTION beowner.trigger_fct_tr_hist_ptnr() RETURNS trigger AS $BODY$
DECLARE
   l_act      varchar(1);
   l_hist_row beowner.ptnr%ROWTYPE;
BEGIN
   l_act := CASE
              WHEN TG_OP = 'INSERT' THEN
               'I'
              WHEN TG_OP = 'UPDATE' THEN
               'U'
              WHEN TG_OP = 'DELETE' THEN
               'D'
           END;

   IF TG_OP = 'DELETE'
   THEN
      l_hist_row.ptnr_id := OLD.ptnr_id;
      l_hist_row.make_id := OLD.make_id;
      l_hist_row.hu_mfr_id := OLD.hu_mfr_id;

   ELSE
      l_hist_row.ptnr_id := NEW.ptnr_id;
      l_hist_row.make_id := NEW.make_id;
      l_hist_row.hu_mfr_id := NEW.hu_mfr_id;

   END IF;

   INSERT INTO beowner.hist_ptnr
      (act, hist_ptnr_guid, milestone, ptnr_id, make_id, hu_mfr_id)
   VALUES
      (l_act,
       beowner.rand_guid(),
       utl.get_milestone(),
       l_hist_row.ptnr_id,
       l_hist_row.make_id,
       l_hist_row.hu_mfr_id);

IF TG_OP = 'DELETE' THEN
  RETURN OLD;
ELSE
  RETURN NEW;
END IF;

END
$BODY$
 LANGUAGE 'plpgsql';

CREATE TRIGGER tr_hist_ptnr
  AFTER INSERT OR UPDATE OR DELETE ON beowner.ptnr FOR EACH ROW
  EXECUTE PROCEDURE beowner.trigger_fct_tr_hist_ptnr();

\i cleanup.sql;
