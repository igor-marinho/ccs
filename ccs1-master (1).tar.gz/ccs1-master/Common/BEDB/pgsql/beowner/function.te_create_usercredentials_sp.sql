SET bedb.filename = 'function.te_create_usercredentials_sp.sql';

\i set_be_env.sql;

/*  Title:	  TE_CREATE_USERCREDENTIALS_SP
    Version:	  4.1
    Date:	  August 5, 2010
    Author:	  Jeff H
    Description:  This stored procedure was created for the August 16, 2010
		  milestone.  The purpose is to create a new record in the
		  credentials and subscribers_Credentials tables to reflect the
		  information passed to this procedure from the calling
		  application.	There is first a validation of the email_address
		  and the password in the subscribers table.  Then a record is
		  created in the credentials table, next a record is created in
		  the subscribers_credentials table to create the relationship.

    Input parameters:
      userLoginId	- subscriber email address
      userPassword	- subscriber password
      service_loginid	- user id for the given service
      service_password	- password for the given service
      token		- token for the given service if necessary
      service_api_number- This is the api number of the service.  The API number
			  is data driven and will be from the services table in
			  the future.
      partnerid_i	- partner id

    Output parameters:
      status_code_0	- Output variable
      success -  status_code of '0' if there is success in creating the new
		 records in the credentials and subscribers_credentials tables.
      failure - '1' if there is failure in the routine.
      failure - '4' - invalid parameter(s)
      failure - '2' - user does not exist
      failure - '7' - userid not on file

    Revision History:

    DATE      AUTHOR	DESCRIPTION

    08/31/2010	Jeff H	  Change to add the update of the credentials information
			  as long as the subscriber information is validated.

    08/31/2010	Jeff H	  Added check for status and delete flag in the
			  subscribers table adn status for credentials table.

    09/10/2010	Bob B	  Change output paramater to sys_recursor

    09/29/2010	Bob B	  Resolved defect #3556 (u pper case email comparison)
    11/26/2010	Bob B	  General cleanup and call new tg_validate_user_sp
    01/17/2011	Bob B	  add partner_uid per task #3797
    03/17/2011	Bob B	  Work Item #4362 expanded ACL status codes
    04/12/2011	Bob B	  Normalize per work item #4507
    04/18/2011	Bob B	  DB Changes in work items 4580, 4509, 4510, 4511
    04/26/2011	Bob B	  Validate service id for this user defect 6733
    04/29/2011	Bob B	  Allow secondary user to create credential if
			  primary user has access to service - defect 7848
    05/01/2011	Bob B	  Defect #7859 and 7849 deal with primary and secondary
			  subscribers differently
    05/04/2011	Bob B	  Defect 7968 set switch to toggle on/off
    05/12/2011	Bob B	  Work Item 4846 - secondary acl rework
    06/01/2011	djb	  This is identical to BE_CREATE_USERCREDENTIALS, so just call it...
*/
DROP FUNCTION IF EXISTS beowner.te_create_usercredentials_sp(text, text, text, text, text, text, text);
CREATE OR REPLACE FUNCTION beowner.te_create_usercredentials_sp(userloginid_i text,
                                                                 userpassword_i text,
                                                                 service_loginid_i text,
                                                                 service_password_i text,
                                                                 token_i text,
                                                                 serviceid_i text,
                                                                 partnerid_i text,
                                                                 status_code_o OUT refcursor) AS
$BODY$
DECLARE

BEGIN

    status_code_o := beowner.be_create_usercredentials_sp(userloginid_i => userloginid_i,
                                      userpassword_i => userpassword_i,
                                      service_loginid_i => service_loginid_i,
                                      service_password_i => service_password_i,
                                      token_i => token_i,
                                      serviceid_i => serviceid_i,
                                      partnerid_i => partnerid_i);

END;
$BODY$
    LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE te_create_usercredentials_sp ( userloginid_i text, userpassword_i text, service_loginid_i text, service_password_i text, token_i text, serviceid_i text, partnerid_i text, status_code_o out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
