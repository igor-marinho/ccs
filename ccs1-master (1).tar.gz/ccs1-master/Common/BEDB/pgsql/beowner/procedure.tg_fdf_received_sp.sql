SET bedb.filename = 'procedure.tg_fdf_received_sp.sql';

\i set_be_env.sql;

CREATE OR REPLACE PROCEDURE tg_fdf_received_sp ( filename_i text, job_log_guid_i text, recordset_o out REFCURSOR ) AS $body$
DECLARE

  rslt varchar(5);

BEGIN
  rslt := fdf.received(filename_i, job_log_guid_i);
  PERFORM utl.doCommit();
  open recordset_o for
    SELECT rslt;
end;
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE tg_fdf_received_sp ( filename_i text, job_log_guid_i text, recordset_o out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
