SET bedb.filename = 'trigger.tr_subscription_event_log.sql';

\i set_be_env.sql;

drop FUNCTION if exists beowner.trigger_fct_tr_subscription_event_log cascade;

CREATE OR REPLACE FUNCTION beowner.trigger_fct_tr_subscription_event_log() RETURNS trigger AS $BODY$
DECLARE
   -- DDCRD-407 moved constants to const package, for re-use elsewhere
   l_vin             vin.vin%TYPE := coalesce(new.vin, old.vin);
   l_usr_id          usr.usr_id%TYPE := coalesce(new.primary_id, old.primary_id);
   l_subscription_id subscription.subscription_id%TYPE;
   l_status          event_log.status%TYPE;
   l_old_status      event_log.old_status%TYPE;
   l_log_status      text;
   l_grace_status    event_log.status%TYPE;
   l_exception_diagnostics trc.EXCEPTION_DIAGNOSTICS;

BEGIN

  SELECT case
           when v.dofu is null
           then utl.get_constant_value('c_new_grace_subs_status')
           else utl.get_constant_value('c_new_active_subs_status')
         end as grace_status
    INTO strict l_grace_status
    FROM vin v
   WHERE v.vin = l_vin;

   IF TG_OP = 'INSERT'
   THEN
      l_status := l_grace_status;
   ELSIF TG_OP = 'DELETE'
   THEN
      l_status := utl.get_constant_value('c_cancelled_subs_status');
      l_old_status := l_grace_status;
   END IF;

   call beowner.tg_update_event_log_sp(itype       => utl.get_constant_value('c_event_log_type_subscription'),
                                       iusrid      => l_usr_id,
                                       ivin        => l_vin, -- DDCRD-542
                                       istatus     => l_status,
                                       iold_status => l_old_status,
                                       ostatusrslt => l_log_status);

   IF l_log_status != utl.get_constant_value('csuccess')
   THEN
      call trc.log(iadditionaldata => 'Unable to log status ' || l_status || ' for subscription ' || l_subscription_id);
   END IF;

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;

EXCEPTION
   WHEN others
   then
    GET STACKED diagnostics
      l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
      l_exception_diagnostics.column_name := COLUMN_NAME,
      l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
      l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
      l_exception_diagnostics.message_text := MESSAGE_TEXT,
      l_exception_diagnostics.table_name := TABLE_NAME,
      l_exception_diagnostics.schema_name := SCHEMA_NAME,
      l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
      l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
      l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

      CALL trc.log(iadditionaldata => 'Error in ' || current_setting('application_name') || ' for subscription ' || l_subscription_id,
                   iexception_diagnostics => l_exception_diagnostics);
END
$BODY$
 LANGUAGE 'plpgsql';

CREATE TRIGGER tr_subscription_event_log
  AFTER INSERT OR DELETE ON beowner.subscription
  FOR EACH ROW
  EXECUTE PROCEDURE beowner.trigger_fct_tr_subscription_event_log();

\i cleanup.sql;
