SET bedb.filename = 'function.be_activate_subscriber_sp.sql';

\i set_be_env.sql;
/*
Description:  This procedure was created to change the user status
              from pending to active if the user is valid.

Input parameters:
  partnerid_i     - partner id
  userLoginId_i   - subscriber email address

Output parameters:
  status_code_o   - status code

  success       - status_code of '0' if there is success in validating
                  the subscriber.
  failure       - '2' if no record found,
                  '4' if value error (usually bad parameters),
                  '7' user id not on file
                  '1' if general failure in the routine,
                  '216' if already activated, and
                  '217' if unable to be activated.
*/
DROP FUNCTION IF EXISTS beowner.be_activate_subscriber_sp(text, text);
CREATE OR REPLACE FUNCTION beowner.be_activate_subscriber_sp(IN partnerid_i text,
                                                             IN userloginid_i text,
                                                             OUT recordset_o refcursor)
AS
$BODY$
DECLARE
    l_action      text;
    l_module_name text := 'be_activate_subscriber_sp';
    vrslt         character varying(10);
    vvin          character varying(17);
    v_updated_rowcount  integer;
    sub RECORD;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    
    l_action := utl.set_module_action( l_module_name,
                                          ' Setting Context');
    
    CALL ctx.set(iptnrid := partnerid_i::uuid, iloginid := userloginid_i);
   
    l_action := utl.set_module_action( l_module_name,
                                          ' Activating User');

   
    UPDATE beowner.usr
       SET verified = clock_timestamp()
     WHERE usr_id = (SELECT usr_id
                       FROM beowner.ctx_data)
       AND verified IS NULL;
      
    /* Moved up for #15354 since the rowcount applies to the update */
    GET DIAGNOSTICS v_updated_rowcount = ROW_COUNT;

    IF v_updated_rowcount = 0
    THEN
        vrslt := utl.get_constant_value('cdbsubscriberalreadyactivated');
    ELSE
        vrslt := utl.get_constant_value('csuccess');
    END IF;
   
    /* Jira DCS1NOTES-50: It looks like this code is no longer used, evaluate */
    /* later if it is actually dead code. */
    SELECT vin
      INTO STRICT vvin
      FROM beowner.ctx_data;

    IF vvin IS NOT NULL
    THEN
        l_action := utl.set_module_action(l_module_name,
                                               ' Checking if conflict exists for this vin ' || vvin);

    
        CALL utl.checkvinconflict(vvin);
    END IF;

    /* Jira DCS1NOTES-50 */

    FOR sub IN (SELECT s.vin, cd.usr_id
                FROM beowner.ctx_data cd
                         JOIN beowner.subscription s
                              ON (s.primary_id = cd.usr_id))
        LOOP
            CALL oem_notifications_mgt.setup_subs_notification(I_VIN => sub.vin, I_USR_ID => sub.usr_id);
        END LOOP;
   
    OPEN recordset_o FOR
    SELECT vrslt;
   
EXCEPTION
   WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
      OPEN recordset_o FOR
         SELECT utl.get_constant_value('cinvalidparams');

   WHEN SQLSTATE 'EPTNR' THEN
      OPEN recordset_o FOR
         SELECT utl.get_constant_value('cdbpartneridnotvalid');

   WHEN SQLSTATE 'EUSRN' THEN
      OPEN recordset_o FOR
         SELECT utl.get_constant_value('cnosuchuser');
        
   WHEN OTHERS THEN
           GET STACKED DIAGNOSTICS
             l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
             l_exception_diagnostics.column_name := COLUMN_NAME,
             l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
             l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
             l_exception_diagnostics.message_text := MESSAGE_TEXT,
             l_exception_diagnostics.table_name := TABLE_NAME,
             l_exception_diagnostics.schema_name := SCHEMA_NAME,
             l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
             l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
             l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

             l_exception_diagnostics.module_name := l_module_name;
             l_exception_diagnostics.action := l_action;

            --Referenced trc.log instead of trc.log_params for DCS1E-420
			CALL trc.log(iadditionaldata => 'partnerid_i : ' || partnerid_i || ',' || 'userloginid_i : ' ||
              userloginid_i, iexception_diagnostics => l_exception_diagnostics);                        
                       
           OPEN recordset_o FOR
            SELECT utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER ;

\i cleanup.sql;
