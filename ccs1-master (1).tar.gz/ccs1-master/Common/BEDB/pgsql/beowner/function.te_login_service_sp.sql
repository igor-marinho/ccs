SET bedb.filename = 'function.te_login_service_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.te_login_service_sp(TEXT,TEXT,TEXT,TEXT);

CREATE OR REPLACE FUNCTION beowner.te_login_service_sp (userloginid_i        text
                                                       ,userpassword_i       text
                                                       ,serviceid_i          text
                                                       ,partnerid_i          text                                                      
                                                       ,recordset_o      OUT refcursor) 
AS
$BODY$
/*
Proc to call either the existing flow or the OneApp flow depending on the partner id passed.
*/
DECLARE
    l_action text;
    l_module_name text := 'te_login_service_sp';
    l_partnerid text := trim(both(partnerid_i));
    l_status integer;
    vrslt refcursor;
    l_exception_diagnostics trc.exception_diagnostics;
   
BEGIN

IF l_partnerid::uuid = utl.getconfig('Oneapp PTNR ID')::uuid THEN
	
    l_action := utl.set_module_action( l_module_name, 'Starting OneApp Login');

    /* call oneapp login flow */

    l_status := beowner.te_oneapp_login_service_sp (uid_i           => userloginid_i                                                             
                                                   ,serviceid_i     => serviceid_i
                                                   ,partnerid_i     => l_partnerid                                                              
                                                   );
    OPEN recordset_o FOR SELECT l_status;
        
    /* reject legacy login after end date*/	
   
ELSIF CURRENT_DATE <= to_date(utl.getconfig('Legacy Login End Date'),'YYYY-MM-DD') THEN
	
    /* call legacy login flow */ 
	
    l_action := utl.set_module_action( l_module_name, 'Starting Legacy Login');

    vrslt := beowner.te_legacy_login_service_sp (userloginid_i  => userloginid_i
                                                ,userpassword_i => userpassword_i
                                                ,serviceid_i    => serviceid_i    
                                                ,partnerid_i    => l_partnerid      
                                                );
    FETCH NEXT FROM vrslt INTO l_status;
   
    OPEN recordset_o FOR SELECT l_status;
	
ELSE	

    OPEN recordset_o FOR SELECT utl.get_constant_value('cfailedauthpwd');
	
END IF;

EXCEPTION

WHEN OTHERS THEN     
                GET STACKED diagnostics
                  l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
                  l_exception_diagnostics.column_name := COLUMN_NAME,
                  l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
                  l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
                  l_exception_diagnostics.message_text := MESSAGE_TEXT,
                  l_exception_diagnostics.table_name := TABLE_NAME,
                  l_exception_diagnostics.schema_name := SCHEMA_NAME,              
                  l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
                  l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
                  l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
                  l_exception_diagnostics.module_name := l_module_name;
                  l_exception_diagnostics.action := l_action;
                  
                  CALL trc.log(iadditionaldata => NULL,
                                iexception_diagnostics => l_exception_diagnostics);                
                               
                  OPEN recordset_o FOR
                  SELECT utl.get_constant_value('cinternalerror');
   
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION beowner.te_login_service_sp TO beuser;
GRANT EXECUTE ON FUNCTION beowner.te_login_service_sp TO teuser;

\i cleanup.sql;