SET bedb.filename = 'procedure.handle_internal_error.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS  beowner.handle_internal_error(TEXT, TEXT, trc.exception_diagnostics);
DROP PROCEDURE IF EXISTS  beowner.handle_internal_error(TEXT, TEXT, trc.exception_diagnostics);

CREATE OR REPLACE PROCEDURE beowner.handle_internal_error(IN userloginid_i TEXT, IN partnerid_i TEXT, in exception_diagnostics_i trc.exception_diagnostics)
AS
$BODY$
/* beowner/te_get_acl_sp */
/* Added config for REL-154 */
declare  
  l_ctx_rec record;
BEGIN
    IF COALESCE(utl.getconfig('LOG ACL NO_DATA_FOUND ERRORS'), 'N') = 'Y'
    THEN
        SELECT *
          INTO STRICT l_ctx_rec
          FROM beowner.ctx_data;
        CALL trc.log(CONCAT_WS('', 'Partner=', partnerid_i, ',CTX values : User=', l_ctx_rec.usr_id, ',VIN=', l_ctx_rec.vin, ',Make=', l_ctx_rec.make_id, ',Timestamp=', TO_CHAR(l_ctx_rec.tmstmp, 'mm/dd/yyyy hh24:mi:ss.us tz')),
                        iexception_diagnostics => exception_diagnostics_i);

    END IF;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
