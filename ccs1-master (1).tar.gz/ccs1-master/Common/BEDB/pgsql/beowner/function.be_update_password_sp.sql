SET bedb.filename = 'function.be_update_password_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS BEOWNER.BE_UPDATE_PASSWORD_SP(TEXT, TEXT, TEXT);

CREATE OR REPLACE FUNCTION beowner.be_update_password_sp(IN userloginid_i  text, 
                                                         IN newpassword_i text, 
                                                         IN partnerid_i text, 
                                                         OUT o_status_code REFCURSOR)
AS
$body$
DECLARE

/*  Title:    BE_UPDATE_PASSWORD_SP
    Version:      4.0
    Date:     August 16, 2010
    Author:   Bob Binger
    Description:  The purpose is to update the user password in the subscribers
          table based upon the email_address1, current password, and
          new password.

    Input parameters:
      userLoginId    - subscriber email address
      newPassword    - new subscriber password
      partnerid      - partner id

    Output parameters:
      status_code_0   - Output variable
      success -  status_code of '0' - If the new record is updated.
      failure - '1' - if there is a problem with updating the record.
      failure - '4' - invalid parameter(s)
      failure - '2' - user does not exist
      failure - '7' - userid not on file

    NOTE:  This routine renamed to indicate primary use by TE.

    Revision History:

    DATE      AUTHOR    DESCRIPTION

    09/10/10  Bob B Change output paramater to sys_recursor
    09/29/10  Bob B Resolved defect #3556 (u pper case email comparison)
    11/26/10  Bob B General cleanup and call new tg_validate_user_sp
    01/17/11  Bob B add partner_uid per task #3797
    03/01/11  Bob B rework per work item #4181 for new user portal
    04/12/11  Bob B Normalize per work item #4507
    04/18/11  Bob B DB Changes in work items 4580, 4509, 4510, 4511
    05/19/11  Dean B    rework for new schema
*/
      l_action text;
      l_module_name text := 'be_update_password_sp';
      l_exception_diagnostics trc.exception_diagnostics;
BEGIN

    l_action := utl.set_module_action( l_module_name, ' Setting Context');

    CALL ctx.set(iPtnrID => partnerid_i::UUID, iLoginID => userloginid_i);

    l_action := utl.set_action(' Updating password');

  update beowner.usr
     set pwd = trim(newpassword_i)
   where usr_id = (SELECT usr_id::uuid from beowner.ctx_data);

  open o_status_code for
    SELECT utl.get_constant_value('csuccess') ;

exception
  
  WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation
  then
    open o_status_code for
      SELECT utl.get_constant_value('cinvalidparams') ;

  when SQLSTATE 'EPTNR'
  then
    open o_status_code for
      SELECT utl.get_constant_value('cdbpartneridnotvalid');

  when SQLSTATE 'EUSRN'
  then
    open o_status_code for
      SELECT utl.get_constant_value('cnosuchuser');

  when SQLSTATE 'EVINN'
  then
    open o_status_code for
      SELECT utl.get_constant_value('cdbvinnotfound');

  when others then
   
    GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

    CALL trc.log(iadditionaldata => NULL,
                    iexception_diagnostics => l_exception_diagnostics);
                       
    open o_status_code for
      SELECT utl.get_constant_value('cinternalerror') ;

END;
$body$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
