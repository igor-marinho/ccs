SET bedb.filename = 'function.be_update_email_address_sp.sql';

\i set_be_env.sql;
/*
     Title:	  BE_UPDATE_EMAIL_ADDRESS_SP
     Version:	  4.0
     Date:	  10/27/ 2010
     Author:	  Michelle Lu
     Work Item #: 952
     Description: The purpose is to change subscriber's current email address to
          another one. This procedure first checks on login/password match
          in the database then modify email address in subscriber table
          and email table.

     Input parameters:
       OLD_EMAIL_I	     IN VARCHAR2 ,
       PASSWORD_I	     IN VARCHAR2 ,
       NEW_EMAIL_I	     IN VARCHAR2 ,
       partnerid_i	     IN VARCHAR2

     Output parameters:
       RECORDSET_O	     0 -- means successful
                 1 -- unexpected error
                 2 -- user login not valid
                 4 -- bad parameter values
                 16 -- invalid email
                 15 -- duplicate email

     Revision History:

     DATE      AUTHOR	 DESCRIPTION

     11-18-10  MLU	 Check if there exists the new email address in the table
             before make changes.
     12-01-10  JLH	 Add email content id with #4 which relates to the
             emails_content table.
     12/03/10  Bob B	 Cleanup
     01/17/11  Bob B	 add partner_uid per task #3795
     04/11/11  Bob B	 Normalize per work item #4507
     04/18/11  Bob B	 DB Changes in work items 4580, 4509, 4510, 4511
     06/03/11  djb	 rework for new schema
     09/19/12  NMS	 Modified for WI #8415 ([DB - 383] UP: Build revised registration process for Entune)
             - reset email to be not validated, set user to be active
   */
DROP FUNCTION IF EXISTS beowner.be_update_email_address_sp(text, text, text, text);
CREATE OR REPLACE FUNCTION beowner.be_update_email_address_sp(old_email_i text,
                                                              password_i text,
                                                              new_email_i text,
                                                              partnerid_i text,
                                                              recordset_o OUT refcursor) AS
$BODY$
DECLARE
    l_action                text;
    l_module_name           text := 'be_update_email_address_sp';
    voldemailaddr           text;
    vnewemailaddr           text;
    vusrid                  beowner.usr.usr_id%type;
    vmakeid                 beowner.make.make_id%type;
    vcount                  integer;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    l_action := utl.set_module_action(l_module_name,
                                      ' Setting Context');

    voldemailaddr := utl.normalize_email(old_email_i, 'yes');
    vnewemailaddr := utl.normalize_email(new_email_i, 'yes');

    CALL ctx.SET(iptnrid => partnerid_i::uuid, iloginid => voldemailaddr);

    SELECT usr_id, make_id
    INTO STRICT vusrid, vmakeid
    FROM beowner.ctx_data;

    l_action := utl.set_module_action(l_module_name,
                                      ' Validating New Email');

    SELECT COUNT(*)
    INTO STRICT vcount
    FROM beowner.usr
    WHERE login_id = vnewemailaddr
      AND make_id = vmakeid;

    IF vcount > 0
    THEN
        OPEN recordset_o FOR SELECT utl.get_constant_value('cuseralreadyexists');

        RETURN;
    END IF;

    l_action := utl.set_module_action(l_module_name,
                                      ' Updating New Email');

    -- this *must* exist, so update
    UPDATE beowner.usr
    SET login_id = vnewemailaddr,
        verified = CURRENT_TIMESTAMP
    WHERE usr_id = vusrid;

    -- this *may* exist, so merge
    INSERT INTO beowner.usr_email(usr_id, email_type_id, email)
    VALUES (vusrid, 'H1', vnewemailaddr)
    ON CONFLICT ON CONSTRAINT pk_usr_email
        DO UPDATE SET email = vnewemailaddr, status = 'N', status_date = NULL;

    OPEN recordset_o FOR SELECT utl.get_constant_value('csuccess');
EXCEPTION
    WHEN SQLSTATE 'EEMML' THEN
        -- we don't have an "invalid email addr" status,
        -- so just return an "invalid params" status for now
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cinvalidparams');
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cinvalidparams');

    WHEN SQLSTATE 'EPTNR' THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cdbpartneridnotvalid');

    WHEN SQLSTATE 'EUSRN' THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cnosuchuser');

    WHEN SQLSTATE 'EVINN' THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cdbvinnotfound');
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cinternalerror');
END;
$BODY$
    LANGUAGE PLPGSQL
    SECURITY DEFINER;
-- REVOKE ALL ON PROCEDURE be_update_email_address_sp ( old_email_i text, password_i text, new_email_i text, partnerid_i text, recordset_o OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
