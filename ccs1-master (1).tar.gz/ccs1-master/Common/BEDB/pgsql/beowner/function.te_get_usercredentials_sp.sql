SET bedb.filename = 'function.te_get_usercredentials_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.te_get_usercredentials_sp(text, text, text, text);--old proc
DROP FUNCTION IF EXISTS beowner.te_get_usercredentials_sp(text, text, text);
CREATE OR REPLACE FUNCTION beowner.te_get_usercredentials_sp(userloginid_i text,
                                                             serviceid_i text,
                                                             partnerid_i text,
                                                             recordset_o OUT refcursor) AS
$BODY$
/*  Title:	  TE_GET_USERCREDENTIALS_SP
    Version:	  4.0
    Date:	  August 5, 2010
    Author:	  Jeff H
    Description:  This stored procedure was created for the August 16, 2010
		  milestone.
		  The purpose is to get the subscriber credentials from the
		  credentials table, based upon the validation of the
		  email_address1 and the password that are passed into the
		  procedure.  There is also the matching of the
		  sub_subscriber_id in the subscribers table to the
		  sc_subscriber_id in the subscribers_credentials table and the
		  matching of the sc_credentials_id in the
		  subscribers_credentials table to the cre_credentials_id in
		  the credentials table.

    Input parameters:
      userLoginId   - subscriber email address
      userPassword  - subscriber password
      serviceId     - api_number for the service
      partnerid_i   - partner id

    Output parameters:
      recordset_o - sys_refcursor.  Returns all the information in the select
		    statement.	If there are exceptions the status code is
		    placed in the output.
      Success -  status_code of '0',
      failure - '1' - if there is an unexpected error.
      failure - '4' - invalid parameter(s)
      failure - '2' - user does not exist
      failure - '7' - userid not on file

    NOTE:  This routine renamed to indicate primary use by TE and BE.

    Revision History:

    DATE      AUTHOR	DESCRIPTION

    09/03/10  Jeff H	Added checks for status and delete flag in the
			subscribers table and status in the credentails table.
			Also changed the output to a refcursor.  Also added code
			to either pass back one or more records based upon the
			input value.  If serviceid is null.

    09/27/10  Bob B	Changed exception to pass back code 18 if no data found.

    09/29/10  Bob B	Resolved defect #3556 (u pper case email comparison)
			Resolved defect #3350 (code 18 if no credential found).
    10/25/10  Bob B	Resolved defect #3902 (must raise no_data_found)
    10/27/10  Bob B	Resolved defect #3983 (return code 2 if subscriber
					       not valid)
    11/26/10  Bob B	General cleanup and call new tg_validate_user_sp
    12/28/10  Jeff	Change the email-address and password to userloginid
			and userpassword
    01/17/11  Bob B	add partner_uid per task #3797
    04/12/11  Bob B	Normalize per work item #4507
    04/18/11  Bob B	DB Changes in work items 4580, 4509, 4510, 4511
    06/02/11  djb	rework for new schema
*/
DECLARE


BEGIN
    recordset_o := beowner.be_get_usercredentials_sp(userloginid_i => userloginid_i,
                                                     serviceid_i => serviceid_i,
                                                     partnerid_i => partnerid_i);
END;
$BODY$

LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE te_get_usercredentials_sp ( userloginid_i text,  service_serviceid_i text, partnerid_i text, recordset_o out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
