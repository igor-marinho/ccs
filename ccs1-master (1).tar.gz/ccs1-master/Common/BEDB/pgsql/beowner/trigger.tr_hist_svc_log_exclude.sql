SET bedb.filename = 'trigger.tr_hist_svc_log_exclude.sql';

\i set_be_env.sql;

DROP function IF exists trigger_fct_tr_hist_svc_log_exclude CASCADE;

create or replace function beowner.trigger_fct_tr_hist_svc_log_exclude() RETURNS trigger AS $BODY$
DECLARE
   l_act      VARCHAR(1);
   l_hist_row beowner.svc_log_exclude;
BEGIN
   l_act := CASE
              WHEN TG_OP = 'INSERT' THEN
               'I'
              WHEN TG_OP = 'UPDATE' THEN
               'U'
              WHEN TG_OP = 'DELETE' THEN
               'D'
           END;

   IF TG_OP = 'DELETE'
   THEN
      l_hist_row.SLE_GUID := old.SLE_GUID;
      l_hist_row.svc_id := old.svc_id;
      l_hist_row.Tel_Type := old.Tel_Type;

   ELSE
      l_hist_row.SLE_GUID := new.SLE_GUID;
      l_hist_row.svc_id := new.svc_id;
      l_hist_row.Tel_Type := new.Tel_Type;

   END IF;

   INSERT INTO beowner.hist_svc_log_exclude
      (act, hsle_guid, milestone, SLE_GUID, svc_id, Tel_Type)
   VALUES
      (l_act,
       beowner.rand_guid(),
       utl.get_milestone(),
       l_hist_row.SLE_GUID,
       l_hist_row.svc_id,
       l_hist_row.Tel_Type);

IF TG_OP = 'DELETE' THEN
  RETURN OLD;
ELSE
  RETURN NEW;
END IF;

END
$BODY$
 LANGUAGE 'plpgsql';

CREATE TRIGGER tr_hist_svc_url
  AFTER INSERT OR UPDATE OR DELETE ON beowner.svc_log_exclude FOR EACH ROW
  EXECUTE PROCEDURE beowner.trigger_fct_tr_hist_svc_log_exclude();

\i cleanup.sql;
