SET bedb.filename = 'function.be_csr_get_servicesinfo_sp.sql';

\i set_be_env.sql;
/*  Title:	  BE_CSR_GET_SERVICESINFO_SP
    Version:	  4.0
    Date:	  November 2, 2010
    Author:	  Bob B
    Description:
      The purpose is to get service data for a VIN from the subscribers
      services table based upon subscriber id.	A cursor containing the data is returned.

    Input parameters:
      userLoginId   - subscriber email address
      vin_i	    - VIN
      partnerid_i   - partner id

    Output parameters:
      recordset_0   - subscriber services data in a refcursor
      success -  status_code of '0'
      failure - '1' - if there is an unexpected error
      failure - '4' - invalid parameter(s)
      failure - '2' - user does not exist
      failure - '7' - userid not on file
      failure - '210' - no data found

    Revision History:

    DATE      AUTHOR	DESCRIPTION

    11/08/10  Bob B	Add VIN to recordset
    11/26/10  Bob B	General cleanup and call new tg_validate_user_sp
    12/03/10  Bob B	Code upper case comparisons
    01/17/11  Bob B	add partner_uid per task #3782
    03/13/11  Bob B	Deprecate partner id per work items #4362 and #4225
    03/15/11  Bob B	Add functionality per task #4390
    04/12/11  Bob B	Normalize per work item #4507
    04/18/11  Bob B	DB Changes in work items 4580, 4509, 4510, 4511
    05/13/11  Bob B	Work Item 4731 expose credentials
    06/15/11  djb	Rework for New Schema
    11/18/13  GCT	    update context to use canecorso context
    01/14/13  NMS	Removed reference to context name when merging with WI #14078, as context name isn't necessary here
*/
DROP FUNCTION IF EXISTS beowner.be_csr_get_servicesinfo_sp(text, text, text);
CREATE OR REPLACE FUNCTION beowner.be_csr_get_servicesinfo_sp(userloginid_i text,
                                                              vin_i text,
                                                              partnerid_i text,
                                                              recordset_o OUT refcursor) AS
$body$
DECLARE
    l_action                text;
    l_module_name           text := 'be_csr_get_servicesinfo_sp';
    -- WI #14078
    l_usr_id                beowner.usr.usr_id%type;
    l_vin                   beowner.vin.vin%type;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    l_action := utl.set_module_action(l_module_name, ' Setting Context');

    CALL ctx.set(iPtnrID => partnerid_i::uuid,
                 iLoginID => userloginid_i,
                 iVIN => vin_i);

    -- WI #14078
    SELECT usr_id, vin
    INTO STRICT l_usr_id, l_vin
    FROM beowner.ctx_data;

    l_action := utl.set_module_action(l_module_name, ' Returning Data');

    OPEN recordset_o FOR
        SELECT utl.get_constant_value('csuccess'),
               to_char(coalesce(dofu, sub_start, CURRENT_TIMESTAMP), 'YYYYMMDD'),
               to_char(coalesce(sub_end, CURRENT_TIMESTAMP + '1 day'), 'YYYYMMDD'),
               svc_id,
               name,
               allowed_status,
               sc_code,
               sc_message,
               vin,
               usr_id,
               CASE credentials WHEN '*' THEN '1' ELSE '0' END credentials
        FROM user_subscription.info(l_usr_id, l_vin) alias5;

EXCEPTION
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
    OPEN recordset_o FOR
      SELECT utl.get_constant_value('cinvalidparams');

  WHEN SQLSTATE 'EPTNR' THEN
    OPEN recordset_o FOR
      SELECT utl.get_constant_value('cdbpartneridnotvalid');

  WHEN SQLSTATE 'EUSRN' THEN
    OPEN recordset_o FOR
      SELECT utl.get_constant_value('cnosuchuser');

  WHEN SQLSTATE 'EVINN' THEN
    OPEN recordset_o FOR
      SELECT utl.get_constant_value('cdbvinnotfound');

  WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS
        l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
        l_exception_diagnostics.column_name := COLUMN_NAME,
        l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
        l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
        l_exception_diagnostics.message_text := MESSAGE_TEXT,
        l_exception_diagnostics.table_name := TABLE_NAME,
        l_exception_diagnostics.schema_name := SCHEMA_NAME,
        l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
        l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
        l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;

    CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
    OPEN recordset_o FOR
      SELECT utl.get_constant_value('cinternalerror');

END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_csr_get_servicesinfo_sp ( userloginid_i text, vin_i text, partnerid_i text, recordset_o out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
