SET bedb.filename = 'procedure.tg_update_event_log_sp.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS beowner.tg_update_event_log_sp(TEXT, UUID, TEXT, TEXT, TEXT, TEXT);

CREATE OR REPLACE PROCEDURE beowner.tg_update_event_log_sp (itype             TEXT
                                                           ,iusrid            UUID 
                                                           ,ivin              TEXT
                                                           ,istatus           TEXT
                                                           ,ostatusrslt INOUT TEXT 
                                                           ,iold_status       TEXT DEFAULT NULL)
AS $body$
DECLARE
      l_action TEXT;
      l_module_name text := 'tg_update_event_log_sp';
   -- The purpose is to insert or delete subscription and user account events
   -- Modified for DDCRD-402 : added old_status, config check and status codes change
    l_event_date event_log.event_date%TYPE := CURRENT_TIMESTAMP;
   -- DDCRD-402 : subtracting 1 directly from systimestamp directly returns UTC time, hence the cast
   -- included population of pkguid for DDCRD-560
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN

   /* Commented out for Jira PU-182 so that initating module is stored on history row
   PERFORM utl.set_module_action( l_module_name,    ' Update Event Log'); */
   IF utl.getconfig(icfgname => utl.get_constant_value('c_log_events_cfg')) = utl.get_constant_value('c_yes')
   THEN

   -- log only if OEMs in this DB need event logging
      IF istatus IN (utl.get_constant_value('c_new_grace_expired_status'), utl.get_constant_value('c_new_subs_expired_status')) -- New Grace Expired and Expired. Others are logged at point in time
      THEN
         l_event_date := l_event_date - INTERVAL '1' DAY;
      END IF;
      INSERT INTO beowner.event_log(pkguid, "type", usr_id, vin, status, event_date, old_status)
      VALUES (beowner.rand_guid(),
          itype,
          iusrid,
          ivin,
          istatus,
          l_event_date,
          iold_status);
   END IF;
   ostatusrslt := utl.get_constant_value('csuccess');

EXCEPTION

   WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
      ostatusrslt := utl.get_constant_value('cinvalidparams');

   WHEN SQLSTATE 'EPTNR' THEN
      ostatusrslt := utl.get_constant_value('cdbpartneridnotvalid');

   WHEN SQLSTATE 'EUSRN' THEN
      ostatusrslt := utl.get_constant_value('cnosuchuser');

   WHEN OTHERS THEN
      GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
      ostatusrslt := utl.get_constant_value('cinternalerror');

END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE tg_update_event_log_sp (itype text, iusrid bytea, ivin text, istatus text, ostatusrslt OUT text, iold_status text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
