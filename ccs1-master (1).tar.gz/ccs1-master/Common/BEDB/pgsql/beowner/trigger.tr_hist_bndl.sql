SET bedb.filename = 'trigger.tr_hist_bndl.sql';

\i set_be_env.sql;

drop FUNCTION if exists beowner.trigger_fct_tr_hist_bndl cascade;

CREATE OR REPLACE FUNCTION beowner.trigger_fct_tr_hist_bndl() RETURNS trigger AS $BODY$
DECLARE
   l_act      varchar(1);
   l_hist_row beowner.bndl;
BEGIN
  l_act := CASE
             WHEN TG_OP = 'INSERT' THEN
               'I'
             WHEN TG_OP = 'UPDATE' THEN
              'U'
             WHEN TG_OP = 'DELETE' THEN
              'D'
          END;

  IF TG_OP = 'DELETE'
  then

    l_hist_row.bndl_id            := old.bndl_id;
    l_hist_row.name               := old.name;
    l_hist_row.description        := old.description;
    l_hist_row.device_id          := old.device_id;
    l_hist_row.payment_type       := old.payment_type;
    l_hist_row.max_users          := old.max_users;
    l_hist_row.bundle_length      := old.bundle_length;
    l_hist_row.grace_length       := old.grace_length;
    l_hist_row.dev_only_bndl      := old.dev_only_bndl;
    l_hist_row.end_date           := old.end_date;
    l_hist_row.warning_start_days := old.warning_start_days;

  ELSE
    l_hist_row.bndl_id            := new.bndl_id;
    l_hist_row.name               := new.name;
    l_hist_row.description        := new.description;
    l_hist_row.device_id          := new.device_id;
    l_hist_row.payment_type       := new.payment_type;
    l_hist_row.max_users          := new.max_users;
    l_hist_row.bundle_length      := new.bundle_length;
    l_hist_row.grace_length       := new.grace_length;
    l_hist_row.dev_only_bndl      := new.dev_only_bndl;
    l_hist_row.end_date           := new.end_date;
    l_hist_row.warning_start_days := new.warning_start_days;
  END IF;

  INSERT INTO beowner.hist_bndl
    (act,
     hist_bndl_guid,
     milestone,
     bndl_id,
     NAME,
     description,
     device_id,
     payment_type,
     max_users,
     bundle_length,
     grace_length,
     dev_only_bndl,
     end_date,
     warning_start_days)
  VALUES
    (l_act,
     beowner.rand_guid(),
     utl.get_milestone(),
     l_hist_row.bndl_id,
     l_hist_row.name,
     l_hist_row.description,
     l_hist_row.device_id,
     l_hist_row.payment_type,
     l_hist_row.max_users,
     l_hist_row.bundle_length,
     l_hist_row.grace_length,
     l_hist_row.dev_only_bndl,
     l_hist_row.end_date,
     l_hist_row.warning_start_days);

IF TG_OP = 'DELETE' THEN
  RETURN OLD;
ELSE
  RETURN NEW;
END IF;

END
$BODY$
 LANGUAGE 'plpgsql';

CREATE TRIGGER tr_hist_bndl
  AFTER INSERT OR UPDATE OR DELETE ON beowner.bndl FOR EACH ROW
  EXECUTE PROCEDURE beowner.trigger_fct_tr_hist_bndl();

\i cleanup.sql;
