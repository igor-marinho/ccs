SET bedb.filename = 'function.rand_guid.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION beowner.rand_guid()
RETURNS UUID
AS
$BODY$
BEGIN
    RETURN extensions.uuid_generate_v4();
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER
;

\i cleanup.sql;
