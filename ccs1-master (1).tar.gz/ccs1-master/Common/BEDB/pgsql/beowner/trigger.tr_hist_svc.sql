SET bedb.filename = 'trigger.tr_hist_svc.sql';

\i set_be_env.sql;

DROP function IF exists trigger_fct_tr_hist_svc CASCADE;

CREATE OR REPLACE function beowner.trigger_fct_tr_hist_svc() RETURNS trigger AS $BODY$
DECLARE
  l_act      VARCHAR(1);
  l_hist_row beowner.svc;
BEGIN
   l_act := CASE
              WHEN TG_OP = 'INSERT' THEN
               'I'
              WHEN TG_OP = 'UPDATE' THEN
               'U'
              WHEN TG_OP = 'DELETE' THEN
               'D'
           END;

   IF TG_OP = 'DELETE'
   THEN
    l_hist_row.svc_id                := old.svc_id;
    l_hist_row.name                  := old.name;
    l_hist_row.description           := old.description;
    l_hist_row.handler               := old.handler;
    l_hist_row.auth                  := old.auth;
    l_hist_row.black_white_lst       := old.black_white_lst;
    l_hist_row.contract_required     := old.contract_required;
    l_hist_row.allow_secondary       := old.allow_secondary;
    l_hist_row.never_expires         := old.never_expires;
    l_hist_row.always_available      := old.always_available;
    l_hist_row.ev_service            := old.ev_service;
    l_hist_row.similar_570_service   := old.similar_570_service;
    l_hist_row.expires_with_contract := old.expires_with_contract;
  ELSE
    l_hist_row.svc_id                := new.svc_id;
    l_hist_row.name                  := new.name;
    l_hist_row.description           := new.description;
    l_hist_row.handler               := new.handler;
    l_hist_row.auth                  := new.auth;
    l_hist_row.black_white_lst       := new.black_white_lst;
    l_hist_row.contract_required     := new.contract_required;
    l_hist_row.allow_secondary       := new.allow_secondary;
    l_hist_row.never_expires         := new.never_expires;
    l_hist_row.always_available      := new.always_available;
    l_hist_row.ev_service            := new.ev_service;
    l_hist_row.similar_570_service   := new.similar_570_service;
    l_hist_row.expires_with_contract := new.expires_with_contract;
  END IF;

  INSERT INTO beowner.hist_svc
    (act,
     hist_svc_guid,
     milestone,
     svc_id,
     NAME,
     description,
     handler,
     auth,
     black_white_lst,
     contract_required,
     allow_secondary,
     never_expires,
     always_available,
     ev_service,
     similar_570_service,
     expires_with_contract)
  VALUES
    (l_act,
     beowner.rand_guid(),
     utl.get_milestone(),
     l_hist_row.svc_id,
     l_hist_row.name,
     l_hist_row.description,
     l_hist_row.handler,
     l_hist_row.auth,
     l_hist_row.black_white_lst,
     l_hist_row.contract_required,
     l_hist_row.allow_secondary,
     l_hist_row.never_expires,
     l_hist_row.always_available,
     l_hist_row.ev_service,
     l_hist_row.similar_570_service,
     l_hist_row.expires_with_contract);

IF TG_OP = 'DELETE' THEN
  RETURN OLD;
ELSE
  RETURN NEW;
END IF;

END
$BODY$
 LANGUAGE 'plpgsql';

CREATE TRIGGER tr_hist_svc
  AFTER INSERT OR UPDATE OR DELETE ON beowner.svc FOR EACH ROW
  EXECUTE PROCEDURE beowner.trigger_fct_tr_hist_svc();

\i cleanup.sql;
