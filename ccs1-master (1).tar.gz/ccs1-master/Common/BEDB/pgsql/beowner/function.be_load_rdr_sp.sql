SET bedb.filename = 'function.be_load_rdr_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.be_load_rdr_sp(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT,
                                               TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, 
                                               TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, 
                                               TEXT, TEXT, TEXT, TEXT, TEXT, TEXT);

CREATE OR REPLACE FUNCTION beowner.be_load_rdr_sp (rdr_job_log_id_i                  text
                                                  ,vin_i                             text DEFAULT NULL
                                                  ,used_ind_i                        text DEFAULT NULL
                                                  ,retail_date_time_i                text DEFAULT NULL
                                                  ,reversal_ind_i                    text DEFAULT NULL
                                                  ,reversal_type_i                   text DEFAULT NULL
                                                  ,company_name_i                    text DEFAULT NULL
                                                  ,org_line1_i                       text DEFAULT NULL
                                                  ,org_line2_i                       text DEFAULT NULL
                                                  ,org_city_i                        text DEFAULT NULL
                                                  ,org_state_i                       text DEFAULT NULL
                                                  ,org_zip_code_i                    text DEFAULT NULL
                                                  ,org_phone_am_areacode_i           text DEFAULT NULL
                                                  ,org_phone_am_exchange_i           text DEFAULT NULL
                                                  ,org_phone_am_line_number_i        text DEFAULT NULL
                                                  ,org_phone_am_extension_i          text DEFAULT NULL
                                                  ,org_phone_pm_areacode_i           text DEFAULT NULL
                                                  ,org_phone_pm_exchange_i           text DEFAULT NULL
                                                  ,org_phone_pm_line_number_i        text DEFAULT NULL
                                                  ,org_phone_pm_extension_i          text DEFAULT NULL
                                                  ,org_email_id_i                    text DEFAULT NULL
                                                  ,buyer_first_name_i                text DEFAULT NULL
                                                  ,buyer_middle_initial_i            text DEFAULT NULL
                                                  ,buyer_last_name_i                 text DEFAULT NULL
                                                  ,buyer_name_suffix_i               text DEFAULT NULL
                                                  ,buyer_line1_i                     text DEFAULT NULL
                                                  ,buyer_line2_i                     text DEFAULT NULL
                                                  ,buyer_city_i                      text DEFAULT NULL
                                                  ,buyer_state_i                     text DEFAULT NULL
                                                  ,buyer_zip_code_i                  text DEFAULT NULL
                                                  ,buyer_phone_am_areacode_i         text DEFAULT NULL
                                                  ,buyer_phone_am_exchange_i         text DEFAULT NULL
                                                  ,buyer_phone_am_linenumber_i       text DEFAULT NULL
                                                  ,buyer_phone_am_extension_i        text DEFAULT NULL
                                                  ,buyer_phone_pm_areacode_i         text DEFAULT NULL
                                                  ,buyer_phone_pm_exchange_i         text DEFAULT NULL
                                                  ,buyer_phone_pm_linenumber_i       text DEFAULT NULL
                                                  ,buyer_phone_pm_extension_i        text DEFAULT NULL
                                                  ,buyer_email_id_i                  text DEFAULT NULL
                                                  ,recordset_o                OUT    refcursor)
AS $body$
DECLARE
    l_action TEXT;
    l_module_name text := 'be_load_rdr_sp';

   -- dropped a lot of columns and parameters for DCS1E-1482
   vrdr  beowner.rdr_staging;
   vrslt RECORD;
   cboolfalse CONSTANT varchar(1) := '-';
   fdf_email  CONSTANT text := 'fdf.notification';

   v_error_message varchar(2000);

   v_rdr_job_log_id beowner.rdr_staging.rs_job_log_id%TYPE;
   l_exception_diagnostics trc.exception_diagnostics;

BEGIN
   l_action := utl.set_module_action( l_module_name,' Loading Record Data');

   BEGIN
      v_rdr_job_log_id := rdr_job_log_id_i::UUID;

      -- WI #14781. If an existing job log ID, then populate local row with rdr_staging contents
      SELECT *
        INTO STRICT vrdr
        FROM beowner.rdr_staging
       WHERE rs_job_log_id = v_rdr_job_log_id;
      --- add condition to ensure that rjl.rjl_num_vin_not_found_indb = 'P' - still pending and not past 60 days
      -- add an error code if row found but value not P
   EXCEPTION
      WHEN no_data_found THEN
         -- Only populate local row with input params if not a pre-existing RDR that is being reprocessed
         vrdr.rs_job_log_id := v_rdr_job_log_id;
         vrdr.rs_vin := upper(trim(both vin_i));
         vrdr.rs_used_ind := upper(trim(both used_ind_i));
         vrdr.rs_retail_date_time := retail_date_time_i;
         vrdr.rs_reversal_ind := upper(trim(both reversal_ind_i));
         vrdr.rs_reversal_type := upper(trim(both reversal_type_i));
         vrdr.rs_company_name := trim(both company_name_i);
         vrdr.rs_org_line1 := org_line1_i;
         vrdr.rs_org_line2 := org_line2_i;
         vrdr.rs_org_city := org_city_i;
         vrdr.rs_org_state := org_state_i;
         vrdr.rs_org_zip_code := org_zip_code_i;
         vrdr.rs_org_phone_am_areacode := org_phone_am_areacode_i;
         vrdr.rs_org_phone_am_exchange := org_phone_am_exchange_i;
         vrdr.rs_org_phone_am_line_number := org_phone_am_line_number_i;
         vrdr.rs_org_phone_am_extension := org_phone_am_extension_i;
         vrdr.rs_org_phone_pm_areacode := org_phone_pm_areacode_i;
         vrdr.rs_org_phone_pm_exchange := org_phone_pm_exchange_i;
         vrdr.rs_org_phone_pm_line_number := org_phone_pm_line_number_i;
         vrdr.rs_org_phone_pm_extension := org_phone_pm_extension_i;
         vrdr.rs_org_email_id := utl.normalize_email(org_email_id_i);
         vrdr.rs_buyer_first_name := buyer_first_name_i;
         vrdr.rs_buyer_middle_initial := buyer_middle_initial_i;
         vrdr.rs_buyer_last_name := buyer_last_name_i;
         vrdr.rs_buyer_name_suffix := buyer_name_suffix_i;
         vrdr.rs_buyer_line1 := buyer_line1_i;
         vrdr.rs_buyer_line2 := buyer_line2_i;
         vrdr.rs_buyer_city := buyer_city_i;
         vrdr.rs_buyer_state := buyer_state_i;
         vrdr.rs_buyer_zip_code := buyer_zip_code_i;
         vrdr.rs_buyer_phone_am_areacode := buyer_phone_am_areacode_i;
         vrdr.rs_buyer_phone_am_exchange := buyer_phone_am_exchange_i;
         vrdr.rs_buyer_phone_am_linenumber := buyer_phone_am_linenumber_i;
         vrdr.rs_buyer_phone_am_extension := buyer_phone_am_extension_i;
         vrdr.rs_buyer_phone_pm_areacode := buyer_phone_pm_areacode_i;
         vrdr.rs_buyer_phone_pm_exchange := buyer_phone_pm_exchange_i;
         vrdr.rs_buyer_phone_pm_linenumber := buyer_phone_pm_linenumber_i;
         vrdr.rs_buyer_phone_pm_extension := buyer_phone_pm_extension_i;
         vrdr.rs_buyer_email_id := utl.normalize_email(buyer_email_id_i);
         vrdr.rs_invalid_vin_flag := cboolfalse;
         vrdr.rs_invalid_make_flag := cboolfalse;
         vrdr.rs_invalid_email_flag := cboolfalse;
         vrdr.rs_invalid_phone_flag := cboolfalse;
         vrdr.rs_invalid_name_flag := cboolfalse;
         vrdr.rs_invalid_address_flag := cboolfalse;
         vrdr.rs_vin_not_found_indb_flag := cboolfalse;
         vrdr.rs_created_date := clock_timestamp();
   END;
   l_action := utl.set_action(' Loading RDR Data');
   vrslt := rdr.load_rdr(vrdr);

   OPEN recordset_o FOR
      SELECT vrslt.o_status_code;

EXCEPTION
   WHEN OTHERS THEN
      v_error_message := 'An error occurred in RDR Load processing (BE_LOAD_RDR_SP) at "' ||
                         to_char(CURRENT_TIMESTAMP, 'YYYY/MM/DD HH24:MI:SS.FF2') ||
                         '" - check "trc" logs around that time. rs_job_log_id = ' ||
                         rdr_job_log_id_i || ' VIN = ' || coalesce(vrdr.rs_vin, '0');

      --numeric or value error exception
      IF SQLSTATE IN ('22P02')
      THEN
         v_error_message := v_error_message ||'. The rdr_job_log_id_i is not a HEX value.';
      END IF;

      GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);

      OPEN recordset_o FOR
         SELECT utl.get_constant_value('cinternalerror');

END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_load_rdr_sp (rdr_job_log_id_i text, recordset_o OUT REFCURSOR, vin_i text DEFAULT NULL, used_ind_i text DEFAULT NULL, retail_date_time_i text DEFAULT NULL, reversal_ind_i text DEFAULT NULL, reversal_type_i text DEFAULT NULL, company_name_i text DEFAULT NULL, org_line1_i text DEFAULT NULL, org_line2_i text DEFAULT NULL, org_city_i text DEFAULT NULL, org_state_i text DEFAULT NULL, org_zip_code_i text DEFAULT NULL, org_phone_am_areacode_i text DEFAULT NULL, org_phone_am_exchange_i text DEFAULT NULL, org_phone_am_line_number_i text DEFAULT NULL, org_phone_am_extension_i text DEFAULT NULL, org_phone_pm_areacode_i text DEFAULT NULL, org_phone_pm_exchange_i text DEFAULT NULL, org_phone_pm_line_number_i text DEFAULT NULL, org_phone_pm_extension_i text DEFAULT NULL, org_email_id_i text DEFAULT NULL, buyer_first_name_i text DEFAULT NULL, buyer_middle_initial_i text DEFAULT NULL, buyer_last_name_i text DEFAULT NULL, buyer_name_suffix_i text DEFAULT NULL, buyer_line1_i text DEFAULT NULL, buyer_line2_i text DEFAULT NULL, buyer_city_i text DEFAULT NULL, buyer_state_i text DEFAULT NULL, buyer_zip_code_i text DEFAULT NULL, buyer_phone_am_areacode_i text DEFAULT NULL, buyer_phone_am_exchange_i text DEFAULT NULL, buyer_phone_am_linenumber_i text DEFAULT NULL, buyer_phone_am_extension_i text DEFAULT NULL, buyer_phone_pm_areacode_i text DEFAULT NULL, buyer_phone_pm_exchange_i text DEFAULT NULL, buyer_phone_pm_linenumber_i text DEFAULT NULL, buyer_phone_pm_extension_i text DEFAULT NULL, buyer_email_id_i text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
