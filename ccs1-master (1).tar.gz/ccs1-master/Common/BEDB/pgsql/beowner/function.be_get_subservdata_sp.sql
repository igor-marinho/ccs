SET bedb.filename = 'function.be_get_subservdata_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.be_get_subservdata_sp(text,text,text);

CREATE OR REPLACE FUNCTION beowner.be_get_subservdata_sp (userloginid_i       text
                                                         ,partnerid_i         text
                                                         ,vin_i               text
                                                         ,recordset_o     OUT refcursor)
AS $body$
/*  Title:    BE_GET_SUBSERVDATA_SP
    Version:      4.1
    Date:     April 25, 2011
    Author:   Bob B
    Description:
      The purpose is to get subscriber services data from the subscriber
      services table.  A cursor containing data is returned.

    Input parameters:
      userLoginId_i   - subscriber email address
      partnerid_i     - partner id
      vin_i       - VIN

    Output parameters:
      recordset_o   - VIN and subscriber vin bundle data
              for subscriber in cursor format
      success - status_code of '0',
      failure - status code of '1' = general failure
                   '2' = failed validation
                   '7' = user not on file
                   '4' = bad parameter
                   '200' - VIN record not found
                   '210' = Subscriber servcies records not found

    Revision History:

    DATE      AUTHOR    DESCRIPTION

    04/29/11  Bob B Retrieve records for secondary user based on primary user
            Defect 7848
    05/04/11  Bob B Defect 7945 add allowed status to cursor
    05/12/11  Bob B Work Item 4846 - secondary acl rework
    06/16/11  djb   Rework for new schema
*/
DECLARE
    l_action text;
    l_module_name text := 'be_get_subservdata_sp';
    l_exception_diagnostics trc.exception_diagnostics;      
BEGIN

  l_action := utl.set_module_action( l_module_name,  ' Setting Context');

  CALL ctx.set( iPtnrID  => partnerid_i::UUID,
                iLoginID => userloginid_i,
                iVIN     => vin_i );

  l_action := utl.set_action(' Returning Dataset');

  open recordset_o for
    SELECT utl.get_constant_value('csuccess') status,
       z.vin, z.svc_id, z.name, z.allowed_status
      from user_subscription.info_ctx() z -- this *always* returns at least two rows, so we'll always return cSuccess
      order by upper(z.name);

exception
  WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation then
    open recordset_o for
      SELECT utl.get_constant_value('cinvalidparams');

  WHEN SQLSTATE 'EPTNR' then
    open recordset_o for
      SELECT utl.get_constant_value('cdbpartneridnotvalid');

  WHEN SQLSTATE 'EUSRN' THEN
    open recordset_o for
      SELECT utl.get_constant_value('cnosuchuser');

  WHEN SQLSTATE 'EVINN' then
    open recordset_o for
      SELECT utl.get_constant_value('cdbvinnotfound');

  when others then
    GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
    open recordset_o for
      SELECT utl.get_constant_value('cinternalerror');

end;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_get_subservdata_sp ( userloginid_i text, partnerid_i text, vin_i text, recordset_o out REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
