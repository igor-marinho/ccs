SET bedb.filename = 'function.be_activate_2nd_subscriber_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.be_activate_2nd_subscriber_sp (text,text);

CREATE OR REPLACE FUNCTION beowner.be_activate_2nd_subscriber_sp(partnerid_i                        text
                                                                ,secondary_subscriber_email_i       text
                                                                ,recordset_o                    OUT refcursor) 
AS $body$
DECLARE
/*
    Title:            BE_ACTIVATE_2ND_SUBSCRIBER_SP
    Version:          4.1
    Date:             04/14/2011
    Author:           Bob Binger
    Description:      Activates secondary subscribers account.

    Input parameters:
      Partnerid_i                   IN  VARCHAR2,
      Secondary_Subscriber_Email_i  IN  VARCHAR2,

    Output parameters:
       recordset_o   status code plus data if applicable

       status code '0' - Success
                   '1' - Undefined exception logged in sql_error_log
                   '4' - value error which is normally invalid parameter(s)

    Revision History:

    DATE      AUTHOR    DESCRIPTION

    05/02/11  Bob B     Defect #7859 and 7849 credentials for second subscriber
    05/11/11  Bob B     Work Item 4290 technical cleanup
    05/12/11  Bob B     Work Item 4846 - secondary acl rework
    05/19/11  Dean B    rework for schema change
*/
BEGIN
  recordset_o := beowner.be_activate_subscriber_sp(partnerid_i => partnerid_i, userloginid_i => secondary_subscriber_email_i);
end;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_activate_2nd_subscriber_sp ( partnerid_i text, secondary_subscriber_email_i text, recordset_o out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
