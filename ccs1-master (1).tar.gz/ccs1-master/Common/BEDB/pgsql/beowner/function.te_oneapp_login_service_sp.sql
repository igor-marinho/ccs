SET bedb.filename = 'function.te_oneapp_login_service_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.te_oneapp_login_service_sp(text,text,text);

CREATE OR REPLACE FUNCTION beowner.te_oneapp_login_service_sp (uid_i           text                                                              
                                                              ,serviceid_i     text
                                                              ,partnerid_i     text                                                              
                                                              ,o_status out integer) 
AS
$BODY$


DECLARE

l_action text;
l_module_name text := 'te_oneapp_login_service_sp';
l_uid text := trim(both(uid_i));
l_partnerid text := trim(both(partnerid_i));
l_usr_exists integer;
l_status integer;
vsvcid text := trim(both(serviceid_i));
vcount INTEGER;
vcount_svc_expired INTEGER;
vsc_code beowner.status_code.code%TYPE;
vrslt refcursor;
l_exception_diagnostics trc.exception_diagnostics;

BEGIN	

l_action := utl.set_module_action( l_module_name, 'Check user');
	
/* Check if the UID exists for both makes*/

SELECT COUNT(1) 
INTO STRICT l_usr_exists
FROM beowner.usr WHERE login_id = l_uid
and make_id in ('LX','TM');

IF l_usr_exists != 2 then

    l_action := utl.set_action( 'Create User for TM and LX');
   
    vrslt := beowner.be_create_user_sp(userloginid_i => l_uid
                                      ,vin_i         => NULL
                                      ,partnerid_i   => utl.getconfig('Lexus PTNR ID')
                                      ,create_type_i => NULL
                                      ,check_email   => FALSE); 
                                     
    FETCH NEXT FROM vrslt INTO l_status;

    IF l_status != utl.get_constant_value('csuccess')::integer THEN 
       o_status := l_status;
       RETURN;
    END IF;          
   
    vrslt := beowner.be_create_user_sp(userloginid_i => l_uid
                                      ,vin_i         => NULL
                                      ,partnerid_i   => utl.getconfig('Toyota PTNR ID') 
                                      ,create_type_i => NULL
                                      ,check_email   => FALSE);    
                                     
    FETCH NEXT FROM vrslt INTO l_status;

    IF l_status != utl.get_constant_value('csuccess')::integer THEN 
       o_status := l_status;
       RETURN;
    END IF;

ELSE

CALL ctx.set(iptnrid := l_partnerid::uuid, iloginid := l_uid);
 
END IF;       

/* Validation of service id if provided */

IF vsvcid IS NOT NULL THEN

l_action := utl.set_action( 'Getting Service Allowed Status');

WITH a1 AS
       (SELECT DISTINCT first_value(svc_id) over(PARTITION BY svc_id ORDER BY ordered_allowed_status) svc_id,
                                    first_value(allowed_status) over(PARTITION BY svc_id ORDER BY ordered_allowed_status) allowed_status

                      FROM user_subscription.info_ctx(isvcid => vsvcid))

        SELECT COALESCE(SUM(CASE
                            WHEN allowed_status = utl.get_constant_value('c_allowed_service_status') THEN
                            1
                            ELSE
                            0
                            END),
                            0) count_status_1,
               COALESCE(SUM(CASE
                            WHEN allowed_status = utl.get_constant_value('c_deprecated_service_status') THEN
                            1
                            ELSE
                            0
                            END),
                            0) count_status_9
               INTO vcount,
                    vcount_svc_expired,
                    vsc_code
               FROM a1
               WHERE svc_id = vsvcid;
       
        IF vcount = 0 THEN
                IF vcount_svc_expired = 0 THEN
                    o_status := utl.get_constant_value('cfailedauthsvc');
                    RETURN;
                ELSE
                    o_status := utl.get_constant_value('c_deprecated_service_error');
                    RETURN;
                END IF;                
        END IF;
END IF;
      
o_status := utl.get_constant_value('csuccess');

RETURN;
       
EXCEPTION

WHEN OTHERS THEN     
                GET STACKED diagnostics
                  l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
                  l_exception_diagnostics.column_name := COLUMN_NAME,
                  l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
                  l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
                  l_exception_diagnostics.message_text := MESSAGE_TEXT,
                  l_exception_diagnostics.table_name := TABLE_NAME,
                  l_exception_diagnostics.schema_name := SCHEMA_NAME,              
                  l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
                  l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
                  l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
                  l_exception_diagnostics.module_name := l_module_name;
                  l_exception_diagnostics.action := l_action;
                  
                  CALL trc.log(iadditionaldata => NULL,
                                iexception_diagnostics => l_exception_diagnostics);
                
          
                  o_status := utl.get_constant_value('cinternalerror');
                  RETURN;            
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;