SET bedb.filename = 'function.be_csr_get_subvininfo_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.be_csr_get_subvininfo_sp(text, text, text, text, text, text, text, text, text);
-- WARNING: parameters order has been changed by Ora2Pg to move parameters with default values at end
-- Original order was: be_csr_get_subvininfo_sp(vin_i text DEFAULT NULL, email_address1_i text DEFAULT NULL, primaryphonecc_i text DEFAULT NULL, primaryphoneac_i text DEFAULT NULL, primaryphonenum_i text DEFAULT NULL, primaryphoneext_i text DEFAULT NULL, firstname_i text DEFAULT NULL, lastname_i text DEFAULT NULL, partnerid_i text, refcursor_o OUT REFCURSOR)
-- You will need to manually reorder parameters in the function calls

/*--  Modified for #18367 to remove dynamic sql
 This is a search function that builds the required query
 based on the inputs above. NULL values are not factored into the
 search.
    Return refcursor has following columns:
      status, email, name_first, name_last,vin,payment_type, sub_end, acct_status, device_id, usractstatus, cc, ac, phone, ext,
      usr_id, sub_start, is_primary, partner_id, make_id
*/
CREATE OR REPLACE FUNCTION beowner.be_csr_get_subvininfo_sp (partnerid_i             text
                                                            ,vin_i                   text DEFAULT NULL
                                                            ,email_address1_i        text DEFAULT NULL
                                                            ,primaryphonecc_i        text DEFAULT NULL
                                                            ,primaryphoneac_i        text DEFAULT NULL
                                                            ,primaryphonenum_i       text DEFAULT NULL
                                                            ,primaryphoneext_i       text DEFAULT NULL
                                                            ,firstname_i             text DEFAULT NULL
                                                            ,lastname_i              text DEFAULT NULL
                                                            ,refcursor_o         OUT refcursor)
AS
$body$
DECLARE
    l_action                text;
    l_module_name           text            := 'be_csr_get_subvininfo_sp';
    l_vin                   text;
    l_email                 text;
    l_cc                    text;
    l_ac                    text;
    l_phone                 text;
    l_ext                   text;
    l_first                 text;
    l_last                  text;
    l_tilda                 char varying(1) := '~'; -- used for query below
    l_count                 integer;

    --  TMSCR10655-11
    l_external_vin_check    beowner.make.external_vin_db_code%type;
    l_query TEXT :=  format('INSERT
                                INTO beowner.gt_usr(SELECT
                                    u.usr_id  
                                FROM beowner.usr u ');
    l_condition TEXT := '';
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    l_action := utl.set_module_action(l_module_name, ' Setting PtnrID Context');

    CALL ctx.set(iptnrid => partnerid_i::uuid);

    l_action := utl.set_module_action(l_module_name, ' Setting local variables');

    l_vin := upper(trim(BOTH NULLIF(vin_i, '')));

    -- Added external VIN logic for TMSCR10655-11
    l_external_vin_check := utl.check_vin_external(i_vin => l_vin);

    IF l_external_vin_check IS NOT NULL
    THEN
        OPEN refcursor_o FOR
            SELECT l_external_vin_check;
        RETURN;
    END IF;

    l_email := utl.normalize_email(email_address1_i);
    -- not doing country code for the moment...
    -- zCC       := trim(primaryphonecc_i);
    l_ac := trim(BOTH NULLIF(primaryphoneac_i, ''));
    l_phone := trim(BOTH NULLIF(primaryphonenum_i, ''));
    l_ext := trim(BOTH NULLIF(primaryphoneext_i, ''));
    l_first := trim(BOTH NULLIF(firstname_i, ''));
    l_last := trim(BOTH NULLIF(lastname_i, ''));

    -- something must be set. If not, it's an error
    IF coalesce(l_vin, l_email, l_cc, l_ac, l_phone, l_ext, l_first, l_last) IS NULL
    THEN
        RAISE EXCEPTION USING ERRCODE = 'invalid_text_representation';
    END IF;

    l_action := utl.set_module_action(l_module_name, ' Populating GT_USR with User IDs');

    DELETE FROM beowner.gt_usr WHERE usr_id IS NOT NULL; -- just in case

    /*Building INSERT query based ON available inputs to improve query performance*/
    IF l_ac IS NOT NULL OR l_phone IS NOT NULL
    THEN 
    l_query := l_query || ' JOIN usr_phone p ON
            p.usr_id = u.usr_id
            AND p.phone_type_id::TEXT = ''H1''::TEXT';
        IF l_ac IS NOT NULL
        THEN
            l_condition :=  l_condition || format(' AND p.ac = %L ', l_ac);
        END IF;
        IF l_phone IS NOT NULL
        THEN
            l_condition :=  l_condition || format(' AND p.phone = %L ', l_phone);
        END IF;
    END IF;
    
    IF l_email IS NOT NULL 
    THEN 
    l_query := l_query || ' JOIN usr_email e ON
            e.usr_id = u.usr_id
            AND e.email_type_id::TEXT = ''H1''::TEXT';
            
    l_condition := l_condition ||  format(' AND e.email = %L ', l_email);
    END IF;
    
    IF l_first IS NOT NULL OR l_last IS NOT NULL 
    THEN 
    l_query := l_query || ' JOIN usr_demog d ON
            d.usr_id = u.usr_id';
        IF l_first IS NOT NULL
        THEN
            l_condition :=  l_condition ||  format(' AND UPPER(d.name_first) = UPPER(%L) ', l_first);
        END IF;
        IF l_last IS NOT NULL 
        THEN 
            l_condition :=  l_condition ||  format(' AND UPPER(d.name_last) = UPPER(%L) ', l_last);
        END IF;
    END IF;
    IF l_vin IS NOT NULL 
    THEN 
    l_query := l_query || ' JOIN beowner.subscription s ON
                s.primary_id = COALESCE(u.parent_id, u.usr_id)';
    
    l_condition := l_condition ||  format(' AND s.vin = %L ', l_vin);
    END IF;
    
    l_query := l_query || ' WHERE 1=1 '|| l_condition || ')';
    
EXECUTE l_query;

    GET DIAGNOSTICS l_count = ROW_COUNT;

    l_action := utl.set_module_action(l_module_name, ' Opening Result Set');

    IF l_count > 0
    THEN
        OPEN refcursor_o FOR
            SELECT utl.get_constant_value('csuccess') status,
                   ubi.email,
                   ubi.name_first,
                   ubi.name_last,
                   z.vin,
                   CASE z.payment_type
                       WHEN 'S' THEN
                           'SUBSIDIZED'
                       WHEN 'P' THEN
                           'PAID'
                       ELSE
                           'UNKNOWN'
                       END                            payment_type,
                   z.sub_end,
                   z.acct_status,
                   z.device_id,
                   CASE
                       WHEN z.verified IS NOT NULL THEN
                           'ACTIVE'
                       ELSE
                           'PENDING'
                       END                            usractstatus,
                   ubi.cc,
                   ubi.ac,
                   ubi.phone,
                   ubi.ext,
                   z.usr_id                           usr_id,
                   coalesce(z.dofu, z.sub_start)      sub_start,
                   CASE z.is_primary
                       WHEN '*' THEN
                           'Primary'
                       ELSE
                           'Secondary'
                       END                            is_primary,
                   p.ptnr_id                          partner_id,
                   z.make_id -- Added for OnTime 6087 (F.Id 2022)
            FROM (SELECT DISTINCT usr_id,
                                  acct_status,
                                  device_id,
                                  sub_start,
                                  sub_end,
                                  payment_type,
                                  vin,
                                  is_primary,
                                  verified,
                                  dofu,
                                  make_id
                  FROM user_subscription.info_gtusr()) z
                     JOIN beowner.usr_basic_info ubi
                          ON ubi.usr_id = z.usr_id
                     JOIN beowner.ptnr p
                          ON z.make_id = p.make_id
                              AND 'TB' = p.hu_mfr_id
                        WHERE coalesce(z.vin, l_tilda) = CASE
                                                         WHEN l_vin IS NULL THEN
                                                             coalesce(z.vin, l_tilda)
                                                         ELSE
                                                             l_vin
                                                         END;
    ELSE
        OPEN refcursor_o FOR
            SELECT utl.get_constant_value('cdbnodatafound') status;
    END IF;
EXCEPTION
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
      OPEN refcursor_o FOR
         SELECT utl.get_constant_value('cinvalidparams');

   WHEN SQLSTATE 'EPTNR' THEN
      OPEN refcursor_o FOR
         SELECT utl.get_constant_value('cdbpartneridnotvalid');

   WHEN SQLSTATE 'EUSRN' THEN
      OPEN refcursor_o FOR
         SELECT utl.get_constant_value('cnosuchuser');

   WHEN SQLSTATE 'EVINN' THEN
      OPEN refcursor_o FOR
         SELECT utl.get_constant_value('cdbvinnotfound');

   WHEN OTHERS THEN
      GET STACKED DIAGNOSTICS
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
      CALL trc.log(iadditionaldata => NULL,
                   iexception_diagnostics => l_exception_diagnostics);

      OPEN refcursor_o FOR
         SELECT utl.get_constant_value('cinternalerror');

END;
$body$ 
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_csr_get_subvininfo_sp ( partnerid_i text, refcursor_o OUT REFCURSOR,vin_i text DEFAULT NULL, email_address1_i text DEFAULT NULL, primaryphonecc_i text DEFAULT NULL, primaryphoneac_i text DEFAULT NULL, primaryphonenum_i text DEFAULT NULL, primaryphoneext_i text DEFAULT NULL, firstname_i text DEFAULT NULL, lastname_i text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;

