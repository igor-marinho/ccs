SET bedb.filename = 'function.check_conflict.sql';

\i set_be_env.sql;

   CREATE OR REPLACE FUNCTION check_conflict RETURN VARCHAR(4000) AS $body$
   BEGIN
      -- see if the VIN is in conflict
      -- count all subscription records for specified VIN
      SELECT COUNT(*)
        INTO vcount
        FROM ctx_data cd
        JOIN subscription s
          ON s.vin = cd.vin;
   
      IF vcount > 2
      THEN
         -- it has multiple conflicts so we'll just abort here
         RETURN cnst.cdbtransfernotallowedconflict;
      END IF;
   
      IF vcount > 1
      THEN
         -- it's in conflict, but check to see if the conflict
         -- record is the destination user
         SELECT COUNT(*)
           INTO vcount
           FROM ctx_data cd
           JOIN subscription s
             ON s.primary_id = vdstusrid
                AND s.vin = cd.vin;
      
         IF vcount = 0
         THEN
            -- the conflict does not involve the DST user, so this is an error
            RETURN cnst.cdbtransfernotallowedconflict;
         END IF;
      END IF;
   
      RETURN utl.get_constant_value('csuccess');
   END;	  
$body$
LANGUAGE PLPGSQL
;
   
\i cleanup.sql;
