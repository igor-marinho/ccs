SET bedb.filename = 'function.be_delete_usercredentials_sp.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS beowner.be_delete_usercredentials_sp (TEXT, TEXT, TEXT, TEXT );
DROP FUNCTION IF EXISTS beowner.be_delete_usercredentials_sp (TEXT, TEXT, TEXT, TEXT );

CREATE OR REPLACE FUNCTION beowner.be_delete_usercredentials_sp (userloginid_i       text
                                                                ,serviceid_i         text
                                                                ,partnerid_i         text
                                                                ,status_code_o   OUT refcursor)
AS $body$
DECLARE
      l_action TEXT;
      l_module_name text := 'be_delete_usercredentials_sp';
      l_exception_diagnostics trc.exception_diagnostics;
/*  Title:    BE_DELETE_USERCREDENTIALS_SP
    Version:      4.1
    Date:     May 3, 2011
    Author:   Dean B
    Description:  Delete User Credentials, then re-run the ACL

    Input parameters:
      userLoginId   - subscriber email address
      serviceid_i   - service id
      partnerid_i   - partner id

    Output parameters:
      status_code_0 - Output variable
      success -  status_code of '0' if the procedure completes successfully
      failure - '1' if there is failure in the routine.
      failure - '4' - invalid parameter(s)

    Revision History:

    DATE      AUTHOR    DESCRIPTION

    05/01/11  Dean B    Defect #7373
    05/04/11  Bob B Defect 7968 set switch to toggle on/off
    05/12/11  Bob B Work Item 4846 - secondary acl rework
*/
BEGIN

  l_action := utl.set_module_action( l_module_name,  'Setting Context');

  CALL ctx.set(iPtnrID => partnerid_i::UUID, iLoginID => userloginid_i);

  l_action := utl.set_module_action( l_module_name,  'Deleting credentials');

  delete FROM beowner.usr_inf
    where (usr_id, svc_id) = (SELECT usr_id, serviceid_i from beowner.ctx_data);


  open status_code_o for
    SELECT utl.get_constant_value('csuccess');

EXCEPTION 

  WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation then

    open status_code_o for
      SELECT utl.get_constant_value('cinvalidparams');

  WHEN SQLSTATE 'EPTNR' then

    open status_code_o for
      SELECT utl.get_constant_value('cdbpartneridnotvalid');

  WHEN SQLSTATE 'EUSRN' then

    open status_code_o for
      SELECT utl.get_constant_value('cnosuchuser');

  WHEN SQLSTATE 'EVINN' then

    open status_code_o for
      SELECT utl.get_constant_value('cdbvinnotfound');

  when others then

    GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
      
        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
    open status_code_o for
      SELECT utl.get_constant_value('cinternalerror');

end;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_delete_usercredentials_sp ( userloginid_i text, serviceid_i text, partnerid_i text, status_code_o out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
