SET bedb.filename = 'function.be_get_subvinbundle_sp.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS beowner.be_get_subvinbundle_sp(text, text, text);
CREATE OR REPLACE FUNCTION beowner.be_get_subvinbundle_sp(userloginid_i text,
                                                          partnerid_i text,
                                                          vin_i text,
                                                          OUT recordset_o refcursor) AS
$body$
    DECLARE
        l_action                text;
        l_module_name           text := 'be_get_subvinbundle_sp';
        l_exception_diagnostics trc.exception_diagnostics;
    BEGIN
        l_action := utl.set_module_action(l_module_name, ' Setting Context');

        CALL ctx.set(iptnrid => partnerid_i::uuid, iloginid => userloginid_i, ivin => vin_i);

        l_action := utl.set_module_action(l_module_name, ' Returning Dataset');

        -- Added v.vin = vin_i for OnTime #13250 (BE_GET_SUBVINBUNDLE_SP does not properly filter by passed-in vin)
        OPEN recordset_o FOR
            SELECT DISTINCT CASE
                                WHEN v.vin IS NOT NULL THEN
                                    utl.get_constant_value('csuccess')
                                ELSE
                                    utl.get_constant_value('cdbsubscribervinnotfound')
                                END                       stat,
                            v.vin,
                            v.year,
                            v.make_id,
                            v.model,
                            CASE z.payment_type
                                WHEN 'S' THEN 'Subsidized'
                                WHEN 'P' THEN 'Paid'
                                ELSE 'Unknown'
                                END                       payment_type,
                            z.acct_status,
                            coalesce(z.dofu, z.sub_start) sub_start,
                            z.sub_end,
                            v.color
            FROM user_subscription.info_ctx() z
                     LEFT JOIN
                 beowner.vin v
                 ON v.vin = z.vin AND v.vin = vin_i;
    EXCEPTION
        WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation
        THEN
          OPEN recordset_o FOR SELECT utl.get_constant_value('cinvalidparams');

        WHEN SQLSTATE 'EPTNR'
        THEN
          OPEN recordset_o FOR SELECT utl.get_constant_value('cdbpartneridnotvalid');

        WHEN SQLSTATE 'EUSRN'
        THEN
            OPEN recordset_o FOR SELECT utl.get_constant_value('cnosuchuser');

        WHEN SQLSTATE 'EVINN'
        THEN
            OPEN recordset_o FOR SELECT utl.get_constant_value('cdbvinnotfound');

        WHEN OTHERS THEN
            GET STACKED DIAGNOSTICS
                l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
                l_exception_diagnostics.column_name := COLUMN_NAME,
                l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
                l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
                l_exception_diagnostics.message_text := MESSAGE_TEXT,
                l_exception_diagnostics.table_name := TABLE_NAME,
                l_exception_diagnostics.schema_name := SCHEMA_NAME,
                l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
                l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
                l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
				l_exception_diagnostics.module_name := l_module_name;
				l_exception_diagnostics.action := l_action;

            CALL trc.log(iadditionaldata => NULL,
                            iexception_diagnostics => l_exception_diagnostics);

            OPEN recordset_o FOR SELECT utl.get_constant_value('cinternalerror');
    END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_get_subvinbundle_sp ( userloginid_i text, partnerid_i text, vin_i text, recordset_o OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
