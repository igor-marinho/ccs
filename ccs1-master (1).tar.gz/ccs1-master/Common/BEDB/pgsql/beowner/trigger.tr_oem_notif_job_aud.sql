SET bedb.filename = 'trigger.tr_oem_notif_job_aud.sql';

\i set_be_env.sql;

drop FUNCTION if exists beowner.trigger_fct_set_audit_cols cascade;

CREATE FUNCTION trigger_fct_set_audit_cols() RETURNS trigger
as
$$
BEGIN
  
  IF TG_OP = 'INSERT'
  THEN
      NEW.created_time := clock_timestamp();
  elsif TG_OP = 'UPDATE'
  THEN
      NEW.modified_time := clock_timestamp();
  END IF;   
    
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER tr_oem_notif_job_aud
BEFORE INSERT or update ON beowner.oem_notif_job
FOR EACH ROW EXECUTE PROCEDURE trigger_fct_set_audit_cols();

\i cleanup.sql;
