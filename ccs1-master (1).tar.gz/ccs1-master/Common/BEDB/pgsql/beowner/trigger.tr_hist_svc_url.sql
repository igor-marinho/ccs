SET bedb.filename = 'trigger.tr_hist_svc_url.sql';

\i set_be_env.sql;

DROP function IF exists trigger_fct_tr_hist_svc_url CASCADE;

CREATE OR REPLACE FUNCTION beowner.trigger_fct_tr_hist_svc_url()  RETURNS trigger AS $BODY$
DECLARE
   l_act      VARCHAR(1);
   l_hist_row beowner.svc_url;
BEGIN
   l_act := CASE
              WHEN TG_OP = 'INSERT' THEN
               'I'
              WHEN TG_OP = 'UPDATE' THEN
               'U'
              WHEN TG_OP = 'DELETE' THEN
               'D'
           END;

   IF TG_OP = 'DELETE'
   THEN
      l_hist_row.svc_id := old.svc_id;
      l_hist_row.url_sequence := old.url_sequence;
      l_hist_row.link := old.link;

   ELSE
      l_hist_row.svc_id := new.svc_id;
      l_hist_row.url_sequence := new.url_sequence;
      l_hist_row.link := new.link;

   END IF;

   INSERT INTO beowner.hist_svc_url
      (act, hist_svc_url_guid, milestone, svc_id, url_sequence, link)
   VALUES
      (l_act,
       beowner.rand_guid(),
       utl.get_milestone(),
       l_hist_row.svc_id,
       l_hist_row.url_sequence,
       l_hist_row.link);

IF TG_OP = 'DELETE' THEN
  RETURN OLD;
ELSE
  RETURN NEW;
END IF;

END
$BODY$
 LANGUAGE 'plpgsql';

CREATE TRIGGER tr_hist_svc_url
  AFTER INSERT OR UPDATE OR DELETE ON beowner.svc_url FOR EACH ROW
  EXECUTE PROCEDURE beowner.trigger_fct_tr_hist_svc_url();

\i cleanup.sql;
