SET bedb.filename = 'function.be_token_resolve_sp.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS beowner.be_token_resolve_sp(text);
CREATE OR REPLACE FUNCTION beowner.be_token_resolve_sp(iEncodedToken text,
                                                       oResult OUT refcursor)
AS
$body$
DECLARE
    vRslt integer;
    v_cnt integer;
BEGIN

    UPDATE beowner.validation_token
    SET resolved = CURRENT_TIMESTAMP
    WHERE encoded_token = iEncodedToken;
    GET DIAGNOSTICS v_cnt = ROW_COUNT;

    vRslt := CASE
                 WHEN v_cnt = 1
                     THEN
                     utl.get_constant_value('csuccess')
                 ELSE
                     utl.get_constant_value('cinternalerror')
        END;
    OPEN oResult FOR
        SELECT vRslt;

    -- note: if there is a status 1 on this procedure, it's
    -- because there's no row updated (invalid token)
END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE be_token_resolve_sp ( iEncodedToken text, oResult out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
