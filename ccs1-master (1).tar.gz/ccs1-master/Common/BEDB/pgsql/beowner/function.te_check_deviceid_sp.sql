SET bedb.filename = 'function.te_check_deviceid_sp.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION beowner.te_check_deviceid_sp (type_i text, 
                                    hu_mfr_i beowner.pair.hu_mfr%TYPE, 
                                    hu_model_i beowner.pair.hu_model%TYPE, 
                                    hu_version_i beowner.pair.hu_version%TYPE, 
                                    hu_conn_type_i beowner.pair.hu_conn_type%TYPE, 
                                    hu_conn_carrier_i beowner.pair.hu_conn_carrier%TYPE, 
                                    hs_model_i beowner.pair.hs_model%TYPE, 
                                    hs_os_i beowner.pair.hs_os%TYPE, 
                                    hs_os_version_i beowner.pair.hs_os_version%TYPE, 
                                    hs_app_i beowner.pair.hs_app%TYPE, 
                                    hs_app_version_i beowner.pair.hs_app_version%TYPE, 
                                    hs_conn_type_i beowner.pair.hs_conn_type%TYPE, 
                                    hs_conn_carrier_i beowner.pair.hs_conn_carrier%TYPE, 
                                    hs_id_i beowner.pair.hs_id%TYPE, 
                                    pcf_bt_mac_addr_i beowner.pair.pcf_bt_mac_addr%TYPE, 
                                    version_string_i beowner.pair.version_string%TYPE, 
                                    hu_make_id_i beowner.pair.hu_make_id%TYPE, 
                                    hu_country_i beowner.pair.hu_country%TYPE, 
                                    hu_region_i beowner.pair.hu_region%TYPE, 
                                    userloginid_i text, 
                                    partnerid_i text, 
                                    recordset_o OUT REFCURSOR) AS $body$
DECLARE
    l_action text;
    l_module_name text := 'te_check_deviceid_sp';

   /* New error codes added for OnTime WI #8878
      const.cInvalidMake              '222'    Invalid Make
      cnst.c_invalid_country          '230'    Invalid Country Code.
      cnst.c_invalid_trade_region     '231'    Invalid Trade Region
   */
   /*
      DDCRD-563: Updated to use parameters instead of strings. This
      is for improved performance

   */
   -- the "type" parameter along with the valid types allowed
   vtype text;
   ctypeh CONSTANT text := 'H';
   ctypem CONSTANT text := 'M';

   v_pair_guid          beowner.pair.guid%TYPE;
   v_pair_guid_existing smallint;
   l_exception_diagnostics trc.exception_diagnostics;
BEGIN
   l_action := utl.set_module_action( l_module_name, 'Computing Hash');

   -- convert empty strings to nulls
   hu_make_id_i := NULLIF(hu_make_id_i,'');
   hu_country_i := NULLIF(hu_country_i,'');
   hu_region_i := NULLIF(hu_region_i,'');
   
   vtype := upper(trim(both type_i));

   IF vtype NOT IN (ctypeh, ctypem)
   THEN
      RAISE EXCEPTION invalid_text_representation ;
   END IF;

   -- check to see if we have anything to process
   IF (vtype = ctypem AND (hs_model_i IS NULL AND hs_os_i IS NULL AND hs_os_version_i IS NULL AND
      hs_app_i IS NULL AND hs_app_version_i IS NULL AND
      hs_conn_type_i IS NULL AND hs_conn_carrier_i IS NULL AND
      hs_id_i IS NULL AND version_string_i IS NULL))
   THEN
      OPEN recordset_o FOR
         SELECT utl.get_constant_value('csuccess'), '0-0-0-0';

      RETURN;
   END IF;

   v_pair_guid := encode(
                    extensions.digest(
                        COALESCE(hu_mfr_i,'') || 
                        COALESCE(hu_model_i,'') ||
                        COALESCE(hu_version_i,'') ||
                        COALESCE(hu_conn_type_i,'') ||
                        COALESCE(hu_conn_carrier_i,'') ||
                        COALESCE(hs_model_i,'') || 
                        COALESCE(hs_os_i,'') ||
                        COALESCE(hs_os_version_i,'') ||
                        COALESCE(hs_app_i,'') ||
                        COALESCE(hs_app_version_i,'') ||
                        COALESCE(hs_conn_type_i,'') ||
                        COALESCE(hs_conn_carrier_i,'') ||
                        COALESCE(hs_id_i,'') ||
                        COALESCE(pcf_bt_mac_addr_i,'') ||
                        COALESCE(version_string_i,'') ||
                        COALESCE(hu_make_id_i,'') ||
                        COALESCE(hu_country_i,'') ||
                        COALESCE(hu_region_i,''),
                        'md5'),
                  'hex')::UUID;

   SELECT COUNT(guid)
     INTO STRICT v_pair_guid_existing
     FROM beowner.pair p
    WHERE p.guid = v_pair_guid;

   IF v_pair_guid_existing = 0
   THEN
      l_action := utl.set_action('Setting Context');
      CALL ctx.set(iptnrid => partnerid_i::uuid, iloginid => userloginid_i);

      l_action := utl.set_action('Checking for valid data');
      -- On-Time Defect# 17867:  TE sets mDeviceId to be 0000-0000-0000-0000 in prod
      -- jjarboe:  Added this "if" check for only "vType" of "H" only, if 'M' then "pairRow.hu_make_id" value is "NULL" which fails call to "utl.is_make_valid"...
      IF vtype = 'H'
      THEN
         IF (hu_make_id_i IS NULL) OR (NOT utl.is_make_valid(i_make_id => hu_make_id_i))
         THEN
            RAISE EXCEPTION USING ERRCODE = utl.get_constant_value('e_invalidmake');
         ELSIF (hu_country_i IS NULL) OR (NOT utl.is_country_valid(i_country_code => hu_country_i))
         THEN
            RAISE EXCEPTION USING ERRCODE = utl.get_constant_value('e_invalid_country');
         ELSIF (hu_region_i IS NULL) OR (NOT utl.is_trade_region_valid(i_trade_region => hu_region_i))
         THEN
            RAISE EXCEPTION USING ERRCODE = utl.get_constant_value('e_invalid_trade_region');
         END IF;
      END IF;

      INSERT INTO beowner.pair (guid,
             hu_mfr,
             hu_model,
             hu_version,
             hu_conn_type,
             hu_conn_carrier,
             hs_model,
             hs_os,
             hs_os_version,
             hs_app,
             hs_app_version,
             hs_conn_type,
             hs_conn_carrier,
             hs_id,
             pcf_bt_mac_addr,
             version_string,
             hu_make_id,
             hu_country,
             hu_region,
             created)
         VALUES (v_pair_guid,
             hu_mfr_i,
             hu_model_i,
             hu_version_i,
             hu_conn_type_i,
             hu_conn_carrier_i,
             hs_model_i,
             hs_os_i,
             hs_os_version_i,
             hs_app_i,
             hs_app_version_i,
             hs_conn_type_i,
             hs_conn_carrier_i,
             hs_id_i,
             pcf_bt_mac_addr_i,
             version_string_i,
             hu_make_id_i,
             hu_country_i,
             hu_region_i,
             CURRENT_TIMESTAMP) ON CONFLICT (guid) DO NOTHING;

    l_action := utl.set_action('Returning Data');

      --PERFORM utl.docommit();
   END IF;

   OPEN recordset_o FOR
      SELECT utl.get_constant_value('csuccess'), v_pair_guid as guid;

EXCEPTION
   WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
      GET STACKED diagnostics
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,              
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;
      CALL trc.log(iadditionaldata => partnerid_i,
                        iexception_diagnostics => l_exception_diagnostics);
      OPEN recordset_o FOR
         SELECT utl.get_constant_value('cinvalidparams');
         
   WHEN SQLSTATE 'EPTNR' THEN
      OPEN recordset_o FOR
         SELECT utl.get_constant_value('cdbpartneridnotvalid');
         
   WHEN SQLSTATE 'EUSRN'  THEN
      OPEN recordset_o FOR
         SELECT utl.get_constant_value('cnosuchuser');
         
   WHEN SQLSTATE 'EMAKE' THEN
      OPEN recordset_o FOR
         SELECT utl.get_constant_value('cinvalidmake');
         
   WHEN SQLSTATE 'ECTRY' THEN
      OPEN recordset_o FOR
         SELECT utl.get_constant_value('c_invalid_country');
         
   WHEN SQLSTATE 'ETRRG' THEN
      OPEN recordset_o FOR
         SELECT utl.get_constant_value('c_invalid_trade_region');
         
   WHEN OTHERS THEN
      GET STACKED diagnostics
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,              
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;   
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;
      call trc.log(iadditionaldata => partnerid_i,
                        iexception_diagnostics => l_exception_diagnostics);

      OPEN recordset_o FOR
         SELECT utl.get_constant_value('cinternalerror');
END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON PROCEDURE te_check_deviceid_sp (type_i text, hu_mfr_i pair.hu_mfr%TYPE, hu_model_i pair.hu_model%TYPE, hu_version_i pair.hu_version%TYPE, hu_conn_type_i pair.hu_conn_type%TYPE, hu_conn_carrier_i pair.hu_conn_carrier%TYPE, hs_model_i pair.hs_model%TYPE, hs_os_i pair.hs_os%TYPE, hs_os_version_i pair.hs_os_version%TYPE, hs_app_i pair.hs_app%TYPE, hs_app_version_i pair.hs_app_version%TYPE, hs_conn_type_i pair.hs_conn_type%TYPE, hs_conn_carrier_i pair.hs_conn_carrier%TYPE, hs_id_i pair.hs_id%TYPE, pcf_bt_mac_addr_i pair.pcf_bt_mac_addr%TYPE, version_string_i pair.version_string%TYPE, hu_make_id_i pair.hu_make_id%TYPE, hu_country_i pair.hu_country%TYPE, hu_region_i pair.hu_region%TYPE, userloginid_i text, partnerid_i text, recordset_o OUT REFCURSOR) FROM PUBLIC;

--GRANT EXECUTE ON FUNCTION beowner.te_check_deviceid_sp TO beuser;
--GRANT EXECUTE ON FUNCTION beowner.te_check_deviceid_sp TO teuser;

\i cleanup.sql;
