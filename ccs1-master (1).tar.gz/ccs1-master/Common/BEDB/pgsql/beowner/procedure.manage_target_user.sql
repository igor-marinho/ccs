SET bedb.filename = 'procedure.manage_target_user.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS beowner.manage_target_user(beowner.usr.usr_id%type, text, text, text, INOUT beowner.usr
    .usr_id%type, INOUT integer, INOUT text);
CREATE OR REPLACE PROCEDURE beowner.manage_target_user(vsrcusrid beowner.usr.usr_id%type,
                                                       newuser_i text,
                                                       vin_i text,
                                                       partnerid_i text,
                                                       INOUT vdstusrid beowner.usr.usr_id%type,
                                                       INOUT vcount integer,
                                                       INOUT vstatus text) AS
$BODY$
DECLARE
    rc refcursor;
BEGIN


    IF vdstusrid IS NULL
    THEN

        rc := beowner.be_create_user_sp(userloginid_i => newuser_i,
                                        vin_i => vin_i,
                                        partnerid_i => partnerid_i);
        FETCH rc
            INTO vstatus;
        CLOSE rc;

        -- context is set after the above call, save it off
        SELECT usr_id
        INTO vdstusrid
        FROM beowner.ctx_data;

    ELSE

        -- see if the user is, in fact, a primary
        SELECT COUNT(*)
        INTO vcount
        FROM beowner.usr
        WHERE usr_id = vdstusrid
          AND lvl = '0';

        IF vcount = 0
        THEN
            vstatus := utl.get_constant_value('cdb2ndrysubsvintrxfrnotallowed');
        END IF;

    END IF;

END;
$BODY$
    LANGUAGE PLPGSQL

\i cleanup.sql;
