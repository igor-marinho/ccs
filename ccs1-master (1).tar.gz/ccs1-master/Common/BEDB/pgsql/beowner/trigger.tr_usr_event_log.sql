SET bedb.filename = 'trigger.tr_usr_event_log.sql';

\i set_be_env.sql;

drop FUNCTION if exists beowner.trigger_fct_tr_usr_event_log cascade;

CREATE OR REPLACE FUNCTION beowner.trigger_fct_tr_usr_event_log() RETURNS trigger AS $BODY$
DECLARE
   c_new_active_primary    event_log.status%TYPE := 'NAP';
   c_new_active_secondary  event_log.status%TYPE := 'NAS';
   c_new_pending_primary   event_log.status%TYPE := 'NPP';
   c_new_pending_secondary event_log.status%TYPE := 'NPS';

   c_deleted_active_primary    event_log.status%TYPE := 'DAP';
   c_deleted_active_secondary  event_log.status%TYPE := 'DAS';
   c_deleted_pending_primary   event_log.status%TYPE := 'DPP';
   c_deleted_pending_secondary event_log.status%TYPE := 'DPS';

   l_is_primary   BOOLEAN := coalesce(new.parent_id, old.parent_id) IS NULL;
   l_is_secondary BOOLEAN := NOT l_is_primary;
   l_is_active    BOOLEAN := coalesce(new.verified, old.verified) IS NOT NULL;
   l_is_pending   BOOLEAN := NOT l_is_active;
   l_was_active   BOOLEAN := old.verified IS NOT NULL;

   l_usr_id     event_log.usr_id%TYPE := coalesce(new.usr_id, old.usr_id);
   l_status     event_log.status%TYPE;
   l_old_status event_log.old_status%TYPE;
   l_log_status TEXT;

   l_exception_diagnostics trc.EXCEPTION_DIAGNOSTICS;
BEGIN

   IF TG_OP = 'INSERT'
   THEN
      CASE
      -- New Active Primary
         WHEN l_is_primary AND
              l_is_active THEN
            l_status := c_new_active_primary;
            -- New Active Secondary. Never supposed to happen, but manual cases in Prod do exist
         WHEN l_is_secondary AND
              l_is_active THEN
            l_status := c_new_active_secondary;
            -- New Pending primary
         WHEN l_is_primary AND
              l_is_pending THEN
            l_status := c_new_pending_primary;
            -- New Pending Secondary
         WHEN l_is_secondary AND
              l_is_pending THEN
            l_status := c_new_pending_secondary;
         ELSE
            NULL;
      END CASE;
   ELSIF TG_OP = 'UPDATE'
   THEN
      CASE
      -- Pending Primary verified, hence converted to Active primary
         WHEN l_is_primary AND
              l_is_active AND
              NOT l_was_active THEN
            l_status := c_new_active_primary;
            l_old_status := c_new_pending_primary;
            -- Pending secondary verified, hence converted to Active secondary
         WHEN l_is_secondary AND
              l_is_active AND
              NOT l_was_active THEN
            l_status := c_new_active_secondary;
            l_old_status := c_new_pending_secondary;
         ELSE
            NULL;
      END CASE;
   ELSE
      -- deleting
      CASE
      -- deleted Active Primary
         WHEN l_is_primary AND
              l_is_active THEN
            l_status := c_deleted_active_primary;
            l_old_status := c_new_active_primary;
            -- deleted Active Secondary
         WHEN l_is_secondary AND
              l_is_active THEN
            l_status := c_deleted_active_secondary;
            l_old_status := c_new_active_secondary;
            -- deleted Pending primary
         WHEN l_is_primary AND
              l_is_pending THEN
            l_status := c_deleted_pending_primary;
            l_old_status := c_new_pending_primary;
            -- deleted Pending Secondary
         WHEN l_is_secondary AND
              l_is_pending THEN
            l_status := c_deleted_pending_secondary;
            l_old_status := c_new_pending_secondary;
         ELSE
            NULL;
      END CASE;
   END IF;

   IF l_status IS NOT NULL
   THEN

      call beowner.tg_update_event_log_sp(itype       => utl.get_constant_value('c_event_log_type_account'),
                                          iusrid      => l_usr_id,
                                          ivin        => NULL,
                                          istatus     => l_status,
                                          iold_status => l_old_status,
                                          ostatusrslt => l_log_status);
      IF l_log_status != utl.get_constant_value('csuccess')
      THEN
         call trc.log(iadditionaldata => 'Unable to log status ' || l_status || ' for user ' || l_usr_id);

      END IF;
   END IF;

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;

EXCEPTION
   WHEN OTHERS
    then
    GET STACKED diagnostics
      l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
      l_exception_diagnostics.column_name := COLUMN_NAME,
      l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
      l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
      l_exception_diagnostics.message_text := MESSAGE_TEXT,
      l_exception_diagnostics.table_name := TABLE_NAME,
      l_exception_diagnostics.schema_name := SCHEMA_NAME,
      l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
      l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
      l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

      CALL trc.log(iadditionaldata => 'Error in ' || current_setting('application_name') || ' for user ' || l_usr_id,
                   iexception_diagnostics => l_exception_diagnostics);
END
$BODY$
 LANGUAGE 'plpgsql';

CREATE TRIGGER tr_usr_event_log
  AFTER INSERT OR DELETE OR UPDATE ON beowner.usr
  FOR EACH ROW
  EXECUTE PROCEDURE beowner.trigger_fct_tr_usr_event_log();

\i cleanup.sql;
