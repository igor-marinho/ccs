SET bedb.filename = 'function.be_token_set_sp.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS beowner.be_token_set_sp(text, text, text, text, text);
CREATE OR REPLACE FUNCTION beowner.be_token_set_sp(iLoginID text,
                                                   iPartnerID text,
                                                   iEncodedToken text,
                                                   iVTType text,
                                                   iNumSecsExpire text,
                                                   oResult OUT refcursor) AS
$BODY$
DECLARE
    l_action                text;
    l_module_name           text := 'be_token_set_sp';
    vCount                  bigint;
    vRslt                   varchar(30);
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN

    vRslt := utl.get_constant_value('csuccess');

    l_action := utl.set_module_action(l_module_name, ' Setting Context');

    CALL ctx.set(iPtnrID => iPartnerID::uuid,
                    iLoginID => iLoginID);

    INSERT INTO beowner.validation_token(encoded_token, usr_id, vt_type, expire)
    SELECT iEncodedToken,
           cd.usr_id,
           iVTType,
           CURRENT_TIMESTAMP + ((iNumSecsExpire)::numeric * ('1' || 'SECOND')::interval)
    FROM beowner.ctx_data cd;

    OPEN oResult FOR
        SELECT vRslt;

EXCEPTION
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
        OPEN oResult FOR
            SELECT utl.get_constant_value('cinvalidparams');

    WHEN SQLSTATE 'EPTNR' THEN
        OPEN oResult FOR
            SELECT utl.get_constant_value('cdbpartneridnotvalid');

    WHEN SQLSTATE 'EUSRN' THEN
        OPEN oResult FOR
            SELECT utl.get_constant_value('cnosuchuser');

    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
        OPEN oResult FOR
            SELECT utl.get_constant_value('cinternalerror');

END;
$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON PROCEDURE be_token_set_sp ( iLoginID text, iPartnerID text, iEncodedToken text, iVTType text, iNumSecsExpire text, oResult out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
