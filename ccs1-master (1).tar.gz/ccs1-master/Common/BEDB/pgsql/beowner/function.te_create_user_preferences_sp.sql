SET bedb.filename = 'function.te_create_user_preferences_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS beowner.te_create_user_preferences_sp(text, text, text, text, text, text); -- old proc
DROP FUNCTION IF EXISTS beowner.te_create_user_preferences_sp(text, text, text, text, text);
CREATE OR REPLACE FUNCTION beowner.te_create_user_preferences_sp(userloginid_i text,
                                                                 list_name_i text,
                                                                  user_data_i text,
                                                                  service_id_i text,
                                                                  partnerid_i text,
                                                                  OUT recordset_o refcursor) AS
$BODY$
DECLARE
    l_action      text;
    l_module_name text := 'te_create_user_preferences_sp';
    vRslt         text;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN

    l_action := utl.set_module_action(l_module_name, ' Setting Context');

    CALL ctx.set(iPtnrID => partnerid_i::uuid,
                    iLoginID => userloginid_i);

    l_action := utl.set_module_action(l_module_name, ' Calling TG Create Preferences');

    vRslt := beowner.tg_create_user_preferences_sp(iLstName => list_name_i,
                                  iSvcID => service_id_i,
                                  iData => user_data_i);


    OPEN recordset_o FOR
        SELECT vRslt;

EXCEPTION

    WHEN SQLSTATE 'EPTNR' THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cdbpartneridnotvalid');

    WHEN SQLSTATE 'EUSRN' THEN
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cnosuchuser');

    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;


        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
        OPEN recordset_o FOR
            SELECT utl.get_constant_value('cinternalerror');
END;
$BODY$
    LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE te_create_user_preferences_sp ( userloginid_i text, list_name_i text, user_data_i text, service_id_i text, partnerid_i text, recordset_o out REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
