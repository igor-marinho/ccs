SET bedb.filename = 'function.be_get_access_token_sp.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION be_token.be_get_access_token_sp ( iuserLoginId usr.login_id%TYPE, ipartnerId ptnr.ptnr_id%TYPE, oResultSet OUT REFCURSOR ) AS $body$
DECLARE
      l_module_name text := 'be_get_access_token_sp';


     vcnt bigint;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN

	PERFORM utl.set_module_action( l_module_name,  ' Setting Context for input: '||'User Login Id: '|| iuserLoginId||' \& '||'Partner Id: '||ipartnerId);

      /* in case NULL is returned in the "ctx.set"... */
      oResultSet := utl.get_dummy_cursor;

      PERFORM ctx.set( iPtnrID	  => ipartnerId, iLoginID   => iuserLoginId );

      select count(*) into STRICT vcnt FROM beowner.validation_token vt, ctx_data ctx
	   WHERE lower(ctx.usr_id)=lower(vt.usr_id)
		       AND vt.vt_type = 'pwd_token';
      RAISE NOTICE 'vcnt:%', vcnt;

     OPEN oResultSet
      FOR SELECT vt.encoded_token
	    FROM beowner.validation_token vt, ctx_data ctx
	   WHERE lower(ctx.usr_id)=lower(vt.usr_id)
		       AND vt.vt_type = 'pwd_token';

     RETURN;

   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
	 RETURN utl.get_constant_value('cdbpartneridnotvalid');
      WHEN SQLSTATE 'EUSRN' THEN
	 RETURN utl.get_constant_value('cnosuchuser');
      WHEN OTHERS
      THEN
	 GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

        perform trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
	 RETURN utl.get_constant_value('cinternalerror');

   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION be_token.be_get_access_token_sp ( iuserLoginId usr.login_id%TYPE, ipartnerId ptnr.ptnr_id%TYPE, oResultSet OUT REFCURSOR ) FROM PUBLIC;


\i cleanup.sql;
