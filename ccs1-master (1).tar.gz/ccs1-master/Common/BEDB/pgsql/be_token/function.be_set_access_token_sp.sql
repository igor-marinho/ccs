SET bedb.filename = 'function.be_set_access_token_sp.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION be_token.be_set_access_token_sp ( iuserLoginId usr.login_id%TYPE, ipartnerId ptnr.ptnr_id%TYPE, iaccessToken validation_token.encoded_token%TYPE ) RETURNS numeric AS $body$
DECLARE
      l_module_name text := 'be_set_access_token_sp';


	vUserId		usr.usr_id%TYPE;
	vMakeId		usr.make_id%TYPE;
	vPwd		  usr.pwd%TYPE;
  vCnt	    bigint;
   ecode bigint;
   emesg varchar(200);
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN

	PERFORM utl.set_module_action( l_module_name,  ' Setting Context for input: '||'User Login Id: '|| iuserLoginId||' \& '||'Partner Id: '||ipartnerId);

	------------------------------------
	/* use CTX.SET... */
	PERFORM ctx.set( iPtnrID    => ipartnerId , iLoginID   => iuserLoginId);
	------------------------------------
	-- after this ctx.set ensure that 'make_id' matches 'parterid' & 'usr.login_id' matches "usr" table...
  BEGIN
    select usr_id,make_id,pwd
      into STRICT vUserId,vMakeId,vPwd
      from usr
      where login_id=iUserLoginId;
  exception
    when no_data_found then
	    RAISE NOTICE 'Login ID: % DOES NOT EXISTS!', iuserLoginId;
      RAISE EXCEPTION USING errcode = utl.get_constant_value('e_vinnotfound');
  END;

  BEGIN

    select count(*) into STRICT vCnt from beowner.validation_token where usr_id = vUserID and vt_type = 'pwd_token';

    if (vCnt > 0) then

       delete from beowner.validation_token where usr_id = vUserID and vt_type = 'pwd_token';  -- added for defect 13009 to prevent any duplicate entries of usr_ID,vt_type pairs.
    end if;

    merge into beowner.validation_token t1
      using( SELECT iaccessToken as encoded_token, vUserId as usr_id, 'pwd_token' as vt_type , CURRENT_TIMESTAMP as created,
		    CURRENT_TIMESTAMP as resolved, CURRENT_TIMESTAMP+30 as expire  ) t2
      on (t1.encoded_token = t2.encoded_token)
      when matched then update set t1.usr_id = t2.usr_id, t1.vt_type = t2.vt_type, t1.created=t2.created, t1.resolved=t2.resolved,t1.expire=t2.expire
      when not matched then insert(t1.encoded_token,t1.usr_id,t1.vt_type,t1.created,t1.resolved,t1.expire)
			    values (t2.encoded_token,t2.usr_id,t2.vt_type,t2.created,t2.resolved,t2.expire);

  	exception
      when unique_violation then
	   RETURN utl.get_constant_value('csuccess');
	END;

	  RETURN utl.get_constant_value('csuccess');

	EXCEPTION
	   WHEN SQLSTATE 'EPTNR'
	   THEN
	      RETURN utl.get_constant_value('cdbpartneridnotvalid');
	   WHEN SQLSTATE 'EUSRN'
	   THEN

	   -- write out the true error that user/partnerid/make_id does not exists...
	      RETURN utl.get_constant_value('cnosuchuser');
	   WHEN OTHERS
	   THEN
	      GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

        perform trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
	 RETURN utl.get_constant_value('cinternalerror');

END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION be_token.be_set_access_token_sp ( iuserLoginId usr.login_id%TYPE, ipartnerId ptnr.ptnr_id%TYPE, iaccessToken validation_token.encoded_token%TYPE ) FROM PUBLIC;

\i cleanup.sql;
