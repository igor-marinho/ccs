SET bedb.filename = 'function.g_generic_make_id.sql';

\i set_be_env.sql;

create OR REPLACE FUNCTION messages.g_generic_make_id() RETURNS varchar AS
$body$
begin
  return '00';

END;
$body$
LANGUAGE PLPGSQL
IMMUTABLE;

\i cleanup.sql;
