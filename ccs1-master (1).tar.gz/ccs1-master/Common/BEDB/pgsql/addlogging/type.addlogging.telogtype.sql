SET bedb.filename = 'type.addlogging.telogtype.sql';

\i set_be_env.sql;

DROP TYPE IF EXISTS addlogging.telogtype CASCADE;

CREATE TYPE addlogging.telogtype AS (
	user_agent TEXT,
	tel_email_address1 TEXT,
	tel_serviceid TEXT,
	tel_type TEXT,
	tel_log TEXT,
	tel_device_latitude TEXT,
	tel_device_longitude TEXT,
	tel_partnerid TEXT,
	tel_strike_time TIMESTAMP WITH TIME ZONE,
	tel_duration TEXT,
	tel_status TEXT,
	tel_mdeviceid TEXT,
	tel_hdeviceid TEXT,
	tel_command TEXT,
	tel_transaction_id TEXT,
	tel_3pp_id TEXT,
	tel_connection_time TEXT,
	tel_client_content TEXT,
	tel_vin TEXT,
	tel_hu_make TEXT,
	tel_hu_country TEXT,
	tel_hu_region TEXT,
	tel_muniqueid TEXT,
	tel_huniqueid TEXT);
	
\i cleanup.sql;
