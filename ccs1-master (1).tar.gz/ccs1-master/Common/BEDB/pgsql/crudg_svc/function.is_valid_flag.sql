SET bedb.filename = 'function.is_valid_flag.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION crudg_svc.is_valid_flag (i_flag text) RETURNS boolean AS $body$
BEGIN
      IF i_flag NOT IN (' ', '*')
      THEN
         RETURN FALSE;
      ELSE
         RETURN TRUE;
      END IF;


   END;

   -- Removed Function cr_svc_sp for DCS1E-605
   -- Removed Function u_svc_sp for DCS1E-605
   -- Removed Function d_svc_sp for DCS1E-605
   -- get service
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION crudg_svc.is_valid_flag (i_flag text) FROM PUBLIC;

\i cleanup.sql;
