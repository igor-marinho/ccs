SET bedb.filename = 'function.g_svc_sp.sql';

\i set_be_env.sql;

/*
   FUNCTION g_svc_sp
           in:  i_svc_id, i_name, i_version
           out: success/failure
           out: (refcursor) svc_id, name, description, handler, auth, black_white_lst, contract_required, allow_secondary, never_expires, always_available, ev_service, similar_570_service,  version
           Not implemented yet : duration, avail_date, end_date. i_version is returned as is in the output ref cursor.

           If neither i_svc_id, nor i_name are provided, all services will be returned

    Error Codes returned :
        c_invalid_svc_id               237      Invalid Service Id.
*/

-- get service
DROP FUNCTION IF EXISTS crudg_svc.g_svc_sp(text, text, text);
CREATE OR REPLACE FUNCTION crudg_svc.g_svc_sp(i_svc_id text,
                                              i_name text,
                                              i_version text,
                                              o_status_code OUT integer,
                                              o_result OUT refcursor) AS
$body$
DECLARE
    l_action      text;
    l_module_name text := 'g_svc_sp';
BEGIN
    o_result := utl.get_dummy_cursor(); -- Jira PU-391
    IF coalesce(i_svc_id, '') != '' AND
       NOT utl.is_service_id_valid(i_svc_id)
    THEN
        o_status_code := utl.get_constant_value('c_invalid_svc_id');
        RETURN;
    ELSE
        l_action := utl.set_module_action(l_module_name,
                                          'Before query in G_SVC_SP i_svc_id = ' ||
                                          i_svc_id || ' name = ' || i_name);

        CLOSE o_result;
        OPEN o_result FOR
            SELECT svc_id,
                   NAME,
                   description,
                   handler,
                   auth,
                   black_white_lst,
                   contract_required,
                   allow_secondary,
                   never_expires,
                   always_available,
                   ev_service,
                   similar_570_service,
                   i_version AS version
            FROM beowner.svc s
            WHERE s.svc_id = coalesce(i_svc_id, s.svc_id)
              AND s.name = coalesce(i_name, s.name)
            ORDER BY (s.svc_id)::integer;
        o_status_code := utl.get_constant_value('csuccess');
        RETURN;
    END IF;
END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
STABLE;
-- REVOKE ALL ON FUNCTION crudg_svc.g_svc_sp (i_svc_id text, i_name text, i_version text, o_result OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
