SET bedb.filename = 'function.g_color.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION crudg_vin.g_color() RETURNS varchar as $body$
begin
  return crudg_vin.g_no_value();
END;
$body$
LANGUAGE PLPGSQL
IMMUTABLE;

\i cleanup.sql;
