SET bedb.filename = 'function.u_vin_sp.sql';

\i set_be_env.sql;
  
   --------------------------------------------------------------------------------------------------------------------------------------------------------
   /*
   Return Code :
   Success cSuccess  '0'
   
   Error Codes returned :
     cinternalerror                 constant vc := '1'      ; -- Internal Error
     cDeviceIDDoesNotExist          constant vc := '38'     ; -- The HU Type/Device ID does not exist in the Device table
     cInvalidMake                   constant vc := '222'    ; -- Invalid Make ID
     c_invalid_model                constant vc := '232'    ; -- Model is null. Added for OnTime WI #8878
     c_invalid_year                 constant vc := '233'    ; -- Year is null. Added for OnTime WI #8878
     c_invalid_vin                  constant vc := '234'    ; -- VIN is null. Added for OnTime WI #8878
     cDbVinNotFound                 constant vc := '200'    ; -- System was passed a VIN which was not found.
   */

   /* Overloaded u_vin_sp for CR10212 - for additional parameter ibatch_guid */
DROP FUNCTION IF EXISTS crudg_vin.u_vin_sp( TEXT, TEXT,TEXT,TEXT,TEXT,TIMESTAMPTZ, TEXT,TEXT,TEXT,UUID);
CREATE OR REPLACE FUNCTION crudg_vin.u_vin_sp(IN ivin TEXT DEFAULT NULL,  
                                              IN imake TEXT DEFAULT NULL, 
                                              IN imodel TEXT DEFAULT NULL, 
                                              IN iyr TEXT DEFAULT NULL, 
                                              IN ihu_type TEXT DEFAULT NULL, 
                                              IN idofu TIMESTAMPTZ DEFAULT NULL, 
                                              IN iversion TEXT DEFAULT NULL, 
                                              IN imodel_code TEXT DEFAULT NULL, 
                                              IN icolor TEXT DEFAULT NULL, 
                                              IN ibatch_guid UUID DEFAULT NULL)
RETURNS INTEGER
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'u_vin_sp';
    vvin beowner.vin.vin%TYPE;
    vmake beowner.vin.make_id%TYPE;
    ctvin beowner.vin.vin%TYPE;
    ctmake beowner.vin.make_id%TYPE;
    vmodel beowner.vin.model%TYPE;
    vyr beowner.vin.year%TYPE;
    vhu_type beowner.vin.device_id%TYPE;
    vversion varchar(100);
    vdevice_id beowner.vin.device_id%TYPE;
    vfactory_flag beowner.vin.factory_flag%TYPE := crudg_vin.g_factory_flag();
    vdealer_flag beowner.vin.dealer_flag%TYPE := crudg_vin.g_dealer_flag();
    vmodel_code beowner.vin.model_code%TYPE := crudg_vin.g_model_code();
    vcolor beowner.vin.color%TYPE := crudg_vin.g_color();
    vdofu beowner.vin.dofu%TYPE;
    vcontract_id beowner.vin.contract_id%TYPE := NULL;
    vmeid beowner.vin.meid%TYPE := NULL;
    ct_transaction_id beowner.VIN.transaction_id%TYPE;
/* WI #14078 */
     l_exception_diagnostics trc.exception_diagnostics;
BEGIN

    select vin, make_id, transactionid
      INTO STRICT ctvin, ctmake, ct_transaction_id
      FROM beowner.ctx_data;
       
    vvin := COALESCE(UPPER(TRIM(ivin)), ctvin);
    vmake := imake;
    vmodel := imodel;
    vyr := iyr;
    vhu_type := ihu_type;
    
    IF ibatch_guid IS NOT NULL AND
     idofu IS NOT NULL -- Jira CR10212-32
    THEN
        l_action :=  utl.set_module_action( l_module_name || ' RDR', 'Validating inputs');    
    ELSE
        l_action :=  utl.set_module_action( l_module_name , 'Validating inputs'); 
    END IF;
    /* modified for WI #14078 to only validate vin and other non null inputs. For others, the existing values will be retained */

    IF vvin IS NULL THEN
        RETURN utl.get_constant_value('c_invalid_vin');
    ELSIF imake IS NOT NULL AND NOT utl.is_make_valid(i_make_id := vmake)
    THEN
        RETURN utl.get_constant_value('cinvalidmake');
    ELSIF vhu_type IS NOT NULL AND NOT utl.is_device_id_valid(i_device_id := vhu_type)
    THEN
        RETURN utl.get_constant_value('cdeviceiddoesnotexist');
    END if
    
    /*
    Commented out for WI #14078
          ELSIF vmodel IS NULL
        THEN
           RETURN cnst.c_invalid_model;
        ELSIF vyr IS NULL
        THEN
           RETURN cnst.c_invalid_year;
        END IF;
    */;

    IF vmake != 'DG'
    /* Defect 16524 needed to add model code and color to primitive to handle Lexus/Toyota calls */
    THEN
        vmodel_code := COALESCE(imodel_code, vmodel_code);
        vcolor := COALESCE(icolor, vcolor);
    END IF;
   
    select vin, COALESCE(make_id, ctmake), model, year, device_id, dofu, dealer_flag, model_code, color
      INTO STRICT vvin, vmake, vmodel, vyr, vhu_type, vdofu, vdealer_flag, vmodel_code, vcolor
      FROM beowner.vin
      WHERE vin = vvin;

    l_action :=  utl.set_action( 'Before update in U_VIN_SP ');       

    IF (idofu IS NOT NULL)
    THEN
        vdofu := idofu;
        vdealer_flag := '1';
    END if;
   
    /* Added transaction_id for OnTime WI #14078 */
    UPDATE beowner.vin
    SET make_id = COALESCE(UPPER(TRIM(imake)), vmake),
        model = COALESCE(UPPER(TRIM(imodel)), vmodel),
        year = COALESCE(UPPER(TRIM(iyr)), vyr),
        device_id = COALESCE(UPPER(TRIM(ihu_type)), device_id),
        dofu = vdofu,
        dealer_flag = vdealer_flag,
        model_code = COALESCE(UPPER(TRIM(imodel_code)), vmodel_code), /* Defect 16524 needed to add model code and color to primitive to handle Lexus/Toyota calls */
        color = COALESCE(UPPER(TRIM(icolor)), vcolor), /* Defect 16524 needed to add model code and color to primitive to handle Lexus/Toyota calls */
        transaction_id = ct_transaction_id
    WHERE vin = vvin;
       
    RETURN utl.get_constant_value('csuccess');
   
EXCEPTION
    WHEN no_data_found THEN
        RETURN utl.get_constant_value('cdbvinnotfound');
    WHEN others THEN
       GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
          call trc.log(iadditionaldata => 'vin=' || vvin ||
                              ' make=' || vmake || ' model =' ||
                              vmodel || ' year=' || vyr ||
                              ' device_id=' || vhu_type ||
                              ' dofu=' || vdofu,
                        iexception_diagnostics => l_exception_diagnostics);                           
        RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
