SET bedb.filename = 'function.g_invalid_value.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION crudg_vin.g_invalid_value() RETURNS varchar as $body$
begin
  return '---'; 
END;
$body$
LANGUAGE PLPGSQL
IMMUTABLE;

\i cleanup.sql;
