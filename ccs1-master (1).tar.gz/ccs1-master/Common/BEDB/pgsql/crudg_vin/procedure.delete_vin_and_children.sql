SET bedb.filename = 'procedure.delete_vin_and_children.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS crudg_vin.delete_vin_and_children(beowner.vin.vin%type,
    INOUT integer,
    INOUT beowner.data_fix_results,
    beowner.data_fix_results.detail_guid%type,
    beowner.usr.login_id%type,
    beowner.usr.usr_id%type,
    beowner.subscription.subscription_id%type,
    text,
    beowner.data_fix_batches.batch_guid%type);
CREATE OR REPLACE PROCEDURE crudg_vin.delete_vin_and_children(IN i_vin beowner.vin.vin%type,
                                                              INOUT io_return_code integer,
                                                              INOUT io_batch_results beowner.data_fix_results,
                                                              IN i_detail_guid beowner.data_fix_results.detail_guid%type,
                                                              IN i_login_id beowner.usr.login_id%type,
                                                              IN i_usr_id beowner.usr.usr_id%type,
                                                              IN i_subscription_id beowner.subscription.subscription_id%type,
                                                              IN i_module_name text,
                                                              IN i_batch_guid beowner.data_fix_batches.batch_guid%type DEFAULT NULL) AS
$body$
DECLARE
    l_action         text;
    l_module_name    text := 'delete_vin_and_children';
    l_transaction_id beowner.vin.transaction_id%type;

BEGIN
    -- include vin_subscription too, even though not necessary for TMS, since TMS QA has these
    -- subscription would've been deleted before as a part of delete user
    l_action := utl.set_module_action(l_module_name, 'Deleting VIN');

    SELECT transactionid
    INTO STRICT l_transaction_id
    FROM beowner.ctx_data;

    DELETE
    FROM beowner.tm_vin_contract_start
    WHERE vin = i_vin;

    -- so that transaction_id shows up in delete history
    IF l_transaction_id IS NOT NULL
    THEN
        UPDATE beowner.vin_subscription
        SET tranid = l_transaction_id
        WHERE vin = i_vin;

        UPDATE beowner.vin
        SET transaction_id = l_transaction_id
        WHERE vin = i_vin;
    END IF;

    DELETE
    FROM beowner.vin_subscription
    WHERE vin = i_vin;

    DELETE
    FROM beowner.vin
    WHERE vin = i_vin;
EXCEPTION
    WHEN foreign_key_violation THEN
        io_return_code = utl.get_constant_value('c_vin_delete_error');
        CALL crudg_vin.handle_error(io_return_code,
                                    io_batch_results,
                                    i_detail_guid,
                                    i_login_id,
                                    i_usr_id,
                                    i_subscription_id,
                                    i_module_name,
                                    i_batch_guid);
END;
$body$ LANGUAGE plpgsql
\i cleanup.sql;
