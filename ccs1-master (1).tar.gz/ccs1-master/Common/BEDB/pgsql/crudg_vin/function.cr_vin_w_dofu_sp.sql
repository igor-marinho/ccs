SET bedb.filename = 'function.cr_vin_w_dofu_sp.sql';

\i set_be_env.sql;
  
   -- Renamed to avoid overloading issue for MT for now. Once MT is able to handle function calls using named parameters, this will be renamed back to cr_vin_sp
 -- Removed column mac_addr for DCS1E-921

CREATE OR REPLACE FUNCTION crudg_vin.cr_vin_w_dofu_sp(IN ivin TEXT, IN imake TEXT DEFAULT NULL, IN imodel TEXT DEFAULT NULL, IN iyr TEXT DEFAULT NULL, IN ihu_type TEXT DEFAULT NULL, IN idofu TIMESTAMP WITH TIME ZONE DEFAULT NULL, IN iversion TEXT DEFAULT NULL, IN imodel_code TEXT DEFAULT NULL, IN icolor TEXT DEFAULT NULL)
RETURNS INTEGER
AS
$BODY$
DECLARE
      l_module_name text := 'cr_vin_w_dofu_sp';
    vvin BEOWNER.vin.vin%TYPE;
    vmake BEOWNER.vin.make_id%TYPE;
    ctvin BEOWNER.vin.vin%TYPE;
    ctmake BEOWNER.vin.make_id%TYPE;
    vmodel BEOWNER.vin.model%TYPE;
    vyr BEOWNER.vin.year%TYPE;
    vhu_type BEOWNER.vin.device_id%TYPE;
    vversion CHARACTER VARYING(100);
    vdevice_id BEOWNER.vin.device_id%TYPE;
    vfactory_flag BEOWNER.vin.factory_flag%TYPE := crudg_vin.g_factory_flag();
    vdealer_flag BEOWNER.vin.dealer_flag%TYPE := crudg_vin.g_dealer_flag();
    vmodel_code BEOWNER.vin.model_code%TYPE := crudg_vin.g_model_code();
    vcolor BEOWNER.vin.color%TYPE := crudg_vin.g_color();
    vdofu BEOWNER.vin.dofu%TYPE;

    vcontract_id BEOWNER.vin.contract_id%TYPE := NULL;
    vmeid BEOWNER.vin.meid%TYPE := NULL;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN

    SELECT
        vin, make_id
        INTO STRICT ctvin, ctmake
        FROM beowner.ctx_data;
    vvin := COALESCE(UPPER(TRIM(ivin)), ctvin);
    vmake := COALESCE(UPPER(TRIM(imake)), ctmake);
    vmodel := UPPER(TRIM(imodel));
    vyr := COALESCE(UPPER(TRIM(iyr)), TO_CHAR(clock_timestamp(), 'YYYY'));
    vhu_type := UPPER(TRIM(ihu_type));
    vdofu := COALESCE(idofu, clock_timestamp());
    PERFORM utl.set_module_action( l_module_name,  
                            
                           'Starting CR_VIN_W_DOFU_SP - vin=' || vvin ||
                           ' make=' || vmake || ' model =' ||
                           vmodel || ' year=' || vyr ||
                           ' device_id=' || vhu_type || ' dofu=' ||
                           vdofu);

    IF vvin IS NULL THEN
        RETURN cnst.gdbnovaliddatainput();
    END IF;

    IF vmake IS NULL THEN
        RETURN cnst.gdbnovaliddatainput();
    END IF;

    IF vhu_type IS NULL THEN
        RETURN cnst.gdbnovaliddatainput();
    END IF;

    IF vmake != 'DG'
    /* Defect 16524 needed to add model code and color to primitive to handle Lexus/Toyota calls */
    THEN
        vmodel_code := COALESCE(imodel_code, vmodel_code);
        vcolor := COALESCE(icolor, vcolor);
    END IF;
   
    INSERT INTO beowner.vin (vin, make_id, device_id, factory_flag, dealer_flag, model_code, model, year, color, dofu,  contract_id, meid)
    VALUES (vvin, vmake, vhu_type, vfactory_flag, vdealer_flag, vmodel_code, vmodel, vyr, vcolor, vdofu,  vcontract_id, vmeid);
   
    RETURN utl.get_constant_value('csuccess');
   
    EXCEPTION
        WHEN others THEN
            PERFORM utl.set_module_action( l_module_name,  
                                   
                                  'Something went really wrong in CR_VIN_W_DOFU_SP with dofu - vin=' || vvin ||
                                  ' make=' || vmake || ' model =' ||
                                  vmodel || ' year=' || vyr ||
                                  ' device_id=' || vhu_type ||
                                  ' dofu=' || vdofu);

            GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,              
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

            perform trc.log(iadditionaldata => NULL,
                            iexception_diagnostics => l_exception_diagnostics);
                           
            return utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
