SET bedb.filename = 'function.cr_vin_sp.sql';

\i set_be_env.sql;
  
   /*
   Return Code :
   Success cSuccess  '0'
   
   Error Codes returned :
     cinternalerror                 constant vc := '1'      ; -- Internal Error
     cDeviceIDDoesNotExist          constant vc := '38'    ; -- The HU Type/Device ID does not exist in the Device table
     cInvalidMake                   constant vc := '222'    ; -- Invalid Make ID
     c_invalid_model                constant vc := '232'    ; -- Model is null. Added for OnTime WI #8878
     c_invalid_year                 constant vc := '233'    ; -- Year is null. Added for OnTime WI #8878
     c_invalid_vin                  constant vc := '234'    ; -- VIN is null. Added for OnTime WI #8878
     c_duplicate_VIN                constant vc := '294'    ; -- VIN already exists    
   
   */
 -- Removed column mac_addr for DCS1E-921
DROP FUNCTION IF EXISTS crudg_vin.cr_vin_sp(TEXT,TEXT,TEXT,TEXT,TEXT,TEXT,TEXT,TEXT);
CREATE OR REPLACE FUNCTION crudg_vin.cr_vin_sp(IN ivin TEXT, 
                                               IN imake TEXT DEFAULT NULL, 
                                               IN imodel TEXT DEFAULT NULL, 
                                               IN iyr TEXT DEFAULT NULL, 
                                               IN ihu_type TEXT DEFAULT NULL, 
                                               IN iversion TEXT DEFAULT NULL, 
                                               IN imodel_code TEXT DEFAULT NULL, 
                                               IN icolor TEXT DEFAULT NULL)
RETURNS INTEGER
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'cr_vin_sp';
    vvin beowner.vin.vin%TYPE;
    vmake beowner.vin.make_id%TYPE;
    ctvin beowner.vin.vin%TYPE;
    ctmake beowner.vin.make_id%TYPE;
    vmodel beowner.vin.model%TYPE;
    vyr beowner.vin.year%TYPE;
    vhu_type beowner.vin.device_id%TYPE;
    vversion varchar(100);
    vdevice_id beowner.vin.device_id%TYPE;
    vfactory_flag beowner.vin.factory_flag%TYPE := crudg_vin.g_factory_flag();
    vdealer_flag beowner.vin.dealer_flag%TYPE := crudg_vin.g_dealer_flag();
    vdofu beowner.vin.dofu%TYPE := NULL;

    vcontract_id beowner.vin.contract_id%TYPE := NULL;
    vmeid beowner.vin.meid%TYPE := NULL;
    vmodel_code beowner.vin.model_code%TYPE := crudg_vin.g_model_code();
    vcolor beowner.vin.color%TYPE := crudg_vin.g_color();
    ct_transaction_id beowner.VIN.transaction_id%TYPE;
    /* WI #14078 */
    l_exception_diagnostics trc.exception_diagnostics;
      
BEGIN

    l_action := utl.set_module_action( l_module_name, 'Starting CR_VIN_SP ') ;

    SELECT vin, make_id, transactionid
      INTO STRICT ctvin, ctmake, ct_transaction_id
      FROM beowner.ctx_data;
       
    vvin := COALESCE(UPPER(TRIM(ivin)), ctvin);
    vmake := imake;
    vmodel := imodel;
    vyr := iyr;
    vhu_type := ihu_type;
    
    l_action := utl.set_action( 'Validating inputs') i;

    IF vvin IS NULL THEN
        RETURN utl.get_constant_value('c_invalid_vin');
    ELSIF imake IS NULL OR NOT utl.is_make_valid(i_make_id := vmake) THEN
        RETURN utl.get_constant_value('cinvalidmake');
    ELSIF vhu_type IS NULL OR NOT utl.is_device_id_valid(i_device_id := vhu_type) THEN
        RETURN utl.get_constant_value('cdeviceiddoesnotexist');
    ELSIF vmodel IS NULL THEN
        RETURN utl.get_constant_value('c_invalid_model');
    ELSIF vyr IS NULL THEN
        RETURN utl.get_constant_value('c_invalid_year');
    END IF;

    IF vmake != 'DG'
    /* Defect 16524 needed to add model code and color to primitive to handle Lexus/Toyota calls */
    THEN
        vmodel_code := COALESCE(imodel_code, vmodel_code);
        vcolor := COALESCE(icolor, vcolor);
    END IF
    /* Added transaction_id for OnTime WI #14078 */;
    INSERT INTO beowner.vin (vin, make_id, device_id, factory_flag, dealer_flag, model_code, model, year, color, dofu,  contract_id, meid, transaction_id)
    VALUES (vvin, vmake, vhu_type, vfactory_flag, vdealer_flag, vmodel_code, vmodel, vyr, vcolor, vdofu, vcontract_id, vmeid, ct_transaction_id);
   
    RETURN utl.get_constant_value('csuccess');
   
    EXCEPTION
        WHEN unique_violation THEN
            RETURN utl.get_constant_value('c_duplicate_vin');
        /* VIN already exists */
        WHEN others THEN
            GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,              
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;
              
            call trc.log(iadditionaldata => 'vin=' || vvin ||
                                  ' make=' || vmake || ' model =' ||
                                  vmodel || ' year=' || vyr ||
                                  ' device_id=' || vhu_type,
                            iexception_diagnostics => l_exception_diagnostics);
                           
            RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
