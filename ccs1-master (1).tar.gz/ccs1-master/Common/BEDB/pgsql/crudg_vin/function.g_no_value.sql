SET bedb.filename = 'function.g_no_value.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION crudg_vin.g_no_value() RETURNS varchar as $body$
begin
  return 'EMPTY_DATA';
END;
$body$
LANGUAGE PLPGSQL
IMMUTABLE;

\i cleanup.sql;
