SET bedb.filename = 'function.g_vin_sp.sql';

\i set_be_env.sql;
  
   --------------------------------------------------------------------------------------------------------------------------------------------------------
   /*
   Return Code :
   Success cSuccess  '0'
   
   Error Codes returned :
     cinternalerror                 constant vc := '1'      ; -- Internal Error
     cDbVinNotFound                 constant vc := '200'    ; -- System was passed a VIN which was not found.
     c_invalid_vin                  constant vc := '234'    ; -- VIN is null. Added for OnTime WI #8878
   */

 -- Removed column mac_addr for DCS1E-921
DROP FUNCTION IF EXISTS crudg_vin.g_vin_sp (text, text, text, text, text, text, text);
CREATE OR REPLACE FUNCTION crudg_vin.g_vin_sp(IN ivin TEXT DEFAULT NULL, 
                                              IN imake TEXT DEFAULT NULL, 
                                              IN imodel TEXT DEFAULT NULL, 
                                              IN iyr TEXT DEFAULT NULL, 
                                              IN ihu_type TEXT DEFAULT NULL, 
                                              IN iversion TEXT DEFAULT NULL, 
                                              IN idofu TEXT DEFAULT NULL, 
                                              OUT o_status_code INTEGER,
                                              OUT rslt REFCURSOR)
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'g_vin_sp';
    vvin BEOWNER.vin.vin%TYPE;

    ctvin BEOWNER.vin.vin%TYPE;
    ctmake BEOWNER.vin.make_id%TYPE;

BEGIN
    -- TODO remove input params imake,imodel,iyr,ihu_type,iversion,idofu...they are not used
    rslt := utl.get_dummy_cursor();
   
    SELECT
        vin, make_id
        INTO STRICT ctvin, ctmake
        FROM beowner.ctx_data;
       
    vvin := COALESCE(UPPER(TRIM(ivin)), ctvin);

    IF vvin IS NULL THEN
        o_status_code := utl.get_constant_value('c_invalid_vin');
        RETURN;
    END IF;
    
    l_action := utl.set_module_action( l_module_name, 'Before query in G_VIN_SP');    

    SELECT vin
      INTO STRICT vvin
      FROM beowner.vin
     WHERE vin = vvin;
    
    CLOSE rslt;
   
    OPEN rslt FOR
    SELECT
        vin, make_id, device_id, factory_flag, dealer_flag, model_code, model, year, color, dofu,  contract_id, meid, transaction_id
        FROM beowner.vin
        WHERE vin = vvin;
       
    o_status_code := utl.get_constant_value('csuccess');
   
    RETURN;
    EXCEPTION
        WHEN no_data_found THEN
            rslt := utl.get_dummy_cursor();
            o_status_code := utl.get_constant_value('cdbvinnotfound');
            RETURN;
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
