SET bedb.filename = 'procedure.handle_error.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS crudg_vin.handle_error(INOUT integer,
    INOUT beowner.data_fix_results,
    IN beowner.data_fix_results.detail_guid%type,
    IN beowner.usr.login_id%type,
    IN beowner.usr.usr_id%type,
    IN beowner.subscription.subscription_id%type,
    IN text,
    IN beowner.data_fix_batches.batch_guid%type);
CREATE OR REPLACE PROCEDURE crudg_vin.handle_error(INOUT io_return_code integer,
                                                   INOUT io_batch_results beowner.data_fix_results,
                                                   IN i_detail_guid beowner.data_fix_results.detail_guid%type,
                                                   IN i_login_id beowner.usr.login_id%type,
                                                   IN i_usr_id beowner.usr.usr_id%type,
                                                   IN i_subscription_id beowner.subscription.subscription_id%type,
                                                   IN i_module_name text,
                                                   IN i_batch_guid beowner.data_fix_batches.batch_guid%type DEFAULT NULL) AS
$body$
BEGIN
    IF io_return_code = utl.get_constant_value('csuccess')::integer
    THEN
        RETURN;
    END IF;
    IF i_batch_guid IS NOT NULL
    THEN
        io_batch_results.status := coalesce(io_batch_results.status,
                                     io_return_code::text);
        CALL crudg_vin.log_batch_result_row(i_batch_guid,
                                            i_detail_guid,
                                            i_login_id,
                                            i_usr_id,
                                            i_subscription_id,
                                            i_module_name,
                                            io_batch_results);
        io_return_code := utl.get_constant_value('csuccess');  -- since 0 should be returned to portal after logging into RRR
    ELSE
        RAISE EXCEPTION USING ERRCODE = utl.get_constant_value('e_deprecated');
    END IF;
END;


$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE crudg_vin.handle_error () FROM PUBLIC;

\i cleanup.sql;
