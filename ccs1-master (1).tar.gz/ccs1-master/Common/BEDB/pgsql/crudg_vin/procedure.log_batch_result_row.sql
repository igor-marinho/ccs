SET bedb.filename = 'procedure.log_batch_result_row.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS crudg_vin.log_batch_result_row(beowner.data_fix_batches.batch_guid%type,
    beowner.data_fix_results.detail_guid%type,
    beowner.usr.login_id%type,
    beowner.usr.usr_id%type,
    beowner.subscription.subscription_id%type,
    text,
    INOUT beowner.data_fix_results);
CREATE OR REPLACE PROCEDURE crudg_vin.log_batch_result_row(IN i_batch_guid beowner.data_fix_batches.batch_guid%type,
                                                           IN i_detail_guid beowner.data_fix_results.detail_guid%type,
                                                           IN i_login_id beowner.usr.login_id%type,
                                                           IN i_usr_id beowner.usr.usr_id%type,
                                                           IN i__subscription_id beowner.subscription.subscription_id%type,
                                                           IN i_module_name text,
                                                           INOUT io_batch_results beowner.data_fix_results) AS
$body$
BEGIN
    IF i_batch_guid IS NOT NULL
    THEN
        io_batch_results.detail_guid := i_detail_guid;
        io_batch_results.user_login_id := i_login_id;
        io_batch_results.usr_id := i_usr_id;
        io_batch_results.subscription_id := i__subscription_id;
        io_batch_results.status := coalesce(io_batch_results.status, utl.get_constant_value('c_deleted_text'));
        CALL data_remediation.log_detail_result(
                i_result_row => io_batch_results,
                i_called_from => i_module_name);
        io_batch_results := NULL;
    END IF;
END;


$body$
    LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE crudg_vin.log_batch_result_row () FROM PUBLIC;

\i cleanup.sql;
