SET bedb.filename = 'function.g_dealer_flag.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION crudg_vin.g_dealer_flag() RETURNS varchar as $body$
begin
  return '0'; 
END;
$body$
LANGUAGE PLPGSQL
IMMUTABLE;

\i cleanup.sql;
