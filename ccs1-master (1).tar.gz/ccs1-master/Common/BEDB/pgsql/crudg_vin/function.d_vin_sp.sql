SET bedb.filename = 'function.d_vin_sp.sql';

\i set_be_env.sql;

/*
### SEE NOTE BELOW ####
*/
/* d_vin_sp
   Completely modified, including spec, for CR10212-35

   Return Code :
   Success cSuccess  '0'

   Error Codes returned/written to data_fix_results:
     cinternalerror                   1   Internal Error
     cinvalidparams                   4   Invalid Parameters
     cdbvinnotfound                 200   System was passed a VIN which was not found.
   * c_invalid_vin                  234   VIN is null
   * c_batch_not_found              450   No matching batch exists
   * c_batch_not_in_progress        451   Batch is not in progress
   * c_duplicate_detail_error       461   Same vin was provided within the batch.
     c_active_users_found           470   VIN has active users associated, so can't be deleted
     c_invalid_flag_value           471   Invalid value provided for flag i_delete_pending_accounts
     c_vin_delete_error             472   There was an error when trying to delete the VIN
     c_vin_used_by_pending          473   VIN is used by pending accounts, hence cannot be deleted with flag of N

  * If this error is encountered, it is returned regardless of whether batch guid is provided or not.
    Otherwise, if the batch guid is provided, the error is written to data_fix_results table and utl.get_constant_value('csuccess') (0) is returned.
*/
DROP FUNCTION IF EXISTS crudg_vin.d_vin_sp(text, text, text, text);

CREATE OR REPLACE FUNCTION crudg_vin.d_vin_sp(IN i_vin text,
                                              IN i_delete_pending_accounts text DEFAULT 'N',
                                              IN i_batch_guid text DEFAULT NULL,
                                              IN i_version text DEFAULT NULL)
    RETURNS integer
AS
$BODY$
DECLARE
    l_action                  text;
    l_module_name             text := 'd_vin_sp';
    l_vin                     BEOWNER.vin.vin%type;
    l_is_vin_valid            bool;
    l_ctx_vin                 BEOWNER.vin.vin%type;
    l_ctx_make                BEOWNER.vin.make_id%type;
    l_return_code             integer;
    l_transaction_id          BEOWNER.VIN.transaction_id%type;
    l_dfd_row                 beowner.data_fix_batch_details%rowtype;
    l_batch_results           beowner.data_fix_results%rowtype;
    l_detail_guid             beowner.data_fix_results.detail_guid%type;
    l_make_id                 beowner.make.make_id%type;
    l_dofu                    beowner.vin.dofu%type;
    l_vin_sub_count           integer;
    l_active_user_count       integer;
    l_other_sub_count         integer;
    l_batch_guid              uuid := i_batch_guid::uuid;
    l_login_id                beowner.usr.login_id%type;
    l_usr_id                  beowner.usr.usr_id%type;
    l_subscription_id         beowner.subscription.subscription_id%type;
    l_delete_pending_accounts char varying(1);
    l_exception_diagnostics   trc.exception_diagnostics;
    vin_subs_cur CURSOR IS
        SELECT s2.vin,
               u.login_id,
               u.verified,
               u.usr_id,
               s2.subscription_id,
               row_number() OVER (ORDER BY s2.subscription_id) current_sub,
               (SELECT COUNT(1)
                FROM beowner.subscription s
                WHERE s.vin = l_vin)                           total_subs
        FROM beowner.usr u,
             beowner.subscription s2
        WHERE u.usr_id = s2.primary_id
          AND s2.vin = l_vin
        ORDER BY s2.subscription_id;

/* WI #14078 */


BEGIN
    begin
	    
	    l_action := utl.set_module_action( l_module_name, 'Validating inputs');
	   
        l_vin := (UPPER(TRIM(BOTH i_vin)));

        IF coalesce(l_vin, '') = '' THEN
            RETURN utl.get_constant_value('c_invalid_vin');
        END IF;

        IF coalesce(trim(BOTH i_batch_guid), '') != ''
        THEN
            l_action := utl.set_module_action(l_module_name, 'insert into batch details ');

            l_dfd_row.batch_guid := l_batch_guid;
            l_dfd_row.vin := l_vin;

            CALL data_remediation.insert_batch_details(i_dfd_row => l_dfd_row,
                                                       i_called_from => l_module_name,
                                                       o_detail_guid => l_detail_guid,
                                                       o_status_code => l_return_code);
            IF l_return_code != utl.get_constant_value('csuccess')::integer
            THEN
                RETURN l_return_code; -- can't log result in this case, so has to be returned
            END IF;
        END IF;

        l_delete_pending_accounts := upper(coalesce(i_delete_pending_accounts, 'N'));
        SELECT o_status_code, o_make_id INTO l_is_vin_valid,l_make_id FROM utl.is_vin_valid(i_vin => l_vin);
        IF NOT l_is_vin_valid
        THEN
            l_return_code := utl.get_constant_value('cdbvinnotfound');
            CALL crudg_vin.handle_error(l_return_code,
                                        l_batch_results,
                                        l_detail_guid,
                                        l_login_id,
                                        l_usr_id,
                                        l_subscription_id,
                                        l_module_name,
                                        l_batch_guid);

            RETURN utl.get_constant_value('csuccess');
        ELSE
            CALL ctx.set(i_makeid => l_make_id::text);
        END IF;

        IF l_delete_pending_accounts NOT IN (utl.get_constant_value('c_yes'), utl.get_constant_value('c_no'))
        THEN
            l_return_code := utl.get_constant_value('c_invalid_flag_value');
            CALL crudg_vin.handle_error(l_return_code,
                                        l_batch_results,
                                        l_detail_guid,
                                        l_login_id,
                                        l_usr_id,
                                        l_subscription_id,
                                        l_module_name,
                                        l_batch_guid);
            RETURN utl.get_constant_value('csuccess');
        END IF;

        SELECT COUNT(DISTINCT primary_id) sub_count,
               SUM(CASE
                       WHEN u.verified IS NOT NULL THEN
                           1
                       ELSE
                           0
                   END)          as         active_user_count
        INTO l_vin_sub_count,
            l_active_user_count
        FROM beowner.subscription s,
             beowner.usr u
        WHERE s.vin = l_vin
          AND u.usr_id = s.primary_id;

        IF l_vin_sub_count = 0
        THEN
            -- VIN has no subscriptions
            CALL crudg_vin.delete_vin_and_children(l_vin,
                                                   l_return_code,
                                                   l_batch_results,
                                                   l_detail_guid,
                                                   l_login_id,
                                                   l_usr_id,
                                                   l_subscription_id,
                                                   l_module_name,
                                                   l_batch_guid);
            l_login_id := utl.get_constant_value('c_no_account_text');
            CALL crudg_vin.log_batch_result_row(l_batch_guid,
                                                l_detail_guid,
                                                l_login_id,
                                                l_usr_id,
                                                l_subscription_id,
                                                l_module_name,
                                                l_batch_results);
        ELSE
            -- VIN has at least one subscription
            FOR subs_rec IN vin_subs_cur
                LOOP

                    l_login_id := subs_rec.login_id;
                    l_usr_id := subs_rec.usr_id;
                    l_subscription_id := subs_rec.subscription_id;

                    IF l_active_user_count > 0
                    THEN
                        -- one or more subscription users is in active state, so VIN should not be deleted
                        l_batch_results.old_account_status := CASE
                                                                  WHEN subs_rec.verified IS NOT NULL THEN
                                                                      utl.get_constant_value('cstatusactive')
                                                                  ELSE
                                                                      utl.get_constant_value('cstatuspending')
                            END;

                        l_batch_results.new_account_status := l_batch_results.old_account_status;

                        l_return_code := utl.get_constant_value('c_active_users_found');
                        CALL crudg_vin.handle_error(l_return_code,
                                                    l_batch_results,
                                                    l_detail_guid,
                                                    l_login_id,
                                                    l_usr_id,
                                                    l_subscription_id,
                                                    l_module_name,
                                                    l_batch_guid);-- will exit after returning the first error if batch guid is null, as expected

                    ELSIF l_delete_pending_accounts = utl.get_constant_value('c_no') -- only pending users, but per flag, vin cannot be deleted
                    THEN
                        l_batch_results.old_account_status := utl.get_constant_value('cstatuspending');
                        l_batch_results.new_account_status := l_batch_results.old_account_status;
                        l_return_code := utl.get_constant_value('c_vin_used_by_pending');
                        CALL crudg_vin.handle_error(l_return_code,
                                                    l_batch_results,
                                                    l_detail_guid,
                                                    l_login_id,
                                                    l_usr_id,
                                                    l_subscription_id,
                                                    l_module_name,
                                                    l_batch_guid);
                    ELSE
                        -- only pending users and per flag, vin can be deletid
                        SELECT COUNT(1)
                        INTO l_other_sub_count
                        FROM beowner.subscription
                        WHERE primary_id = subs_rec.usr_id
                          AND vin != l_vin;

                        IF l_other_sub_count = 0
                        THEN
                            -- User on VIN's subscription has no other subscriptions, so it can be deleted, along with it's subscription
                            l_return_code := crudg_usr.d_usr_sp(iusr_id => subs_rec.usr_id::text,
                                                                i_delete_children => 'Y');
                        ELSE
                            -- user has other subscriptions, just delete the one for this VIN
                            l_return_code :=
                                    crudg_subscription.d_subscription1(i_subscription_id => subs_rec.subscription_id::text);
                        END IF;
                        l_batch_results.old_account_status := utl.get_constant_value('cstatuspending');
                        l_batch_results.new_account_status := utl.get_constant_value('c_deleted_text');
                        l_batch_results.status := utl.get_constant_value('c_deleted_text');
                        CALL crudg_vin.log_batch_result_row(l_batch_guid,
                                                            l_detail_guid,
                                                            l_login_id,
                                                            l_usr_id,
                                                            l_subscription_id,
                                                            l_module_name,
                                                            l_batch_results);

                        IF subs_rec.current_sub = subs_rec.total_subs
                        THEN
                            -- only delete if it is the last subscription for the vin
                            CALL crudg_vin.delete_vin_and_children(l_vin,
                                                                   l_return_code,
                                                                   l_batch_results,
                                                                   l_detail_guid,
                                                                   l_login_id,
                                                                   l_usr_id,
                                                                   l_subscription_id,
                                                                   l_module_name,
                                                                   l_batch_guid);
                        END IF;
                    END IF; -- check for active users
                END LOOP;

        END IF;

    EXCEPTION
        WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation
        THEN
    l_return_code := utl.get_constant_value('cinvalidparams');
    CALL crudg_vin.handle_error(l_return_code,
                                l_batch_results,
                                l_detail_guid,
                                l_login_id,
                                l_usr_id,
                                l_subscription_id,
                                l_module_name,
                                l_batch_guid);

    WHEN SQLSTATE 'EDEPR' THEN
    RAISE;

    WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS
        l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
        l_exception_diagnostics.column_name := COLUMN_NAME,
        l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
        l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
        l_exception_diagnostics.message_text := MESSAGE_TEXT,
        l_exception_diagnostics.table_name := TABLE_NAME,
        l_exception_diagnostics.schema_name := SCHEMA_NAME,
        l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
        l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
        l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;


    CALL trc.log(iadditionaldata => NULL,
                 iexception_diagnostics => l_exception_diagnostics);
    l_return_code := utl.get_constant_value('cinternalerror');
    CALL crudg_vin.handle_error(l_return_code,
                                l_batch_results,
                                l_detail_guid,
                                l_login_id,
                                l_usr_id,
                                l_subscription_id,
                                l_module_name,
                                l_batch_guid);
END; RETURN utl.get_constant_value('csuccess');

EXCEPTION
    WHEN SQLSTATE 'EDEPR' THEN
        RETURN l_return_code;

END;
$BODY$ LANGUAGE plpgsql
    SECURITY DEFINER;

\i cleanup.sql;
