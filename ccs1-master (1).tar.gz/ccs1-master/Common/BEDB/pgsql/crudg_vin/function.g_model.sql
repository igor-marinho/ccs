SET bedb.filename = 'function.g_model.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION crudg_vin.g_model() RETURNS varchar as $body$
begin
  return crudg_vin.g_no_value();
END;
$body$
LANGUAGE PLPGSQL
IMMUTABLE;

\i cleanup.sql;
