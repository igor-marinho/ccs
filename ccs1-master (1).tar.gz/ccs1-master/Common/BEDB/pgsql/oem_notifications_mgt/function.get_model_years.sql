SET bedb.filename = 'function.get_model_years.sql';

\i set_be_env.sql;

   /* GET_MODEL_YEARS
      To be used by portal to get list of all Years for the provided model category.
      
      Out : Ref cursor with one column - year 
        
      Expected Return Values:
         0     : Success
         1     : Unknown Error
         4     : Invalid Parameter (length or datatype)         
         222   : Invalid Make ID or Make Id is null    (cnst.cinvalidmake)    
         622   : Model Category must be provided       (cnst.c_model_category_is_null)        
         639   : Invalid Model Category                (cnst.c_invalid_model_category)   
   */

DROP FUNCTION IF EXISTS oem_notifications_mgt.get_model_years(beowner.make.make_id%TYPE, beowner.model_categories.category%TYPE);


CREATE OR REPLACE FUNCTION oem_notifications_mgt.get_model_years (i_make_id beowner.make.make_id%TYPE,
                                                                  i_model_category beowner.model_categories.category%TYPE, 
																  o_status_code OUT integer,
																  o_result OUT REFCURSOR) AS $body$
DECLARE
		
      l_action text;
      l_module_name text := 'get_model_years';
      l_make_id  beowner.make.make_id%TYPE;
      l_category beowner.model_categories.category%TYPE;
      l_exception_diagnostics trc.exception_diagnostics;
      l_min_year text := utl.get_constant_value('c_min_year');
	  l_max_year beowner.cfg.value%type := utl.getconfig(utl.get_constant_value('c_cfg_notif_max_year'));

BEGIN
      l_action := utl.set_module_action( l_module_name, 'Validating inputs');
	  
      o_result := utl.get_dummy_cursor();

      l_make_id := upper(i_make_id);
      IF NOT utl.is_make_valid(i_make_id => l_make_id)
      THEN
	     o_status_code := utl.get_constant_value('cinvalidmake');
         RETURN;
      END IF;

      l_category := upper(i_model_category);
      IF l_category IS NULL
      THEN
	     o_status_code := utl.get_constant_value ('c_model_category_is_null');
         RETURN;
		 
      ELSIF NOT utl.is_model_category_valid(i_category => l_category)
      THEN
	     o_status_code := utl.get_constant_value ('c_invalid_model_category');
         RETURN;
      END IF;

      l_action := utl.set_action('Returning results');
	  
	  close o_result;

	  OPEN o_result FOR
         SELECT DISTINCT v.year
           FROM beowner.vin              v,
                beowner.model_categories mc
          WHERE v.make_id = l_make_id
                AND mc.category = l_category
                AND v.model = mc.model
                AND v.year >= l_min_year 
                AND v.year <= l_max_year
          ORDER BY v.year;
		  
		  o_status_code := utl.get_constant_value ('csuccess');

      RETURN;
	  
   EXCEPTION
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
	  
	     o_status_code := utl.get_constant_value('cinvalidparams');
         RETURN;
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
		
		  o_result := utl.get_dummy_cursor();	
		  o_status_code := utl.get_constant_value ('cinternalerror');
         RETURN;
   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION oem_notifications_mgt.get_model_years (i_make_id make.make_id%TYPE, i_model_category model_categories.category%TYPE, o_result OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
