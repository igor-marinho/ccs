SET bedb.filename = 'function.execute_job.sql';

\i set_be_env.sql;


DROP FUNCTION IF EXISTS oem_notifications_mgt.execute_job();

CREATE OR REPLACE FUNCTION oem_notifications_mgt.execute_job()
RETURNS integer AS
$BODY$
DECLARE
  l_action                   text;
  l_id                       beowner.oem_notif_job.id%type;
  l_job_action               beowner.oem_notif_job.job_action%type;
  l_module_name              text := 'execute_job';
  l_exception_diagnostics    trc.exception_diagnostics;
BEGIN

  l_action := utl.set_module_action(l_module_name, 'Looking for job to execute');
  
  begin
    
    select j.id
          ,j.job_action
      INTO STRICT l_id
                 ,l_job_action
      FROM beowner.oem_notif_job j
     WHERE j.start_time <= clock_timestamp() 
       and j.end_time is null
       and j.execution_count < utl.getconfig('OEM notif job retry max')::smallint
     order by execution_count asc
             ,j.start_time asc
     LIMIT 1
       FOR UPDATE SKIP locked;    
     
  exception
  when no_data_found
  then
    RETURN utl.get_constant_value('csuccess');
  end;
     
  l_action := utl.set_module_action(l_module_name, 'Excuting job...');  

  execute l_job_action;
  
  update beowner.oem_notif_job
     set end_time = clock_timestamp()        
        ,execution_count = execution_count + 1
   where id = l_id; 

  RETURN utl.get_constant_value('csuccess');

EXCEPTION
  WHEN others
  then
    GET STACKED DIAGNOSTICS
      l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
      l_exception_diagnostics.column_name := COLUMN_NAME,
      l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
      l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
      l_exception_diagnostics.message_text := MESSAGE_TEXT,
      l_exception_diagnostics.table_name := TABLE_NAME,
      l_exception_diagnostics.schema_name := SCHEMA_NAME,
      l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
      l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
      l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

      l_exception_diagnostics.module_name := l_module_name;
      l_exception_diagnostics.action := l_action;

    CALL trc.log(iadditionaldata => NULL,
                 iexception_diagnostics => l_exception_diagnostics);
        
    update beowner.oem_notif_job
       set execution_count = execution_count + 1
          ,start_time = clock_timestamp() + make_interval(mins => utl.getconfig('OEM notif job retry interval minutes')::smallint * (execution_count + 1))
     where id = l_id;
 
    RETURN utl.get_constant_value('cinternalerror');

END;
$BODY$ LANGUAGE plpgsql
    SECURITY DEFINER;

\i cleanup.sql;
