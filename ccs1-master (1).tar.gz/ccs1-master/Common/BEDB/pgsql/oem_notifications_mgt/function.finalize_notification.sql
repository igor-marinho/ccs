SET bedb.filename = 'function.finalize_notification.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS oem_notifications_mgt.finalize_notification(text, text);
CREATE OR REPLACE FUNCTION oem_notifications_mgt.finalize_notification(i_on_guid IN text,
                                                                       i_portal_user IN text) RETURNS integer AS
$BODY$
/*
       To be used by portal for finalizing a notification created earlier

      Expected Return Values:
          0     : Success
          1     : Unknown Error
          4     : Invalid Parameter (length or datatype)

          200   : System was passed a VIN which was not found                             (cnst.cDbVinNotFound)
          458   : Portal user is mandatory                                                (cnst.c_portal_user_is_null)

          604   : A configuration value is invalid. Check "trc" for details               (cnst.c_invalid_config_setting)
          606   : Draft Notification doesn't exist                                        (cnst.c_not_draft_notif)
          607   : Existing Notification GUID must be provided                             (cnst.c_notif_not_provided)
          610   : Bundles must be provided for Recipient Type B                           (cnst.c_bundles_is_null)
          611   : VIN or Batch GUID must be provided for Recipient Type B                 (cnst.c_vin_or_batch_mandatory)
          612   : VIN and Batch GUID cannot both be provided                              (cnst.c_either_vin_or_batch)
          613   : Make doesn't match that of the notification for at least one recipient  (cnst.c_incompatible_recip_make)
          619   : Batch must be complete                                                  (cnst.c_batch_incomplete)
          620   : Batch has errors                                                        (cnst.c_batch_vin_errors)
          621   : VIN Batch is empty                                                      (cnst.c_batch_is_empty)
          622   : Model Category must be provided                                         (cnst.c_model_category_is_null)
          623   : At least one year must be provided for Recipient Type M                 (cnst.c_no_years_provided)
          624   : One or more years on the notification is invalid                        (cnst.c_invalid_notif_year)
          625   : Start Date must be provided                                             (cnst.c_start_date_is_null)
          626   : Start Date must be at least x mins in the future                        (cnst.c_start_date_too_soon)
                  where x = value for 'Add notif recipients before mins'
          627   : Expiration Date must be provided for InBox notification                 (cnst.c_exp_date_is_null)
          628   : Expiration Date can only be provided for InBox notification             (cnst.c_exp_date_only_for_inbox)
          629   : Expiration Date cannot be more than config value for                    (cnst.c_exp_date_too_far)
                  'OEM notif max duration in days' after start date
          630   : Content must be provided                                                (cnst.c_content_is_null)
          631   : Subject must be provided for InBox notification                         (cnst.c_subject_is_null)
          632   : Could not add recipients job. Check "trc"                               (cnst.c_error_adding_recip_job)
          639   : Invalid Model Category                                                  (cnst.c_invalid_model_category)
*/
DECLARE
    l_action                   text;
    l_module_name              text := 'finalize_notification';
    l_on_guid                  beowner.oem_notifications.on_guid%type;
    l_on_row                   beowner.oem_notifications%rowtype;
    l_return_code              text;
    l_add_recips_job_tmstmp_tz timestamp WITH TIME ZONE;
    l_is_draft                 boolean;
    l_exception_diagnostics    trc.exception_diagnostics;
 
    c_job_prefix CONSTANT VARCHAR(16) := utl.get_constant_value('c_oem_notif_job_prefix');
    l_job_action beowner.oem_notif_job.job_action%type;
BEGIN

    l_action := utl.set_module_action(l_module_name, 'Validating inputs');

    IF i_on_guid IS NULL
    THEN
        RETURN utl.get_constant_value('c_notif_not_provided');
    ELSE
        l_on_guid := i_on_guid;
        CALL oem_notifications_mgt.is_draft_notif(l_on_guid,
                                                  l_is_draft,
                                                  l_on_row);
        IF NOT l_is_draft THEN
            RETURN utl.get_constant_value('c_not_draft_notif');
        END IF;
    END IF;
    IF l_on_row.content IS NULL THEN
        RETURN utl.get_constant_value('c_content_is_null');
    END IF;

    IF l_on_row.notif_type = utl.get_constant_value('c_notif_type_inbox') AND
       l_on_row.subject IS NULL THEN
        RETURN utl.get_constant_value('c_subject_is_null');
    END IF;

    CALL oem_notifications_mgt.validate_dates(l_on_row,
                                              l_add_recips_job_tmstmp_tz,
                                              l_return_code);
    IF l_return_code != utl.get_constant_value('csuccess')
    THEN
        RETURN l_return_code;
    END IF;

    IF i_portal_user IS NULL
    THEN
        RETURN utl.get_constant_value('c_portal_user_is_null');
    END IF;

    CASE l_on_row.recipient_type
        WHEN utl.get_constant_value('c_recipient_type_bundle')
            THEN CALL oem_notifications_mgt.validate_bundles(l_on_row, l_return_code);

        WHEN utl.get_constant_value('c_recipient_type_vin')
            THEN CALL oem_notifications_mgt.validate_vin_batch(l_on_row, l_return_code);

        ELSE -- Model/years
        CALL oem_notifications_mgt.validate_model_years(l_on_row, l_return_code);
        END CASE;

    IF l_return_code != utl.get_constant_value('csuccess')
    THEN
        RETURN l_return_code;
    END IF;

    UPDATE beowner.oem_notifications
    SET finalized     = utl.get_constant_value('c_yes'),
        modified_by   = i_portal_user,
        modified_date = CURRENT_TIMESTAMP
    WHERE on_guid = l_on_row.on_guid;

    BEGIN
        l_job_action := 'call oem_notifications_mgt.add_notification_recipients(i_on_guid => ''' || l_on_guid || ''');';

        insert into beowner.oem_notif_job(job_description, job_action, start_time, initial_start_time)
        values (c_job_prefix || l_on_row.notif_seq, l_job_action, l_add_recips_job_tmstmp_tz, l_add_recips_job_tmstmp_tz);
  
    EXCEPTION
        WHEN others
        THEN
            call trc.log('Could not create recipients job for notification ' || l_on_guid);
            RETURN utl.get_constant_value('c_error_adding_recip_job')::int;

    END;
  
    RETURN utl.get_constant_value('csuccess');
EXCEPTION
    WHEN no_data_found THEN
        RETURN l_return_code;
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;

        RAISE NOTICE 'l_exception_diagnostics==================%', l_exception_diagnostics;
        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
        RETURN utl.get_constant_value('cinternalerror');

END;

$BODY$ LANGUAGE plpgsql
    SECURITY DEFINER;

\i cleanup.sql;
