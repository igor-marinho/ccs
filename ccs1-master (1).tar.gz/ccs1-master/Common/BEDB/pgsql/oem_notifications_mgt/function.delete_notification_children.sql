SET bedb.filename = 'function.delete_notification_children.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS oem_notifications_mgt.delete_notification_children (beowner.oem_notifications.on_guid%TYPE);

CREATE OR REPLACE FUNCTION oem_notifications_mgt.delete_notification_children (i_on_guid IN beowner.oem_notifications.on_guid%TYPE) RETURNS INTEGER AS $body$

DECLARE
    l_exception_diagnostics trc.exception_diagnostics;
	l_module_name text := 'delete_notification_children';
    l_action text;
	l_on_row      beowner.oem_notifications%ROWTYPE;
	l_child_table VARCHAR(30);
	
BEGIN

    
	l_action := utl.set_module_action( l_module_name, 'Deleting notif children');
	
	SELECT * INTO l_on_row FROM beowner.oem_notifications oen WHERE oen.on_guid = i_on_guid;
		 
    CASE l_on_row.recipient_type
            WHEN utl.get_constant_value('c_recipient_type_bundle') THEN
			
               l_child_table := 'OEM_NOTIF_DEVICES';
			   DELETE FROM beowner.oem_notif_devices ond WHERE ond.on_guid = i_on_guid;
			   
            WHEN utl.get_constant_value('c_recipient_type_model') THEN
			
               l_child_table := 'OEM_NOTIF_YEARS';
               DELETE FROM beowner.oem_notif_years ony WHERE ony.on_guid = i_on_guid;
            
			ELSE
               -- type V. Any existing related batch is deleted after notification
               NULL;
			   
         END CASE;

         RETURN utl.get_constant_value('csuccess');
		 
      EXCEPTION
         WHEN OTHERS THEN
             GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,              
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
             
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;

              CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);			 
              RETURN utl.get_constant_value('cinternalerror');
      END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION oem_notifications_mgt.delete_notification_children () FROM PUBLIC;

\i cleanup.sql;
