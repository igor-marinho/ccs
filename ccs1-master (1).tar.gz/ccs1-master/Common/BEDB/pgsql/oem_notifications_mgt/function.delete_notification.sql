SET bedb.filename = 'function.delete_notification.sql';

\i set_be_env.sql;

   /* DELETE_NOTIFICATION 
      For portal to delete a draft or final notification
           0     : Success
           1     : Unknown Error
           4     : Invalid Parameter (length or datatype)
           
           458   : Portal user is mandatory                                                            (cnst.c_portal_user_is_null)   
   
           600   : No such notification exists                                                         (cnst.c_notif_not_provided)
           607   : Existing Notification GUID must be provided                                         (cnst.c_notif_missing)
           634   : Notification is not in a state (draft or finalized currently) that allows deletion  (cnst.c_notif_cannot_be_deleted)
           635   : An error was encountered when deleting notification. Check "trc" log                (cnst.c_notif_deletion_error)
   
   */

DROP FUNCTION IF EXISTS oem_notifications_mgt.delete_notification(TEXT,beowner.oem_notifications.modified_by%TYPE);

CREATE or REPLACE FUNCTION oem_notifications_mgt.delete_notification(i_on_guid     IN TEXT,
                                                                     i_portal_user IN beowner.oem_notifications.modified_by%TYPE)
RETURNS INTEGER AS $body$
 DECLARE
 
      l_action text;
      l_module_name text := 'delete_notification';
      l_on_row      beowner.oem_notifications%ROWTYPE;
      l_status_code text;
      l_child_table VARCHAR(30);
      l_on_guid uuid := i_on_guid::uuid;
	  l_exception_diagnostics trc.exception_diagnostics;
	  
   BEGIN
   
      l_action := utl.set_module_action( l_module_name, 'Validating inputs');
   
      IF COALESCE(i_portal_user, '') = '' 
      THEN
      RETURN utl.get_constant_value('c_portal_user_is_null');
      END IF;
   
      IF COALESCE(i_on_guid, '') = ''
      THEN
      RETURN utl.get_constant_value('c_notif_not_provided');
      END IF;
      BEGIN
           SELECT *
           INTO l_on_row
           FROM beowner.oem_notifications oen
           WHERE oen.on_guid = l_on_guid;
          IF oem_notifications_mgt.get_notification_status(i_finalized            => l_on_row.finalized,
                                                          i_recalled             => l_on_row.recalled,
                                                          i_start_date           => l_on_row.start_date,
                                                          i_processing_started   => l_on_row.processing_started,
                                                          i_processing_completed => l_on_row.processing_completed,
                                                          i_errored              => l_on_row.errored) NOT IN (utl.get_constant_value('c_notif_status_draft'), 
														                                                      utl.get_constant_value('c_notif_status_finalized'))
            
         THEN
         RETURN utl.get_constant_value('c_notif_cannot_be_deleted');
         END IF;
      EXCEPTION
         WHEN no_data_found THEN
         RETURN utl.get_constant_value('c_notif_missing');
      END;
   
   
	  l_action := utl.set_module_action( l_module_name, 'Deleting notif children');
	  
      l_status_code := oem_notifications_mgt.delete_notification_children(l_on_guid);
	  
      IF l_status_code != utl.get_constant_value('csuccess')
      THEN
      RETURN utl.get_constant_value('c_notif_deletion_error');
      END IF;
   
	  l_action := utl.set_module_action( l_module_name, 'Deleting notification');
	  
      UPDATE beowner.oem_notifications SET modified_by = i_portal_user, modified_date = CURRENT_TIMESTAMP WHERE on_guid = l_on_guid;
	  
      DELETE from beowner.oem_notifications oen WHERE oen.on_guid = l_on_guid;
   
      IF l_on_row.vin_batch_guid IS NOT NULL
      THEN
      l_action := utl.set_action('Deleting notif batch');
	  
      CALL oem_notifications_mgt.delete_notif_batch(i_batch_guid => l_on_row.vin_batch_guid);
	  
      END IF;
   
      RETURN utl.get_constant_value('csuccess');
      EXCEPTION
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
      RETURN utl.get_constant_value('cinvalidparams');
	  
      WHEN OTHERS THEN
	  
	  GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
						
         RETURN utl.get_constant_value('cinternalerror');
   END;
   
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;

\i cleanup.sql;
