SET bedb.filename = 'function.get_device_ids.sql';

\i set_be_env.sql;

   /* GET_DEVICE_IDS
   
      To be used by portal to get list of all Device IDs/Bundles.
      
      Out : Ref cursor with columns device_id, name
      
      Expected Return Values:
         0     : Success
         1     : Unknown Error
         4     : Invalid Parameter (length or datatype)         
         222   : Invalid Make ID or Make Id is null    (cnst.cinvalidmake)   
   */
   
DROP FUNCTION IF EXISTS oem_notifications_mgt.get_device_ids (TEXT);

CREATE OR REPLACE FUNCTION oem_notifications_mgt.get_device_ids (i_make_id beowner.make.make_id%TYPE, 
                                                                 o_status_code OUT INTEGER,
                                                                 o_result OUT REFCURSOR)
AS $body$

DECLARE

    l_action text;
    l_module_name text := 'get_device_ids';
    l_make_id beowner.make.make_id%TYPE;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      o_result := utl.get_dummy_cursor();
	  
	  l_action := utl.set_module_action( l_module_name, 'Validating input');
	  
      l_make_id := upper(i_make_id);
	  
      IF NOT utl.is_make_valid(i_make_id => l_make_id)
      THEN
	     o_status_code := utl.get_constant_value('cinvalidmake');
         RETURN;
      END IF;
	  
	  close o_result;

	   l_action := utl.set_action('Returning results');

      OPEN o_result FOR
         SELECT d.device_id,
                b.name
           FROM beowner.device d,
                beowner.bndl   b
          WHERE d.make_id = l_make_id
                AND b.device_id = d.device_id
          ORDER BY d.device_id;
		  
	  o_status_code := utl.get_constant_value ('csuccess');	  
	  RETURN;
   EXCEPTION
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
	     o_status_code := utl.get_constant_value('cinvalidparams');
		 o_result := utl.get_dummy_cursor();
         RETURN;
         
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
		  
		  o_result := utl.get_dummy_cursor();	
		  o_status_code := utl.get_constant_value ('cinternalerror');
		  
          RETURN;
   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION oem_notifications_mgt.get_device_ids (i_make_id make.make_id%TYPE, o_result OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
