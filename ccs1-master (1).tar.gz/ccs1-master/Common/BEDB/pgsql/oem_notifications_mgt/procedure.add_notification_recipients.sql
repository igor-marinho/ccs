SET bedb.filename = 'procedure.add_notification_recipients.sql';

\i set_be_env.sql;

   /* ADD_NOTIFICATION_RECIPIENTS 
      Called internally by scheduled job
      Any errors encountered are logged into "trc" table
   */

DROP PROCEDURE IF EXISTS oem_notifications_mgt.add_notification_recipients(beowner.oem_notifications.on_guid%TYPE);

CREATE OR REPLACE PROCEDURE oem_notifications_mgt.add_notification_recipients (i_on_guid beowner.oem_notifications.on_guid%TYPE) AS $body$
DECLARE

      l_action text;
      l_module_name text := 'add_notification_recipients';
      l_on_row      beowner.oem_notifications;
      l_status_code text;
      l_exception_diagnostics trc.exception_diagnostics;

BEGIN

      l_action := utl.set_module_action( l_module_name, 'Validating inputs');
	  
      l_status_code := utl.get_constant_value('csuccess');
	  
	  IF COALESCE(i_on_guid::text, '') = ''
      THEN
         l_status_code := utl.get_constant_value('c_notif_not_provided');
      ELSE
         BEGIN
            SELECT *
              INTO STRICT l_on_row
              FROM beowner.oem_notifications AS oen
             WHERE oen.on_guid = i_on_guid;
            IF oem_notifications_mgt.get_notification_status(i_finalized            => l_on_row.finalized,
                                                             i_recalled             => l_on_row.recalled,
                                                             i_start_date           => l_on_row.start_date,
                                                             i_processing_started   => l_on_row.processing_started,
                                                             i_processing_completed => l_on_row.processing_completed,
                                                             i_errored              => l_on_row.errored) != utl.get_constant_value('c_notif_status_finalized')
            THEN
               l_status_code := utl.get_constant_value('c_not_final_notif');
            END IF;
         EXCEPTION
            WHEN no_data_found THEN
               l_status_code := utl.get_constant_value('c_notif_missing');
         END;
      END IF;

      IF l_status_code != utl.get_constant_value('csuccess')
      THEN
	     
	    l_exception_diagnostics.module_name := l_module_name;
		
        l_exception_diagnostics.action := l_action;
		
        CALL trc.log(iadditionaldata => i_on_guid || ' Notif recipients cannot be added because of error ' || l_status_code,
                     iexception_diagnostics => l_exception_diagnostics);

         RETURN;
      END IF;

      l_action := utl.set_action('Updating notification');


	
      UPDATE beowner.oem_notifications 
      SET processing_started = clock_timestamp()
      WHERE on_guid = l_on_row.on_guid;
     

      -- needed here, so that processing start date is populated while processing is in progress
      --commit;
	  
	  l_action := utl.set_action('Inserting recipients');

      -- Added for DCS1NOTES-468, just to be able to repro the issue
      IF utl.g_test_mode_on()
      THEN
         RAISE no_data_found;
      END IF;

      -- User may have two qualifying vehicles, hence distinct is necessary
      -- If there  are any changes to this logic, make corresponding changes
      --to setup_subs_notification as well
      INSERT INTO beowner.oem_notif_recipients(onr_guid, on_guid, usr_id,status)
         (SELECT beowner.rand_guid(),
                 l_on_row.on_guid,
                 users.usr_id,'U'
            FROM (SELECT DISTINCT u.usr_id
                    FROM beowner.subscription s,
                         beowner.usr u,
                         (SELECT v.vin
                            FROM beowner.vin v,
                                 beowner.oem_notif_devices ond
                           WHERE l_on_row.recipient_type =
                                 utl.get_constant_value('c_recipient_type_bundle')
                                 AND ond.on_guid = l_on_row.on_guid
                                 AND v.device_id = ond.device_id

UNION ALL

                          SELECT l_on_row.vin
                           WHERE l_on_row.recipient_type =
                                 utl.get_constant_value('c_recipient_type_vin')
                                 AND l_on_row.vin IS NOT NULL
                          
UNION ALL

                          SELECT dfd.vin
                            FROM beowner.data_fix_batch_details dfd
                           WHERE l_on_row.recipient_type =
                                 utl.get_constant_value('c_recipient_type_vin')
                                 AND l_on_row.vin IS NULL
                                 AND dfd.batch_guid = l_on_row.vin_batch_guid
                          
UNION ALL

                          SELECT v.vin
                            FROM beowner.vin              v,
                                 beowner.oem_notif_years  ony,
                                 beowner.model_categories mc
                           WHERE l_on_row.recipient_type =
                                 utl.get_constant_value('c_recipient_type_model')
                                 AND v.make_id = l_on_row.make_id
                                 AND v.model = mc.model
                                 AND mc.category = l_on_row.model_category
                                 AND v.year = ony.year
                                 AND ony.on_guid = l_on_row.on_guid) vins
                   WHERE s.vin = vins.vin
                         AND u.usr_id = s.primary_id
                         AND u.verified IS NOT NULL) users); 
	  
	  l_action := utl.set_action('Calling queue_push_notifications');

      --  IF l_on_row.notif_type = cnst.c_notif_type_push
      --   THEN
      CALL oem_notifications_mgt.queue_push_notifications(i_on_row => l_on_row);
      --   END IF;
      UPDATE beowner.oem_notifications
      SET processing_completed = clock_timestamp()
      WHERE on_guid = l_on_row.on_guid;

   EXCEPTION
         WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          UPDATE beowner.oem_notifications 
          SET errored = utl.get_constant_value('c_yes')
          WHERE on_guid = i_on_guid;
		 
		  CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);

         RAISE;

   END;

$body$
LANGUAGE PLPGSQL
security definer 
;
-- REVOKE ALL ON PROCEDURE oem_notifications_mgt.add_notification_recipients (i_on_guid oem_notifications.on_guid%TYPE) FROM PUBLIC;

\i cleanup.sql;
