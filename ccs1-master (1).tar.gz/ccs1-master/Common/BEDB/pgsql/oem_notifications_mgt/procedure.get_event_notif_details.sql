SET bedb.filename = 'procedure.get_event_notif_details.sql';

\i set_be_env.sql;

   -- New sprocs below added for DCS1NOTES-566

-- WARNING: parameters order has been changed by Ora2Pg to move parameters with default values at end
-- Original order was: oem_notifications_mgt.get_event_notif_details(i_make_id oem_notifications.make_id%TYPE, i_event oem_notifications.driven_by_event%TYPE, i_notif_type oem_notifications.notif_type%TYPE, i_hs_os oem_notifications.hs_os%TYPE DEFAULT NULL, i_device_id oem_notif_devices.device_id%TYPE DEFAULT NULL, o_on_guid OUT oem_notifications.on_guid%TYPE, o_content OUT oem_notifications.content%TYPE, o_priority OUT oem_notifications.priority%TYPE)
-- You will need to manually reorder parameters in the function calls

DROP PROCEDURE IF EXISTS oem_notifications_mgt.get_event_notif_details(beowner.oem_notifications.make_id%TYPE,
                                                                       beowner.oem_notifications.driven_by_event%TYPE,
																	   beowner.oem_notifications.notif_type%TYPE,
																	   beowner.oem_notifications.on_guid%TYPE,
																	   beowner.oem_notifications.content%TYPE,
																	   beowner.oem_notifications.priority%type,
																	   beowner.oem_notifications.hs_os%TYPE,
																	   beowner.oem_notif_devices.device_id%TYPE);

CREATE OR REPLACE PROCEDURE oem_notifications_mgt.get_event_notif_details (i_make_id beowner.oem_notifications.make_id%TYPE,
                                                                           i_event beowner.oem_notifications.driven_by_event%TYPE,
                                                                           i_notif_type beowner.oem_notifications.notif_type%TYPE,
                                                                           o_on_guid INOUT beowner.oem_notifications.on_guid%TYPE,
                                                                           o_content INOUT beowner.oem_notifications.content%TYPE, 
                                                                           o_priority INOUT beowner.oem_notifications.priority%type,
                                                                           i_hs_os beowner.oem_notifications.hs_os%TYPE DEFAULT NULL,
																		   i_device_id beowner.oem_notif_devices.device_id%TYPE DEFAULT NULL) 
AS $body$

DECLARE

      l_action text;
	  l_module_name text := 'get_event_notif_details';
	  

BEGIN

      l_action := utl.set_module_action( l_module_name, 'Fetching OEM Notification Details');
	  
      SELECT oen.on_guid,
             (CASE
                WHEN i_notif_type = utl.get_constant_value('c_notif_type_push') THEN
                 oen.content
                ELSE
                 NULL
             END) AS content,
             oen.priority
        INTO STRICT o_on_guid,
             o_content,
             o_priority
        FROM beowner.oem_notifications oen
       WHERE oen.make_id = i_make_id
             AND oen.driven_by_event = i_event
             AND oen.notif_type = i_notif_type
             AND coalesce(oen.hs_os, i_hs_os, '!') = coalesce(i_hs_os, '!');
            
          

      -- device_id has been added for future use; is not required currently
      -- content is not needed subsequently in the sproc for InBox, hence is returned only for Push
   EXCEPTION
      WHEN no_data_found THEN
         NULL;
      WHEN too_many_rows THEN
         o_on_guid := NULL;
         CALL trc.log('FATAL ERROR : Multiple OEM Notifications found for event ' ||
                 i_event || ', make ' || i_make_id || ' , notif_type ' ||
                 i_notif_type);
	  
		
   END;


$body$
LANGUAGE PLPGSQL

;
-- REVOKE ALL ON PROCEDURE oem_notifications_mgt.get_event_notif_details (i_make_id oem_notifications.make_id%TYPE, i_event oem_notifications.driven_by_event%TYPE, i_notif_type oem_notifications.notif_type%TYPE, o_on_guid OUT oem_notifications.on_guid%TYPE, o_content OUT oem_notifications.content%TYPE, o_priority OUT oem_notifications.priority%TYPE, i_hs_os oem_notifications.hs_os%TYPE DEFAULT NULL, i_device_id oem_notif_devices.device_id%TYPE DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
