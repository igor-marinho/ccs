SET bedb.filename = 'function.generate_notification_seq.sql';

\i set_be_env.sql;
CREATE SEQUENCE IF NOT EXISTS beowner.oem_notif_seq INCREMENT BY 1 MAXVALUE 9999 CYCLE;

CREATE OR REPLACE FUNCTION oem_notifications_mgt.generate_notification_seq() RETURNS beowner.oem_notifications.notif_seq%type AS
$body$
BEGIN
    -- e.g. if created on 8/25 @ 1:34 PM and sequence number is 9, it would be 17082513340009.
    RETURN (to_char(current_timestamp, 'yymmddhh24mi') ||
            lpad(nextval('beowner.oem_notif_seq')::text, 4, '0'))::numeric;
END;

$body$
    LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION oem_notifications_mgt.generate_notification_seq () FROM PUBLIC;

\i cleanup.sql;
