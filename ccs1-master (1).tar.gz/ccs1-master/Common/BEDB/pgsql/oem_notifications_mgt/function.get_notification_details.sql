SET bedb.filename = 'function.get_notification_details.sql';

\i set_be_env.sql;

   /* GET_NOTIFICATION_DETAILS
      To be used by portal to retrieve the option/recipients for a specific notification
      
      Out refcursors: 
        o_notif_cur : notif_seq, notif_type, make_id, status, status description, start_date, expiration_date, priority, subject, content, recipient_type, hs_os, vin, batch_guid
        o_category_or_bndls_cur :
          If recipient_type = M - category, category_selected
          If recipient_type = B - device_id, name, device_selected
        o_years_cur :
          If recipient_type = Y - year, year_selected
   
        Ref cursors with a single NULL column are returned when there is no relevant data.                 
         
         Expected Return Values:
            0     : Success
            1     : Unknown Error
            600   : No such notification exists                          (cnst.c_notif_missing)
            607   : Existing Notification GUID must be provided          (cnst.c_notif_not_provided)
   */

DROP FUNCTION IF EXISTS oem_notifications_mgt.get_notification_details(text);

CREATE OR REPLACE FUNCTION oem_notifications_mgt.get_notification_details (i_on_guid text, 
                                                                           o_status_code OUT INTEGER,
                                                                           o_notif_cur OUT REFCURSOR, 
                                                                           o_category_or_bndls_cur OUT REFCURSOR, 
                                                                           o_years_cur OUT REFCURSOR) AS $body$
DECLARE

      l_action text;
      l_module_name text := 'get_notification_details';
      l_on_row       beowner.oem_notifications%ROWTYPE;
      l_check_result text;
      l_record    record;
      l_status       beowner.domain_values.notif_status_fk%TYPE;
      l_status_desc  beowner.domain_values.description%TYPE;
	  l_on_guid uuid := i_on_guid::uuid;
      l_exception_diagnostics trc.exception_diagnostics;
	  l_max_year beowner.cfg.value%type := utl.getconfig(utl.get_constant_value('c_cfg_notif_max_year'));

BEGIN
      l_action := utl.set_module_action( l_module_name, 'Validating input');
      o_notif_cur := utl.get_dummy_cursor();
      o_category_or_bndls_cur := utl.get_dummy_cursor();
      o_years_cur := utl.get_dummy_cursor();


     -- l_check_result := o_on_row  => l_on_row := oem_notifications_mgt.validate_on_guid(i_on_guid => i_on_guid);
	
      SELECT * FROM oem_notifications_mgt.validate_on_guid(i_on_guid => l_on_guid) into l_record;
    
      l_check_result := l_record.o_status_code;
     
      l_on_row := l_record.o_on_row;
	
      IF l_check_result != utl.get_constant_value('csuccess')
      THEN
        o_status_code := l_record.o_status_code;
        return;
      END IF; 

      l_status := oem_notifications_mgt.get_notification_status(i_finalized            => l_on_row.finalized,
                                                                i_recalled             => l_on_row.recalled,
                                                                i_start_date           => l_on_row.start_date,
                                                                i_processing_started   => l_on_row.processing_started,
                                                                i_processing_completed => l_on_row.processing_completed,
                                                                i_errored              => l_on_row.errored,
                                                                i_driven_by_event      => l_on_row.driven_by_event); -- DCS1NOTES-566
										  
      l_status_desc := utl.get_domain_value_desc(i_domain => utl.get_constant_value('c_domain_notif_status'),
                                                 i_value  => l_status);

      
	  l_action := utl.set_action('Returning results');
	  
	  close o_notif_cur;

      OPEN o_notif_cur FOR
         SELECT l_on_row.notif_seq    as   notif_seq,
                l_on_row.notif_type    as  notif_type,
                l_on_row.make_id    as     make_id,
                l_status       as          status,
                l_status_desc     as       status_desc,
                l_on_row.start_date   as   start_date,
                l_on_row.expiration_date as expiration_date,
                l_on_row.priority   as     priority,
                l_on_row.subject  as       subject,
                l_on_row.content   as      content,
                l_on_row.recipient_type as  recipient_type,
                l_on_row.hs_os      as     hs_os,
                l_on_row.vin       as      vin,
                l_on_row.vin_batch_guid  as batch_guid
;

      IF l_on_row.recipient_type = utl.get_constant_value('c_recipient_type_model')
      THEN
	     
		 close o_category_or_bndls_cur;
	     
         OPEN o_category_or_bndls_cur FOR

              SELECT DISTINCT mc.category,
                     case WHEN mc.category = l_on_row.model_category THEN utl.get_constant_value('c_yes') else utl.get_constant_value('c_no') END category_selected
              FROM beowner.model_categories mc
              WHERE EXISTS (SELECT 1
                           FROM beowner.vin v
                           WHERE v.make_id = l_on_row.make_id
                           AND v.model = mc.model)
              ORDER BY mc.category;

         IF l_on_row.model_category IS NOT NULL
         THEN
		 
		       close o_years_cur;
		      
               OPEN o_years_cur FOR
                      SELECT DISTINCT v.year as YEAR,
                      CASE WHEN ony.year IS NOT NULL THEN utl.get_constant_value('c_yes') ELSE utl.get_constant_value('c_no') END year_selected
                      FROM beowner.model_categories mc, beowner.vin v
                      LEFT OUTER JOIN beowner.oem_notif_years ony ON (v.year = ony.year AND l_on_guid = ony.on_guid)
                      WHERE v.make_id = l_on_row.make_id AND v.model = mc.model AND mc.category = l_on_row.model_category
					  AND v.year >= utl.get_constant_value('c_min_year') AND v.year <= l_max_year   ORDER BY v.year;
         END IF;
        
      ELSIF l_on_row.recipient_type = utl.get_constant_value('c_recipient_type_bundle')
      THEN
	  
	           close o_category_or_bndls_cur;
	          
               OPEN o_category_or_bndls_cur FOR
                      SELECT d.device_id device_id,b.name as NAME,
                      CASE WHEN ond.device_id IS NOT NULL THEN utl.get_constant_value('c_yes') ELSE utl.get_constant_value('c_no') END device_selected
                      FROM beowner.bndl b, beowner.device d
                      LEFT OUTER JOIN beowner.oem_notif_devices ond ON (d.device_id = ond.device_id AND l_on_guid = ond.on_guid)
                      WHERE d.make_id = l_on_row.make_id AND b.device_id = d.device_id   ORDER BY d.device_id;
      END IF;

      o_status_code := utl.get_constant_value('csuccess');
	  RETURN;
	  
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
		  
          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
						
	      o_notif_cur := utl.get_dummy_cursor();
          o_category_or_bndls_cur := utl.get_dummy_cursor();
          o_years_cur := utl.get_dummy_cursor(); 
		  
          o_status_code := utl.get_constant_value('cinternalerror');
		  
		  RETURN;
   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION oem_notifications_mgt.get_notification_details (i_on_guid oem_notifications.on_guid%TYPE, o_notif_cur OUT REFCURSOR, o_category_or_bndls_cur OUT REFCURSOR, o_years_cur OUT REFCURSOR) FROM PUBLIC;


\i cleanup.sql;
