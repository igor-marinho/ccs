SET bedb.filename = 'procedure.expire_notifications.sql';

\i set_be_env.sql;

/* EXPIRE_NOTIFICATIONS   
  Called internally by scheduled job expire_notifications_job. Deletes notification recipients for expired InBox and sent Push notifications.
*/

DROP PROCEDURE IF EXISTS oem_notifications_mgt.expire_notifications ();

CREATE OR REPLACE PROCEDURE oem_notifications_mgt.expire_notifications (o_status_code INOUT INTEGER)
AS $body$
DECLARE
      l_action text;
      l_module_name text := 'expire_notifications';
      l_exception_diagnostics trc.exception_diagnostics;
	  l_deleted_count integer;
BEGIN
     	  
  l_action := utl.set_module_action( l_module_name, ' Deleting recipients');

  DELETE FROM beowner.oem_notif_recipients onr
  WHERE EXISTS (SELECT oen.on_guid
                  FROM beowner.oem_notifications oen
                 WHERE oen.on_guid = onr.on_guid
                   AND coalesce(oen.expiration_date, clock_timestamp()) <= clock_timestamp()
                   AND oen.processing_completed IS NOT NULL
                   AND oen.start_date < clock_timestamp()
                   AND (oen.driven_by_event IS NULL OR
                        oen.notif_type = utl.get_constant_value ('c_notif_type_push')));
  -- in case processing has completed but push notification start date hasn't occurred yet, notification recipients shouldn't be deleted
  -- intentionally excluded = for start date so that notifications starting right at midnight schedule are kept around until next day
  -- Modified for DCS1NOTES-566 to exclude event-driven inbox messages
  get diagnostics l_deleted_count = ROW_COUNT;

  CALL trc.log(l_deleted_count || ' recipients for expired notificatons deleted');
  o_status_code := utl.get_constant_value('csuccess');

EXCEPTION
  WHEN OTHERS THEN
    GET STACKED diagnostics
      l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
      l_exception_diagnostics.column_name := COLUMN_NAME,
      l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
      l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
      l_exception_diagnostics.message_text := MESSAGE_TEXT,
      l_exception_diagnostics.table_name := TABLE_NAME,
      l_exception_diagnostics.schema_name := SCHEMA_NAME,              
      l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
      l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
      l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

    l_exception_diagnostics.module_name := l_module_name;
    l_exception_diagnostics.action := l_action;

    CALL trc.log(iadditionaldata => NULL,
                 iexception_diagnostics => l_exception_diagnostics);
               
    o_status_code := utl.get_constant_value('cinternalerror');
  
END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE oem_notifications_mgt.expire_notifications () FROM PUBLIC;

\i cleanup.sql;
