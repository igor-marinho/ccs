SET bedb.filename = 'procedure.legacy_usr_push_notif.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS oem_notifications_mgt.legacy_usr_push_notif();

CREATE OR REPLACE PROCEDURE oem_notifications_mgt.legacy_usr_push_notif() AS
$BODY$
DECLARE
    l_action                   text;
    l_module_name              text := 'legacy_usr_push_notif';
    l_make_id                  text;
    l_hs_os                    text;
    l_status_code              text;
    l_vin                      text;
    l_on_guid                  text;
    l_content                  text;
    l_exception_diagnostics    trc.exception_diagnostics;   
    l_frequency                text;

BEGIN
	
    l_action := utl.set_module_action( l_module_name, 'Create Push Notification');
   
    l_frequency := (utl.getconfig('Push message frequency')||' days');
   
    /*Context set by the calling proc*/
   
    /*Check if push notification exits for the user for the day.If yes, don't create a new one*/
   
    IF EXISTS (SELECT onr.usr_id FROM beowner.hist_oem_notif_recipients onr, beowner.ctx_data ctx 
               WHERE onr.usr_id = ctx.usr_id
               AND onr.tmstmp > current_timestamp at time zone 'UTC' - l_frequency::interval
			   AND onr.tmstmp <= current_timestamp at time zone 'UTC') THEN        
         RETURN;
    END IF;     
   
    SELECT s.vin, ctx.make_id, uph.hs_os into l_vin, l_make_id, l_hs_os
    FROM beowner.subscription s, beowner.ctx_data ctx, beowner.usr_push_handsets uph 
    WHERE ctx.usr_id = s.primary_id
    AND   uph.usr_id = ctx.usr_id 
    AND uph.status = utl.get_constant_value('c_valid')
    LIMIT 1;
   
    SELECT o_status_code, o_new_on_guid into l_status_code, l_on_guid FROM oem_notifications_mgt.maintain_draft_notification (i_on_guid         => null::text
                                                                                                                             ,i_make_id         => l_make_id
                                                                                                                             ,i_notif_type      => 'P'
                                                                                                                             ,i_subject         => utl.getconfig('Legacy Push Subject')
                                                                                                                             ,i_content         => utl.getconfig('Legacy Push Content')
                                                                                                                             ,i_start_date      => current_timestamp at time zone 'UTC' + interval '10 minutes'
                                                                                                                             ,i_expiration_date => current_timestamp at time zone 'UTC' + interval '1 day'
                                                                                                                             ,i_priority        => 0
                                                                                                                             ,i_portal_user     => 'Legacy-Login-Push-Notif'
                                                                                                                             );                                                         
    IF l_status_code != utl.get_constant_value('csuccess') 
    THEN         
         RAISE EXCEPTION USING ERRCODE = 'DRAFT';        
    END IF;
                                                         
   l_status_code := oem_notifications_mgt.set_oem_notif_options(i_on_guid        => l_on_guid,
                                                                i_hs_os          => l_hs_os,
                                                                i_recipient_type => 'V',
                                                                i_model_category => null,
                                                                i_vin            => l_vin,
                                                                i_batch_guid     => null,
                                                                i_bundles        => null,
                                                                i_years          => null,
                                                                i_portal_user    => 'Legacy-Login-Push-Notif');                                                        
                                                          
    IF l_status_code != utl.get_constant_value('csuccess') 
    THEN         
         RAISE EXCEPTION USING ERRCODE = 'SETON';
    END IF;

    l_status_code := oem_notifications_mgt.finalize_notification(i_on_guid => l_on_guid,
                                                                 i_portal_user => 'Legacy-Login-Push-Notif');
                                                               
    IF l_status_code != utl.get_constant_value('csuccess') 
    THEN         
         RAISE EXCEPTION USING ERRCODE = 'FINAL';
    END IF;  
                                         
    CALL trc.log ('Notification created for VIN '||l_vin);
                    
EXCEPTION
    WHEN SQLSTATE 'DRAFT' THEN
         CALL trc.log ('Draft Notification could not be created for VIN '||l_vin||' Error code-'||l_status_code);
       
    WHEN SQLSTATE 'SETON' THEN
         CALL trc.log ('Set Notification options unsuccessful for VIN '||l_vin||' Error code-'||l_status_code);
       
    WHEN SQLSTATE 'FINAL' then
         CALL trc.log ('Finalize Notification unsuccessful for VIN '||l_vin||' Error code-'||l_status_code);
        
    WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
		
END;
$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
\i cleanup.sql;