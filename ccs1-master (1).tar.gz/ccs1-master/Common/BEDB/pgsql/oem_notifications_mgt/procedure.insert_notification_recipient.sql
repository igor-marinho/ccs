SET bedb.filename = 'procedure.insert_notification_recipient.sql';

\i set_be_env.sql;

   /* INSERT_NOTIFICATION_RECIPIENT 
      Called internally by other DB sprocs
   */

   -- Added o_onr_guid and overloading for DCS1NOTES-566
DROP PROCEDURE IF EXISTS oem_notifications_mgt.insert_notification_recipient(beowner.usr.usr_id%type,
    beowner.oem_notifications.on_guid%type,
    INOUT beowner.oem_notif_recipients.onr_guid%type);
CREATE OR REPLACE PROCEDURE oem_notifications_mgt.insert_notification_recipient(i_usr_id beowner.usr.usr_id%type,
                                                                                i_on_guid beowner.oem_notifications.on_guid%type,
                                                                                o_onr_guid INOUT beowner.oem_notif_recipients.onr_guid%type) AS
$BODY$
DECLARE

      --Jira DCS1NOTES-299
      --Ignore fk violations for users that still have a job scheduled
      --even though they are not longer in the system
      

BEGIN
      INSERT INTO beowner.oem_notif_recipients(onr_guid, on_guid, usr_id, status)
      VALUES (beowner.rand_guid(), i_on_guid, i_usr_id, 'U')
      RETURNING onr_guid INTO o_onr_guid;
   EXCEPTION
      WHEN unique_violation THEN
         NULL;
      WHEN SQLSTATE '23503' THEN
         NULL;
      WHEN OTHERS THEN
          RAISE;
   END;

$BODY$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE oem_notifications_mgt.insert_notification_recipient (i_usr_id usr.usr_id%TYPE, i_on_guid oem_notifications.on_guid%TYPE, o_onr_guid OUT oem_notif_recipients.onr_guid%TYPE) FROM PUBLIC;
DROP PROCEDURE IF EXISTS oem_notifications_mgt.insert_notification_recipient(beowner.usr.usr_id%type, beowner.oem_notifications.on_guid%type);
CREATE OR REPLACE PROCEDURE oem_notifications_mgt.insert_notification_recipient(i_usr_id beowner.usr.usr_id%type,
                                                                                i_on_guid beowner.oem_notifications.on_guid%type) AS
$BODY$
DECLARE

      l_onr_guid beowner.oem_notif_recipients.onr_guid%TYPE;

BEGIN
      CALL oem_notifications_mgt.insert_notification_recipient(i_usr_id   => i_usr_id,
                                    i_on_guid  => i_on_guid,
                                    o_onr_guid => l_onr_guid);
   END;


$BODY$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE oem_notifications_mgt.insert_notification_recipient (i_usr_id usr.usr_id%TYPE, i_on_guid oem_notifications.on_guid%TYPE) FROM PUBLIC;

\i cleanup.sql;
