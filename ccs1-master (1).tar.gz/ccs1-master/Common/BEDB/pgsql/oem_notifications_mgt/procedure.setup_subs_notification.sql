SET bedb.filename = 'procedure.setup_subs_notification.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS oem_notifications_mgt.setup_subs_notification(beowner.vin.vin%type, beowner.usr.usr_id%type);
CREATE OR REPLACE PROCEDURE oem_notifications_mgt.setup_subs_notification(i_vin beowner.vin.vin%type,
                                                                          i_usr_id beowner.usr.usr_id%type) AS
$body$
/* SETUP_SUBS_NOTIFICATION
   Called internally by other DB sprocs
*/
DECLARE
    l_action                text;
    l_module_name           text := 'setup_subs_notification';
	l_schema_name           TEXT := 'oem_notifications_mgt'; 
    v_job_no                integer;
    rec                     record;
    l_job_action beowner.oem_notif_job.job_action%type;
    l_job_start_date beowner.oem_notif_job.start_time%type;
    l_exception_diagnostics trc.exception_diagnostics;
    c_job_prefix CONSTANT VARCHAR(16) := utl.get_constant_value('c_oem_notif_job_prefix');
BEGIN
    -- Intentionally not setting module so as to not change original module in subscription history
    l_action := utl.set_module_action(l_module_name,'Adding new applicable notifications');
    --if there  are any changes to this logic, make corresponding changes
    --to add_notification_recipients as well
    FOR rec IN (WITH notifs AS (SELECT *
                                FROM beowner.oem_notifications oem
                                WHERE oem.notif_type = utl.get_constant_value('c_notif_type_inbox')
                                  AND oem.processing_started IS NOT NULL
                                  AND oem.expiration_date > clock_timestamp())
                SELECT users.usr_id,
                       users.on_guid,
                       users.processing_completed,
                       users.start_date,
                       users.notif_seq
                FROM (SELECT DISTINCT u.usr_id,
                                      vins.on_guid,
                                      vins.processing_completed,
                                      vins.start_date,
                                      vins.notif_seq
                      FROM beowner.usr u,
                           (SELECT n.*
                            FROM beowner.vin v,
                                 beowner.oem_notif_devices ond,
                                 notifs n
                            WHERE n.recipient_type = utl.get_constant_value('c_recipient_type_bundle')
                              AND ond.on_guid = n.on_guid
                              AND v.vin = i_vin
                              AND v.device_id = ond.device_id
                            UNION ALL
                            SELECT n.*
                            FROM notifs n
                            WHERE n.recipient_type = utl.get_constant_value('c_recipient_type_vin')
                              AND n.vin = i_vin
                            UNION ALL
                            SELECT n.*
                            FROM beowner.data_fix_batch_details dfd,
                                 notifs n
                            WHERE n.recipient_type = utl.get_constant_value('c_recipient_type_vin')
                              AND n.vin IS NULL
                              AND dfd.batch_guid = n.vin_batch_guid
                              AND dfd.vin = i_vin
                            UNION ALL
                            SELECT n.*
                            FROM beowner.vin v,
                                 beowner.oem_notif_years ony,
                                 notifs n,
                                 beowner.model_categories mc
                            WHERE n.recipient_type = utl.get_constant_value('c_recipient_type_model')
                              AND v.vin = i_vin
                              AND v.make_id = n.make_id
                              AND v.model = mc.model
                              AND mc.category = n.model_category
                              AND v.year = ony.year
                              AND ony.on_guid = n.on_guid) vins
                           --cartesian join with vins, only one vin
                           --should be in the sub-query
                      WHERE u.verified IS NOT NULL
                        AND u.usr_id = i_usr_id) users)
        LOOP
        --if processing_completed is null, then schedule a job in order to avoid
        --duplicate inserts from an ongoing add_notification_recipients job. These
        --duplications could occur if add_notification_recipients is running
        --its query to populate oem_notif_recipients
            IF rec.processing_completed IS NULL
            THEN
            
                 l_job_start_date := timezone('UTC',rec.start_date );
                 l_job_action := 'call ' || l_schema_name ||'.insert_notification_recipient(i_usr_id => ''' || rec.usr_id || ''', i_on_guid => ''' || rec.on_guid || ''');';
                
                insert into beowner.oem_notif_job(job_description, job_action, start_time, initial_start_time)
                values (c_job_prefix || rec.notif_seq, l_job_action, l_job_start_date, l_job_start_date);                              

            ELSE

                BEGIN
                    CALL oem_notifications_mgt.insert_notification_recipient(i_usr_id => rec.usr_id,
                                                                             i_on_guid => rec.on_guid);
                EXCEPTION
                    WHEN OTHERS THEN
                        GET STACKED DIAGNOSTICS
                            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
                            l_exception_diagnostics.column_name := COLUMN_NAME,
                            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
                            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
                            l_exception_diagnostics.message_text := MESSAGE_TEXT,
                            l_exception_diagnostics.table_name := TABLE_NAME,
                            l_exception_diagnostics.schema_name := SCHEMA_NAME,
                            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
                            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
                            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
							l_exception_diagnostics.module_name := l_module_name;
							l_exception_diagnostics.action := l_action;
                        CALL trc.log(i_usr_id || ',' || i_vin,
                                        iexception_diagnostics => l_exception_diagnostics);
                END;
            END IF;

        END LOOP;

EXCEPTION
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;

        CALL trc.log(i_usr_id || ',' || i_vin,
                        iexception_diagnostics => l_exception_diagnostics);
END;
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE oem_notifications_mgt.setup_subs_notification (i_vin vin.vin%TYPE, i_usr_id usr.usr_id%TYPE) FROM PUBLIC;

\i cleanup.sql;
