SET bedb.filename = 'procedure.delete_years.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS oem_notifications_mgt.delete_years(beowner.oem_notifications.on_guid%TYPE);
   
CREATE OR REPLACE PROCEDURE oem_notifications_mgt.delete_years (i_on_guid IN beowner.oem_notifications.on_guid%TYPE) AS $body$

BEGIN
DELETE FROM beowner.oem_notif_years WHERE on_guid = i_on_guid;
END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE oem_notifications_mgt.delete_years () FROM PUBLIC;
   
\i cleanup.sql;
