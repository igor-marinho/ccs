SET bedb.filename = 'procedure.delete_bundles.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS oem_notifications_mgt.delete_bundles (beowner.oem_notifications.on_guid%TYPE);

CREATE OR REPLACE PROCEDURE oem_notifications_mgt.delete_bundles (i_on_guid IN beowner.oem_notifications.on_guid%TYPE) AS $body$
BEGIN
DELETE FROM beowner.oem_notif_devices WHERE on_guid = i_on_guid;
END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE oem_notifications_mgt.delete_bundles () FROM PUBLIC;
   
\i cleanup.sql;
