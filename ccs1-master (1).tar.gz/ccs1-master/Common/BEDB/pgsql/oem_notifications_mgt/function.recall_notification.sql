SET bedb.filename = 'function.recall_notification.sql';

\i set_be_env.sql;

   /* RECALL_NOTIFICATION
      For portal to indicate that no more InBox notifications should be sent, after notification has started being sent
          
              0     : Success
              1     : Unknown Error
              4     : Invalid Parameter (length or datatype)
              
              458   : Portal user is mandatory                                                (cnst.c_portal_user_is_null)   
   
              600   : No such notification exists                                             (cnst.c_notif_not_provided)
              607   : Existing Notification GUID must be provided                             (cnst.c_notif_missing)              
              636   : Notification has not been sent yet                                      (cnst.c_not_sent_notif)            
              637   : Only Inbox notifications can be recalled                                (cnst.c_not_inbox_notif)
              638   : Notification has already expired, hence cannot be recalled              (cnst.c_notif_expired_already)   
   */



DROP FUNCTION IF EXISTS oem_notifications_mgt.recall_notification (TEXT,beowner.oem_notifications.created_by%TYPE);

CREATE OR REPLACE FUNCTION oem_notifications_mgt.recall_notification (i_on_guid TEXT, 
                                                                      i_portal_user beowner.oem_notifications.created_by%TYPE) returns INTEGER AS $body$

DECLARE
      l_action text;
      l_module_name text := 'recall_notification';
      l_on_row beowner.oem_notifications;
	  l_exception_diagnostics trc.exception_diagnostics;

BEGIN
     
	  l_action := utl.set_module_action( l_module_name, 'Validating inputs');
	 
	  IF COALESCE(i_on_guid, '') = ''

      THEN
      RETURN utl.get_constant_value('c_notif_not_provided');
      END IF;
      
      IF COALESCE(i_portal_user, '') = ''
      THEN
      RETURN utl.get_constant_value('c_portal_user_is_null');
      END IF;

      BEGIN
           SELECT *
           INTO STRICT l_on_row
           FROM beowner.oem_notifications oen
           WHERE oen.on_guid = i_on_guid::uuid;

         IF l_on_row.notif_type != utl.get_constant_value('c_notif_type_inbox')
         THEN
         RETURN utl.get_constant_value('c_not_inbox_notif');
         END IF;
         IF l_on_row.expiration_date <= clock_timestamp()
         THEN
         RETURN utl.get_constant_value('c_notif_expired_already');
         END IF;
         IF oem_notifications_mgt.get_notification_status(i_finalized            => l_on_row.finalized,
                                    i_recalled             => l_on_row.recalled,
                                    i_start_date           => l_on_row.start_date,
                                    i_processing_started   => l_on_row.processing_started,
                                    i_processing_completed => l_on_row.processing_completed,
                                    i_errored              => l_on_row.errored) !=
            utl.get_constant_value('c_notif_status_sent')
         THEN
         RETURN utl.get_constant_value('c_not_sent_notif');
         END IF;
      EXCEPTION
         WHEN no_data_found THEN
         RETURN utl.get_constant_value('c_notif_missing');
      END;

	  l_action := utl.set_action('Updating notification');

      UPDATE beowner.oem_notifications
         SET expiration_date = clock_timestamp(),
             recalled        = utl.get_constant_value('c_yes'),
             modified_by     = i_portal_user,
             modified_date   = clock_timestamp()
       WHERE on_guid = l_on_row.on_guid;

      RETURN utl.get_constant_value('csuccess');

   EXCEPTION
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
         RETURN utl.get_constant_value('cinvalidparams');
      WHEN OTHERS THEN
		 
		 GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
		
		  RETURN utl.get_constant_value ('cinternalerror');
   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION oem_notifications_mgt.recall_notification (i_on_guid oem_notifications.on_guid%TYPE, i_portal_user oem_notifications.created_by%TYPE) FROM PUBLIC;


\i cleanup.sql;
