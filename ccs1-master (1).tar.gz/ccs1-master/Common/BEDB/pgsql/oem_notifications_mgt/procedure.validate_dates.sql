SET bedb.filename = 'procedure.validate_dates.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS oem_notifications_mgt.validate_dates(beowner.oem_notifications, timestamptz,text);

CREATE OR REPLACE PROCEDURE oem_notifications_mgt.validate_dates(IN on_row beowner.oem_notifications,
                                                                 INOUT add_recips_job_tmstmp_tz timestamptz,
                                                                 INOUT return_code text) AS
$BODY$
DECLARE
    l_add_recip_b4_mins       integer;
    l_notif_max_duration_days integer;
    l_earliest_start_date     beowner.oem_notifications.start_date%type;
BEGIN


    CALL oem_notifications_mgt.get_config_value(utl.get_constant_value('c_cfg_add_recipient_b4_mins'),
                                                return_code,
                                                l_add_recip_b4_mins);

    -- subtracting a minute to allow for time taken to get to this point from the portal call
    l_earliest_start_date := CURRENT_TIMESTAMP + make_interval(mins := l_add_recip_b4_mins - 1);

    --Jira DCS1NOTES-266    --
    --Since l_on_row.start_date is a standard date, any
    --implicit conversions to a timestamp may be affected by the client
    --calling this procedure. Use UTC when doing the timestamp conversion
    add_recips_job_tmstmp_tz := timezone('UTC',(on_row.start_date - make_interval(mins := l_add_recip_b4_mins)));

    CALL oem_notifications_mgt.get_config_value(utl.get_constant_value('c_cfg_notif_max_duration_days'),
                                                return_code,
                                                l_notif_max_duration_days);
    return_code := CASE
                       WHEN on_row.start_date IS NULL THEN
                           utl.get_constant_value('c_start_date_is_null')

                       WHEN on_row.notif_type = utl.get_constant_value('c_notif_type_inbox') AND
                            on_row.expiration_date IS NULL THEN
                           utl.get_constant_value('c_exp_date_is_null')

                       WHEN on_row.notif_type = utl.get_constant_value('c_notif_type_push') AND
                            on_row.expiration_date IS NOT NULL THEN
                           utl.get_constant_value('c_exp_date_only_for_inbox')

                       WHEN on_row.start_date < l_earliest_start_date THEN
                           utl.get_constant_value('c_start_date_too_soon')

                       WHEN on_row.expiration_date - on_row.start_date > make_interval(days :=
                           l_notif_max_duration_days) THEN
                           utl.get_constant_value('c_exp_date_too_far')

                       ELSE
                           utl.get_constant_value('csuccess')
        END;

EXCEPTION
    WHEN no_data_found THEN
        RETURN;
END ;
$BODY$ LANGUAGE PLPGSQL;

\i cleanup.sql;
