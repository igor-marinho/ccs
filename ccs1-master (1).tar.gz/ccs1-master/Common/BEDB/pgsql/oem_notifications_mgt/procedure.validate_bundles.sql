SET bedb.filename = 'procedure.validate_bundles.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS oem_notifications_mgt.validate_bundles(IN beowner.oem_notifications, INOUT text);
CREATE OR REPLACE PROCEDURE oem_notifications_mgt.validate_bundles(IN on_row beowner.oem_notifications,
                                                                   INOUT return_code text) AS
$body$
DECLARE

    l_device_count       integer;
    l_invalid_make_count integer;

BEGIN
    SELECT COUNT(1),
           SUM(CASE
                   WHEN d.make_id != on_row.make_id THEN
                       1
                   ELSE
                       0
               END) invalid_make_count
    INTO STRICT l_device_count,
        l_invalid_make_count
    FROM beowner.oem_notif_devices ond,
         beowner.device d
    WHERE ond.on_guid = on_row.on_guid
      AND d.device_id = ond.device_id;
    return_code := CASE
                       WHEN l_device_count = 0 THEN
                           utl.get_constant_value('c_bundles_is_null')
                       WHEN l_invalid_make_count != 0 THEN
                           utl.get_constant_value('c_incompatible_recip_make')
                       ELSE
                           utl.get_constant_value('csuccess')
        END;
END ;

$body$
    LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE oem_notifications_mgt.validate_bundles () FROM PUBLIC;

\i cleanup.sql;
