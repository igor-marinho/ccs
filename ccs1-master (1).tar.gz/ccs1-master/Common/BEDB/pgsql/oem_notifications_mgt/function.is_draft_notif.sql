SET bedb.filename = 'function.is_draft_notif.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS oem_notifications_mgt.is_draft_notif(beowner.oem_notifications.on_guid%type);
CREATE OR REPLACE PROCEDURE oem_notifications_mgt.is_draft_notif(i_on_guid beowner.oem_notifications.on_guid%type,
                                                                 INOUT o_status boolean,
                                                                 INOUT o_on_row record) AS
$body$
BEGIN
    SELECT *
    INTO STRICT o_on_row
    FROM beowner.oem_notifications oen
    WHERE oen.on_guid = i_on_guid
      AND finalized = utl.get_constant_value('c_no');
    o_status = TRUE;
EXCEPTION
    WHEN no_data_found THEN
        o_status = FALSE;
END;

$body$
    LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION oem_notifications_mgt.is_draft_notif (i_on_guid oem_notifications.on_guid%TYPE, o_on_row OUT oem_notifications) FROM PUBLIC;


\i cleanup.sql;
