SET bedb.filename = 'procedure.get_notification_status.sql';

\i set_be_env.sql;

/* GET_NOTIFICATION_STATUS
   Returns the status of the notification based on the provided column values 
   Only to be used internally
   i_driven_by_event added for DCS1NOTES-566. Is optional as isn't required in most cases
*/
DROP FUNCTION IF EXISTS oem_notifications_mgt.get_notification_status(beowner.oem_notifications.finalized%type,
                                                                    beowner.oem_notifications.recalled%type,
                                                                    beowner.oem_notifications.start_date%type,
                                                                    beowner.oem_notifications.processing_started%type,
                                                                    beowner.oem_notifications.processing_completed%type,
                                                                    beowner.oem_notifications.errored%type,
                                                                    beowner.oem_notifications.driven_by_event%type);
CREATE OR REPLACE FUNCTION oem_notifications_mgt.get_notification_status(i_finalized IN beowner.oem_notifications.finalized%type,
                                                                         i_recalled IN beowner.oem_notifications.recalled%type,
                                                                         i_start_date IN beowner.oem_notifications.start_date%type,
                                                                         i_processing_started IN beowner.oem_notifications.processing_started%type,
                                                                         i_processing_completed IN beowner.oem_notifications.processing_completed%type,
                                                                         i_errored IN beowner.oem_notifications.errored%type,
                                                                         i_driven_by_event IN beowner.oem_notifications.driven_by_event%type DEFAULT NULL)
    RETURNS beowner.domain_values.notif_status_fk%type AS
$body$
DECLARE
    l_notif_status char varying(10);
BEGIN

    -- Modified for DCS1NOTES-468 to add new errored/failed status, 
    -- and for DCS1NOTES-566 to add driven_by_event/internal status
    l_notif_status := CASE
                          WHEN i_driven_by_event IS NOT NULL THEN
                              utl.get_constant_value('c_notif_status_internal')
                          WHEN i_errored = utl.get_constant_value('c_yes') THEN
                              utl.get_constant_value('c_notif_status_errored')
                          WHEN i_recalled = utl.get_constant_value('c_yes') THEN
                              utl.get_constant_value('c_notif_status_recalled')
                          WHEN i_processing_completed IS NOT NULL AND
                               i_start_date <= CURRENT_TIMESTAMP THEN
                              utl.get_constant_value('c_notif_status_sent')
                          WHEN i_processing_started IS NOT NULL AND
                               i_processing_completed IS NULL THEN
                              utl.get_constant_value('c_notif_status_processing')
                          WHEN i_processing_completed IS NOT NULL AND
                               i_start_date > CURRENT_TIMESTAMP THEN
                              utl.get_constant_value('c_notif_status_ready_to_send')
                          WHEN i_finalized = utl.get_constant_value('c_yes') THEN
                              utl.get_constant_value('c_notif_status_finalized')
                          ELSE
                              utl.get_constant_value('c_notif_status_draft')
        END;

    RETURN l_notif_status;
END ;


$body$
    LANGUAGE PLPGSQL
;

\i cleanup.sql;
