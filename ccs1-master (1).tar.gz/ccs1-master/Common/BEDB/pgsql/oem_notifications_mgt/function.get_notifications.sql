SET bedb.filename = 'function.get_notifications.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS oem_notifications_mgt.get_notifications(beowner.domain_values.notif_status_fk%type, text);
CREATE OR REPLACE FUNCTION oem_notifications_mgt.get_notifications(i_status beowner.domain_values.notif_status_fk%type,
                                                                   i_export text DEFAULT 'N',
                                                                   OUT o_status_code integer,
                                                                   OUT o_result refcursor) AS
$body$
/* GET_NOTIFICATIONS
   To be used by portal for retrieving high level notification details for notifications with a specific status

 Out : Refcursor - ON_guid, notif_seq, notif_type, status, status_desc, hs_os, subject, start_date, expiration_date, priority, modified_by

 When i_export is passed as Y, an additional header row is returned as the very first one.
 For input status of S (Sent), the number of rows returned is restricted by config option 'OEM notifications rows returned'.
 Format of dates returned is determined by config option 'OEM notif date format'.

       Expected Return Values:
         0     : Success
         1     : Unknown Error
         602   : Invalid notification status (only D, F and S allowed)     (cnst.c_notif_invalid_status)
         618   : Value besides Y and N was provided for export parameter   (cnst.c_invalid_export_value)
*/

DECLARE
    l_action                text;
    l_module_name           text := 'get_notifications';
    l_status                beowner.domain_values.notif_status_fk%type;
    l_export                varchar(1);
    l_domain				text := utl.get_constant_value('c_domain_notif_status');
    l_rows_returned         beowner.cfg.value%type;
    l_date_format           beowner.cfg.value%type;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    o_result := utl.get_dummy_cursor();
    l_action := utl.set_module_action(l_module_name, 'Validating inputs');

    l_status := upper(i_status);
    IF l_status NOT IN (utl.get_constant_value('c_notif_status_draft'),
                        utl.get_constant_value('c_notif_status_finalized'),
                        utl.get_constant_value('c_notif_status_sent'))
    THEN
        o_status_code := utl.get_constant_value('c_notif_invalid_status');
        RETURN;
    END IF;

    l_export := coalesce(upper(i_export), utl.get_constant_value('c_no'));
    IF l_export NOT IN (utl.get_constant_value('c_yes'), utl.get_constant_value('c_no'))
    THEN
        o_status_code := utl.get_constant_value('c_invalid_export_value');
        RETURN;
    END IF;

    l_action := utl.set_module_action(l_module_name, 'Get config options');

    l_date_format := utl.getconfig(icfgname => utl.get_constant_value('c_cfg_notif_date_format'));

    l_rows_returned := utl.getconfig(icfgname => utl.get_constant_value('c_cfg_notif_rows_returned'));

    l_action := utl.set_module_action(l_module_name, 'Returning results');

    -- modified for DCS1NOTES-272 to show first 40 chars of content in subject when subject is null
    CLOSE o_result;
    OPEN o_result FOR
        SELECT 'ON_GUID'         on_guid,
               'NOTIF_SEQ'       notif_seq,
               'NOTIF_TYPE'      notif_type,
               'STATUS'          status,
               'STATUS_DESC'     status_desc,
               'HS_OS'           hs_os,
               'SUBJECT'         subject,
               'START_DATE'      start_date,
               'EXPIRATION_DATE' expiration_date,
               'PRIORITY'        priority,
               'MODIFIED_BY'     modified_by
        WHERE l_export = utl.get_constant_value('c_yes')
        UNION ALL
        SELECT notifs.on_guid::text                       on_guid,
               notifs.notif_seq::text                      notif_seq,
               notifs.notif_type                              notif_type,
               notifs.status                                  status,
               notifs.status_desc                             status_desc,
               notifs.hs_os                                   hs_os,
               notifs.subject                                 subject,
               to_char(notifs.start_date, l_date_format)      start_date,
               to_char(notifs.expiration_date, l_date_format) expiration_date,
               notifs.priority::text                       priority,
               notifs.modified_by                             modified_by
        FROM (SELECT all_notifs.on_guid,
                     all_notifs.notif_seq,
                     all_notifs.notif_type,
                     all_notifs.status,
                     dv.description                                          status_desc,
                     all_notifs.hs_os,
                     all_notifs.subject,
                     all_notifs.start_date,
                     all_notifs.expiration_date,
                     all_notifs.priority                                     priority,
                     all_notifs.modified_by
              FROM (SELECT oem_notifications_mgt.get_notification_status(i_finalized => oen.finalized,
                                                                         i_recalled => oen.recalled,
                                                                         i_start_date => oen.start_date,
                                                                         i_processing_started => oen.processing_started,
                                                                         i_processing_completed => oen.processing_completed,
                                                                         i_errored => oen.errored,
                                                                         i_driven_by_event => oen.driven_by_event) status, -- DCS1NOTES-566
                         oen.on_guid,
	                     oen.notif_seq,
	                     oen.notif_type,
	                     oen.hs_os,
	                     coalesce(oen.subject,
                              CAST(substr(oen.content, 1, 40) AS varchar(40)))   subject,
	                     oen.start_date,
	                     oen.expiration_date,
	                     oen.priority                                     priority,
	                     coalesce(oen.modified_by, oen.created_by) modified_by
                    FROM beowner.oem_notifications oen
                    ORDER BY coalesce(oen.modified_date,
                                oen.created_date) DESC) all_notifs,
                   beowner.domain_values dv
              WHERE dv.domain =  l_domain 				--utl.get_constant_value('c_domain_notif_status')
                AND dv.value  = all_notifs.status
                AND dv.attribute1 = l_status  ) notifs
        LIMIT (l_rows_returned::bigint);

    o_status_code := utl.get_constant_value('csuccess');
    RETURN;
EXCEPTION
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL, iexception_diagnostics => l_exception_diagnostics);
        o_result := utl.get_dummy_cursor();
        o_status_code := utl.get_constant_value('cinternalerror');
        RETURN;
END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION oem_notifications_mgt.get_notifications (i_status domain_values.notif_status_fk%TYPE, o_result OUT REFCURSOR, i_export text DEFAULT 'N') FROM PUBLIC;


\i cleanup.sql;
