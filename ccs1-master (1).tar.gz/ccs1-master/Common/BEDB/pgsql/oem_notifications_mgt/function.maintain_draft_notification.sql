SET bedb.filename = 'function.maintain_draft_notification.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS oem_notifications_mgt.maintain_draft_notification (beowner.oem_notifications.on_guid%TYPE
																		  ,beowner.make.make_id%TYPE
																		  ,beowner.oem_notifications.notif_type%TYPE
																		  ,beowner.oem_notifications.subject%TYPE
																		  ,beowner.oem_notifications.content%TYPE
																		  ,beowner.oem_notifications.start_date%TYPE
																		  ,beowner.oem_notifications.expiration_date%TYPE
																		  ,beowner.oem_notifications.priority%TYPE
																		  ,beowner.oem_notifications.created_by%TYPE);
DROP FUNCTION IF EXISTS oem_notifications_mgt.maintain_draft_notification ( TEXT
                                                                           ,beowner.make.make_id%TYPE
                                                                           ,beowner.oem_notifications.notif_type%TYPE
                                                                           ,beowner.oem_notifications.subject%TYPE
                                                                           ,beowner.oem_notifications.content%TYPE
                                                                           ,beowner.oem_notifications.start_date%TYPE
                                                                           ,beowner.oem_notifications.expiration_date%TYPE
                                                                           ,beowner.oem_notifications.priority%TYPE
                                                                           ,beowner.oem_notifications.created_by%TYPE);
DROP FUNCTION IF EXISTS oem_notifications_mgt.maintain_draft_notification ( TEXT
                                                                           ,beowner.make.make_id%TYPE
                                                                           ,beowner.oem_notifications.notif_type%TYPE
                                                                           ,beowner.oem_notifications.subject%TYPE
                                                                           ,beowner.oem_notifications.content%TYPE
                                                                           ,beowner.oem_notifications.start_date%TYPE
                                                                           ,beowner.oem_notifications.expiration_date%TYPE
                                                                           ,INTEGER
                                                                           ,beowner.oem_notifications.created_by%TYPE);
/* MAINTAIN_DRAFT_NOTIFICATION
   To be used by portal to create/edit message draft notification.

   Out : o_new_on_guid - GUID for new notification (only)

   Expected Return Values:
      0     : Success
      1     : Unknown Error
      4     : Invalid Parameter (length or datatype)
      222   : Invalid Make ID or Make Id is null             (cnst.cinvalidmake)
      423   : Start date should be prior to expiry date      (cnst.c_started_should_prior_expiry)
      458   : Portal user is mandatory                       (cnst.c_portal_user_is_null)
      605   : Invalid Notification type                      (cnst.c_invalid_notif_type)
      606   : Draft Notification doesn't exist               (cnst.c_not_draft_notif)
*/
CREATE OR REPLACE FUNCTION oem_notifications_mgt.maintain_draft_notification (i_on_guid               TEXT
                                                                             ,i_make_id               beowner.make.make_id%TYPE
                                                                             ,i_notif_type            beowner.oem_notifications.notif_type%TYPE
                                                                             ,i_subject               beowner.oem_notifications.subject%TYPE
                                                                             ,i_content               beowner.oem_notifications.content%TYPE
                                                                             ,i_start_date            beowner.oem_notifications.start_date%TYPE
                                                                             ,i_expiration_date       beowner.oem_notifications.expiration_date%TYPE
                                                                             ,i_priority              INTEGER
                                                                             ,i_portal_user           beowner.oem_notifications.created_by%TYPE
                                                                             ,o_status_code       OUT INTEGER
                                                                             ,o_new_on_guid       OUT TEXT) AS
$body$
DECLARE
    l_action                text;
    l_module_name           text := 'maintain_draft_notification';
    l_on_guid               beowner.oem_notifications.on_guid%type;
    l_make_id               beowner.make.make_id%type;
    l_notif_type            beowner.oem_notifications.notif_type%type;
    l_priority              beowner.oem_notifications.priority%type;
    l_notif_seq             beowner.oem_notifications.notif_seq%type;
    l_start_date            beowner.oem_notifications.start_date%type;
    l_expiration_date       beowner.oem_notifications.expiration_date%type;
    l_dummy_row             record;
    l_is_draft_notif        boolean;
    l_exception_diagnostics trc.exception_diagnostics;
    l_subject               beowner.oem_notifications.subject%TYPE;
    l_content               beowner.oem_notifications.content%type;

BEGIN

    l_action := utl.set_module_action(l_module_name, 'Validating inputs');
  
    --prevent the empty string from being used
    l_subject := NULLIF(trim(both i_subject),'');
    l_content := NULLIF(trim(both i_content),'');

    l_make_id := upper(i_make_id);
    IF NOT utl.is_make_valid(i_make_id => l_make_id)
    THEN
        o_status_code := utl.get_constant_value('cinvalidmake');
        RETURN;
    END IF;

    l_notif_type := upper(i_notif_type);
    IF NOT utl.is_domain_value_valid(i_domain => utl.get_constant_value('c_domain_notif_type'),
                                     i_value => l_notif_type)
    THEN
        o_status_code := utl.get_constant_value('c_invalid_notif_type');
        RETURN;
    END IF;

    l_priority := coalesce(i_priority, 0); -- will raise value_error if not a number
    IF  l_priority > 9
    THEN
        RAISE EXCEPTION numeric_value_out_of_range;
    END IF;
  
    l_start_date := i_start_date;
    l_expiration_date := i_expiration_date;

    IF l_notif_type = utl.get_constant_value('c_notif_type_push') THEN
        l_expiration_date := NULL;
    ELSIF l_start_date IS NOT NULL AND
          l_expiration_date IS NOT NULL AND
          l_expiration_date < l_start_date
    THEN
        o_status_code := utl.get_constant_value('c_started_should_prior_expiry');
        RETURN;
    END IF;

    IF i_portal_user IS NULL
    THEN
        o_status_code := utl.get_constant_value('c_portal_user_is_null');
        RETURN;
    END IF;

    IF COALESCE(i_on_guid, '') != ''
    THEN
        l_on_guid := i_on_guid::UUID;
        CALL  oem_notifications_mgt.is_draft_notif(l_on_guid,l_is_draft_notif, l_dummy_row);
        IF NOT l_is_draft_notif THEN
            o_status_code = utl.get_constant_value('c_not_draft_notif');
            RETURN;
        END IF;
    ELSE
        -- New Notification
        l_on_guid := beowner.rand_guid();
        l_notif_seq := oem_notifications_mgt.generate_notification_seq();
    END IF;
    l_action := utl.set_module_action(l_module_name, 'Populating Notification row');

    INSERT INTO beowner.oem_notifications(on_guid,
                                          notif_type,
                                          finalized,
                                          make_id,
                                          notif_seq,
                                          created_by,
                                          created_date,
                                          recalled,
                                          content,
                                          start_date,
                                          expiration_date,
                                          subject,
                                          priority)
    VALUES (l_on_guid,
            l_notif_type,
            utl.get_constant_value('c_no'),
            l_make_id,
            COALESCE(l_notif_seq, 1),
            i_portal_user,
            current_timestamp,
            utl.get_constant_value('c_no'),
            l_content,
            l_start_date,
            l_expiration_date,
            l_subject,
            l_priority)
    ON CONFLICT ON CONSTRAINT oem_notifications_pk
        DO UPDATE SET notif_type = l_notif_type,
                      make_id         = l_make_id,
                      content         = l_content,
                      modified_by     = i_portal_user,
                      modified_date   = current_timestamp,
                      start_date      = l_start_date,
                      expiration_date = l_expiration_date,
                      subject         = l_subject,
                      priority        = l_priority,
                      hs_os           = CASE
                                            WHEN l_notif_type = utl.get_constant_value('c_notif_type_push') 
                                            THEN oem_notifications.hs_os
                                            ELSE NULL
                                        END;


    IF COALESCE(i_on_guid, '') = ''
    THEN
        o_new_on_guid := l_on_guid;
    END IF;

    o_status_code = utl.get_constant_value('csuccess');
    RETURN;
EXCEPTION
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
        o_status_code = utl.get_constant_value('cinvalidparams');
        RETURN;
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);

        o_status_code = utl.get_constant_value('cinternalerror');
        RETURN;
   END;
$body$ 
LANGUAGE PLPGSQL 
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION oem_notifications_mgt.maintain_draft_notification (i_on_guid oem_notifications.on_guid%TYPE, i_make_id make.make_id%TYPE, i_notif_type oem_notifications.notif_type %TYPE, i_subject oem_notifications.subject %TYPE, i_content oem_notifications.content %TYPE, i_start_date oem_notifications.start_date %TYPE, i_expiration_date oem_notifications.expiration_date %TYPE, i_priority oem_notifications.priority %TYPE, i_portal_user oem_notifications.created_by %TYPE, o_new_on_guid OUT oem_notifications.on_guid%TYPE) FROM PUBLIC;


\i cleanup.sql;
