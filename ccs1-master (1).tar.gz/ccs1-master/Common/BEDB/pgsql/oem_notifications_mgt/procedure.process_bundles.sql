SET bedb.filename = 'procedure.process_bundles.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS oem_notifications_mgt.process_bundles(VARCHAR(4000),
                                                               beowner.oem_notifications.on_guid%type,
                                                               TEXT);
   
CREATE OR REPLACE PROCEDURE oem_notifications_mgt.process_bundles (i_bundles IN VARCHAR(4000),
                                                                   i_on_guid IN beowner.oem_notifications.on_guid%type,
                                                                   o_return_code INOUT TEXT) AS $body$

DECLARE
         l_action text;
         l_module_name text := 'process_bundles';
         l_device_id      beowner.device.device_id%TYPE;
         l_device_make_id beowner.device.make_id%TYPE;
		 l_bundles        VARCHAR(4000);
		 l_exception_diagnostics trc.exception_diagnostics;
         devices_rec RECORD;

begin
	
	    l_action := utl.set_module_action( l_module_name, 'Processing bundles');
         -- start from scratch in case there are changes
         CALL oem_notifications_mgt.delete_bundles(i_on_guid => i_on_guid);
		 
		 l_bundles := rtrim(ltrim(upper(i_bundles), ','), ',');

         IF COALESCE(l_bundles, '') != '' 
         THEN
         
           FOR devices_rec IN (SELECT DISTINCT (regexp_split_to_table(l_bundles,E',')) AS device)
         
            LOOP
               l_device_id := devices_rec.device;

               BEGIN
                  SELECT make_id
                    INTO STRICT l_device_make_id
                    FROM beowner.device
                   WHERE device_id = l_device_id;
               EXCEPTION
                  WHEN no_data_found THEN
                     o_return_code := utl.get_constant_value('cdeviceiddoesnotexist');
                     RETURN;
               END;
               INSERT INTO beowner.oem_notif_devices(ond_guid, on_guid, device_id)
               VALUES (beowner.rand_guid(), i_on_guid, l_device_id);
            END LOOP;
         END IF;
         o_return_code := utl.get_constant_value('csuccess');
      exception
      
         WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
          o_return_code := utl.get_constant_value('cinvalidparams');
       
         WHEN OTHERS then
         
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
                       
          o_return_code := utl.get_constant_value('c_invalid_device_list');
      END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE oem_notifications_mgt.process_bundles (o_return_code OUT cnst.vc) FROM PUBLIC;
   
\i cleanup.sql;

