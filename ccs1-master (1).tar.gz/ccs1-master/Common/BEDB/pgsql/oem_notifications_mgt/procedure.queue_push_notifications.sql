SET bedb.filename = 'procedure.queue_push_notifications.sql';

\i set_be_env.sql;

DROP procedure if exists oem_notifications_mgt.queue_push_notifications(beowner.oem_notifications);

CREATE OR REPLACE PROCEDURE oem_notifications_mgt.queue_push_notifications(i_on_row IN beowner.oem_notifications) AS $body$
declare

      l_action text;
      l_module_name text := 'queue_push_notifications'; 
      l_key_values         xml;
      l_unread_message_cnt integer;
      push_recipients record;
     
   BEGIN
       
     l_action := utl.set_module_action( l_module_name, 'Looping through push candidates');
   
      FOR push_recipients IN (SELECT dv.hs_os_fk hs_os,
                                     uph.push_token,
                                     onr.onr_guid,
                                     onr.usr_id
                                FROM beowner.oem_notif_recipients onr,
                                     beowner.usr_push_handsets    uph,
                                     beowner.domain_values        dv
                               WHERE dv.hs_os_fk =
                                     coalesce(i_on_row.hs_os, dv.hs_os_fk)
                                     AND onr.on_guid = i_on_row.on_guid
                                     AND uph.usr_id = onr.usr_id
                                     AND uph.hs_os = dv.hs_os_fk
                                     AND uph.status = utl.get_constant_value('c_valid'))
      LOOP
         IF i_on_row.notif_type = utl.get_constant_value('c_notif_type_push') -- Normal push message
         then
         
            SELECT xmlconcat(xmlelement(name "body", i_on_row.content),
                             xmlelement(name "pushTarget",
                                        xmlelement(name "deviceOs",
                                                   push_recipients.hs_os),
                                        xmlelement(name "token",
                                                   push_recipients.push_token)))
              INTO l_key_values;
         
         ELSE
            -- InBox push - DCS1NOTES-492
         
            SELECT COUNT(*)
              INTO l_unread_message_cnt
              FROM (SELECT row_number() over(ORDER BY onr.created_date DESC, oem.start_date DESC, oem.notif_seq DESC) AS rn,
                           onr.status
                      FROM beowner.oem_notif_recipients onr
                      JOIN beowner.oem_notifications oem
                        ON (oem.on_guid = onr.on_guid)
                     WHERE oem.notif_type = utl.get_constant_value('c_notif_type_inbox')
                           AND oem.start_date <= i_on_row.start_date
                           AND oem.expiration_date > CURRENT_TIMESTAMP
                           AND onr.usr_id = push_recipients.usr_id) msg
             WHERE msg.rn <= utl.getconfig(utl.get_constant_value('c_cfg_notif_rows_ret_client'))::integer
                   AND msg.status IN
                   (utl.get_constant_value('c_recipient_status_sent'),
                        utl.get_constant_value('c_recipient_status_unread'));
         
            /* <ns2:PushRequest xmlns:ns2="http://www.tweddletech.com/SmtpCore">
              <title>New inbox message</title>
              <body>You have 1 new messages</body>
              <data name="inbox_unread">1</data>
              <pushTarget>
                <deviceOs>ANDROID/IOS</deviceOs>
                <token>hs_token_for_deviceOS</token>
              </pushTarget>
            </ns2:PushRequest> 
            
            REPLACE(g_inbox_push_msg_body,'$1',l_unread_message_cnt)
            */
         
            SELECT xmlconcat(xmlelement(name "title", utl.getconfig(utl.get_constant_value('c_cfg_inbox_push_msg_title'))),
                             xmlelement(name "body", i_on_row.subject),
                             xmlelement(name "data",
                                        xmlattributes('inbox_unread' AS "name"),
                                        l_unread_message_cnt),
                             xmlelement(name "pushTarget",
                                        xmlelement(name "deviceOs",
                                                   push_recipients.hs_os),
                                        xmlelement(name "token",
                                                   push_recipients.push_token)))
              INTO l_key_values;
         END IF;
      
       perform utl.push_message_to_queue(i_make_id      => i_on_row.make_id,
									     i_key_values   => l_key_values,
									     i_enqueue_time => timezone('UTC',i_on_row.start_date)); -- DCS1NOTES-566

         IF i_on_row.notif_type = utl.get_constant_value('c_notif_type_push') -- Sent status should only be updated for normal push message
         THEN
            UPDATE beowner.oem_notif_recipients 
            SET sent_on = clock_timestamp()
			  , status = CASE WHEN read_on IS NULL 
							THEN 'S' ELSE status
						 END						/*Update relavant status when read_on, sent_on, deleted_on are modified*/
            WHERE onr_guid = push_recipients.onr_guid
            AND sent_on IS NULL; -- in case the user has multiple tokens, the row will only be updated the first time
         
         END IF;
      END LOOP;
   
      -- any exceptions encountered should be promoted to the calling sproc   
   END;
   
$body$
LANGUAGE PLPGSQL
;

\i cleanup.sql;
