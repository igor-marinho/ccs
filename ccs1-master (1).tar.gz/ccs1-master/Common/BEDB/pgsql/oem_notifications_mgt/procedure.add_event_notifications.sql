SET bedb.filename = 'procedure.add_event_notifications.sql';

\i set_be_env.sql;


   -- Added for DCS1NOTES-566, for internal use, to be called from other triggers or sprocs
   
DROP PROCEDURE IF EXISTS oem_notifications_mgt.add_event_notifications (beowner.usr.usr_id%TYPE,
                                                                        beowner.oem_notifications.driven_by_event%TYPE,
																		beowner.vin.vin%TYPE,
																		TEXT);

CREATE OR REPLACE PROCEDURE oem_notifications_mgt.add_event_notifications (i_usr_id  beowner.usr.usr_id%TYPE, 
                                                                           i_event   beowner.oem_notifications.driven_by_event%TYPE, 
																		   i_vin     beowner.vin.vin%TYPE DEFAULT NULL,
																		   i_bndl_id TEXT DEFAULT NULL) AS $body$
DECLARE

      -- only need usr_id for now, bndl_id and vin are for future use
      l_make_id     beowner.usr.make_id%TYPE;
      l_create_type beowner.usr.create_type%TYPE;
      l_created     beowner.usr.created%TYPE;
      l_on_guid     beowner.oem_notifications.on_guid%TYPE;
      l_hs_os       beowner.oem_notifications.hs_os%TYPE;
      l_push_token  beowner.usr_push_handsets.push_token%TYPE;
      l_content     beowner.oem_notifications.content%TYPE;
      l_priority    beowner.oem_notifications.priority%TYPE;
      l_key_values  xml;
      l_onr_guid    beowner.oem_notif_recipients.onr_guid%TYPE;

BEGIN
      -- Intentionally not setting module so as to not change original module in subscription history
      IF i_event = utl.get_constant_value('c_notif_event_new_account')
      THEN

         SELECT make_id,
                create_type,
                created
           INTO STRICT l_make_id,
                l_create_type,
                l_created
           FROM beowner.usr
          WHERE usr_id = i_usr_id;

         -- Only sending if the user was created within the last 2 minutes via a phone
         -- this ensures that notifications aren't sent again if the user adds another VIN to their account subsequently
         IF l_create_type = utl.get_constant_value('c_create_type_phone') AND
            l_created > CURRENT_TIMESTAMP - INTERVAL '2' minute
         THEN
           -- SELECT * FROM oem_notifications_mgt.get_event_notif_details(i_make_id    => l_make_id, i_event      => i_event, i_notif_type => cnst.c_notif_type_inbox, o_on_guid    => l_on_guid, o_content    => l_content) 
			--INTO STRICT o_priority   => l_priority, ,;
			
		  CALL oem_notifications_mgt.get_event_notif_details( i_make_id    => l_make_id,
                                                                                      i_event      => i_event,
                                                                                      i_notif_type => utl.get_constant_value('c_notif_type_inbox'),
                                                                                      o_on_guid    => l_on_guid,
                                                                                      o_content    => l_content,
                                                                                      o_priority   => l_priority);

            IF l_on_guid IS NOT NULL
			
            THEN
			
               CALL oem_notifications_mgt.insert_notification_recipient(i_usr_id  => i_usr_id,
                                                                        i_on_guid => l_on_guid);
            END IF;

            -- Send push message
            BEGIN
               SELECT uph.hs_os,uph.push_token INTO STRICT l_hs_os, l_push_token
               FROM beowner.usr_push_handsets uph
               WHERE uph.usr_id = i_usr_id
               AND uph.status = utl.get_constant_value('c_valid');

            EXCEPTION
               WHEN no_data_found THEN
               RETURN;
            END;

         --   SELECT * FROM oem_notifications_mgt.get_event_notif_details(i_make_id    => l_make_id, i_event      => i_event, i_notif_type => cnst.c_notif_type_push, i_hs_os      => l_hs_os, o_on_guid    => l_on_guid) INTO STRICT o_content    => l_content, o_priority   => l_priority,;
			
			CALL oem_notifications_mgt.get_event_notif_details(i_make_id    => l_make_id,
                                                               i_event      => i_event,
                                                               i_notif_type => utl.get_constant_value('c_notif_type_push'),                                                             
                                                               o_on_guid    => l_on_guid,
                                                               o_content    => l_content,
                                                               o_priority   => l_priority,
															   i_hs_os      => l_hs_os);
			
            IF l_on_guid IS NOT NULL
            THEN
			
               CALL oem_notifications_mgt.insert_notification_recipient(i_usr_id   => i_usr_id,
                                                                        i_on_guid  => l_on_guid,
                                                                        o_onr_guid => l_onr_guid);

               SELECT xmlconcat(XMLELEMENT(name "body", l_content),
                                XMLELEMENT(name "pushTarget",
                                           XMLELEMENT(name "deviceOs", l_hs_os),
                                           XMLELEMENT(name "token", l_push_token)))
                 INTO STRICT l_key_values;


             PERFORM utl.push_message_to_queue(i_make_id      => l_make_id,
                                                 i_key_values   => l_key_values,
                                                 i_enqueue_time => clock_timestamp());

               UPDATE beowner.oem_notif_recipients
                  SET sent_on = clock_timestamp()
					 ,status =   CASE WHEN read_on IS NULL 
									THEN 'S' ELSE status
								  END		/*Update relavant status when read_on, sent_on, deleted_on are modified*/
                WHERE onr_guid = l_onr_guid
                      AND sent_on is NULL; -- in case there are multiple tokens for the same user, unlikely in this case
            END IF;
         END IF;
      END IF;
   END;


$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON PROCEDURE oem_notifications_mgt.add_event_notifications (i_usr_id usr.usr_id%TYPE, i_event oem_notifications.driven_by_event%TYPE, i_vin vin.vin%TYPE DEFAULT NULL, i_bndl_id bndl.bndl_id%TYPE DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
