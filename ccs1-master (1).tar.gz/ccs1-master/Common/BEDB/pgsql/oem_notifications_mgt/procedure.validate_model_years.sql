SET bedb.filename = 'procedure.validate_model_years.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS oem_notifications_mgt.validate_model_years(beowner.oem_notifications, INOUT text);
CREATE OR REPLACE PROCEDURE oem_notifications_mgt.validate_model_years(IN on_row beowner.oem_notifications,
                                                                       INOUT return_code text) AS
$body$
DECLARE

    l_year_count         integer;
    l_invalid_year_count integer;
    l_g_max_year         beowner.cfg.value%type;

BEGIN
    return_code := utl.get_constant_value('csuccess');
    IF on_row.model_category IS NULL THEN
        return_code := utl.get_constant_value('c_model_category_is_null');
    ELSIF NOT utl.is_model_category_valid(i_category => on_row.model_category) THEN
        return_code := utl.get_constant_value('c_invalid_model_category');
    ELSE
        l_g_max_year := utl.getconfig(utl.get_constant_value('c_cfg_notif_max_year'));
        SELECT COUNT(1),
               SUM(CASE
                       WHEN ony.year NOT BETWEEN utl.get_constant_value('c_min_year')
                           AND l_g_max_year THEN
                           1
                       ELSE
                           0
                   END) invalid_year_count
        INTO l_year_count,
            l_invalid_year_count
        FROM beowner.oem_notif_years ony
        WHERE ony.on_guid = on_row.on_guid;
        IF l_year_count = 0
        THEN
            return_code := utl.get_constant_value('c_no_years_provided');
        ELSIF l_invalid_year_count != 0
        THEN
            return_code := utl.get_constant_value('c_invalid_notif_year');
        END IF;
    END IF;
END ;

$body$
    LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE oem_notifications_mgt.validate_model_years () FROM PUBLIC;

\i cleanup.sql;
