SET bedb.filename = 'procedure.validate_vin_batch.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS oem_notifications_mgt.validate_vin_batch(beowner.oem_notifications, INOUT text);
CREATE OR REPLACE PROCEDURE oem_notifications_mgt.validate_vin_batch(IN on_row beowner.oem_notifications,
                                                                     INOUT return_code text) AS
$body$
DECLARE

    l_make_id      beowner.vin.make_id%type;
    l_is_vin_valid boolean;
    l_batch_status beowner.data_fix_batches.status%type;
    l_error_count  integer;
    l_result_count integer;

BEGIN
    CASE
        WHEN on_row.vin IS NULL AND
             on_row.vin_batch_guid IS NULL THEN
            return_code := utl.get_constant_value('c_vin_or_batch_mandatory');
        WHEN on_row.vin IS NOT NULL AND
             on_row.vin_batch_guid IS NOT NULL THEN
            return_code := utl.get_constant_value('c_either_vin_or_batch');
        WHEN on_row.vin IS NOT NULL THEN
            SELECT rst.o_status_code, rst.o_make_id
            INTO STRICT l_is_vin_valid, l_make_id
            FROM utl.is_vin_valid(on_row.vin) rst;
            CASE
                -- this must be kept first, as next condition depends on it
                WHEN NOT l_is_vin_valid THEN
                    return_code := utl.get_constant_value('cdbvinnotfound');
                WHEN l_make_id != on_row.make_id THEN
                    return_code := utl.get_constant_value('c_incompatible_recip_make');
                ELSE
                    return_code := utl.get_constant_value('csuccess');
                END CASE;
        ELSE
            --  on_row.vin_batch_guid IS NOT NULL
            BEGIN
                SELECT dfb.status,
                       dfb.make_id,
                       SUM(CASE
                               WHEN coalesce(dfr.status,
                                             dfd.error_code,
                                             dfb.error_code) != utl.get_constant_value('csuccess') THEN
                                   1
                               ELSE
                                   0
                           END)               error_count,
                       COUNT(dfr.detail_guid) result_count
                INTO STRICT l_batch_status,
                    l_make_id,
                    l_error_count,
                    l_result_count
                FROM beowner.data_fix_batches dfb,
                     beowner.data_fix_batch_details dfd
                         LEFT OUTER JOIN beowner.data_fix_results dfr ON (dfd.detail_guid = dfr.detail_guid)
                WHERE dfb.batch_guid = on_row.vin_batch_guid
                  AND dfd.batch_guid = dfb.batch_guid
                GROUP BY dfb.status,
                         dfb.make_id;

                return_code := CASE
                                   WHEN l_make_id != on_row.make_id THEN
                                       utl.get_constant_value('c_incompatible_recip_make')
                                   WHEN l_batch_status != utl.get_constant_value('c_batch_complete') THEN
                                       utl.get_constant_value('c_batch_incomplete')
                                   WHEN l_error_count != 0 THEN
                                       utl.get_constant_value('c_batch_has_errors')
                                   WHEN l_result_count = 0 THEN
                                       utl.get_constant_value('c_batch_is_empty')
                                   ELSE
                                       utl.get_constant_value('csuccess')
                    END;

            EXCEPTION
                WHEN no_data_found THEN
                    return_code := utl.get_constant_value('c_batch_not_found');
            END;
        END CASE;
END;

$body$ LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE oem_notifications_mgt.validate_vin_batch () FROM PUBLIC;

\i cleanup.sql;
