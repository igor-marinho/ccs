SET bedb.filename = 'procedure.delete_notification_recipient.sql';

\i set_be_env.sql;

   /*
   Called internally
   Deletes corresponding row/s from oem_notif_recipients. 
   Deletes all rows for the user if i_on_guid is null and all rows for notification if i_usr_Id is null. Both cannot be null
   */

CREATE OR REPLACE PROCEDURE oem_notifications_mgt.delete_notification_recipient (i_usr_id usr.usr_id%TYPE, i_on_guid oem_notifications.on_guid%TYPE, o_status_code OUT cnst.vc) AS $body$
DECLARE
      l_module_name text := 'delete_notification_recipient';
BEGIN

      l_module_name := l_module_name || '.DELETE_NOTIFICATION_RECIPIENT';
      PERFORM utl.set_operation(l_module_name,'Deleting recipient/s');

      IF i_usr_id IS NOT NULL OR
         i_on_guid IS NOT NULL
      THEN
         DELETE FROM oem_notif_recipients onr
          WHERE onr.usr_id = coalesce(i_usr_id, onr.usr_id)
                AND onr.on_guid = coalesce(i_on_guid, onr.on_guid);
      ELSE
         -- this is not likely to occur as this sproc is used internally, but adding just to prevent accidental deletion of ALL recipients
         o_status_code := cnst.cinternalerror;
         RETURN;
      END IF;
      o_status_code := utl.get_constant_value('csuccess');

   EXCEPTION
      WHEN OTHERS THEN
         PERFORM trc.log(i_on_guid);
         o_status_code := cnst.cinternalerror;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE oem_notifications_mgt.delete_notification_recipient (i_usr_id usr.usr_id%TYPE, i_on_guid oem_notifications.on_guid%TYPE, o_status_code OUT cnst.vc) FROM PUBLIC;

\i cleanup.sql;
