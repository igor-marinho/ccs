SET bedb.filename = 'function.validate_on_guid.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS oem_notifications_mgt.validate_on_guid(uuid);

CREATE OR REPLACE FUNCTION oem_notifications_mgt.validate_on_guid (i_on_guid oem_notifications.on_guid%TYPE, 
                                                                   o_status_code out INTEGER,
                                                                   o_on_row OUT oem_notifications) AS $body$

BEGIN
      IF COALESCE(i_on_guid::text, '') = ''
      THEN
      o_status_code := utl.get_constant_value('c_notif_not_provided');
      RETURN;
      END IF;

      SELECT * INTO STRICT o_on_row FROM beowner.oem_notifications oen WHERE oen.on_guid = i_on_guid;
      
      o_status_code := utl.get_constant_value('csuccess');
      RETURN;

exception

       WHEN no_data_found then
       o_status_code :=utl.get_constant_value('c_notif_missing');
       RETURN;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION oem_notifications_mgt.validate_on_guid (i_on_guid oem_notifications.on_guid%TYPE, o_on_row OUT oem_notifications) FROM PUBLIC;


\i cleanup.sql;
