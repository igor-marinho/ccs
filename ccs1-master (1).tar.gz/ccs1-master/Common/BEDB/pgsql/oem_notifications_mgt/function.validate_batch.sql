SET bedb.filename = 'function.validate_batch.sql';

\i set_be_env.sql;
   
drop function if exists oem_notifications_mgt.validate_batch(beowner.data_fix_batches.batch_guid%type,
                                                             beowner.oem_notifications.vin_batch_guid%type,
                                                             beowner.oem_notifications.on_guid%TYPE);

CREATE OR REPLACE FUNCTION oem_notifications_mgt.validate_batch (i_batch_guid IN beowner.data_fix_batches.batch_guid%TYPE,
                                                                 i_batch_guid2 IN beowner.oem_notifications.vin_batch_guid%TYPE,
                                                                 i_on_guid IN beowner.oem_notifications.on_guid%TYPE) RETURNS TEXT AS $body$
DECLARE

         l_batch_count integer;
		 l_vin_batch_guid beowner.data_fix_batches.batch_guid%TYPE;
		 

BEGIN

         l_vin_batch_guid := i_batch_guid;
		 	    
		 IF COALESCE(l_vin_batch_guid::text, '') != ''
         THEN
            SELECT COUNT(1)
              INTO STRICT l_batch_count
              FROM beowner.data_fix_batches
             WHERE batch_guid = l_vin_batch_guid
                   AND make_id IS NOT NULL;
            IF l_batch_count = 0
            THEN
            RETURN utl.get_constant_value('c_batch_not_found');
            END IF;
         END IF;

         IF COALESCE(l_vin_batch_guid::text, '') != '' AND
            i_batch_guid2::text != coalesce(l_vin_batch_guid::text, 'AA')
         THEN
            -- delete previous batch
            CALL oem_notifications_mgt.delete_notif_batch(i_batch_guid => i_batch_guid2,
                                                          i_on_guid    => i_on_guid);
         END IF;
         RETURN utl.get_constant_value('csuccess');
      END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION oem_notifications_mgt.validate_batch () FROM PUBLIC;
   
 
\i cleanup.sql;
