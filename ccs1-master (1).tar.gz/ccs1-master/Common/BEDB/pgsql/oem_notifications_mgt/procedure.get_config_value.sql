SET bedb.filename = 'procedure.get_config_value.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS oem_notifications_mgt.get_config_value(beowner.cfg.name%type, INOUT text, INOUT integer);
CREATE OR REPLACE PROCEDURE oem_notifications_mgt.get_config_value(i_name beowner.cfg.name%type,
                                                                   INOUT return_code text,
                                                                   INOUT value integer) AS
$body$
DECLARE

BEGIN
    value := utl.getconfig(icfgname => i_name)::integer;
EXCEPTION
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
	   CALL trc.log('Config setting for ' || i_name || ' is not set up as an integer');
	   return_code := utl.get_constant_value('c_invalid_config_setting');
	   RAISE  EXCEPTION USING ERRCODE = 'no_data_found';
END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION oem_notifications_mgt.get_config_value (i_name cfg.name%TYPE) FROM PUBLIC;

\i cleanup.sql;
