SET bedb.filename = 'procedure.process_model_years.sql';

\i set_be_env.sql;

drop procedure if exists oem_notifications_mgt.process_model_years (beowner.oem_notifications.on_guid%type,
                                                                    VARCHAR,
                                                                    beowner.oem_notifications.model_category%type,
                                                                    TEXT);

CREATE OR REPLACE PROCEDURE oem_notifications_mgt.process_model_years (i_on_guid IN beowner.oem_notifications.on_guid%TYPE,
                                                                       i_years IN VARCHAR(4000),
                                                                       i_model_category IN beowner.oem_notifications.model_category%type,
                                                                       o_return_code INOUT TEXT) AS $body$
declare

         l_model_category beowner.oem_notifications.model_category%type;
         l_years VARCHAR(4000);
         l_year beowner.vin.year%TYPE;
         years_rec RECORD;

BEGIN
         -- start from scratch in case there are changes
        CALL oem_notifications_mgt.delete_years(i_on_guid => i_on_guid);
        
        l_model_category := upper(i_model_category);
        l_years := rtrim(ltrim(upper(i_years), ','), ',');
    	
	     IF COALESCE(l_model_category, '') != '' AND
		    COALESCE(l_years, '') != ''
         THEN
         
           FOR years_rec IN (SELECT DISTINCT (regexp_split_to_table(l_years,E',')) AS YEAR)
            
           LOOP
               l_year := years_rec.year;
               INSERT INTO beowner.oem_notif_years(ony_guid, on_guid, YEAR)
               VALUES (beowner.rand_guid(), i_on_guid, l_year);

            END LOOP;
         END IF;
         o_return_code := utl.get_constant_value('csuccess');
      EXCEPTION
         WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
            o_return_code := utl.get_constant_value('cinvalidparams');
         WHEN OTHERS THEN
            o_return_code := utl.get_constant_value('c_invalid_year_list');
      END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE oem_notifications_mgt.process_model_years (o_return_code OUT cnst.vc) FROM PUBLIC;
   
\i cleanup.sql;
