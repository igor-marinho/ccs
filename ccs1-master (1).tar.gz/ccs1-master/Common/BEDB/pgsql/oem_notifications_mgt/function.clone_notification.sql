SET bedb.filename = 'procedure.clone_notification.sql';

\i set_be_env.sql;

   /* CLONE_NOTIFICATION
      For portal to clone a notification, in any state
   
              0     : Success
              1     : Unknown Error
              4     : Invalid Parameter (length or datatype)
              
              458   : Portal user is mandatory                                                (cnst.c_portal_user_is_null)   
   
              600   : No such notification exists                                             (cnst.c_notif_not_provided)
              607   : Existing Notification GUID must be provided                             (cnst.c_notif_missing)
   */


DROP FUNCTION IF EXISTS oem_notifications_mgt.clone_notification(TEXT,beowner.oem_notifications.created_by%TYPE);

CREATE or REPLACE FUNCTION oem_notifications_mgt.clone_notification(i_on_guid IN TEXT,
                                                                    i_portal_user IN beowner.oem_notifications.created_by%TYPE,
																	o_status_code OUT integer,
                                                                    o_new_notif_seq OUT TEXT) AS $BODY$ 

DECLARE

      l_action text;
      l_module_name text := 'clone_notification';
      l_on_row beowner.oem_notifications%ROWTYPE;
      l_exception_diagnostics trc.exception_diagnostics;
	  l_on_guid UUID := i_on_guid::uuid;
	  l_expiry_date integer:= utl.getconfig(icfgname => utl.get_constant_value('c_cfg_notif_max_duration_days'))::integer + 1;
	  
   BEGIN
    
	  l_action := utl.set_module_action( l_module_name, 'Validating inputs');
   
      IF COALESCE(i_on_guid, '') = '' 
      THEN
      o_status_code := utl.get_constant_value('c_notif_not_provided');
	  RETURN;
      END IF;
   
	  IF COALESCE(i_portal_user, '') = '' 
      THEN
      o_status_code := utl.get_constant_value('c_portal_user_is_null');
	  RETURN;
      END IF;
   
	  l_action := utl.set_action('Initializing main row');
      BEGIN
           SELECT *
           INTO l_on_row
           FROM beowner.oem_notifications oen
           WHERE oen.on_guid = l_on_guid;
      
      EXCEPTION
         WHEN no_data_found THEN
         o_status_code := utl.get_constant_value('c_notif_missing');
		 RETURN;
      END;
   
      l_on_row.finalized := utl.get_constant_value('c_no');
      l_on_row.recalled := utl.get_constant_value('c_no');
      l_on_row.processing_started := NULL;
      l_on_row.processing_completed := NULL;
   
      l_on_row.start_date := CURRENT_TIMESTAMP + interval '1' day;
   
      -- SBM-513, added getconfig for DCS1E-445
      l_on_row.expiration_date := CASE
                                     WHEN l_on_row.notif_type = utl.get_constant_value('c_notif_type_inbox') THEN
                                     CURRENT_TIMESTAMP + l_expiry_date * interval '1 day'
                                     ELSE NULL END;
      l_on_row.vin_batch_guid := NULL;
   
      l_on_row.created_date := CURRENT_TIMESTAMP;
      l_on_row.created_by := i_portal_user;
      l_on_row.modified_date := NULL;
      l_on_row.modified_by := NULL;
      l_on_row.on_guid := beowner.rand_guid();
      l_on_row.notif_seq := oem_notifications_mgt.generate_notification_seq();
   
      INSERT INTO beowner.oem_notifications
      SELECT l_on_row.on_guid,l_on_row.notif_type,l_on_row.finalized,l_on_row.make_id,l_on_row.notif_seq,l_on_row.created_by,l_on_row.created_date,l_on_row.recalled,l_on_row.recipient_type,l_on_row."content",l_on_row.modified_by,l_on_row.modified_date,l_on_row.start_date,l_on_row.expiration_date,l_on_row.subject,l_on_row.priority,l_on_row.hs_os,l_on_row.vin,l_on_row.vin_batch_guid,l_on_row.model_category,l_on_row.processing_started,l_on_row.processing_completed,l_on_row.errored,l_on_row.driven_by_event;
     -- SELECT l_on_row;
     
	  l_action := utl.set_action('Cloning children');
   
      CASE l_on_row.recipient_type

	  WHEN utl.get_constant_value('c_recipient_type_bundle') THEN
            INSERT INTO beowner.oem_notif_devices (ond_guid, on_guid, device_id)
               (SELECT beowner.rand_guid(),
                       l_on_row.on_guid,
                       src.device_id
                       FROM beowner.oem_notif_devices src
                       WHERE src.on_guid = l_on_guid);
					   
         WHEN utl.get_constant_value('c_recipient_type_model') THEN
            INSERT INTO beowner.oem_notif_years  (ony_guid, on_guid, YEAR)
               (SELECT beowner.rand_guid(),
                       l_on_row.on_guid,
                       src.year
                       FROM beowner.oem_notif_years src
                       WHERE src.on_guid = l_on_guid);
         ELSE
            -- VIN batch should not be cloned
            NULL;
      END CASE;
   
      -- DCS1NOTES-314
      o_new_notif_seq := l_on_row.notif_seq::text;
      o_status_code := utl.get_constant_value('csuccess');
      return;
   
   EXCEPTION
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
         o_status_code :=  utl.get_constant_value('cinvalidparams');
		 RETURN;
      WHEN OTHERS THEN
		 GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
          
          o_status_code := utl.get_constant_value('cinternalerror');
          return;
						
   END;
  
$BODY$
LANGUAGE plpgsql
SECURITY DEFINER;

\i cleanup.sql;
