SET bedb.filename = 'function.set_oem_notif_options.sql';

\i set_be_env.sql;

   /* SET_OEM_NOTIF_OPTIONS
      To be used by portal to set the recipient options for draft notification.
    
      Expected Return Values:
         0     : Success
         1     : Unknown Error
         4     : Invalid Parameter (length or datatype)
         38    : At least one Device/Bundle ID is invalid                  (cnst.cdeviceiddoesnotexist)
         
         450   : Such a batch (with a make) doesn't exist                  (cnst.c_batch_not_found)         
         458   : Portal user is mandatory                                  (cnst.c_portal_user_is_null)   
         507   : Invalid Handset OS                                        (cnst.c_invalid_hs_os)
         
         606   : Draft Notification doesn't exist                          (cnst.c_not_draft_notif) 
         607   : Existing Notification GUID must be provided               (cnst.c_notif_not_provided)
         608   : Recipient Type must be provided                           (cnst.c_recip_type_is_null) 
         609   : Invalid Recipient Type                                    (cnst.c_invalid_recip_type) 
         614   : Model Cateogry must be specifid when years are provided   (cnst.c_years_without_model_category)    
         615   : HS OS can only be provided for Push notifications         (cnst.c_hs_os_only_for_push) 
         616   : Device list is not formatted properly as a csv            (cnst.c_invalid_device_list) 
         617   : Year list is not formatted properly as a csv              (cnst.c_invalid_year_list) 
   */

drop function  if exists oem_notifications_mgt.set_oem_notif_options (TEXT,
                                                                      beowner.oem_notifications.hs_os%TYPE,
                                                                      beowner.oem_notifications.recipient_type%TYPE,
                                                                      beowner.oem_notifications.model_category%TYPE,
                                                                      beowner.oem_notifications.vin%TYPE,
                                                                      TEXT,
                                                                      VARCHAR,
                                                                      VARCHAR,
                                                                      beowner.oem_notifications.modified_by%TYPE);

CREATE OR REPLACE FUNCTION oem_notifications_mgt.set_oem_notif_options(i_on_guid        IN TEXT,
                                                                       i_hs_os          IN beowner.oem_notifications.hs_os%TYPE,
                                                                       i_recipient_type IN beowner.oem_notifications.recipient_type%TYPE,
                                                                       i_model_category IN beowner.oem_notifications.model_category%TYPE,
                                                                       i_vin            IN beowner.oem_notifications.vin%TYPE,
                                                                       i_batch_guid     IN TEXT,
                                                                       i_bundles        IN VARCHAR(4000),
                                                                       i_years          IN VARCHAR(4000),
                                                                       i_portal_user    IN beowner.oem_notifications.modified_by%TYPE)
RETURNS INTEGER as $body$

DECLARE
      l_action text;
      l_module_name text := 'set_oem_notif_options';
      l_on_guid        beowner.oem_notifications.on_guid%type := i_on_guid::uuid;
      l_batch_guid     beowner.oem_notifications.vin_batch_guid%type := i_batch_guid::uuid;
      l_on_row         beowner.oem_notifications%ROWTYPE;
      l_recipient_type beowner.oem_notifications.recipient_type%TYPE;
      l_return_code    text;
      l_status boolean;
      l_hs_os          beowner.oem_notifications.hs_os%TYPE;
      l_bundles        VARCHAR(4000);
      l_years          VARCHAR(4000);
      l_vin            beowner.vin.vin%TYPE;
      l_model_category beowner.model_categories.category%TYPE;
      l_vin_batch_guid beowner.data_fix_batches.batch_guid%TYPE;
	  l_exception_diagnostics trc.exception_diagnostics;
	  
   BEGIN


      l_action := utl.set_module_action( l_module_name, 'Validating inputs');
   
      IF COALESCE(i_on_guid::text, '') = '' 
      THEN
      RETURN utl.get_constant_value('c_notif_not_provided');
	  
      ELSE
           
     call oem_notifications_mgt.is_draft_notif(i_on_guid => l_on_guid, 
                                               o_status => l_status,
                                               o_on_row => l_on_row);
                                              
         IF NOT l_status
         THEN
         RETURN utl.get_constant_value('c_not_draft_notif');
         END IF;
      END IF;
   
	  IF COALESCE(i_portal_user, '') = ''
      THEN
      RETURN utl.get_constant_value('c_portal_user_is_null');
      END IF;
   
      l_hs_os := upper(i_hs_os);
      
	  IF COALESCE(l_hs_os, '') != ''
      THEN
         IF l_on_row.notif_type = utl.get_constant_value('c_notif_type_inbox')
         THEN
         RETURN utl.get_constant_value('c_hs_os_only_for_push');
         END IF;
         IF NOT utl.is_domain_value_valid(i_domain => utl.get_constant_value('c_domain_hs_os'),
                                          i_value  => l_hs_os)
         THEN
         RETURN utl.get_constant_value('c_invalid_hs_os');
         END IF;
      END IF;
   
      l_recipient_type := upper(i_recipient_type);
      CASE
	  
         WHEN coalesce(l_recipient_type,'')='' THEN RETURN utl.get_constant_value('c_recip_type_is_null');
		 
         WHEN NOT utl.is_domain_value_valid(i_domain => utl.get_constant_value('c_domain_recipient_type'),
                                            i_value  => l_recipient_type) THEN
         RETURN utl.get_constant_value('c_invalid_recip_type');
			
			
         WHEN l_recipient_type = utl.get_constant_value('c_recipient_type_bundle') THEN
              
			l_bundles := rtrim(ltrim(upper(i_bundles), ','), ',');
			
            CALL oem_notifications_mgt.process_bundles(i_bundles => i_bundles,
                                                       i_on_guid => l_on_guid,
                                                       o_return_code => l_return_code );
			
            IF l_return_code != utl.get_constant_value('csuccess')
            THEN
            RETURN l_return_code;
            END IF;
			
            CALL oem_notifications_mgt.delete_years(i_on_guid => l_on_guid);
			
            CALL oem_notifications_mgt.delete_notif_batch(i_batch_guid => l_on_row.vin_batch_guid,
                                                          i_on_guid    => l_on_guid);
							   
         WHEN l_recipient_type = utl.get_constant_value('c_recipient_type_vin') THEN
		 
            l_vin := TRIM(upper(i_vin));
            l_vin_batch_guid := l_batch_guid;
            l_return_code := oem_notifications_mgt.validate_batch(l_vin_batch_guid,l_on_row.vin_batch_guid,l_on_guid);
            IF l_return_code != utl.get_constant_value('csuccess')
            THEN
            RETURN l_return_code;
            END IF;
			
            CALL oem_notifications_mgt.delete_bundles(i_on_guid => l_on_guid);
            CALL oem_notifications_mgt.delete_years(i_on_guid => l_on_guid);
           
         ELSE
            -- model_category/years
            l_model_category := upper(i_model_category);
            l_years := rtrim(ltrim(upper(i_years), ','), ',');
           
            IF coalesce(l_model_category,'')='' AND
               coalesce(l_years,'') != '' 
            THEN
            RETURN utl.get_constant_value('c_years_without_model_category');
            ELSE
               CALL oem_notifications_mgt.process_model_years(i_on_guid => l_on_guid,
			                                                  i_years   => i_years, 
															  i_model_category => i_model_category,
															  o_return_code => l_return_code);
			   
               IF l_return_code != utl.get_constant_value('csuccess')
               THEN
               RETURN l_return_code;
               END IF;
            END IF;
            CALL oem_notifications_mgt.delete_bundles(i_on_guid => l_on_guid);
			
            CALL oem_notifications_mgt.delete_notif_batch(i_batch_guid => l_on_row.vin_batch_guid,
                                                          i_on_guid    => l_on_guid);
      END CASE;
   
    
update beowner.oem_notifications
set  recipient_type  = upper(l_recipient_type), 
modified_by    = i_portal_user, 
modified_date  = CURRENT_TIMESTAMP,
hs_os  = upper(l_hs_os) ,
vin = TRIM(upper(l_vin)),
vin_batch_guid = l_batch_guid,
model_category = upper(l_model_category)  where on_guid = l_on_guid;
                        
   
RETURN utl.get_constant_value('csuccess');
   
   EXCEPTION
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
      RETURN utl.get_constant_value('cinvalidparams');
	  
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
		
         RETURN utl.get_constant_value('cinternalerror');
END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
\i cleanup.sql;
