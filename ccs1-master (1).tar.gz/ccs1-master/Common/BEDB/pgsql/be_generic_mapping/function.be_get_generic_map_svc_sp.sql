SET bedb.filename = 'function.be_get_generic_map_svc_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF exists be_generic_mapping.be_get_generic_map_svc_sp (TEXT, TEXT, TEXT );
/*  Title:        BE_GET_GENERIC_MAP_SVC_SP
    Version:      1.0
    Date:         June 07, 2013
    Author:       K. Osato
    Description:  This procedure was created to check mapping values being
                  passed from application requests. Any mapping values not found will 
                  invalidate transaction and send error code back to middle tier app.

    Input parameters:
      program_i         - mapping program
      name_i            - mapping application name
      key_i             - mapping key value

    Status codes:
      success -  0 - mapping exists in table.
      failure - 53 - invalid mapping program
      failure - 54 - invalid mapping program/name
      failure - 55 - invalid mapping program/name/key

    Cursor Return values if successful:
      mapping application name, key, value, description

    Revision History:

    DATE      AUTHOR       DESCRIPTION
    06/07/13  K. Osato     new stuff for SM29 work item 12160
    
*/

CREATE OR REPLACE FUNCTION be_generic_mapping.be_get_generic_map_svc_sp ( program_i beowner.cfg_mapping.program%TYPE
                                                                         ,name_i beowner.cfg_mapping.name%TYPE
                                                                         ,key_i beowner.cfg_mapping.key%TYPE
                                                                         ,o_status_code OUT INTEGER
                                                                         ,recordset_o OUT refcursor )
AS
$body$
DECLARE
    l_action text;
    l_module_name text := 'be_get_generic_map_svc_sp';
-- set default if no values passed
    v_pgm             beowner.cfg_mapping.program%TYPE := program_i;
    v_name            beowner.cfg_mapping.name%TYPE := name_i;
    v_key             beowner.cfg_mapping.key%TYPE := key_i;
    v_rows            numeric;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      l_action := utl.set_module_action( l_module_name,  ' Returning Dataset');

      o_status_code :=utl.get_constant_value('csuccess'); --default to success unless error
      recordset_o := utl.get_dummy_cursor();  -- OnTime #18752

      if v_name is null then             -- only 1st parameter passed
          select count(*) into STRICT v_rows
          from beowner.cfg_mapping cm
          where cm.program = v_pgm;
          if v_rows > 0 THEN
          CLOSE recordset_o;
            OPEN recordset_o for
              SELECT cm.name, cm.key, (cm.value::UUID)::TEXT, cm.description
              from beowner.cfg_mapping cm
              where cm.program = v_pgm;
          else
            o_status_code := utl.get_constant_value('cmappingprogramnotfound');
          end if;

      elsif v_key is null then         -- 2 parameters passed
          select count(*) into STRICT v_rows
          from beowner.cfg_mapping cm
          where cm.program = v_pgm
            and cm.name = v_name;
          if v_rows > 0 THEN
          CLOSE recordset_o;
            OPEN recordset_o for
              SELECT cm.name, cm.key, (cm.value::UUID)::TEXT, cm.description
              from beowner.cfg_mapping cm
              where cm.program = v_pgm
                and cm.name = v_name;
          else
            o_status_code := utl.get_constant_value('cmappingpgmnamenotfound') ;
          end if;

      else                             -- all 3 parameters passed  */
          select count(*) into STRICT v_rows
          from beowner.cfg_mapping cm
          where cm.program = v_pgm
            and cm.name = v_name
            and cm.key = v_key;
          if v_rows > 0 THEN
          CLOSE recordset_o;
            OPEN recordset_o for
              SELECT cm.name, cm.key, (cm.value::UUID)::TEXT, cm.description
              from beowner.cfg_mapping cm
              where cm.program = v_pgm
                and cm.name = v_name
                and cm.key = v_key;
          else
            o_status_code := utl.get_constant_value('cmappingpgmnamekeynotfound');
          end if;

      end if;
      RETURN; 

  EXCEPTION
    WHEN OTHERS THEN
        GET STACKED diagnostics
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,              
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;
        call trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);

       recordset_o := utl.get_dummy_cursor();  
       o_status_code := utl.get_constant_value('cinternalerror');
   
       RETURN;
    END;

$body$
LANGUAGE PLPGSQL
STABLE
SECURITY DEFINER;

-- REVOKE ALL ON FUNCTION be_generic_mapping.be_get_generic_map_svc_sp ( program_i beowner.cfg_mapping.program%TYPE, name_i beowner.cfg_mapping.name%TYPE, key_i beowner.cfg_mapping.key%TYPE, recordset_o OUT REFCURSOR ) FROM PUBLIC;

\i cleanup.sql;
