SET bedb.filename = 'function.get_push_tokens_for_vin.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS ns.get_push_tokens_for_vin(text,text,text);
   /*  GET_PUSH_TOKENS_FOR_VIN
   
       Created for Jira TCP-301
   
       Gets a list of push tokens that are configured for notifications (for the particular notification type)
       for the provided VIN.
   
       Expected Return Values:
         0     : success (this can include an empty result set; a cursor with no rows)
         1     : Unknown Error
         200   : No such VIN                                              (cnst.cDbVinNotFound)
         213   : Invalid Partner ID                                       (cnst.cDbPartneridNotValid)
         261   : Unknown Notification Type                                (cnst.cDbNotificationTypeUnknown)
         263   : The Subscription has Expired                             (cnst.csubscriptionexpired)
         401   : More than one user has a subscription for an EV type VIN (cnst.cmultiplesubscriptions)
   */
CREATE OR REPLACE FUNCTION ns.get_push_tokens_for_vin (i_partner_id        text
                                                      ,i_vin               text
                                                      ,i_notif_type        text
                                                      ,o_status_code   OUT INTEGER
                                                      ,o_push_tokens   OUT refcursor)
AS $body$
DECLARE
    l_action TEXT;
    l_module_name text := 'get_push_tokens_for_vin';
    l_validation_return integer;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      l_action := utl.set_module_action(l_module_name, ' Opening Results');

      l_validation_return := ns.common_validations(i_partner_id => i_partner_id,
                                                   i_vin        => i_vin,
                                                   i_notif_type => i_notif_type);
      IF l_validation_return != utl.get_constant_value('csuccess')::INTEGER
      THEN 
          o_status_code := l_validation_return;
          o_push_tokens := utl.get_dummy_cursor();
           RETURN;
      END IF;
      
      OPEN o_push_tokens FOR
      -- a1 will return 0 or 1 row; if 0 then result set will be empty, which is not an error
         WITH a1 AS
          (SELECT s.primary_id,
                  uph.hs_id,
                  uph.hs_os,
                  uph.push_token
             FROM beowner.subscription s
             JOIN beowner.bndlsvc bs
               ON bs.bndl_id = s.bndl_id
                  AND bs.optin_level <= s.optin_level
             JOIN beowner.notif_svc ns
               ON ns.svc_id = bs.svc_id
             JOIN beowner.notif_optin_level nol
               ON nol.notification_id = ns.notification_id
                  AND nol.optin_level = s.optin_level
                  AND nol.sent_email = utl.get_constant_value('c_yes')
             JOIN beowner.subs_notif sn
               ON sn.notification_id = ns.notification_id
                  AND sn.subscription_id = s.subscription_id
                  AND sn.send_push = utl.get_constant_value('c_yes')
             JOIN beowner.subs_notif_push_handsets snp
               ON snp.subs_notif_id = sn.subs_notif_id
             JOIN beowner.usr_push_handsets uph
               ON uph.uph_guid = snp.uph_guid
                  AND uph.status = utl.get_constant_value('c_valid') -- TCP-418
            WHERE s.vin = (SELECT vin
                             FROM beowner.ctx_data)
                  AND ns.notification_id = i_notif_type)
         -- based on a1, pull the information we need for the result set
         SELECT DISTINCT s.push_token push_token,
                s.hs_os,
                s.hs_id
           FROM a1 s
           JOIN beowner.usr u
             ON u.usr_id = s.primary_id;

      o_status_code := utl.get_constant_value('csuccess');
      RETURN;
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
         o_status_code := utl.get_constant_value('cinternalerror');
         o_push_tokens := utl.get_dummy_cursor();
         RETURN;
   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION ns.get_push_tokens_for_vin (i_partner_id text, i_vin text, i_notif_type text, o_push_tokens OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
