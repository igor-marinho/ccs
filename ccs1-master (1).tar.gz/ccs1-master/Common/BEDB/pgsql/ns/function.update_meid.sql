SET bedb.filename = 'function.update_meid.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS ns.update_meid(text,text,text);
/*  UPDATE_MEID
   Records an MEID change for a VIN. The end-user that calls this function is
   intended to be a service mechanic at a dealer using a specialized applicaion
   solely for this purpose, hence there is no particular security in the DB.

   input: iVIN    the VIN with which to update the MEID
		  iMEID   the new MEID value. NULL if clearing the MEID
		  iInfo   Additional info useful for auditing/debugging.
				  This can be a free-form string or XML document.
				  It should contain information about the dealer,
				  user, terminal, etc of the update.

   return: integer 0    if successful
				   1    if unknown error
				   200  if VIN not found
				   4    if some other value error (length too long, for example)
*/
CREATE OR REPLACE FUNCTION ns.update_meid (ivin text, imeid text, iinfo text) RETURNS integer
AS $body$
BEGIN
      UPDATE beowner.vin
         SET meid = imeid
       WHERE vin = upper(trim(both ivin));

      RETURN CASE WHEN FOUND 
                THEN utl.get_constant_value('csuccess') 
                ELSE utl.get_constant_value('cdbvinnotfound')
             END;
   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION ns.update_meid (ivin text, imeid text, iinfo text) FROM PUBLIC;

\i cleanup.sql;
