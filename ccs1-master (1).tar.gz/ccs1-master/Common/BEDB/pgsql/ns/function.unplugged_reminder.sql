SET bedb.filename = 'function.unplugged_reminder.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS ns.unplugged_reminder(text, text);
   -- onTime#6752
   /*  unplugged_reminder
       Return the following output to the caller from the subs_notif/notif_location table
      1.  VIN number information 
      2.  OPTIN information
      3.  Location latitude
      4.  Location longitude
      5.  Location radius
      6.  Location time zone
      7.  Day of the week - Monday (valid value: 1/0)
      8.  Day of the week - Tuesday (valid value: 1/0)
      9.  Day of the week - Wednesday (valid value: 1/0)
      10. Day of the week - Thursday (valid value: 1/0)
      11. Day of the week - Friday (valid value: 1/0)
      12. Day of the week - Saturday (valid value: 1/0)
      13. Day of the week - Sunday (valid value: 1/0)
   
       input: iVIN        VIN input
              i_ptnr_id   Partner ID input
           oResults    OUT parameter
   
       return: integer 0    if successful
                       1    if unknown error (error can be checked in "trc" table)
                       200  if VIN not found
                       213  if partnerid is not valid
   */
CREATE OR REPLACE FUNCTION ns.unplugged_reminder (i_vin               text
                                                 ,i_ptnr_id           text
                                                 ,o_status_code   OUT INTEGER
                                                 ,oresults        OUT refcursor)
AS $body$
DECLARE 
    l_action text;
    l_module_name text := 'unplugged_reminder';
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
      l_action := utl.set_module_action(l_module_name, 'Setting Context');
      CALL ctx.set(iptnrid => i_ptnr_id::UUID, ivin => i_vin);

      -- Modified below select for OnTime #14738 (DB - the plug-in reminder email is not sent based on specific DOW value of the location.)
      -- to bitand notif_location.dow with subs_notif.dow to return the day-wise settings
      -- also moved the utl and bitand function into an inner-query, to only apply it once
      -- Modified for Jira TCP-301 to use value 127 (c_all_dow) instead of sn.dow for push
      -- Modified for Jira TCP-950 to match the DOW value set by portal and MT - shifted a day
      OPEN oresults FOR
      SELECT s.vin,
                s.optin_level,
                utl.arr_to_cur(ARRAY(SELECT ROW(lat,
                               lng,
                               trim(trailing '00' FROM radius::varchar)::NUMERIC,
                               tz,
                               coalesce(substr(bin_dow, 7, 1), '0'), --mon
                               coalesce(substr(bin_dow, 6, 1), '0'), --tue
                               coalesce(substr(bin_dow, 5, 1), '0'), --wed
                               coalesce(substr(bin_dow, 4, 1), '0'), --thu
                               coalesce(substr(bin_dow, 3, 1), '0'), --fri
                               coalesce(substr(bin_dow, 2, 1), '0'), --sat
                               coalesce(substr(bin_dow, 1, 1), '0')  --sun
                               )::ns.typ_notif_loc_info
                          FROM (SELECT nl.lat,
                                       nl.lng,
                                       nl.radius,
                                       nl.time_zone tz,
                                       utl.dec_to_bin((nl.dow &
                                                             CASE
                                                                WHEN sn.send_push = utl.get_constant_value('c_yes') THEN
                                                                 utl.get_constant_value('c_all_dow')::INTEGER
                                                                ELSE
                                                                 sn.dow
                                                             END)) bin_dow,
                                       sn.subscription_id
                                  FROM subs_notif     sn,
                                       notif_location nl
                                 WHERE sn.notification_id = 'UNPLUGGED'
                                       AND sn.subs_notif_id = nl.subs_notif_id) n
                         WHERE n.subscription_id = s.subscription_id)) notif_loc_info
           FROM beowner.ctx_data     cd,
                beowner.vin          v,
                beowner.subscription s
          WHERE cd.vin = v.vin
                AND v.vin = s.vin;

      o_status_code := utl.get_constant_value('csuccess');
      RETURN; 
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
         oresults := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cdbpartneridnotvalid');
         RETURN;
      WHEN SQLSTATE 'EVINN' THEN
         oresults := utl.get_dummy_cursor();    
         o_status_code := utl.get_constant_value('cdbvinnotfound');
         RETURN;
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
         oresults := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cinternalerror');
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION ns.unplugged_reminder (i_vin text, i_ptnr_id text, oresults OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
