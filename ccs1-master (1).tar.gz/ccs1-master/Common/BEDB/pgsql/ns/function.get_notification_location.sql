SET bedb.filename = 'function.get_notification_location.sql';

\i set_be_env.sql;

DROP function if exists ns.get_notification_location (text,text,text,text);
   -- onTime#6752
   /*  get_notification_location
       Return the following output to the caller from the notif_location table
      1.  Login ID information
      2.  Notification Type (UNPLUGGED)
      3.  VIN number information 
      4.  Location name
      5.  Location display order (which also a composite PK from the notif_location table)
      6.  Day of the week (not in binary format) 
      7.  Location enabled flag (1/0)
      8.  Location address
      9.  Location latitude
      10. Location longitude
      11. Location radius
      12. Location time zone
   
       input: i_ptnr_id          Partner ID input
           i_login_id         Login ID input
           i_VIN              VIN input
           i_notif_type       Notification Type input which is UNPLUGGED
           oResults           OUT parameter
   
       return: integer 0    if successful
                       1    if unknown error (error can be checked in "trc" table)
                       7    if The username or password is not correct.
                       213  if partnerid is not valid
                       200  if VIN not found
                       261  if The Notification Type is Unknown
   */
CREATE OR REPLACE FUNCTION ns.get_notification_location (i_ptnr_id          text
                                                        ,i_login_id         text
                                                        ,i_vin              text
                                                        ,i_notif_type       text
                                                        ,o_status_code  OUT integer
                                                        ,oresults       OUT refcursor)
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'get_notification_location';
    v_notif_check INTEGER;
    v_tel_partnerid TEXT;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      oresults := utl.get_dummy_cursor();

      BEGIN
         SELECT trim(both regexp_replace(i_ptnr_id, '( *[[:punct:]])', '', 'g'))
           INTO STRICT v_tel_partnerid;
      EXCEPTION
         WHEN OTHERS THEN
            RAISE EXCEPTION USING errcode = utl.get_constant_value('e_invalidpartnerid');
      END;

    l_action := utl.set_module_action( l_module_name, 'setting context');
      CALL ctx.set(iptnrid  => v_tel_partnerid::UUID,
                   iloginid => i_login_id,
                   ivin     => i_vin);

      --
      BEGIN
         SELECT 1
           INTO STRICT v_notif_check
           FROM beowner.notif_svc
          WHERE notification_id = upper(trim(both i_notif_type));
      EXCEPTION
         WHEN OTHERS THEN
            RAISE EXCEPTION 'notif_type_exception' USING ERRCODE = utl.get_constant_value('e_notif_type_exception');
      END;

    l_action := utl.set_module_action( l_module_name, 'Fetching data into refcursor');
      -- Modified for Jira TCP-301 to use value 127 (c_all_dow) instead of sn.dow for push
      CLOSE oresults;
      OPEN oresults FOR
         SELECT u.login_id,
                sn.notification_id,
                s.vin,
                nl.name,
                nl.position display_order,
                coalesce(nl.dow,
                    CASE
                       WHEN sn.send_push = utl.get_constant_value('c_yes') THEN
                        utl.get_constant_value('c_all_dow')::INTEGER
                       ELSE
                        sn.dow
                    END) dow,
                nl.address,
                nl.lat,
                nl.lng,
                nl.radius,
                nl.time_zone
           FROM beowner.ctx_data       cd,
                beowner.usr            u,
                beowner.subscription   s,
                beowner.subs_notif     sn,
                beowner.notif_location nl
          WHERE u.usr_id = cd.usr_id
                AND s.primary_id = coalesce(u.parent_id, u.usr_id)
                AND s.vin = cd.vin
                AND sn.notification_id = upper(trim(both i_notif_type))
                AND s.subscription_id = sn.subscription_id
                AND sn.subs_notif_id = nl.subs_notif_id;

      o_status_code := utl.get_constant_value('csuccess');
      RETURN;
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
         o_status_code := utl.get_constant_value('cdbpartneridnotvalid');
         RETURN;
      WHEN SQLSTATE 'EUSRN' THEN
         o_status_code := utl.get_constant_value('cnosuchuser');
         RETURN;
      WHEN SQLSTATE 'EVINN' THEN
         o_status_code := utl.get_constant_value('cdbvinnotfound');
         RETURN;
      WHEN SQLSTATE 'ENTYP' THEN
         o_status_code := utl.get_constant_value('cdbnotificationtypeunknown'); -- Invalid Notification Type
         RETURN;
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
         oresults := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cinternalerror');
         RETURN;
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION ns.get_notification_location (i_ptnr_id text, i_login_id text, i_vin text, i_notif_type text, oresults OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
