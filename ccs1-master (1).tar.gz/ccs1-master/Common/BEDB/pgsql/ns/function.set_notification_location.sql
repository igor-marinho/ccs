SET bedb.filename = 'function.set_notification_location.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS ns.set_notification_location (text, text, text ,text ,text,INTEGER,INTEGER, text, text, text, text, text);
														
   -- onTime#6752
   /*  set_notification_location
       update or records the location changes into notif_location table. 
   
       input:   i_ptnr_id          Partner ID input
             i_login_id         Login ID input
             i_VIN              VIN input
             i_notif_type       Notification Type input which is UNPLUGGED
             i_name             Location name input
             i_display_order    Position input (composite primary key)
             i_dow              Day of the week input
             i_enabled          Enabled flag input (valid value 1/0)
             i_address          Location address input
             i_lat              Location latitude input
             i_Long             Location longitude input
             i_radius           Location radius input
             i_tz               Location timezone input
   
       return: integer 0    if successful
                       1    if unknown error (error can be checked in "trc" table)
                       7    if The username or password is not correct.
                       213  if partnerid is not valid
                       200  if VIN not found
                       261  if The Notification Type is Unknown
   */
CREATE OR REPLACE FUNCTION ns.set_notification_location (i_ptnr_id         text
                                                        ,i_login_id        text
                                                        ,i_vin             text
                                                        ,i_notif_type      text
                                                        ,i_name            text
                                                        ,i_display_order   INTEGER
                                                        ,i_dow             INTEGER
                                                        ,i_address         text
                                                        ,i_lat             text
                                                        ,i_long            text
                                                        ,i_radius          text
                                                        ,i_tz              text) RETURNS INTEGER
AS $body$
DECLARE
	l_action text;
    l_module_name text := 'set_notification_location';
    v_subscription_id beowner.subscription.subscription_id%TYPE;
    v_subs_notif_id   beowner.subs_notif.subs_notif_id%TYPE;
    v_notif_check INTEGER;
    v_tel_partnerid TEXT;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      BEGIN
         SELECT trim(both regexp_replace(i_ptnr_id, '( *[[:punct:]])', '', 'g'))
           INTO STRICT v_tel_partnerid;
      EXCEPTION
         WHEN OTHERS THEN
            RAISE EXCEPTION USING errcode = utl.get_constant_value('e_invalidpartnerid');
      END;

	l_action := utl.set_module_action( l_module_name, 'setting context');
      CALL ctx.set(iptnrid  => v_tel_partnerid::UUID,
				   iloginid => i_login_id,
				   ivin     => i_vin);

	l_action := utl.set_module_action( l_module_name, 'Check Notification Type');
      BEGIN
         SELECT 1
           INTO STRICT v_notif_check
           FROM beowner.notif_svc
          WHERE notification_id = upper(trim(both i_notif_type));
      EXCEPTION
         WHEN OTHERS THEN
            RAISE EXCEPTION 'notif_type_exception' USING ERRCODE = utl.get_constant_value('e_notif_type_exception');
      END;

      l_action := utl.set_module_action( l_module_name, 'Check Notification Type');
      DECLARE
         vtimestamp     TIMESTAMP WITH TIME ZONE;
         vsubend        TIMESTAMP WITH TIME ZONE;
         vsuboptinlevel INTEGER;
         vusrid         usr.usr_id%TYPE;
         vvin           vin.vin%TYPE;
      BEGIN
         SELECT DISTINCT x.tmstmp,
                         x.sub_end,
                         x.sub_optin_level
           INTO STRICT vtimestamp,
                vsubend,
                vsuboptinlevel
           FROM beowner.ctx_data cd
           JOIN user_subscription.info(iusrid => cd.usr_id, ivin => cd.vin) x
             ON NULL IS NULL;

         IF vsubend < vtimestamp
         THEN
            RETURN utl.get_constant_value('csubscriptionexpired');
         END IF;
         /*IF vsuboptinlevel <= 0
         THEN
            RETURN cnst.cbadoptinlevel;
         END IF;*/
      EXCEPTION
         WHEN no_data_found THEN
            RETURN utl.get_constant_value('cdbvinnotfound');
      END;

      SELECT s.subscription_id
        INTO STRICT v_subscription_id
        FROM beowner.ctx_data cd
        JOIN beowner.usr u
          ON u.usr_id = cd.usr_id
        JOIN beowner.subscription s
          ON s.primary_id = coalesce(u.parent_id, u.usr_id)
             AND s.vin = cd.vin;

      BEGIN
         SELECT subs_notif_id
           INTO STRICT v_subs_notif_id
           FROM beowner.subs_notif
          WHERE subscription_id = v_subscription_id
                AND notification_id = upper(trim(both i_notif_type));
      EXCEPTION
        WHEN OTHERS THEN
            v_subs_notif_id := beowner.rand_guid();

        INSERT INTO beowner.subs_notif(subs_notif_id, subscription_id, notification_id, dow)
        VALUES (v_subs_notif_id, 
            v_subscription_id,
            upper(trim(both i_notif_type)),
            0);
        
      END;

	l_action := utl.set_module_action( l_module_name, 'Insert into notif_location');
	INSERT INTO beowner.notif_location (subs_notif_id
									   ,position
									   ,lat
									   ,lng
									   ,radius
									   ,time_zone
									   ,dow
									   ,name
									   ,address)
		 VALUES (v_subs_notif_id
				,i_display_order
				,i_lat::numeric
				,i_long::numeric
				,i_radius::numeric
				,i_tz
				,i_dow
				,i_name
				,i_address)
		ON CONFLICT (subs_notif_id, position)
		DO UPDATE SET
		 lat           = i_lat::numeric           
		,lng           = i_long::numeric          
		,radius        = i_radius::numeric        
		,time_zone     = i_tz            
		,dow           = i_dow           
		,name          = i_name          
		,address       = i_address;

      RETURN utl.get_constant_value('csuccess');
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
         RETURN utl.get_constant_value('cdbpartneridnotvalid');
      WHEN SQLSTATE 'EUSRN' THEN
         RETURN utl.get_constant_value('cnosuchuser');
      WHEN SQLSTATE 'EVINN' THEN
         RETURN utl.get_constant_value('cdbvinnotfound');
      WHEN SQLSTATE 'ENTYP' THEN
         RETURN utl.get_constant_value('cdbnotificationtypeunknown'); -- Invalid Notification Type
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');
   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION ns.set_notification_location (i_ptnr_id text, i_login_id text, i_vin text, i_notif_type text, i_name text, i_display_order bigint, i_dow bigint, i_address text, i_lat text, i_long text, i_radius text, i_tz text) FROM PUBLIC;

\i cleanup.sql;
