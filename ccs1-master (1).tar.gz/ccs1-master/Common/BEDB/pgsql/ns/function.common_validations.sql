SET bedb.filename = 'function.common_validations.sql';

\i set_be_env.sql;

DROP function if exists ns.common_validations (text,text, text);

   -- Jira TCP-301 : Moved out from get_emails_for_vin, so can be used for get_push_tokens_for_vin too 
CREATE OR REPLACE FUNCTION ns.common_validations (i_partner_id text, i_vin text, i_notif_type text) RETURNS INTEGER
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'common_validations';
    vcount integer;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    l_action := utl.set_module_action(l_module_name, 'Setting Context');

    CALL ctx.set(iptnrid => i_partner_id::UUID, ivin => i_vin);

    l_action := utl.set_action(' Checking subscription count');

      SELECT COUNT(*)
        INTO STRICT vcount
        FROM beowner.subscription
       WHERE vin = (SELECT vin
                      FROM beowner.ctx_data);

      IF vcount > 1
      THEN
         -- multiple subscriptions == conflict - do not notify anybody
         RETURN utl.get_constant_value('cmultiplesubscriptions');
      END IF;
      -- onTime defect#12465
      DECLARE
         vtimestamp    TIMESTAMP WITH TIME ZONE;
         vsubend       TIMESTAMP WITH TIME ZONE;
         vusrid        beowner.usr.usr_id%TYPE;
         vdevice_id    beowner.vin.device_id%TYPE;
         is_ev_vehicle boolean := FALSE;
      BEGIN
         -- Get user_id from subscription since we only allow to send notification to single subscription per vin
         SELECT primary_id,
                v.device_id
           INTO STRICT vusrid,
                vdevice_id
           FROM beowner.subscription s,
                beowner.vin          v
          WHERE s.vin = (SELECT vin
                           FROM beowner.ctx_data)
                AND s.vin = v.vin;

         -- Replaced existing logic with the below for OnTime WI #15529
         is_ev_vehicle := (utl.are_notifications_sent(i_device_id => vdevice_id) = 'Y');

         IF is_ev_vehicle
         THEN
            SELECT DISTINCT x.tmstmp,
                            x.sub_end
              INTO STRICT vtimestamp,
                   vsubend
              FROM beowner.ctx_data cd
              JOIN user_subscription.info(iusrid => vusrid, ivin => cd.vin)  x
                ON NULL IS NULL;

            IF vsubend < vtimestamp
            THEN
               RETURN utl.get_constant_value('csubscriptionexpired');
            END IF;
         END IF;
      EXCEPTION
         WHEN no_data_found THEN
            RETURN utl.get_constant_value('cdbvinnotfound');
      END;

      -- onTime defect#12465
      l_action := utl.set_module_action( l_module_name, ' Checking valid Notification Message');

      SELECT COUNT(*)
        INTO STRICT vcount
        FROM beowner.notif_svc
       WHERE notification_id = i_notif_type;

      IF vcount != 1
      THEN
         RETURN utl.get_constant_value('cdbnotificationtypeunknown');
      END IF;

      RETURN utl.get_constant_value('csuccess');
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
         RETURN utl.get_constant_value('cdbpartneridnotvalid');
      WHEN SQLSTATE 'EVINN' THEN
         RETURN utl.get_constant_value('cdbvinnotfound');
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        call trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');
   END;
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION ns.common_validations (i_partner_id text, i_vin text, i_notif_type text) FROM PUBLIC;
 
\i cleanup.sql;
