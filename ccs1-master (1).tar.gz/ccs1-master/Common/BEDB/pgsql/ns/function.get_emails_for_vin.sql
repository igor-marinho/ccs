SET bedb.filename = 'function.get_emails_for_vin.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS ns.get_emails_for_vin (text,text,text);
   /*  GET_EMAILS_FOR_VIN
   
       Gets a list of emails that are configured for
       notifications (for the particular notification type)
       regarding a particular VIN.
   
       Expected Return Values:
         0     : success (this can include an empty result set; a cursor with no rows)
         1     : Unknown Error
         200   : No such VIN                                              (cnst.cDbVinNotFound)
         213   : Invalid Partner ID                                       (cnst.cDbPartneridNotValid)
         261   : Unknown Notification Type                                (cnst.cDbNotificationTypeUnknown)
         263   : The Subscription has Expired                             (cnst.csubscriptionexpired)
         401   : More than one user has a subscription for an EV type VIN (cnst.cmultiplesubscriptions)
   */
CREATE OR REPLACE FUNCTION ns.get_emails_for_vin (ipartnerid              text
                                                 ,ivin                    text
                                                 ,inotificationtype       text
                                                 ,o_status_code       OUT integer
                                                 ,oaddresses          OUT refcursor)
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'get_emails_for_vin';
    l_validation_return INTEGER;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      oaddresses := utl.get_dummy_cursor();
      l_action := utl.set_module_action(l_module_name, 'Validating inputs');
      -- Modified for Jira TCP-301 to call the module
      l_validation_return := ns.common_validations(i_partner_id => ipartnerid,
                                                   i_vin        => ivin,
                                                   i_notif_type => inotificationtype);
      IF l_validation_return != utl.get_constant_value('csuccess')::INTEGER
      THEN 
          o_status_code := l_validation_return;
          oaddresses := utl.get_dummy_cursor();
           RETURN;
      END IF;
      l_action := utl.set_module_action(l_module_name, ' Opening Results');

      -- Modified for OnTime #14700 (DB - the unpluggedReminder email still can be sent out even day of week is not picked.)
      -- Replaced logic for getting dow - using bitand on subs_notif.dow and notif_location.dow before applying bitand with utl.day_bit()
      -- if notif_svc has use_location set as * (e.g. for UNPLUGGED), then nl.dow is used, otherwise 127 is used instead of nl.dow
      -- Subsequently modified for OnTime #14738 (DB - the plug-in reminder email is not sent based on specific DOW value of the location.)
      -- to remove any checks in notif_location, as these checks need to be made in unplugged_reminder instead
      -- modified query below to only use usr login_id for Jira TCP-419
      CLOSE oaddresses;
      OPEN oaddresses FOR
      -- a1 will return 0 or 1 row; if 0 then result set will be empty, which is not an error
         WITH a1 AS
          (SELECT s.primary_id
             FROM beowner.subscription s -- where VIN = iVIN
             JOIN beowner.bndlsvc bs -- join up on OPTIN_LEVEL
               ON bs.bndl_id = s.bndl_id
                  AND bs.optin_level <= s.optin_level
             JOIN beowner.notif_svc ns -- where notification_id = iNotificationType
               ON ns.svc_id = bs.svc_id
           -- onTime defect#13039
             JOIN beowner.notif_optin_level nol
               ON nol.notification_id = ns.notification_id
                  AND nol.optin_level = s.optin_level
                  AND nol.sent_email = 'Y'
             JOIN beowner.subs_notif sn -- user-chosen notification setting
           -- onTime defect#13039
               ON sn.notification_id = ns.notification_id
                  AND sn.subscription_id = s.subscription_id -- Fix for OT 10760
                  AND (utl.day_bit() & coalesce(sn.dow, 0)) > 0 -- user-chosen DOW setting
            WHERE s.vin = (SELECT vin
                             FROM beowner.ctx_data)
                  AND ns.notification_id = inotificationtype)
         -- based on a1, pull the information we need for the result set
         SELECT u.login_id email_addr, -- get demographic data
                d.name_first,
                d.name_last
           FROM a1 s
           JOIN beowner.usr u
             ON u.usr_id = s.primary_id
           LEFT JOIN beowner.usr_demog d
             ON d.usr_id = u.usr_id;

      o_status_code := utl.get_constant_value('csuccess');
      RETURN;
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
         o_status_code := utl.get_constant_value('cinternalerror');
         oaddresses := utl.get_dummy_cursor();
         RETURN;
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;

-- REVOKE ALL ON FUNCTION ns.get_emails_for_vin (ipartnerid text, ivin text, inotificationtype text, oaddresses OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
