SET bedb.filename = 'function.get_last_reg_user_for_ev_vin.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS ns.get_last_reg_user_for_ev_vin (text, text);
   /*  GET_LAST_REG_USER_FOR_EV_VIN
   
       Created for Jira TCP-240/TCP-419
   
       Gets the information of the user that last registered for EV services for the provided VIN.
       If no such user is found, no row will be returned, with a return code of 0.
          
       Ref cursor columns : login_id, name_first, name_last, usr_id
   
       Expected Return Values:
         0     : Success                                                  (utl.get_constant_value('csuccess'))
         1     : Unhandled Error                                          (cnst.cInternalError)
         4     : Invalid Parameters                                       (utl.get_constant_value('cinvalidparams'))        
         200   : No such VIN                                              (cnst.cDbVinNotFound)
         213   : Invalid Partner ID                                       (cnst.cDbPartneridNotValid)
         234   : VIN is null                                              (cnst.c_invalid_vin)
         348   : Partner ID is null                                       (cnst.c_ptnr_id_null)
         
   */
CREATE OR REPLACE FUNCTION ns.get_last_reg_user_for_ev_vin (i_ptnr_id           text
                                                           ,i_vin               text
                                                           ,o_status_code   OUT INTEGER
                                                           ,o_user_info     OUT refcursor)
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'get_last_reg_user_for_ev_vin';
    l_vin beowner.vin.vin%TYPE;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      o_user_info := utl.get_dummy_cursor();
      l_action := utl.set_module_action(l_module_name,'Validating inputs');

      IF COALESCE(i_ptnr_id, '') = ''
      THEN
      o_status_code:= utl.get_constant_value('c_ptnr_id_null');
         RETURN;
      END IF;

      IF COALESCE(i_vin, '') = ''
      THEN
      o_status_code:= utl.get_constant_value('c_invalid_vin');
         RETURN;
      END IF;

      CALL ctx.set(iptnrid => i_ptnr_id::UUID, ivin => i_vin);

      -- get the normalized vin
      SELECT vin
        INTO STRICT l_vin
        FROM beowner.ctx_data;
     
     CLOSE o_user_info;
      OPEN o_user_info FOR
         SELECT u.login_id
              ,ud.name_first
              ,ud.name_last
              ,u.usr_id
          FROM beowner.subscription  s
              ,beowner.usr           u
               LEFT OUTER JOIN beowner.usr_demog ud ON (u.usr_id = ud.usr_id)
         WHERE     s.vin = l_vin
               AND u.usr_id = s.primary_id
               AND s.optin_level >= 0                                   -- find last modified subscription that had opt-in level >= 0
               AND s.subscription_id = (SELECT last_sub.subscription_id
                                          FROM (  SELECT h.subscription_id
                                                    FROM beowner.hist_subscription h
                                                   WHERE h.vin = l_vin AND h.optin_level >= 0
                                                ORDER BY tmstmp DESC) last_sub LIMIT 1);
      o_status_code := utl.get_constant_value('csuccess');
  RETURN;
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
         o_status_code := utl.get_constant_value('cdbpartneridnotvalid');
         o_user_info := utl.get_dummy_cursor();
         RETURN;
      WHEN SQLSTATE 'EVINN' THEN
         o_status_code := utl.get_constant_value('cdbvinnotfound');
         o_user_info := utl.get_dummy_cursor();
         RETURN;
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
         o_status_code := utl.get_constant_value('cinvalidparams');
         o_user_info := utl.get_dummy_cursor();
         RETURN;
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         o_user_info := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cinternalerror');
         RETURN;
   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION ns.get_last_reg_user_for_ev_vin (i_ptnr_id text, i_vin text, o_user_info OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
