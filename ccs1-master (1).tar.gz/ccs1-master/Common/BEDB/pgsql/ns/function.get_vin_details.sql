SET bedb.filename = 'function.get_vin_details.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS ns.get_vin_details (text, text);
/*  GET_VIN_DETAILS

   Gets VIN information for a given VIN; calls VIN_MANAGER.GET_VIN_DETAILS.

*/
   
CREATE OR REPLACE FUNCTION ns.get_vin_details (ipartnerid text, ivin text, oresult OUT REFCURSOR) 
AS $body$
BEGIN
    select o_result INTO oresult from vin_manager.get_vin_details(ipartnerid, ivin);
    RETURN;
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;

-- REVOKE ALL ON FUNCTION ns.get_vin_details (ipartnerid text, ivin text, oresult OUT REFCURSOR) FROM PUBLIC;
\i cleanup.sql;
