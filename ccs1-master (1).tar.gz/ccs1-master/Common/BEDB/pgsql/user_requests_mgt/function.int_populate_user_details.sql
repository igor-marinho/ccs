SET bedb.filename = 'function.int_populate_user_details.sql';

\i set_be_env.sql;
 
DROP FUNCTION IF EXISTS user_requests_mgt.int_populate_user_details (beowner.user_requests.ur_guid%TYPE);

/* Populates information from from hist_usr for all login_ids included on the user request
    Only called by populate_user_details, hence the prefix */
CREATE OR REPLACE FUNCTION user_requests_mgt.int_populate_user_details (i_ur_guid               beowner.user_requests.ur_guid%TYPE
                                                                       ,o_status_code      OUT  INTEGER) 
AS
$BODY$
DECLARE
        l_request_type       beowner.user_requests.request_type%TYPE;
        l_scope_start_date   beowner.user_requests.scope_start_date%TYPE;
        l_login_ids          beowner.user_requests.login_ids%TYPE;
        l_user_found         BOOLEAN := FALSE;
        users_rec            RECORD;
        deleted_users_rec    RECORD;
        rows_inserted        INTEGER;
    BEGIN
        /* Modified for CCS1E-2298 to account for cases where same user may have multiple login IDs in history */
        BEGIN
            SELECT request_type, scope_start_date, login_ids
              INTO l_request_type, l_scope_start_date, l_login_ids
              FROM beowner.user_requests
             WHERE ur_guid = i_ur_guid;
        EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
                o_status_code := utl.get_constant_value('c_request_not_found');
                RETURN;
        END;

        /* Modified for CCS1E-2297 to clean up deleted users before populating user_request_details

        Populate user_created based on when the first history user row was added with same login ID
        Populate user_deleted based on this logic:
           The date of user delete, if user was truly deleted.
           In case user login was updated, use (almost) the next login ID's first history row as deleted date.
        User_current simply indicates if the user currently exists or not with the same login ID

        Distinct is needed in inner sub-query to select distinct combinations from history,
           hence outer select was added to include rand_guid
        */
       FOR users_rec IN (SELECT DISTINCT (regexp_split_to_table(l_login_ids,E',')) as login_id)
        LOOP
            FOR deleted_users_rec IN (SELECT hu.usr_id
                                        FROM beowner.hist_usr hu
                                       WHERE hu.login_id = users_rec.login_id AND hu.act = 'D')
            LOOP
                o_status_code := user_requests_mgt.delete_users (i_ur_guid => NULL, i_usr_id => deleted_users_rec.usr_id);
                IF o_status_code != utl.get_constant_value('csuccess')::INTEGER
                THEN
                    EXIT;
                END IF;
            END LOOP;
            IF o_status_code != utl.get_constant_value('csuccess')::INTEGER
            THEN
               EXIT;                                  /*if delete failed for a user, there's no point in processing further*/
            END IF;

            INSERT INTO beowner.user_request_details (urd_guid
                                                     ,ur_guid
                                                     ,usr_id
                                                     ,login_id
                                                     ,parent_id
                                                     ,user_created
                                                     ,user_deleted
                                                     ,user_current)
                    (SELECT beowner.rand_guid ()
                           ,i_ur_guid
                           ,usr_id
                           ,login_id
                           ,parent_id
                           ,min_tmstmp
                           ,max_tmstmp
                           ,user_current
                   FROM (SELECT DISTINCT hu.usr_id
                                        ,hu.login_id
                                        ,parent_id
                                        ,FIRST_VALUE (hu.tmstmp)
                                             OVER (PARTITION BY hu.usr_id, hu.login_id
                                                   ORDER BY hu.tmstmp
                                                   RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)    min_tmstmp
                                        ,(SELECT MIN (hu2.tmstmp) - INTERVAL '0.001' SECOND
                                            FROM beowner.hist_usr hu2
                                           WHERE     hu2.usr_id = hu.usr_id
                                                 AND hu2.login_id != hu.login_id
                                                 AND hu2.tmstmp > hu.tmstmp)                                     max_tmstmp
                                        ,(SELECT CASE WHEN COUNT (1) = 1 THEN 'Y' ELSE 'N' END
                                            FROM beowner.usr u
                                           WHERE u.usr_id = hu.usr_id AND u.login_id = hu.login_id)              user_current
                           FROM beowner.hist_usr hu
                          WHERE hu.login_id = users_rec.login_id) AS src);

            GET DIAGNOSTICS rows_inserted := ROW_COUNT;
            l_user_found := l_user_found OR (rows_inserted != 0);
        END LOOP;

        IF o_status_code != utl.get_constant_value('csuccess')::INTEGER
        THEN
            -- in case delete_users failed for any user
            RETURN;
        ELSIF NOT l_user_found
        THEN
            o_status_code := utl.get_constant_value('c_no_users_found');
        ELSE
            o_status_code := utl.get_constant_value('csuccess');
        END IF;
    -- promote exceptions to calling sproc
    END;
$BODY$
LANGUAGE PLPGSQL
;
\i cleanup.sql;

