SET bedb.filename = 'function.delete_users.sql';

\i set_be_env.sql;
 
   /* CCS1E-2194 : Delete the user/s and their history
     Called by CCPA batch processing file batch_process_user_requests

      Since this procedure isn't meant to be called directly by any API, the ur_guid is expected to be a valid one,
        hence no logic is being added to handle non-existing requests.

        Any exceptions encountered are raised.

        Modified for CCS1E-2297 to allow cleanup of a single deleted user's data
    */

DROP FUNCTION IF EXISTS user_requests_mgt.delete_users (TEXT,
														TEXT);
														
DROP FUNCTION IF EXISTS user_requests_mgt.delete_users (beowner.user_requests.ur_guid%TYPE,
														beowner.usr.usr_id%TYPE);

CREATE OR REPLACE FUNCTION user_requests_mgt.delete_users( i_ur_guid       IN   beowner.user_requests.ur_guid%TYPE
														  ,i_usr_id        IN   beowner.usr.usr_id%TYPE DEFAULT NULL
														  ,o_status_code   OUT  INTEGER ) AS $body$
    DECLARE
	    l_action                 text;
        l_module_name            text := 'delete_users';
        l_delete_user_status     INTEGER;
        c_obfuscated_text        CONSTANT TEXT := 'xxxx';
		users_rec                RECORD;
        c_null_substitute_text   CONSTANT TEXT := 'A';
        l_guid                   uuid := '00000000-0000-0000-0000-000000000000'::uuid;
		l_exception_diagnostics trc.exception_diagnostics;
   
	BEGIN
		
		l_action := utl.set_module_action( l_module_name, 'Updating user_requests');

        FOR users_rec
            IN (SELECT urd.usr_id
                      ,urd.parent_id
                      ,urd.login_id
                      ,u.make_id
                      ,urd.user_deleted
                  FROM beowner.user_request_details urd left join beowner.usr u ON     
                       u.usr_id = urd.usr_id
					   WHERE  i_ur_guid IS NOT NULL AND urd.ur_guid = i_ur_guid
                UNION
                SELECT hu.usr_id
                      ,hu.parent_id
                      ,hu.login_id
                      ,NULL          make_id
                      ,hu.tmstmp     user_deleted
                  FROM beowner.hist_usr hu
                 WHERE i_usr_id IS NOT NULL AND hu.usr_id = i_usr_id AND hu.act = 'D')
        LOOP
            IF users_rec.make_id IS NOT NULL
            -- only current users need to be deleted
            THEN
                PERFORM ctx.SET( imakeid => users_rec.make_id );
				
                l_delete_user_status := crudg_usr.d_usr_sp( iusr_id => users_rec.usr_id::text, i_delete_children => 'Y' );
				
                IF l_delete_user_status != utl.get_constant_value('csuccess')::Integer
                THEN
                    o_status_code := l_delete_user_status;
					l_exception_diagnostics.module_name := l_module_name;
                    l_exception_diagnostics.action := l_action;
                    CALL trc.LOG( 'Error encountered when trying to delete ' || users_rec.login_id );
                    RAISE exception using errcode ='ERROR';
                END IF;
            END IF;

            DELETE from beowner.hist_usr_email hue
             WHERE hue.usr_id = users_rec.usr_id;

            DELETE from beowner.hist_usr_phone hup
             WHERE hup.usr_id = users_rec.usr_id;

            DELETE from beowner.hist_usr_demog hud
             WHERE hud.usr_id = users_rec.usr_id;

            DELETE from beowner.hist_usr_inf hui
             WHERE hui.usr_id = users_rec.usr_id;

            DELETE from beowner.hist_usr_push_handsets hup
             WHERE hup.usr_id = users_rec.usr_id;

            DELETE from beowner.hist_usr_acl hua
             WHERE hua.usr_id = users_rec.usr_id;

            -- only primary users can have data in these tables
            IF users_rec.parent_id IS NULL
            THEN
                DELETE FROM
                    beowner.hist_notif_location hnl
                      WHERE hnl.subs_notif_id IN
					            (SELECT hsn.subs_notif_id FROM beowner.hist_subs_notif  hsn,
								
                                (SELECT hs.subscription_id ,hs.primary_id,FIRST_VALUE( hs.tmstmp ) OVER(PARTITION BY hs.subscription_id,hs.primary_id
                                                                          ORDER BY hs.tmstmp
                                                                          RANGE BETWEEN UNBOUNDED PRECEDING
                                                                          AND     UNBOUNDED FOLLOWING)    min_tmstmp
                                                                          
                                 ,CASE
                                 WHEN coalesce ( s.primary_id::text,c_null_substitute_text ) = hs.primary_id::text
                                 THEN
                                 CURRENT_TIMESTAMP

                                 else LAST_VALUE( hs.tmstmp ) OVER(PARTITION BY hs.subscription_id ,hs.primary_id
                                  ORDER BY hs.tmstmp
                                  RANGE BETWEEN unbounded PRECEDING
                                  AND     unbounded FOLLOWING) END      max_tmstmp
                                  
                                 FROM beowner.hist_subscription hs left join beowner.subscription s on s.subscription_id = hs.subscription_id
                                 where hs.primary_id = users_rec.usr_id) hs

                                 where hsn.subscription_id = hs.subscription_id
                                 AND hsn.tmstmp BETWEEN hs.min_tmstmp AND hs.max_tmstmp
                                 AND hsn.act = 'I'
                                 AND hnl.subs_notif_id = hsn.subs_notif_id);

                DELETE from beowner.hist_subscription hs
                 WHERE hs.primary_id = users_rec.usr_id;

                DELETE from beowner.hist_oem_notif_recipients honr
                 WHERE honr.usr_id = users_rec.usr_id;
            END IF;

            -- some data in Prod for secondaries
            DELETE from telogowner.notification_log nl
             WHERE nl.email_id = users_rec.login_id AND nl.create_date <= users_rec.user_deleted;

            DELETE from beowner.hist_usr hu
             WHERE hu.usr_id = users_rec.usr_id;

            UPDATE beowner.data_fix_results
               SET user_login_id = c_obfuscated_text
             WHERE     user_login_id = users_rec.login_id
                   AND usr_id = users_rec.usr_id
                   AND processed_on <= users_rec.user_deleted;

            -- CCS1E-2297 - Only delete RDRs that came in before the user was deleted, or current time if the user was never deleted.

          UPDATE beowner.rdr_staging
               SET rs_company_name = c_obfuscated_text
                  ,rs_org_line1 = c_obfuscated_text
                  ,rs_org_line2 = c_obfuscated_text
                  ,rs_org_city = c_obfuscated_text
                  ,rs_org_state = c_obfuscated_text
                  ,rs_org_zip_code = c_obfuscated_text
                  ,rs_org_phone_am_areacode = c_obfuscated_text
                  ,rs_org_phone_am_exchange = c_obfuscated_text
                  ,rs_org_phone_am_line_number = c_obfuscated_text
                  ,rs_org_phone_am_extension = c_obfuscated_text
                  ,rs_org_phone_pm_areacode = c_obfuscated_text
                  ,rs_org_phone_pm_exchange = c_obfuscated_text
                  ,rs_org_phone_pm_line_number = c_obfuscated_text
                  ,rs_org_phone_pm_extension = c_obfuscated_text
                  ,rs_org_email_id = c_obfuscated_text
                  ,rs_buyer_first_name = c_obfuscated_text
                  ,rs_buyer_middle_initial = c_obfuscated_text
                  ,rs_buyer_last_name = c_obfuscated_text
                  ,rs_buyer_name_suffix = c_obfuscated_text
                  ,rs_buyer_line1 = c_obfuscated_text
                  ,rs_buyer_line2 = c_obfuscated_text
                  ,rs_buyer_city = c_obfuscated_text
                  ,rs_buyer_state = c_obfuscated_text
                  ,rs_buyer_zip_code = c_obfuscated_text
                  ,rs_buyer_phone_am_areacode = c_obfuscated_text
                  ,rs_buyer_phone_am_exchange = c_obfuscated_text
                  ,rs_buyer_phone_am_linenumber = c_obfuscated_text
                  ,rs_buyer_phone_am_extension = c_obfuscated_text
                  ,rs_buyer_phone_pm_areacode = c_obfuscated_text
                  ,rs_buyer_phone_pm_exchange = c_obfuscated_text
                  ,rs_buyer_phone_pm_linenumber = c_obfuscated_text
                  ,rs_buyer_phone_pm_extension = c_obfuscated_text
                  ,rs_buyer_email_id = c_obfuscated_text
             WHERE     coalesce( rs_buyer_email_id, rs_org_email_id ) = users_rec.login_id
                   AND rs_created_date <=
                       coalesce(  users_rec.user_deleted at time zone 'UTC', CURRENT_TIMESTAMP );

            -- obfuscate login_id found in prior user requests
            -- nvl in below updates ensures that any prior user requests are obfuscated even when i_ur_guid is null

            UPDATE beowner.user_requests
               SET login_ids = REPLACE( login_ids, users_rec.login_id, c_obfuscated_text )
             WHERE     created_date <= users_rec.user_deleted
                   AND ur_guid IN
                           (SELECT DISTINCT urd.ur_guid
                              FROM beowner.user_request_details as urd
                             WHERE     urd.ur_guid != coalesce( i_ur_guid, l_guid )
                                   AND urd.login_id = users_rec.login_id
                                   AND urd.usr_id = users_rec.usr_id);

            UPDATE beowner.user_request_details
               SET login_id = c_obfuscated_text
             WHERE     ur_guid != coalesce( i_ur_guid, l_guid )
                   AND login_id = users_rec.login_id
                   AND usr_id = users_rec.usr_id
                   AND created_date <= users_rec.user_deleted;
        ----
        END LOOP;

        /* Below 2 updates will do nothing if i_ur_guid is null, which is OK since if i_usr_id is provided,
        the updates within loop will obfuscate user_requests data */
        UPDATE beowner.user_request_details
           SET login_id = c_obfuscated_text
         WHERE ur_guid = i_ur_guid;

        UPDATE beowner.user_requests
           SET login_ids = c_obfuscated_text
         WHERE ur_guid = i_ur_guid;
        
        o_status_code := utl.get_constant_value('csuccess');
		RETURN;
		
    EXCEPTION
        WHEN sqlstate 'ERROR' THEN
		RETURN;
          
        -- o_status_code set earlier
        WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
		
          o_status_code := utl.get_constant_value('cinternalerror');
		  RETURN;
         
END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
\i cleanup.sql;

