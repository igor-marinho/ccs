SET bedb.filename = 'function.is_request_valid.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS user_requests_mgt.is_request_valid( beowner.user_requests.request_id%TYPE);

CREATE OR REPLACE FUNCTION user_requests_mgt.is_request_valid(i_request_id beowner.user_requests.request_id%TYPE,
                                                              OUT o_status_code BOOLEAN)
AS
$BODY$

DECLARE 

l_request_id beowner.user_requests.request_id%type := upper(i_request_id);
l_found varchar(1);

BEGIN
	
    SELECT 1 INTO strict l_found  
    FROM beowner.user_requests
    WHERE UPPER (request_id) = l_request_id;
    
    o_status_code := TRUE;   
    RETURN;
   
EXCEPTION
    WHEN no_data_found THEN
    o_status_code := FALSE;
    RETURN;
   
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
