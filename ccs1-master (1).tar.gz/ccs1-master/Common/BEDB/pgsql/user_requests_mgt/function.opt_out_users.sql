SET bedb.filename = 'function.opt_out_users.sql';

\i set_be_env.sql;
 
/* CCS1E-1508 : Opt-out users in the request
      Called by CCPA batch processing file batch_process_user_requests

      Since this procedure isn't meant to be called directly by any API, the ur_guid is expected to be a valid one,
        hence no logic is being added to handle non-existing requests.

      Any exceptions encountered are raised.
    */

drop function if exists user_requests_mgt.opt_out_users(text);

CREATE OR REPLACE FUNCTION user_requests_mgt.opt_out_users( i_ur_guid       IN     TEXT
															,o_status_code   OUT    INTEGER ) AS $BODY$ 

DECLARE

      l_action text;
      l_module_name text := 'opt_out_users';
      l_exception_diagnostics trc.exception_diagnostics;
	  l_ur_guid uuid := i_ur_guid::uuid;
	  
BEGIN
		
		l_action := utl.set_module_action( l_module_name, 'Updating users');

        UPDATE beowner.usr
           SET opted_out = utl.get_constant_value('c_yes')
         WHERE     usr_id IN (SELECT urd.usr_id
                                  FROM user_request_details urd
                                 WHERE urd.ur_guid = l_ur_guid)
               AND opted_out IS NULL;

        
        o_status_code := utl.get_constant_value('csuccess');
		RETURN;
		
EXCEPTION

         WHEN OTHERS THEN
		 GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
          
          o_status_code := utl.get_constant_value('cinternalerror');
		  
          return;
            
END;
$BODY$
LANGUAGE plpgsql
SECURITY DEFINER;
\i cleanup.sql;

