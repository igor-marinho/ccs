SET bedb.filename = 'function.process_new_request.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS user_requests_mgt.process_new_request(beowner.user_requests.request_id%TYPE
                                                            , beowner.user_requests.request_type%TYPE
                                                            , beowner.user_requests.login_ids%TYPE
                                                            , beowner.user_requests.vins%TYPE
                                                            , beowner.user_requests.scope_start_date%TYPE);
 /*
    PROCESS_NEW_REQUEST
       Process new user request received - currently just for CCPA
       Valid request types : (R)eport/(D)elete/(O)pt-out
       Requests are simply validated and queued in user_requests and user_request_details tables unless request type = O (Opt-out)

      Out : o_ur_guid - primary key from user_requests
            o_status_code - Status

          Expected Return Values:
          0     : Operation was successful. (csuccess)
          1     : Internal Error (cinternalerror)
          4     : Invalid Parameters (cinvalidparams)
          288   : No matching subscriptions were found. (c_no_such_subscription_exists)
          660   : Invalid Request ID (c_invalid_request_id)
          661   : Invalid Request Type (c_invalid_request_type)
          662   : Request ID already exists (c_duplicate_request_id)
          663   : Active Safety Connect contract found (c_active_contract_found)
          664   : Active application usage (TELOG) found in past 30 days (c_active_mobile_usage_found)
          665   : Request ID is mandatory (c_request_id_is_required)
          666   : No login ids provided (c_login_ids_required)
          667   : Too many login IDs provided. Length of comma-separated values must not exceed 4000 (c_too_many_login_ids)
          668   : No VINs provided (c_vins_required)
          669   : Too many VINs provided. Length of comma-separated values must not exceed 4000 (c_too_many_vins)
          670   : Request doesn't exist (c_request_not_found)
          671   : None of the users exist in the DB (c_no_users_found)
         */
CREATE OR REPLACE FUNCTION user_requests_mgt.process_new_request (i_request_id             beowner.user_requests.request_id%TYPE
                                                                 ,i_request_type           beowner.user_requests.request_type%TYPE
                                                                 ,i_login_ids              beowner.user_requests.login_ids%TYPE
                                                                 ,i_vins                   beowner.user_requests.vins%TYPE
                                                                 ,i_scope_start_date       beowner.user_requests.scope_start_date%TYPE
                                                                 ,o_ur_guid            OUT TEXT
                                                                 ,o_status_code        OUT INTEGER ) AS
$BODY$
DECLARE
        l_action text;
        l_module_name text := 'process_new_request';
        l_request_count                INTEGER;
        l_request_type                 beowner.user_requests.request_type%TYPE;
        l_hist_subs_exists             INTEGER;
        l_login_ids                    beowner.user_requests.login_ids%TYPE;
        l_vins                         beowner.user_requests.vins%TYPE;
        l_request_id                   beowner.user_requests.request_id%TYPE;
        l_unexpired_contract_exists    INTEGER;
        l_telog_exists                 INTEGER;
        l_scope_start_date             beowner.user_requests.scope_start_date%TYPE;
        l_populate_users_status        INTEGER;
        l_ur_guid                      beowner.user_requests.ur_guid%TYPE;
        c_mobile_usage_days   CONSTANT beowner.cfg.VALUE%TYPE := utl.getconfig (icfgname => utl.get_constant_value('c_cfg_mobile_usage_days'));
        l_exception_diagnostics trc.exception_diagnostics;
    BEGIN
        l_action := utl.set_module_action( l_module_name, ' Validating inputs');

        -- Jira CCS1E-2308 All assignments moved inside begin/end, to ensure value error is raised if datatype or length are mismatched
        l_request_type := UPPER (i_request_type);

        IF i_scope_start_date IS NULL
        THEN
            o_status_code := utl.get_constant_value('c_scope_start_date_is_required');
            RETURN;
        ELSIF i_scope_start_date > current_date
        THEN
            o_status_code := utl.get_constant_value('c_invalid_scope_start_date');
            RETURN;
        ELSE
            l_scope_start_date := i_scope_start_date;
        END IF;

        -- spaces don't work in the file-name
        l_request_id := REPLACE (i_request_id, ' ', '_');

        IF NOT utl.is_domain_value_valid (i_domain => utl.get_constant_value('c_user_request_type_domain'), i_value => l_request_type)
        THEN
            o_status_code := utl.get_constant_value('c_invalid_request_type');
            RETURN;
        END IF;

        IF COALESCE(i_request_id, '') = ''
        THEN
            o_status_code := utl.get_constant_value('c_request_id_is_required');
            RETURN;
        ELSE
            SELECT COUNT (1)
              INTO l_request_count
              FROM beowner.user_requests
             WHERE UPPER (request_id) = UPPER (l_request_id) 
             AND status != utl.get_constant_value('c_request_status_error');

            IF l_request_count > 0
            THEN
                o_status_code := utl.get_constant_value('c_duplicate_request_id');
                RETURN;
            END IF;
        END IF;

        IF COALESCE(TRIM(i_login_ids), '') = ''
        THEN
            o_status_code := utl.get_constant_value('c_login_ids_required');
            RETURN;
        ELSIF LENGTH (i_login_ids) > 4000
        THEN
            o_status_code := utl.get_constant_value('c_too_many_login_ids');
            RETURN;
        ELSE
            l_login_ids := LOWER (TRIM (i_login_ids));
        END IF;

        IF COALESCE(TRIM (i_vins), '') = ''
        THEN
            o_status_code := utl.get_constant_value('c_vins_required');
            RETURN;
        ELSIF LENGTH (i_vins) > 4000
        THEN
            o_status_code := utl.get_constant_value('c_too_many_vins');
            RETURN;
        ELSE
            l_vins := UPPER (TRIM (i_vins));
        END IF;

        l_action := utl.set_module_action( l_module_name, 'Inserting user request');
        
        INSERT INTO beowner.user_requests (ur_guid
                       ,request_id
                       ,request_type
                       ,scope_start_date
                       ,login_ids
                       ,vins
                       ,status)
                VALUES (beowner.rand_guid()
                       ,l_request_id
                       ,l_request_type
                       ,l_scope_start_date
                       ,l_login_ids
                       ,l_vins
                       ,utl.get_constant_value('c_request_status_new'))
        ON CONFLICT ON CONSTRAINT ur_pk
        DO UPDATE SET 
               request_type = l_request_type
              ,scope_start_date = l_scope_start_date
              ,login_ids = l_login_ids
              ,vins = l_vins
              ,error_code = NULL
              ,status = utl.get_constant_value('c_request_status_new');

        SELECT ur_guid
          INTO l_ur_guid
          FROM beowner.user_requests
         WHERE request_id = l_request_id;

        l_populate_users_status := user_requests_mgt.int_populate_user_details (i_ur_guid => l_ur_guid);
        -- an exception could also be raised in the above sproc, which will be raised

        IF l_populate_users_status != utl.get_constant_value('csuccess')::INTEGER
        THEN
            o_status_code := l_populate_users_status;
            RAISE EXCEPTION USING ERRCODE = 50001;
        END IF;

        -- check that at least one combination of user (or secondary's primary user)/vin from the inputs provided exists in hist_subscription
        SELECT COUNT (1)
          INTO l_hist_subs_exists
          FROM beowner.hist_subscription hs, beowner.user_request_details urd
         WHERE     urd.ur_guid = l_ur_guid
               AND hs.primary_id = COALESCE(urd.parent_id, urd.usr_id)
               AND hs.vin IN ( SELECT DISTINCT (regexp_split_to_table(l_vins,E',')) )
               LIMIT 1;

        IF l_hist_subs_exists = 0
        THEN
            o_status_code := utl.get_constant_value('c_no_such_subscription_exists');
            RAISE EXCEPTION USING ERRCODE = 50001;
        END IF;

        l_action := utl.set_module_action( l_module_name, 'Validating for delete');

        IF l_request_type = utl.get_constant_value('c_request_type_delete')
        THEN
            /*  Check if any of the AFV users' VINs has a contract that has not expired.
            Check if any TELOG data exists for any of the provided login_ids in the past 30 days (regardless of make).  */

            SELECT COUNT (1)
              INTO l_unexpired_contract_exists
              FROM beowner.user_request_details  urd
                  ,beowner.subscription          s
                  ,beowner.vin                   v
                  ,beowner.device                d
                  ,beowner.device_types          dt
                  ,beowner.contrct               c
             WHERE urd.ur_guid = l_ur_guid
                   AND s.primary_id = urd.usr_id
                   AND v.vin = s.vin
                   AND d.device_id = v.device_id
                   AND dt.TYPE = d.device_type
                   AND dt.conflict_enforced = utl.GET_constant_value('c_yes')
                   AND c.contract_id = v.contract_id
                   AND date(expired) + 1 > CURRENT_DATE
                   LIMIT 1;

            IF l_unexpired_contract_exists > 0
            THEN
                o_status_code := utl.get_constant_value('c_active_contract_found');
                RAISE EXCEPTION USING ERRCODE = 50001;
            END IF;

            SELECT COUNT (1)
              INTO l_telog_exists
              FROM telogowner.telog t, beowner.user_request_details urd
             WHERE     urd.ur_guid = l_ur_guid
                   AND tel_email_address1 = urd.login_id
                   AND tel_created_date > CURRENT_DATE - c_mobile_usage_days::INTEGER
                   LIMIT 1;

            IF l_telog_exists > 0
            THEN
                o_status_code := utl.get_constant_value('c_active_mobile_usage_found');
                RAISE EXCEPTION USING ERRCODE = 50001;
            END IF;
        END IF;

        o_ur_guid := l_ur_guid::TEXT;
        o_status_code := utl.get_constant_value('csuccess');
    /* TBD with a later story - processing when request_type = 'O'

     opt_out_user
     mark_request_completion with status = P
    */
    EXCEPTION
        WHEN SQLSTATE '50001' 
        THEN
            UPDATE beowner.user_requests
               SET status = utl.get_constant_value('c_request_status_error'), ERROR_CODE = o_status_code
             WHERE ur_guid = l_ur_guid;

            DELETE FROM beowner.user_request_details
                  WHERE ur_guid = l_ur_guid;
            RETURN;
        WHEN  string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.action := l_action;
          l_exception_diagnostics.module_name := l_module_name;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
         o_status_code := utl.get_constant_value('cinvalidparams');
         RETURN;
        WHEN OTHERS
        THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.action := l_action;
          l_exception_diagnostics.module_name := l_module_name;

          CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
          o_status_code := utl.get_constant_value('cinternalerror');
          RETURN;
END;
$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
\i cleanup.sql;

