SET bedb.filename = 'function.get_ccpa_report_data.sql';

\i set_be_env.sql;

DROP FUNCTION if exists user_requests_mgt.get_ccpa_report_data (beowner.user_request_details.ur_guid%TYPE,beowner.user_requests.file_name%type );

CREATE OR REPLACE FUNCTION user_requests_mgt.get_ccpa_report_data(i_ur_guid                         beowner.user_request_details.ur_guid%TYPE,
                                                                  i_file_name                       beowner.user_requests.file_name%type,
                                                                  o_status_code               OUT   INTEGER,
                                                                  user_info_cur               OUT   REFCURSOR,
                                                                  usr_demo_info_cur           OUT   REFCURSOR,
                                                                  usr_ph_hist_cur             OUT   REFCURSOR,
                                                                  usr_hs_push_hist_cur        OUT   REFCURSOR,
                                                                  dest_search_hist_cur        OUT   REFCURSOR,
                                                                  log_ret_del_rec_cur         OUT   REFCURSOR,
                                                                  sub_hist_cur                OUT   REFCURSOR,
                                                                  plug_in_notif_loc_hist_cur  OUT   REFCURSOR,
                                                                  usr_req_cur                 OUT   REFCURSOR,
                                                                  usr_req_dtl_cur             OUT   REFCURSOR )
AS $body$
/*
DCS1E-1485 - CCPA: DB script to return User's right to know reports
Get data for the CCPA for the provided ur_guid, request_id and start_date

First parameter : UR_GUID
Second parameter : REQUEST_ID

Modified for Jira CCS1E-2310 and CCS1E-2298:
  to show base table results (first part of the union) if the user currently exists with the same login_id
  to only include history (and login_Id) if it matches the timestamps on user_request_details for the user
  */
DECLARE
   l_action         text;
   l_module_name    text := 'get_ccpa_report_data';
   l_status_code    INTEGER;
   l_exception_diagnostics trc.exception_diagnostics;
   l_scope_start_date beowner.user_requests.scope_start_date%type;

BEGIN

   l_action := utl.set_module_action(l_module_name, 'Main User Information');
   
   select scope_start_date 
     into strict l_scope_start_date
     from beowner.user_requests ur 
    where ur.ur_guid  = i_ur_guid;

--PROMPT Main User Information - Describes association between login_id (email) with make of vehicle
open user_info_cur for
SELECT u.login_id "EMAIL ADDRESS",
       NULL "TIMESTAMP",
       'Current' "ACTION",
       m.description "MAKE",
       u.opted_out "OPTED OUT"
  FROM beowner.usr u, beowner.make m, beowner.user_request_details urd
 WHERE     urd.ur_guid = i_ur_guid
       AND u.usr_id = urd.usr_id
       AND urd.user_current = 'Y'
       AND m.make_id = u.make_id
UNION ALL
SELECT hu.login_id,
       hu.tmstmp as "TIMESTAMP",
       CASE hu.act
           WHEN 'I' THEN 'Insert'
           WHEN 'U' THEN 'Update'
           WHEN 'D' THEN 'Delete'
       END  as "ACTION",
       m.description "MAKE",
       hu.opted_out
  FROM beowner.hist_usr hu, beowner.make m, beowner.user_request_details urd
  WHERE     urd.ur_guid =  i_ur_guid
       AND hu.usr_id = urd.usr_id
       AND hu.login_id = urd.login_id
       AND m.make_id = hu.make_id
       AND hu.tmstmp >= GREATEST (l_scope_start_date, urd.user_created)
       AND hu.tmstmp <= COALESCE (urd.user_deleted, current_timestamp)
ORDER BY 1, 2 NULLS FIRST;

l_action := utl.set_action('User Demographic Information');
--PROMPT User Demographic Information - Provides name and address of user

open usr_demo_info_cur for
SELECT urd.login_id "EMAIL ADDRESS",
       NULL "TIMESTAMP",
       'Current' "ACTION",
       ud.name_first "FIRST NAME",
       ud.name_mi "MIDDLE",
       ud.name_last "LAST NAME",
       ud.name_suffix "SUFFIX",
       ud.addr1 "ADDRESS 1",
       ud.addr2 "ADDRESS 2",
       ud.city,
       ud.state,
       ud.postal_code "POSTAL CODE",
       ud.country
  FROM beowner.usr_demog ud, beowner.user_request_details urd
 WHERE     urd.ur_guid = i_ur_guid
       AND ud.usr_id = urd.usr_id
       AND urd.user_current = 'Y'
UNION ALL
SELECT urd.login_id,
       hud.tmstmp,
       CASE hud.act
           WHEN 'I' THEN 'Insert'
           WHEN 'U' THEN 'Update'
           WHEN 'D' THEN 'Delete'
       END  as "ACTION",
       hud.name_first,
       hud.name_mi,
       hud.name_last,
       hud.name_suffix,
       hud.addr1,
       hud.addr2,
       hud.city,
       hud.state,
       hud.postal_code,
       hud.country
  FROM beowner.hist_usr_demog hud, beowner.user_request_details urd
 WHERE     urd.ur_guid = i_ur_guid
       AND hud.usr_id = urd.usr_id
       AND hud.tmstmp >= GREATEST (l_scope_start_date, urd.user_created)
       AND hud.tmstmp <= COALESCE (urd.user_deleted, current_timestamp)
ORDER BY 1, 2 NULLS FIRST;


l_action := utl.set_action('User phone history');
--PROMPT User phone history - Updates to the phone number for the user
open usr_ph_hist_cur for
SELECT urd.login_id "EMAIL ADDRESS",
       NULL "TIMESTAMP",
       'Current' "ACTION",
       UP.cc "COUNTRY CODE",
       UP.ac "AREA CODE",
       UP.phone "LINE NUMBER",
       UP.ext "EXTENSION"
  FROM beowner.usr_phone UP, beowner.user_request_details urd
 WHERE     urd.ur_guid = i_ur_guid
       AND UP.usr_id = urd.usr_id
       AND urd.user_current = 'Y'
UNION ALL
SELECT urd.login_id,
       hup.tmstmp,
       CASE hup.act
           WHEN 'I' THEN 'Insert'
           WHEN 'U' THEN 'Update'
           WHEN 'D' THEN 'Delete'
       END,
       hup.cc,
       hup.ac,
       hup.phone,
       hup.ext
  FROM beowner.hist_usr_phone hup, beowner.user_request_details urd
 WHERE     urd.ur_guid = i_ur_guid
       AND hup.usr_id = urd.usr_id
       AND hup.tmstmp >= GREATEST (l_scope_start_date, urd.user_created)
       AND hup.tmstmp <= COALESCE (urd.user_deleted, current_timestamp)
ORDER BY 1, 2 NULLS FIRST;


l_action := utl.set_action('User handset push history');
--PROMPT User handset push history - Access tokens related to allowing push notifications on the mobile device
open usr_hs_push_hist_cur for
SELECT urd.login_id "EMAIL ADDRESS",
       NULL "TIMESTAMP",
       'Current' "ACTION",
       uph.hs_id "HANDSET ID",
       'Token' "PUSH TOKEN"
  FROM beowner.usr_push_handsets uph, beowner.user_request_details urd
 WHERE     urd.ur_guid = i_ur_guid
       AND uph.usr_id = urd.usr_id
       AND urd.user_current = 'Y'
UNION ALL
SELECT urd.login_id,
       hup.tmstmp,
       CASE hup.act
           WHEN 'I' THEN 'Insert'
           WHEN 'U' THEN 'Update'
           WHEN 'D' THEN 'Delete'
       END,
       hup.hs_id,
       'Token'
  FROM beowner.hist_usr_push_handsets hup, beowner.user_request_details urd
 WHERE     urd.ur_guid = i_ur_guid
       AND hup.usr_id = urd.usr_id
       AND hup.tmstmp >= GREATEST (l_scope_start_date, urd.user_created)
       AND hup.tmstmp <= COALESCE (urd.user_deleted , current_timestamp)
ORDER BY 1, 2 NULLS FIRST;


l_action := utl.set_action('Destination search history');
--PROMPT Destination search history - Types of destination search performed by user
open dest_search_hist_cur for
  SELECT urd.login_id "EMAIL ADDRESS",
         ua.last_action_date "LAST ACTION DATE",
         ua.svc_id "SERVICE",
         ua.TYPE "TYPE",
         ua.user_action "USER ACTION"
    FROM beowner.usr_actions ua, beowner.user_request_details urd
   WHERE     urd.ur_guid = i_ur_guid
         AND ua.usr_id = urd.usr_id
       AND ua.last_action_date >= GREATEST (l_scope_start_date, urd.user_created)
       AND ua.last_action_date <= COALESCE (urd.user_deleted, current_timestamp)
ORDER BY 1, 2;

l_action := utl.set_action('Log of Retail Delivery Record');
--PROMPT Log of Retail Delivery Record (RDR) details - Information related to the sale and buyer of the vehicle
-- Cannot add the check that RDR came in after user was created, as RDR could've come in before
open log_ret_del_rec_cur for
  SELECT rs.rs_buyer_email_id "BUYER EMAIL ADDRESS",
         rs.rs_org_email_id "ORG EMAIL ADDRESS",
         rs.rs_vin "VIN",
         rs.rs_retail_date_time "RETAIL DATE TIME",
         rs.rs_buyer_first_name "BUYER FIRST NAME",
         rs.rs_buyer_middle_initial "BUYER MIDDLE INITIAL",
         rs.rs_buyer_last_name "BUYER LAST NAME",
         rs.rs_buyer_name_suffix "BUYER NAME SUFFIX",
         rs.rs_buyer_line1 "BUYER ADDRESS LINE 1",
         rs.rs_buyer_line2 "BUYER ADDRESS LINE 2",
         rs.rs_buyer_city "BUYER CITY",
         rs.rs_buyer_state "BUYER STATE",
         rs.rs_buyer_zip_code "BUYER ZIP CODE",
         rs.rs_buyer_phone_am_areacode "BUYER PHONE AM AREACODE",
         rs.rs_buyer_phone_am_exchange "BUYER PHONE AM EXCHANGE",
         rs.rs_buyer_phone_am_linenumber "BUYER PHONE AM LINENUMBER",
         rs.rs_buyer_phone_am_extension "BUYER PHONE AM EXTENSION",
         rs.rs_buyer_phone_pm_areacode "BUYER PHONE PM AREACODE",
         rs.rs_buyer_phone_pm_exchange "BUYER PHONE PM EXCHANGE",
         rs.rs_buyer_phone_pm_linenumber "BUYER PHONE PM LINENUMBER",
         rs.rs_buyer_phone_pm_extension "BUYER PHONE PM EXTENSION",
         rs.rs_company_name "COMPANY NAME",
         rs.rs_org_line1 "ORG ADDRESS LINE 1",
         rs.rs_org_line2 "ORG ADDRESS LINE 2",
         rs.rs_org_city "ORG CITY",
         rs.rs_org_state "ORG STATE",
         rs.rs_org_zip_code "ORG ZIP CODE",
         rs.rs_org_phone_am_areacode "ORG PHONE AM AREA CODE",
         rs.rs_org_phone_am_exchange "ORG PHONE AM EXCHANGE",
         rs.rs_org_phone_am_line_number "ORG PHONE AM LINE NUMBER",
         rs.rs_org_phone_am_extension "ORG PHONE AM EXTENSION",
         rs.rs_org_phone_pm_areacode "ORG PHONE PM AREACODE",
         rs.rs_org_phone_pm_exchange "ORG PHONE PM EXCHANGE",
         rs.rs_org_phone_pm_line_number "ORG PHONE PM LINE NUMBER",
         rs.rs_org_phone_pm_extension "ORG PHONE PM EXTENSION"
    FROM beowner.rdr_staging rs, beowner.user_request_details urd
   WHERE     urd.ur_guid = i_ur_guid
         AND urd.login_id != 'xxxx'
         AND COALESCE (rs_buyer_email_id, rs_org_email_id) = urd.login_id
         AND rs.rs_created_date at time zone 'UTC' >= l_scope_start_date
         AND rs.rs_created_date at time zone 'UTC' <= COALESCE (urd.user_deleted, current_timestamp)
ORDER BY 1,
         2,
         3,
         4;

l_action := utl.set_action('Subscription history');
--PROMPT Subscription history - Subscription information including Safety Connect contract information
open sub_hist_cur for
 SELECT urd.login_id "EMAIL ADDRESS",
       s.vin,
       NULL "TIMESTAMP",
       'Current' "ACTION",
       s.sub_start "SUBSCRIPTION START",
       s.conflict "VIN CONFLICT DATE",
       s.sub_duration "SUBSCRIPTION DURATION",
       be.obfuscate_contract_id (i_contract_id => c.extrnl_ctrct_id)
          "SXM CONTRACT ID",
       s.nickname "VEHICLE NICKNAME"
  FROM beowner.subscription s
  JOIN beowner.user_request_details urd ON s.primary_id = urd.usr_id
  LEFT JOIN beowner.contrct c ON c.contract_id = s.contract_id
 WHERE urd.ur_guid = i_ur_guid
       AND urd.user_current = 'Y'
UNION ALL
SELECT urd.login_id,
       hs.vin,
       hs.tmstmp,
       CASE hs.act
           WHEN 'I' THEN 'Insert'
           WHEN 'U' THEN 'Update'
           WHEN 'D' THEN 'Delete'
       END,
       hs.sub_start,
       hs.conflict,
       hs.sub_duration,
       be.obfuscate_contract_id (i_contract_id => c.extrnl_ctrct_id),
       hs.nickname
  FROM beowner.hist_subscription hs
  JOIN beowner.user_request_details urd ON hs.primary_id = urd.usr_id
  LEFT JOIN beowner.contrct c ON  c.contract_id = hs.contract_id
 WHERE     urd.ur_guid = i_ur_guid
        AND hs.tmstmp >= GREATEST (l_scope_start_date, urd.user_created)
        AND hs.tmstmp <= COALESCE (urd.user_deleted, current_timestamp)
ORDER BY 1, 2, 3 NULLS FIRST;


l_action := utl.set_action('Plug-in Reminder notification location history');
--PROMPT Plug-in Reminder notification location history - Specifies geolocation of vehicle within which plug-in reminder notifications should be sent

/* Includes logic to ensure that only the notifications created by the current user on the subscription are considered
   Especially important in case of VIN transfers. In this case source user may not have been deleted (or it's email ID changed),
      hence cannot use same logic as other queries */
Open plug_in_notif_loc_hist_cur for
SELECT urd.login_id "EMAIL ADDRESS",
       s.vin,
       NULL "TIMESTAMP",
       'Current' "ACTION",
       nl.lat "LOCATION LATITUDE",
       nl.lng "LOCATION LONGITUDE",
       nl.name "LOCATION NAME",
       nl.address "ADDRESS"
  FROM beowner.notif_location nl,
       beowner.subs_notif sn,
       beowner.subscription s,
       beowner.user_request_details urd
 WHERE     urd.ur_guid = i_ur_guid
       AND s.primary_id = urd.usr_id
       AND sn.subscription_id = s.subscription_id
       AND nl.subs_notif_id = sn.subs_notif_id
       AND urd.user_current = 'Y'
UNION ALL
SELECT hs.login_id,
       hs.vin,
       hnl.tmstmp,
       CASE hnl.act
           WHEN 'I' THEN 'Insert'
           WHEN 'U' THEN 'Update'
           WHEN 'D' THEN 'Delete'
       END,
       hnl.lat,
       hnl.lng,
       hnl.name,
       hnl.address
  FROM beowner.hist_notif_location hnl,
       beowner.hist_subs_notif hsn,
       (SELECT DISTINCT
               hs.subscription_id,
               hs.primary_id,
               hs.vin,
               urd.login_id,
               FIRST_VALUE (hs.tmstmp)
               OVER (
                  PARTITION BY hs.subscription_id, hs.primary_id
                  ORDER BY hs.tmstmp
                  RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)
                  min_tmstmp,
               CASE
                  WHEN s.primary_id = hs.primary_id
                  THEN
                     current_timestamp
                  ELSE
                     LAST_VALUE (hs.tmstmp)
                     OVER (
                        PARTITION BY hs.subscription_id, hs.primary_id
                        ORDER BY hs.tmstmp
                        RANGE BETWEEN UNBOUNDED PRECEDING
                              AND     UNBOUNDED FOLLOWING)
               END
                  max_tmstmp
          FROM beowner.hist_subscription hs
          JOIN beowner.user_request_details urd ON hs.primary_id = urd.usr_id
          LEFT JOIN beowner.subscription s ON s.subscription_id = hs.subscription_id
         WHERE     urd.ur_guid = i_ur_guid) hs
 WHERE     hsn.subscription_id = hs.subscription_id
       AND hsn.tmstmp BETWEEN hs.min_tmstmp AND hs.max_tmstmp
       AND hsn.act = 'I'
       AND hnl.subs_notif_id = hsn.subs_notif_id
       AND hnl.tmstmp >= l_scope_start_date
ORDER BY 1, 2, 3 NULLS FIRST;


l_action := utl.set_action('CCPA User Requests');
--PROMPT CCPA User Requests - User's CCPA requests

Open usr_req_cur for
SELECT ur.request_id           "DSAR REQUEST_ID"
      ,ur.request_type         "REQUEST TYPE"
      ,ur.scope_start_date     "SCOPE_START_DATE"
      ,ur.login_ids            "EMAIL_ADDRESS"
      ,ur.vins                 "VINS"
      ,ur.status               "STATUS"
      ,ur.created_date         "REQUEST CREATED DATE"
      ,ur.processed_date       "PROCESSED DATE"
      ,ur.file_name            "DB File Name"
      ,ur.external_status      "EXTERNAL STATUS"
      ,ur.last_retry_date      "LAST RETRY DATE"
    FROM beowner.user_requests ur
   where 1= 1
     and ur.ur_guid = i_ur_guid
ORDER BY ur.request_id, ur.created_date, ur.processed_date;

l_action := utl.set_action('CCPA User Request Details');
--PROMPT CCPA User Request Details - User's CCPA requests details required for CCPA customer validation
open usr_req_dtl_cur for
SELECT login_id         "EMAIL ADDRESS"
      ,created_date     "REQUEST CREATED DATE"
      ,user_created     "USER CREATED"
      ,user_deleted     "USER DELETED"
      ,user_current     "CURRENT USER"
    FROM beowner.user_request_details
   WHERE ur_guid = i_ur_guid
ORDER BY 1, 2;

o_status_code := utl.get_constant_value('csuccess');
RETURN;
   EXCEPTION
      WHEN OTHERS THEN
     GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.action := l_action;
          l_exception_diagnostics.module_name:= l_module_name;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
        user_info_cur              := utl.get_dummy_cursor();
        usr_demo_info_cur          := utl.get_dummy_cursor();
        usr_ph_hist_cur            := utl.get_dummy_cursor();
        usr_hs_push_hist_cur       := utl.get_dummy_cursor();
        dest_search_hist_cur       := utl.get_dummy_cursor();
        log_ret_del_rec_cur        := utl.get_dummy_cursor();
        sub_hist_cur               := utl.get_dummy_cursor();
        plug_in_notif_loc_hist_cur := utl.get_dummy_cursor();
        usr_req_cur                := utl.get_dummy_cursor();
        usr_req_dtl_cur            := utl.get_dummy_cursor();
     o_status_code := utl.get_constant_value('cinternalerror');
     RETURN;
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;

\i cleanup.sql;
