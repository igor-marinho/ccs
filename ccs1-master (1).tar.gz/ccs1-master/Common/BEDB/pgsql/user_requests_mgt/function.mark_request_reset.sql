SET bedb.filename = 'function.mark_request_reset.sql';

\i set_be_env.sql;


DROP FUNCTION IF EXISTS user_requests_mgt.mark_request_reset (beowner.user_requests.request_id%TYPE);
																	 
CREATE OR REPLACE FUNCTION user_requests_mgt.mark_request_reset(i_request_id   IN  beowner.user_requests.request_id%TYPE,
                                                                o_status_code  OUT integer)
AS $BODY$

DECLARE
/*
        MARK_REQUEST_RESET
        Reset status for a given Request ID.  
        This will ensure the request is picked up by batch_process_user_requests.sql in the next run.

        Out :  o_status_code - Status

        Expected Return Values:
                0     : Operation was successful.
                1     : Internal Error                
                660   : Invalid Request ID
                665   : Request ID is mandatory               
*/
    l_action text;
    l_module_name text := 'mark_request_reset';
    l_request_id beowner.user_requests.request_id%type := upper(i_request_id);
    l_exception_diagnostics trc.exception_diagnostics;
   
BEGIN
	
    l_action := utl.set_module_action( l_module_name, 'Validate request');
		
	/* Validating Request ID */
	
    IF COALESCE(l_request_id, '') = '' THEN
	
        o_status_code := utl.get_constant_value('c_request_id_is_required');
        RETURN;
    
	END IF;			         
      
    IF NOT user_requests_mgt.is_request_valid(l_request_id) THEN
  
        o_status_code := utl.get_constant_value('c_invalid_request_id');
        RETURN;
 
    END IF;
    
    l_action := utl.set_module_action( l_module_name, 'Reset request');
	
    /*Updating USER_REQUESTS */
	
    UPDATE beowner.user_requests SET 
    status = utl.get_constant_value('c_request_status_new'),
    file_name = null,
    processed_date = null,
    external_status = null,
    no_of_retries = null,
    last_retry_date = null
    WHERE UPPER(request_id) = l_request_id;
      
    o_status_code := utl.get_constant_value('csuccess');   
    RETURN;
   
EXCEPTION
    WHEN OTHERS THEN       
    GET STACKED diagnostics
        l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
        l_exception_diagnostics.column_name := COLUMN_NAME,
        l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
        l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
        l_exception_diagnostics.message_text := MESSAGE_TEXT,
        l_exception_diagnostics.table_name := TABLE_NAME,
        l_exception_diagnostics.schema_name := SCHEMA_NAME,              
        l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
        l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
        l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
        l_exception_diagnostics.action := l_action;
        l_exception_diagnostics.module_name := l_module_name;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
        o_status_code := utl.get_constant_value('cinternalerror');
        RETURN;
END;
$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
\i cleanup.sql;