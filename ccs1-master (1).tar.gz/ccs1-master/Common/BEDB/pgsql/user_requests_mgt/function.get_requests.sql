SET bedb.filename = 'function.get_requests.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS user_requests_mgt.get_requests (beowner.user_requests.status%TYPE
                                                       ,beowner.user_requests.external_status%TYPE
                                                       ,beowner.user_requests.created_date%TYPE); 

  /*
       GET_REQUESTS
          return user requests that match the i_db_status, i_external_status and requests created after i_created_date
          The inputs are optional and not validated. Null data is returned when no valid inputs are provided.
          i_db_status and i_external_status can be comma separated inputs.
         Out :  o_results - Refcursor, o_status_code - Status

             Expected Status Return Values:
               0     : Operation was successful.
               1   : Internal Error
               4     : Invalid Parameters
            */
											   
CREATE OR REPLACE FUNCTION user_requests_mgt.get_requests (i_db_status         IN     beowner.user_requests.status%TYPE
                                                          ,i_external_status   IN     beowner.user_requests.external_status%TYPE
                                                          ,i_created_date      IN     beowner.user_requests.created_date%TYPE
                                                          ,o_status_code          OUT INTEGER
                                                          ,o_results              OUT REFCURSOR)
AS $BODY$
DECLARE
    l_action text;
    l_module_name text := 'get_requests';
    l_exception_diagnostics trc.exception_diagnostics;
   
    BEGIN
        l_action := utl.set_module_action( l_module_name, 'Get Requests ');

        OPEN o_results FOR 
				WITH 
				db_status AS 
				(SELECT NULLIF(regexp_split_to_table(COALESCE(i_db_status, ''), E','), '') AS db_status),
				ext_status AS
				(SELECT NULLIF(regexp_split_to_table(COALESCE(i_external_status, ''), E','), '') AS ext_status)
				SELECT request_id
						 ,ur_guid
						 ,request_type
						 ,scope_start_date
						 ,created_date
						 ,processed_date
						 ,status
						 ,external_status
						 ,no_of_retries
						 ,last_retry_date
					 FROM beowner.user_requests ur
					 JOIN db_status ds ON COALESCE (ur.status, '~') = COALESCE(ds.db_status, ur.status, '~')
					 JOIN ext_status es ON COALESCE (ur.external_status, '~') = COALESCE(es.ext_status, ur.external_status, '~')
				   WHERE COALESCE(ur.created_date, CLOCK_TIMESTAMP()) >= COALESCE(i_created_date, ur.created_date, CLOCK_TIMESTAMP());

        o_status_code := utl.get_constant_value('csuccess');
    EXCEPTION
        WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation 
        THEN
          o_results := utl.get_dummy_cursor();
          o_status_code := utl.get_constant_value('cinvalidparams');
     
        WHEN OTHERS
        THEN
            GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.action := l_action;
          l_exception_diagnostics.module_name := l_module_name;

          CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
          o_results := utl.get_dummy_cursor();
          o_status_code := utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
\i cleanup.sql;

