SET bedb.filename = 'function.set_push_token.sql';

\i set_be_env.sql;

   /*  SET_PUSH_TOKEN
   
         Added for TCP-144 to allow for setting of push token for the provided handset
   
         Expected Return Values:
           0     : success (this can include an empty result set; a cursor with no rows)
           1     : Unknown Error
           4     : Invalid Parameter (Length/data-type)                    
           7     : User Not Found
           27    : The Login ID provided is null (cnst.c_null_login_id)
           213   : Invalid Partner ID        (cnst.cDbPartneridNotValid)
           348   : Partner ID is null        (cnst.c_ptnr_id_null)
           504   : Handset ID is required    (cnst.c_hs_id_required)  
           505   : Push token is required    (cnst.c_push_token_required)
           506   : Handset OS is required    (cnst.c_hs_os_required)
           507   : Invalid Handset OS        (cnst.c_invalid_hs_os)
   */
DROP FUNCTION IF EXISTS be.set_push_token(text, text, text, text, text);
CREATE OR REPLACE FUNCTION be.set_push_token(IN i_ptnr_id text,
                                             IN i_login_id text,
                                             IN i_hs_id text,
                                             IN i_hs_token text,
                                             IN i_hs_os text, -- iOS, Android
                                             OUT o_status_code integer,
                                             OUT o_push_token_guid text) AS
$BODY$
DECLARE
      l_action      text;
      l_module_name text := 'set_push_token';

      l_usr_id             beowner.usr.usr_id%TYPE;
      l_hs_id              beowner.usr_push_handsets.hs_id%TYPE;
      l_push_token         beowner.usr_push_handsets.push_token%TYPE;
      l_hs_os              beowner.usr_push_handsets.hs_os%TYPE;
      l_uph_row            beowner.usr_push_handsets;
      l_uph_guid           beowner.usr_push_handsets.uph_guid%TYPE;
      l_existing_row_token boolean := FALSE;
      l_exception_diagnostics trc.exception_diagnostics;
      
BEGIN
      l_action := utl.set_module_action(l_module_name,'Validating inputs');

      IF i_ptnr_id IS NULL
      THEN
          o_status_code := utl.get_constant_value('c_ptnr_id_null');
          RETURN;
      END IF;

      IF i_login_id IS NULL
      THEN
          o_status_code := utl.get_constant_value('c_null_login_id');
          RETURN;
      END IF;

      l_hs_os := trim(both upper(i_hs_os));

      IF NOT utl.is_domain_value_valid(i_domain => utl.get_constant_value('c_domain_hs_os'),
                                       i_value  => l_hs_os)
      THEN
          o_status_code := utl.get_constant_value('c_invalid_hs_os');
          RETURN;
      END IF;

      CALL ctx.set(iptnrid => i_ptnr_id::uuid, iloginid => i_login_id);

      -- assigning outside the declare section so that value errors are caught
      l_hs_id := trim(both i_hs_id);
      l_push_token := trim(both i_hs_token);

      IF l_hs_id IS NULL
      THEN
          o_status_code := utl.get_constant_value('c_hs_id_required');
          RETURN;
      END IF;

      IF l_push_token IS NULL
      THEN
          o_status_code := utl.get_constant_value('c_push_token_required');
          RETURN;
      END IF;

      IF l_hs_os IS NULL
      THEN
          o_status_code := utl.get_constant_value('c_hs_os_required');
          RETURN;
      END IF;

      SELECT usr_id
        INTO STRICT l_usr_id
        FROM beowner.ctx_data;

      -- find if token already exists for user and hs_id
      BEGIN
         BEGIN
            --Look for existing row by hs_id and user
            SELECT *
              INTO STRICT l_uph_row
              FROM beowner.usr_push_handsets
             WHERE usr_id = l_usr_id
                   AND hs_id = l_hs_id;

         EXCEPTION
            WHEN no_data_found THEN
               --Look for existing row by token and user
               SELECT *
                 INTO STRICT l_uph_row
                 FROM beowner.usr_push_handsets
                WHERE usr_id = l_usr_id
                      AND push_token = l_push_token;

               --Existing row was found by token
               l_existing_row_token := TRUE;
         END;

         l_uph_guid := l_uph_row.uph_guid;
         IF (NOT l_existing_row_token AND l_uph_row.push_token = l_push_token AND
            l_uph_row.hs_os = l_hs_os AND l_uph_row.status = utl.get_constant_value('c_valid')) -- TCP-418. If status is
         -- currently invalid, it
            -- should be updated
         -- os and token are still the same
         THEN
            o_push_token_guid := l_uph_guid;
            o_status_code := utl.get_constant_value('csuccess');
            RETURN;
         END IF;
      EXCEPTION
         WHEN OTHERS THEN
            l_uph_guid := beowner.rand_guid();
      END;

      IF l_existing_row_token
      THEN
          l_action := utl.set_module_action(l_module_name, 'Updating handset');
          DECLARE
              v_match_count integer;
          BEGIN
              SELECT count(1)
              INTO v_match_count
              FROM beowner.usr_push_handsets
              WHERE usr_id = l_usr_id
                AND push_token = l_push_token;

              IF v_match_count > 0
              THEN
                  UPDATE beowner.usr_push_handsets
                  SET hs_os       = l_hs_os,
                      hs_id       = l_hs_id,
                      status      = utl.get_constant_value('c_valid'),
                      status_date = CASE -- only change date if handset has changed or existing status != Valid
                                        WHEN hs_id != l_hs_id OR
                                             status != utl.get_constant_value('c_valid') THEN
                                            CURRENT_TIMESTAMP
                                        ELSE
                                            status_date
                          END
                  WHERE usr_id = l_usr_id
                    AND push_token = l_push_token;
              END IF;
          END;
      ELSE
          l_action := utl.set_module_action(l_module_name, 'Updating push token');

          DECLARE
              v_match_count integer;
          BEGIN
              SELECT count(1)
              INTO v_match_count
              FROM beowner.usr_push_handsets
              WHERE usr_id = l_usr_id
                AND hs_id = l_hs_id;

              IF v_match_count > 0
              THEN
                  UPDATE beowner.usr_push_handsets
                  SET hs_os       = l_hs_os,
                      push_token  = l_push_token,
                      status      = utl.get_constant_value('c_valid'),
                      status_date = CASE -- only change date if push token has changed or existing status != Valid
                                        WHEN push_token != l_push_token OR
                                             status != utl.get_constant_value('c_valid') THEN
                                            CURRENT_TIMESTAMP
                                        ELSE
                                            status_date
                          END
                  WHERE usr_id = l_usr_id
                    AND hs_id = l_hs_id;
              ELSE
                  INSERT INTO beowner.usr_push_handsets(uph_guid, usr_id, hs_id, hs_os, push_token)
                  VALUES (l_uph_guid, l_usr_id, l_hs_id, l_hs_os, l_push_token);

              END IF;
          END;

      END IF;
      o_push_token_guid := l_uph_guid;
      o_status_code := utl.get_constant_value('csuccess');
      RETURN;
    EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
          o_status_code := utl.get_constant_value('cdbpartneridnotvalid');
          RETURN;
      WHEN SQLSTATE 'EUSRN' THEN
         o_status_code := utl.get_constant_value('cnosuchuser');
         RETURN;
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
         o_status_code := utl.get_constant_value('cinvalidparams');
         RETURN;
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
          o_status_code := utl.get_constant_value('cinternalerror');
          RETURN;
   END;
$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION be.set_push_token (i_ptnr_id text, i_login_id text, i_hs_id text, i_hs_token text, i_hs_os text, o_push_token_guid OUT text) FROM PUBLIC;


\i cleanup.sql;
