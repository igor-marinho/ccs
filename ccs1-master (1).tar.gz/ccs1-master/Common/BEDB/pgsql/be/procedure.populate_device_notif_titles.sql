SET bedb.filename = 'procedure.populate_device_notif_titles.sql';

\i set_be_env.sql;

-------------------------------------------------------------------------------
   
   -- moved other constants to cnst package with TCP-301
   
CREATE OR REPLACE PROCEDURE be.populate_device_notif_titles () AS $body$
DECLARE

      l_notif_titles device_notif_rec;

  dt_rec RECORD;

BEGIN
      FOR dt_rec IN (SELECT TYPE,
                            notifications_title
                       FROM device_types)
      LOOP
         l_notif_titles.notif_title := dt_rec.notifications_title;
         current_setting('be.g_notif_titles_tbl')::device_notif_tbl(dt_rec.type) := l_notif_titles;
      END LOOP;
   END;
   -------------------------------------------------------------------------------
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE be.populate_device_notif_titles () FROM PUBLIC;

\i cleanup.sql;
