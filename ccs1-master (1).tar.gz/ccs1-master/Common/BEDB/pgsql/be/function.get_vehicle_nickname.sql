SET bedb.filename = 'function.get_vehicle_nickname.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS be.get_vehicle_nickname(text, text, text);
   /* get_vehicle_nickname
        Gets the nickname for the vehicle (VIN) provided.
        Inputs:
        iPartnerId   Partner Id for the VIN
        iLoginId     Login Id for the VIN
        iVin         VIN that the nickname will be set for
   
     Expected Return Values:
            0     : success
            1     : Unknown Error
            7     : No such User found           (cnst.cNoSuchUser)
            200   : VIN not found (not your VIN) (cnst.cDbVinNotFound)
            201   : Subscriber/VIN not found     (cnst.cdbsubscribervinnotfound)
            213   : Partner Id is not valid      (cnst.cDbPartneridNotValid)  
   */
CREATE OR REPLACE FUNCTION be.get_vehicle_nickname (ipartnerid          text
                                                   ,iloginid            text
                                                   ,ivin                text
                                                   ,o_status_code   OUT integer
                                                   ,onickname       OUT text)
AS
$BODY$
DECLARE
    l_action                text;
    l_module_name           text := 'get_vehicle_nickname';
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    l_action := utl.set_module_action(l_module_name, ' Setting Context');

    CALL ctx.set(iloginid => iloginid, ivin => ivin, iptnrid => ipartnerid::UUID);

    l_action := utl.set_module_action( l_module_name, ' getting nickname');

    SELECT nickname
    INTO STRICT onickname
    FROM beowner.subscription
    WHERE (primary_id, vin) = (SELECT usr_id,
                                      vin
                               FROM beowner.ctx_data);
    o_status_code := utl.get_constant_value('csuccess');
    RETURN;
   EXCEPTION
      WHEN SQLSTATE 'EVINN' THEN
      o_status_code := utl.get_constant_value('cdbvinnotfound');
         RETURN;
      WHEN SQLSTATE 'EPTNR' THEN
      o_status_code := utl.get_constant_value('cdbpartneridnotvalid');
         RETURN;
      WHEN SQLSTATE 'EUSRN' THEN        
      o_status_code := utl.get_constant_value('cnosuchuser');
         RETURN;
      WHEN no_data_found THEN
      o_status_code := utl.get_constant_value('cdbsubscribervinnotfound');
         RETURN;
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
    o_status_code := utl.get_constant_value('cinternalerror');
         RETURN;
   END;

$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION be.get_vehicle_nickname (ipartnerid text, iloginid text, ivin text, onickname OUT text) FROM PUBLIC;
\i cleanup.sql;
