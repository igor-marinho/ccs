SET bedb.filename = 'function.is_push_set_for_different_hs.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS be.is_push_set_for_different_hs (beowner.subs_notif.subs_notif_id%TYPE,beowner.usr_push_handsets.uph_guid%TYPE);

CREATE OR REPLACE FUNCTION be.is_push_set_for_different_hs (i_subs_notif_id       beowner.subs_notif.subs_notif_id%TYPE
                                                           ,i_current_push_guid   beowner.usr_push_handsets.uph_guid%TYPE) RETURNS boolean 
AS $body$
DECLARE
      l_count integer;
BEGIN
      SELECT COUNT(1)
        INTO STRICT l_count
        FROM beowner.subs_notif_push_handsets
       WHERE subs_notif_id = i_subs_notif_id
             AND uph_guid != coalesce(i_current_push_guid, beowner.rand_guid());
      RETURN(l_count > 0);
   END;
$body$
LANGUAGE PLPGSQL
STABLE;
-- REVOKE ALL ON FUNCTION be.is_push_set_for_different_hs (i_subs_notif_id subs_notif.subs_notif_id%TYPE, i_current_push_guid usr_push_handsets.uph_guid%TYPE) FROM PUBLIC;

\i cleanup.sql; 
