SET bedb.filename = 'function.set_notification_configured.sql';

\i set_be_env.sql;

   /* SET_NOTIFICATION_CONFIGURED

       NOTE: Defect 10875

          0    : success
         1     : Unknown Error
         7     : User Not Found
         200   : VIN not found (not your VIN) (cnst.cDbVinNotFound)
         201   : Subscription not found
   */
DROP FUNCTION IF EXISTS be.set_notification_configured(text, text, text);
CREATE OR REPLACE FUNCTION be.set_notification_configured(IN ipartnerid text,
                                                          IN iloginid text,
                                                          IN ivin text)
    RETURNS
        integer
AS
$BODY$
DECLARE
      l_action      text;
      l_module_name text := 'set_notification_configured';

      updated_rowcount int;
      vnotifeverset beowner.subscription.notif_ever_set%TYPE := '1';
  l_exception_diagnostics trc.exception_diagnostics;
BEGIN
      l_action := utl.set_module_action( l_module_name,
                                         ' Setting Context');

      CALL ctx.set(iptnrid => ipartnerid::uuid, iloginid => iloginid, ivin => ivin);

      l_action := utl.set_module_action( l_module_name,
                                       ' Validating Subscription');

      UPDATE beowner.subscription s
         SET notif_ever_set = vnotifeverset
       WHERE (s.primary_id, s.vin) =
             (SELECT usr_id,
                     vin
                FROM beowner.ctx_data);

      GET DIAGNOSTICS updated_rowcount =  ROW_COUNT;
      IF updated_rowcount = 0
      THEN
         RAISE no_data_found;
      END IF;

      l_action := utl.set_module_action( l_module_name,
                                         ' Opening Result Set');

      RETURN utl.get_constant_value('csuccess');
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
         RETURN utl.get_constant_value('cdbpartneridnotvalid');
      WHEN SQLSTATE 'EUSRN' THEN
         RETURN utl.get_constant_value('cnosuchuser');
      WHEN SQLSTATE 'EVINN' THEN
         RETURN utl.get_constant_value('cdbvinnotfound');
      WHEN no_data_found THEN
         RETURN utl.get_constant_value('cdbsubscribervinnotfound');
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');
   END;

$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION be.set_notification_configured (ipartnerid text, iloginid text, ivin text) FROM PUBLIC;

\i cleanup.sql;  
