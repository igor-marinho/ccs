SET bedb.filename = 'function.update_push_token.sql';

\i set_be_env.sql;

   /*  UPDATE_PUSH_TOKEN
   
         Added for TCP-680/TCP-924 to update existing token with a new one
   
         Expected Return Values:
           0     : Success 
           1     : Unknown Error
           4     : Invalid Parameter (Length/data-type)                    
           508   : Invalid Push Token (old)   (cnst.c_invalid_push_token)        
           511   : Old Push token is required (cnst.c_old_push_token_required)
           512   : New Push token is required (cnst.c_new_push_token_required)
             
   */
DROP FUNCTION IF EXISTS be.update_push_token(text, text);
CREATE OR REPLACE FUNCTION be.update_push_token(IN i_old_hs_token text,
                                                IN i_new_hs_token text) RETURNS integer AS
$BODY$
DECLARE
      l_action      text;
      l_module_name text := 'update_push_token';

      l_old_push_token        beowner.usr_push_handsets.push_token%type;
      l_new_push_token        beowner.usr_push_handsets.push_token%type;
      l_exception_diagnostics trc.exception_diagnostics;
BEGIN
      l_action := utl.set_module_action(l_module_name,'Validating inputs');

      l_old_push_token := trim(both i_old_hs_token);

      IF l_old_push_token IS NULL
      THEN
         RETURN utl.get_constant_value('c_old_push_token_required');
      END IF;

      l_new_push_token := trim(both i_new_hs_token);

      IF l_new_push_token IS NULL
      THEN
         RETURN utl.get_constant_value('c_new_push_token_required');
      END IF;

      l_action := utl.set_module_action(l_module_name,'Updating token');

      UPDATE beowner.usr_push_handsets
         SET push_token  = l_new_push_token,
             status      = utl.get_constant_value('c_valid'),
             status_date = CURRENT_TIMESTAMP
       WHERE push_token = l_old_push_token;

      IF NOT FOUND
      THEN
          RETURN utl.get_constant_value('c_invalid_push_token');
      END IF;

      RETURN utl.get_constant_value('csuccess');
   EXCEPTION
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
         RETURN utl.get_constant_value('cinvalidparams');
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');
   END;
$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION be.update_push_token (i_old_hs_token text, i_new_hs_token text) FROM PUBLIC;

\i cleanup.sql;
