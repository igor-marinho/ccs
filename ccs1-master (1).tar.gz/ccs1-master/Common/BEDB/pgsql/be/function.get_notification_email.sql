SET bedb.filename = 'function.get_notification_email.sql';

\i set_be_env.sql;

   /* GET_NOTIFICATION_EMAIL
   
       NOTE: Work item 5822
   
       Expected Return Values:
         0     : success (this can include an empty result set; a cursor with no rows)
         1     : Unknown Error
         7     : User Not Found
         213   : Invalid Partner ID        (cnst.cDbPartneridNotValid)
         4     : Invalid Parameter (likely, iValue is not 0 or 1)
   */
DROP FUNCTION IF EXISTS be.get_notification_email(text, text);
 CREATE OR REPLACE FUNCTION be.get_notification_email(IN ipartnerid text,
                                                      in iloginid text,
                                                      out o_status_code integer,
                                                      out o_result texT) AS
   $BODY$
   DECLARE
      l_action      text;
      l_module_name text := 'get_notification_email';
  l_exception_diagnostics trc.exception_diagnostics;      
BEGIN
      l_action := utl.set_module_action( l_module_name,
                                         ' Setting Context');

      CALL ctx.set(iptnrid => ipartnerid::uuid, iloginid => iloginid);

      BEGIN
         -- OnTime Defect #18703. Replaced variable rslt with oresult
         SELECT email
           INTO STRICT o_result
           FROM beowner.ctx_data cd
           JOIN beowner.usr_email ue
             ON ue.usr_id = cd.usr_id
                AND ue.email_type_id = 'N1';

         o_status_code :=  utl.get_constant_value('csuccess');
         RETURN;
      EXCEPTION
         WHEN no_data_found THEN
             o_status_code :=  utl.get_constant_value('cdbnodatafound');
             RETURN;
      END;
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
         o_status_code :=  utl.get_constant_value('cdbpartneridnotvalid');
         RETURN;
      WHEN SQLSTATE 'EUSRN' THEN
        o_status_code :=  utl.get_constant_value('cnosuchuser');
        RETURN;
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         o_status_code :=  utl.get_constant_value('cinternalerror');
         RETURN;
   END;

$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION be.get_notification_email (ipartnerid text, iloginid text, oresult OUT text) FROM PUBLIC;

\i cleanup.sql; 
