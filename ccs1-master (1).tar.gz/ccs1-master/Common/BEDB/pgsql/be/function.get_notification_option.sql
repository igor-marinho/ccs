SET bedb.filename = 'function.get_notification_option.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS be.get_notification_option (text, text, text, text);
/*  GET_NOTIFICATION_OPTION

   NOTE: Work item 5822

   Modified for TCP-144 to add input of ihs_id and return of push notification setting

   Outputs a result set consisting of:
   Notification_id, description, svc_id, use_location, dow, email_enabled, label, notification_title, push_enabled (0/1), email_allowed (Y/N), push_allowed (Y/N)

   enabled and push_enabled are returnd as either a 0 or 1
   0 = disabled, 1 = enabled

   Description is what would show up as information for the notification. Label is the notificaton label.
   Notification_title is meant to be displayed at the top of the notificatons page/popup
   
   If ihs_id (handset ID) is provided :
		If a push token is available for it, it will return 0 or 1 based on whether the user chose to receive push for that notification on that handset
		If a push token is not available, 501 will be returned.
   If not, it will return 1 or 0 based on whether the user chose to receive push for that notification on ANY of their handsets.

   Expected Return Values:
	 0     : Success (this can include an empty result set; a cursor with no rows)   (utl.get_constant_value('csuccess'))
	 1     : Unknown Error                        (cnst.cinternalerror)
	 7     : User Not Found                       (cnst.cnosuchuser)
	 200   : VIN/Subscription was not found.      (cnst.cdbvinnotfound) 
	 213   : Invalid Partner ID                   (cnst.cDbPartneridNotValid)
	 263   : The User's Subscription has Expired  (cnst.csubscriptionexpired)      
*/
CREATE OR REPLACE FUNCTION be.get_notification_option (ipartnerid          text
                                                      ,iloginid            text
                                                      ,ivin                text
                                                      ,ihs_id              text
                                                      ,o_status_code   OUT INTEGER
                                                      ,oresult         OUT refcursor)
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'get_notification_option';
    c_yes         text := utl.get_constant_value('c_yes');
    -- #TCP-144
    l_push_token_guid beowner.usr_push_handsets.uph_guid%TYPE;
    l_usr_id          beowner.usr.usr_id%TYPE;
    l_vin             beowner.vin.vin%TYPE;
    l_notif_title     beowner.device_types.notifications_title%TYPE;
    l_hs_id           beowner.usr_push_handsets.hs_id%TYPE; -- TCP-301
    l_exception_diagnostics trc.exception_diagnostics;      
BEGIN
      oresult := utl.get_dummy_cursor();

      l_action := utl.set_module_action( l_module_name, ' Setting Context');

      CALL ctx.set(iptnrid => ipartnerid::UUID, iloginid => iloginid, ivin => ivin);

      l_action := utl.set_action(' Validating Subscription');

      DECLARE
         vtimestamp TIMESTAMP WITH TIME ZONE;
         vsubend    TIMESTAMP WITH TIME ZONE;
      BEGIN
         SELECT DISTINCT x.tmstmp,
                         x.sub_end,
                         cd.usr_id,
                         cd.vin
           INTO STRICT vtimestamp,
                vsubend,
                l_usr_id,
                l_vin
           FROM beowner.ctx_data cd
           JOIN user_subscription.info(iusrid => cd.usr_id, ivin => cd.vin) as x
             ON NULL IS NULL;

         -- TCP-144
         IF l_usr_id IS NULL
         THEN
            RETURN;
         END IF;

         IF vsubend < vtimestamp
         THEN
            RETURN;
         END IF;
      EXCEPTION
         WHEN no_data_found THEN
            RETURN;
      END;

      l_action := utl.set_module_action( l_module_name, ' Opening Result Set');

      l_hs_id := trim(both ihs_id); -- TCP-301
      IF COALESCE(l_hs_id, '') != ''
      THEN
         CALL be.get_push_token_guid(i_usr_id => l_usr_id, i_hs_id => l_hs_id, o_push_token_guid => l_push_token_guid);
      END IF;

      SELECT notifications_title
        INTO l_notif_title
      FROM beowner.device_types dt
      WHERE TYPE = utl.get_device_type (i_vin => l_vin);
      

      -- Modified for TCP-144 to return push_enabled, label and notification_title and renamed enabled to email_enabled
      -- Modified for OnTime #24501 to also return any notifications that don't allow emails even if ihs_id is sent as null
      --    this will enable the CSR portal to show all notitifications. User portal should use email_allowed flag = Y to only
      --    display notifications that allow only emails
      CLOSE oresult;
      OPEN oresult FOR
         SELECT ns.notification_id,
                ns.info description,
                ns.svc_id,
                ns.use_location,
                sn.dow,
                CASE
                   WHEN coalesce(dow, 0) > 0 THEN -- TCP-144
                    1
                   ELSE
                    0
                END email_enabled,
                ns.label AS label,
                l_notif_title notification_title,
                CASE
                   WHEN l_hs_id IS NULL THEN
                    CASE
                       WHEN sn.send_push = c_yes THEN
                        1
                       ELSE
                        0
                    END
                   ELSE -- ihs_id is not null, only return 1 if push notification has been set for the provided hs_id
                    CASE
                       WHEN snp.snp_guid IS NOT NULL THEN
                        1
                       ELSE
                        0
                    END
                END push_enabled,
                -- TCP-397
                ns.email_allowed,
                ns.push_allowed
           FROM beowner.subscription s
           JOIN beowner.bndlsvc bs
             ON bs.bndl_id = s.bndl_id
                AND bs.optin_level <= s.optin_level
           JOIN beowner.notif_svc ns
             ON ns.svc_id = bs.svc_id
                AND (ns.email_allowed = c_yes OR
                ns.push_allowed = c_yes) -- -- TCP-397 only return notifications that allow at least one of email or push
           LEFT OUTER JOIN beowner.subs_notif sn
             ON sn.notification_id = ns.notification_id
                AND sn.subscription_id = s.subscription_id
           LEFT OUTER JOIN beowner.subs_notif_push_handsets snp
             ON l_hs_id IS NOT NULL
                AND snp.subs_notif_id = sn.subs_notif_id
                AND snp.uph_guid = l_push_token_guid
          WHERE (s.primary_id, s.vin) =
                (SELECT usr_id,
                        vin
                   FROM beowner.ctx_data)
          ORDER BY ns.notif_type,
                   ns.notif_subtype;

      o_status_code := utl.get_constant_value('csuccess');
      RETURN;
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
         oresult := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cdbpartneridnotvalid');
         RETURN;
      WHEN SQLSTATE 'EUSRN' THEN
         oresult := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cnosuchuser');
         RETURN;
      WHEN SQLSTATE 'EVINN' THEN
         oresult := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cdbvinnotfound');
         RETURN;
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata        => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
         oresult := utl.get_dummy_cursor();
         o_status_code :=  utl.get_constant_value('cinternalerror');
         RETURN;
   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION be.get_notification_option (ipartnerid text, iloginid text, ivin text, ihs_id text, oresult OUT REFCURSOR) FROM PUBLIC;
  
\i cleanup.sql; 
