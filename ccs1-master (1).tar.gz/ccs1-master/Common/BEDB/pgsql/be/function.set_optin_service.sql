SET bedb.filename = 'function.set_optin_service.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS be.set_optin_service(text, text, text, integer);
   /*  SET_OPTIN_SERVICE
   
       output: oTimeStamp will be one of two things: (provided no error occurs)
                 1) if iLevel == 0, then oTimeStamp will return NULL
                 2) if iLevel > 0, then oTimeStamp will contain a string formatted per
                    ISO 8601 date/time format: "2011-10-19T08:31Z". Note the time
                    is in Zulu (UTC) time.
   
       Expected Return Values:
         0     : success
         1     : Unknown Error
         7     : User Not Found
         262   : Bad OptIn Level Value                                  (cnst.cBadOptInLevel)
         200   : VIN not found (not your VIN)                           (cnst.cDbVinNotFound)
         201   : Subscriber/VIN not found                               (cnst.cdbsubscribervinnotfound)
         213   : Partner Id is not valid                                (cnst.cDbPartneridNotValid)
         263   : Subscription Expired                                   (cnst.cSubscriptionExpired)
         264   : Contract Not Found                                     (cnst.cContractNotFound)
         265   : You're not a Primary                                   (cnst.cSecondaryPrivilege)
         227   : The Subscription and VIN contracts are different       (cnst.c_Contract_Mismatched)            - added for OnTime Defect 12196
   */
CREATE OR REPLACE FUNCTION be.set_optin_service(IN ipartnerid text,
                                                IN iloginid text,
                                                IN ivin text,
                                                IN ilevel integer) RETURNS integer
AS
$BODY$
DECLARE
      ctrue         text := '*';
      l_action      text;
      l_module_name text := 'set_optin_service';

      vvalidcontract text;
      -- onTime defect#13058
      v_subscription_id  beowner.subscription.subscription_id%TYPE;
      vdelete_subs_notif integer; --DI# 1457
      -- JIRA #CR10212-66
      l_usr_id         beowner.usr.usr_id%TYPE;
      l_vin            beowner.vin.vin%TYPE;
      l_transaction_id beowner.ctx_data.transactionid%TYPE;
      l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      IF ilevel NOT BETWEEN -1 AND 3 -- #14435
      THEN
         RETURN utl.get_constant_value('cbadoptinlevel');
      END IF;

      l_action := utl.set_module_action( l_module_name,  
                                         ' Setting Context');

      CALL ctx.set(iptnrid => ipartnerid::uuid, iloginid => iloginid, ivin => ivin);

      l_action := utl.set_module_action( l_module_name,  
                                        
                                       ' Validating Operation');

      DECLARE
         vtimestamp TIMESTAMP WITH TIME ZONE;
         vsubend    TIMESTAMP WITH TIME ZONE;
         visprimary text;
      BEGIN
         SELECT DISTINCT tmstmp,
                         sub_end,
                         is_primary,
                         valid_contract
         INTO STRICT vtimestamp,
                vsubend,
                visprimary,
                vvalidcontract
         FROM user_subscription.info_ctx()
         WHERE vin = ivin;

         IF vsubend < vtimestamp
         THEN
            RETURN utl.get_constant_value('csubscriptionexpired');
         END IF;

         IF visprimary != ctrue
         THEN
            RETURN utl.get_constant_value('csecondaryprivilege');
         END IF;

         -- Below If condition added for OnTime Defect #12196 (DB - the user can set opt-in level and notification options even without correct contractId)
         -- added ilevel condition for OnTime Defect #14435 (DB: BE.SET_OPTIN_SERVICE() should not check for contractID match when setting 0 or -1)
         IF ilevel > 0 AND
            vvalidcontract != ctrue
         THEN
            RETURN utl.get_constant_value('c_contract_mismatched');
         END IF;
      EXCEPTION
         WHEN no_data_found THEN
            RETURN utl.get_constant_value('cdbsubscribervinnotfound');
      END;

      l_action := utl.set_module_action( l_module_name,  
                                         ' Updating data');

      -- todo - handle TSC callout (queue?)
      -- Modified for OnTime Defect 11644 - TMSEV#132: Rank 3: SM18 accounts are getting automatically updated
      -- Added vin in the where clause
      /* Modified for Defect #12196, modified case below since vvalidcontract will always be ctrue at this point now.
      Old code :
        contract_tmstmp =
                 CASE
                    WHEN ilevel = 0 AND vvalidcontract = ctrue
                    THEN
                       NULL
                    WHEN ilevel > 0 AND vvalidcontract = cfalse
                    THEN
                       SYSTIMESTAMP
                    ELSE
                       contract_tmstmp
                 END
       */
      -- JIRA #CR10212-66
      SELECT usr_id,
             vin,
             transactionid
        INTO STRICT l_usr_id,
             l_vin,
             l_transaction_id
        FROM beowner.ctx_data;

      -- setting contract_tmstmp to null even for ilevel <0 for #14435
      UPDATE beowner.subscription
         SET optin_level     = ilevel,
             contract_tmstmp = CASE
                                  WHEN ilevel <= 0 THEN
                                   NULL
                                  ELSE
                                   contract_tmstmp
                               END,
             -- JIRA #CR10212-66
             transaction_id = l_transaction_id
       WHERE primary_id = l_usr_id
             AND vin = l_vin
      -- onTime defect#13058
      RETURNING subscription_id INTO v_subscription_id;

      -- deleting from subs_notif even for ilevel <0 for #14435
      IF ilevel <= 0
      THEN
         -- if he changes his Opt-In level to none (0) then the user's settings for the EV Unplugged Notification feature shall be cleared.
         vdelete_subs_notif := crudg_subscription.delete_subs_notif(v_subscription_id); --DI# 1457
         IF vdelete_subs_notif != utl.get_constant_value('csuccess')::INTEGER
         THEN
            RETURN vdelete_subs_notif;
         END IF;
      END IF;

      RETURN utl.get_constant_value('csuccess');
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
         RETURN utl.get_constant_value('cdbpartneridnotvalid');
      WHEN SQLSTATE 'EUSRN' THEN
         RETURN utl.get_constant_value('cnosuchuser');
      WHEN SQLSTATE 'EVINN' THEN
         RETURN utl.get_constant_value('cdbvinnotfound');
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');
   END;

$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION be.set_optin_service (ipartnerid text, iloginid text, ivin text, ilevel numeric) FROM PUBLIC;

\i cleanup.sql;
