SET bedb.filename = 'function.get_ev_vin_info.sql';

\i set_be_env.sql;

/*  GET_EV_VIN_INFO
    Added for Jira stories CR10212-160 and TCP-301

    Gets information for a given EV VIN and it's owner
    Assumes there is no conflict on the VIN.
    If there is a conflict, will return an empty result set.

    Ref cursor columns:
    vin, make_id, model, year, color, device_id, nickname, usr_id, login_id, dofu

       Expected Return Values:
        0     : Success (this can also include an empty result set; a cursor with no rows)
        1     : Unknown Error
        4     : Invalid Parameter (Length/data-type)
      200     : VIN not found
      234     : VIN is null

*/

DROP FUNCTION IF EXISTS be.get_ev_vin_info(TEXT);
CREATE OR REPLACE FUNCTION be.get_ev_vin_info(IN i_vin TEXT,
                                              OUT o_status_code INTEGER,
                                              OUT o_result REFCURSOR)
AS
$BODY$
DECLARE

    l_action                TEXT;
    l_module_name           TEXT := 'get_ev_vin_info';
    l_vin                   beowner.vin.vin%TYPE;
    l_exception_diagnostics trc.EXCEPTION_DIAGNOSTICS;
BEGIN

    o_result := utl.get_dummy_cursor();

    l_vin := upper(trim(BOTH i_vin));

    IF l_vin IS NULL
    THEN
        o_status_code := utl.get_constant_value('c_invalid_vin');
        RETURN;
    ELSIF NOT (SELECT t.o_status_code FROM utl.is_vin_valid(l_vin) t)
    THEN
        o_status_code := utl.get_constant_value('cdbvinnotfound');
        RETURN;
    END IF;

    l_action := utl.set_module_action(l_module_name, 'Fetching VIN data');

    -- Modified for DCS1E-1031 to improve CPU usage
    CLOSE o_result;
    OPEN o_result FOR
        SELECT v.vin,
               v.make_id,
               v.model,
               v.year,
               v.color,
               v.device_id,
               s.nickname,
               s.primary_id                    usr_id,
               (SELECT u.login_id
                FROM beowner.usr u
                WHERE u.usr_id = s.primary_id) login_id,
               v.dofu
        FROM beowner.vin v,
             beowner.subscription s
        WHERE v.vin = l_vin
          AND s.vin = v.vin
          AND v.contract_id = s.contract_id -- only the rightful owner of the VIN
        LIMIT 1; -- just in case the data is messed up because of replication issues
    o_status_code := utl.get_constant_value('csuccess');
    RETURN;

EXCEPTION
    WHEN OTHERS THEN
        GET STACKED diagnostics
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);

        o_result := utl.get_dummy_cursor();
        o_status_code := utl.get_constant_value('cinternalerror');
        RETURN;
END;

$BODY$
    LANGUAGE PLPGSQL
    STABLE
    SECURITY DEFINER ;
-- REVOKE ALL ON FUNCTION be.get_ev_vin_info (i_vin text, o_result OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
