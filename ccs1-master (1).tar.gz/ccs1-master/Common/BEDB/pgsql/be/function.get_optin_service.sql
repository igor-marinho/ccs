SET bedb.filename = 'function.get_optin_service.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS be.get_optin_service(text, text, text);
CREATE OR REPLACE FUNCTION be.get_optin_service(IN ipartnerid text,
                                                IN iloginid text,
                                                IN ivin text,
                                                OUT o_status_code integer,
                                                OUT o_result refcursor) AS
$BODY$

   /*  GET_OPTIN_SERVICE
      
          Result parameter returns a cursor of one row with the following fields:
      
            PARTNER_ID      : (passed-in value)
            LOGIN_ID        : (passed-in value)
            VIN             : (passed-in value)
            OPTIN_LEVEL     : the current optin level
            >> the following values can be NULL
            CONTRACT_OWNER  : the owner/dispenser of the contract (like ATX)
            CONTRACT_ID     : the current contract id for the user/vin
            CONTRACT_TMSTMP : string formatted per ISO 8601 date/time format:
                              "2011-10-19T08:31Z". Note the time is in Zulu (UTC) time.
            DISPLAY_CONTRACT_ID : Obfuscated Contract ID (last 3 chars preceded by *s)
      
          Expected Return Values:
            0     : success
            1     : Unknown Error
            7     : User Not Found
            200   : VIN not found (not your VIN) (cnst.cDbVinNotFound)
            213   : Partner Id is not valid      (cnst.cDbPartneridNotValid)
            263   : Subscription Expired         (cnst.cSubscriptionExpired)
            264   : Contract Not Found           (cnst.cContractNotFound)
            265   : You're not a Primary         (cnst.cSecondaryPrivilege)
            222   : Invalid (or null) MakeID for the OneApp partner ID and VIN provided (cinvalidmake)
   */

DECLARE
      ctrue         text := '*';
      l_action      text;
      l_module_name text := 'get_optin_service';
      vsuboptinlevel  integer;
      vcontractowner  text;
      vextcontractid  text;
      vcontracttmstmp TIMESTAMP WITH TIME ZONE;
      l_makeid        text;
      l_partnerid      text := ipartnerid;
      l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    o_result := utl.get_dummy_cursor();

    l_action := utl.set_module_action(l_module_name,
                                      ' Setting Context');
    
    /*For OneApp partner id, swap to Toyota or Lexus partner id based on VIN*/
                                     
    IF l_partnerid::uuid = utl.getconfig('Oneapp PTNR ID')::uuid THEN
    
    SELECT make_id INTO l_makeid FROM beowner.vin WHERE vin = trim(both(ivin));
   
       IF l_makeid = 'LX' THEN l_partnerid := utl.getconfig('Lexus PTNR ID');
       
       ELSIF l_makeid = 'TM' THEN l_partnerid := utl.getconfig('Toyota PTNR ID');   
      
       ELSE o_status_code := utl.get_constant_value('cinvalidmake');
       RETURN;
      
       END IF;
    
    END IF;

    CALL ctx.set(iptnrid => l_partnerid::uuid, iloginid => iloginid, ivin => ivin);

    l_action := utl.set_module_action(l_module_name,
                                       ' Validating Operation');

      DECLARE
         vtimestamp     TIMESTAMP WITH TIME ZONE;
         vsubend        TIMESTAMP WITH TIME ZONE;
         visprimary     text;
         vvalidcontract text;
      BEGIN
         SELECT DISTINCT tmstmp,
                         sub_end,
                         is_primary,
                         valid_contract,
                         sub_optin_level,
                         cntrct_owner,
                         cntrct_external_id,
                         cntrct_tmstmp
           INTO STRICT vtimestamp,
                vsubend,
                visprimary,
                vvalidcontract,
                vsuboptinlevel,
                vcontractowner,
                vextcontractid,
                vcontracttmstmp
           FROM user_subscription.info_ctx()
          WHERE vin = ivin;

         IF vsubend < vtimestamp
         THEN
             o_status_code := utl.get_constant_value('csubscriptionexpired');
             RETURN;
         END IF;

         IF visprimary != ctrue
         THEN
            o_status_code := utl.get_constant_value('csecondaryprivilege');
            RETURN;
         END IF;

         IF vsuboptinlevel < 1
         THEN
            vextcontractid := NULL;
         END IF;

         IF vsuboptinlevel != 0
         THEN
            IF vvalidcontract != ctrue
            THEN
               o_status_code := utl.get_constant_value('ccontractnotfound');
               RETURN;
            END IF;
         END IF;
      EXCEPTION
         WHEN no_data_found THEN
            o_status_code := utl.get_constant_value('ccontractnotfound');
            RETURN;
      END;

      CLOSE o_result;
      OPEN o_result FOR
         SELECT l_partnerid partner_id,
                iloginid  login_id,
                ivin  vin,
                vsuboptinlevel  optin_level,
                vcontractowner contract_owner,
                vextcontractid contract_id,
                vcontracttmstmp contract_tmstamp,
                be.obfuscate_contract_id(vextcontractid) display_contract_id;

      o_status_code := utl.get_constant_value('csuccess');
      RETURN;
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
         o_status_code := utl.get_constant_value('cdbpartneridnotvalid');
         RETURN;
      WHEN SQLSTATE 'EUSRN' THEN
         o_status_code := utl.get_constant_value('cnosuchuser');
         RETURN;
      WHEN SQLSTATE 'EVINN' THEN
         o_status_code := utl.get_constant_value('cdbvinnotfound');
         RETURN;
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         o_status_code := utl.get_constant_value('cinternalerror');
         o_result := utl.get_dummy_cursor();
         RETURN;
   END;

$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER ;
-- REVOKE ALL ON FUNCTION be.get_optin_service (ipartnerid text, iloginid text, ivin text, oresult OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql; 
