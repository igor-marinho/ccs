SET bedb.filename = 'function.get_optin_levels.sql';

\i set_be_env.sql;

   /*   GET_OPTIN_LEVELS
   
       Return the option levels and their descriptions for the provided VIN's device type
       Added for Jira TCP-69
   
       o_result cursor columns : device_type, device_id, optin_level, optin_level_name, description
   
       Expected Return Values:
         0     : Success                                (utl.get_constant_value('csuccess'))
         1     : Unhandled Error                        (cnst.cInternalError)
       200     : VIN not found                          (cnst.cdbvinnotfound)
       234     : VIN is null                            (cnst.c_invalid_vin)
       500     : No optin levels found for device type  (cnst.no_optin_levels_found)
   */
DROP FUNCTION IF EXISTS be.get_optin_levels(text);
CREATE OR REPLACE FUNCTION be.get_optin_levels(i_vin TEXT,
                                               OUT o_status_code INTEGER,
                                               OUT o_result REFCURSOR)
AS
$BODY$
DECLARE
      l_action             text;
      l_module_name text := 'get_optin_levels';

      l_device_type        beowner.device_types.type%TYPE;
      l_device_id          beowner.device.device_id%TYPE;
      l_optin_levels_found integer;
      l_vin                beowner.vin.vin%TYPE := upper(i_vin);
      l_exception_diagnostics trc.exception_diagnostics;
BEGIN
      o_result := utl.get_dummy_cursor();

      l_action := utl.set_module_action(l_module_name,'Validating VIN');

      IF l_vin IS NULL
      THEN
         o_status_code:= utl.get_constant_value('c_invalid_vin');
         RETURN;
      END IF;

      BEGIN
         SELECT d.device_type,
                v.device_id
           INTO STRICT l_device_type,
                l_device_id
           FROM beowner.vin    v,
                beowner.device d
          WHERE v.vin = l_vin
                AND d.device_id = v.device_id;
      EXCEPTION
         WHEN no_data_found THEN
            o_status_code:= utl.get_constant_value('cdbvinnotfound');
            RETURN;
      END;

      SELECT COUNT(1)
        INTO STRICT l_optin_levels_found
        FROM beowner.device_type_optin_levels
       WHERE device_type = l_device_type;

      IF l_optin_levels_found = 0
      THEN
         o_status_code := utl.get_constant_value('c_no_optin_levels_found');
         RETURN;
      ELSE
         CLOSE o_result;
         OPEN o_result FOR
            SELECT dol.device_type,
                   l_device_id     device_id,
                   dol.optin_level,
                   dol.name        optin_level_name,
                   dol.description
              FROM beowner.device_type_optin_levels dol
             WHERE device_type = l_device_type
             ORDER BY optin_level;

         o_status_code := utl.get_constant_value('csuccess');
         RETURN;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
         l_exception_diagnostics.module_name := l_module_name;
         l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         o_result := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cinternalerror');
         RETURN;
   END;

$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION be.get_optin_levels (i_vin vin.vin%TYPE, o_result OUT REFCURSOR) FROM PUBLIC;


\i cleanup.sql;
