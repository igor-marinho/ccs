SET bedb.filename = 'function.validate_user_email.sql';

\i set_be_env.sql;

   /*   VALIDATE_USER_EMAIL

       This procedure was created to change the user email status to valid.
       Added for OnTime WI #8415 ([DB - 383] UP: Build revised registration process for Entune)

           Input parameters:
             i_partner_id     - partner id
             i_user_login_id  - subscriber email address/ login ID

       Expected Return Values:
         0     : Success                                (utl.get_constant_value('csuccess'))
         1     : Unhandled Error                        (cnst.cInternalError)
         4     : Invalid Parameters                     (utl.get_constant_value('cinvalidparams'))
         7     : No user with the login ID exists       (cnst.cNoSuchUser)
         213   : Invalid Partner ID                     (cnst.cDbPartneridNotValid)
         228   : Email ID was already validated         (cnst.c_email_already_validated)
         229   : Email ID for this type not found       (cnst.c_Email_ID_Not_Found)
   */
   CREATE OR REPLACE FUNCTION be.validate_user_email(IN i_partner_id text,
                                                     IN i_user_login_id text,
                                                     IN i_email_type_id text
                                                         DEFAULT 'H1') RETURNS integer AS
   $BODY$
   DECLARE
      l_action      text;
      l_module_name text := 'validate_user_email';

      l_return      integer;
      l_usr_id      beowner.ctx_data.usr_id%TYPE;
      l_status_date beowner.usr_email.status_date%TYPE;
      l_status      beowner.usr_email.status%TYPE;
      l_exception_diagnostics trc.exception_diagnostics;
BEGIN
      BEGIN
         l_action := utl.set_module_action( l_module_name,
                                            ' Setting Context');

         CALL ctx.set(iptnrid => i_partner_id::uuid, iloginid => i_user_login_id);

         SELECT usr_id
           INTO STRICT l_usr_id
           FROM beowner.ctx_data cd;

         l_action := utl.set_module_action( l_module_name,

                                          ' Getting Email State');

         SELECT status_date,
                status
           INTO STRICT l_status_date,
                l_status
           FROM beowner.usr_email ue
          WHERE ue.usr_id = l_usr_id
                AND ue.email_type_id = i_email_type_id;

         IF (l_status_date IS NULL OR coalesce(l_status, 'N') != 'V')
         -- only set the email as validated if it isn't already set so
         THEN
            l_action := utl.set_module_action( l_module_name,
                                             ' Validating Email');

            UPDATE beowner.usr_email ue
               SET status_date = CURRENT_TIMESTAMP,
                   status      = 'V'
             WHERE ue.usr_id = l_usr_id
                   AND ue.email_type_id = i_email_type_id;

            l_return := utl.get_constant_value('csuccess');
         ELSE
            l_return := utl.get_constant_value('c_email_already_validated');
         END IF;

      EXCEPTION
         WHEN no_data_found THEN
            l_return := utl.get_constant_value('c_email_id_not_found');
         WHEN  string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
            l_return := utl.get_constant_value('cinvalidparams');
         WHEN SQLSTATE 'EPTNR' THEN
            l_return := utl.get_constant_value('cdbpartneridnotvalid');
         WHEN SQLSTATE 'EUSRN' THEN
            l_return := utl.get_constant_value('cnosuchuser');
         WHEN OTHERS THEN
            GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

          l_exception_diagnostics.module_name = l_module_name;
          l_exception_diagnostics.action = l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
            l_return := utl.get_constant_value('cinternalerror');

      END ;
      RETURN l_return;
   END;

$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION be.validate_user_email (i_partner_id text, i_user_login_id text, i_email_type_id text DEFAULT 'H1') FROM PUBLIC;

\i cleanup.sql;
