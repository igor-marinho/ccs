SET bedb.filename = 'function.set_notification_option.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS be.set_notification_option (TEXT,TEXT,TEXT,TEXT,INTEGER, INTEGER, TEXT);
   /*  SET_NOTIFICATION_OPTION
   
       NOTE: Work item 5822
       Modified for TCP-144 to add input of ipush_value and ihs_id
       Changed value to iemail_value
   
       Expected Return Values:
         0     : Success (this can include an empty result set; a cursor with no rows)
         1     : Unknown Error
         4     : Invalid Parameter     
         7     : User Not Found
         200   : VIN not found - no subscription
         213   : Invalid Partner ID        (cnst.cDbPartneridNotValid)
         227   : The Subscription and VIN contracts are different (cnst.c_Contract_Mismatched)      
         261   : Unknown Notification Type (cnst.cDbNotificationTypeUnknown)
         262   : Invalid Opt-In value      (cnst.cBadOptInLevel)
         266   : Bad Notification setting for Opt-In settings.     
         501   : Push token unavailable    (cnst.c_missing_push_token) ONLY if ipush_value = 1 and ihs_id is not null
         502   : Push value is required    (cnst.c_push_value_required)
         504   : Handset ID is required    (cnst.c_hs_id_required)  
         509   : Emails are not allowed for this notification (cnst.c_email_not_allowed)
         510   : Push is not allowed for this notification    (cnst.c_push_not_allowed)
   
   */
   -- Modified significantly for TCP-144 to accept ipush_value and ihs_id and set the related data accordingly
CREATE OR REPLACE FUNCTION be.set_notification_option (ipartnerid        text
                                                      ,iloginid          text
                                                      ,ivin              text
                                                      ,inotificationid   text
                                                      ,iemail_value      INTEGER                -- email setting (0/1)
                                                      ,ipush_value       INTEGER DEFAULT NULL   -- push setting (0/1)
                                                      ,ihs_id            text DEFAULT NULL) RETURNS INTEGER 
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'set_notification_option';
      vsubid             beowner.subscription.subscription_id%TYPE;
      vvalidcontract     text; -- #12196
      vdelete_subs_notif integer; --DI# 1457
      -- TCP-144
      l_usr_id          beowner.usr.usr_id%TYPE;
      l_push_token_guid beowner.usr_push_handsets.uph_guid%TYPE;
      l_push_value      integer := ipush_value;
      l_email_value integer := CASE
                                  WHEN coalesce(iemail_value, 0) != 0 THEN
                                   utl.get_constant_value('c_all_dow')::INTEGER
                                  ELSE 0
                               END;
      -- for backward compatibility, as portal apparently always sends 127 if the value is not 0, but this will allow the MT to send a 1
      l_send_push     beowner.subs_notif.send_push%TYPE;
      l_subs_notif_id beowner.subs_notif.subs_notif_id%TYPE;
      l_sn_row        beowner.subs_notif;
      l_hs_id         beowner.usr_push_handsets.hs_id%TYPE; -- TCP-301
      -- TCP-397
      l_notification_id beowner.notif_svc.notification_id%TYPE;
      l_email_allowed   beowner.notif_svc.email_allowed%TYPE;
      l_push_allowed    beowner.notif_svc.push_allowed%TYPE;
      c_yes text := utl.get_constant_value('c_yes');
      c_no text  := utl.get_constant_value('c_no');
      ctrue CONSTANT VARCHAR(1) := '*';
      l_exception_diagnostics trc.exception_diagnostics;
BEGIN
      l_action:= utl.set_module_action( l_module_name, ' Validate Notification');

      -- Modified for TCP-397
      BEGIN
         SELECT notification_id,
                email_allowed,
                push_allowed
           INTO STRICT l_notification_id,
                l_email_allowed,
                l_push_allowed
           FROM beowner.notif_svc
          WHERE notification_id = inotificationid;
      EXCEPTION
         WHEN no_data_found THEN
            RETURN utl.get_constant_value('cdbnotificationtypeunknown');
      END;

      CALL ctx.set(iptnrid => ipartnerid::UUID, iloginid => iloginid, ivin => ivin);

      l_action := utl.set_action(' Validating Subscription');

      DECLARE
         vtimestamp     TIMESTAMP WITH TIME ZONE;
         vsubend        TIMESTAMP WITH TIME ZONE;
         vsuboptinlevel INTEGER;
      BEGIN
         -- Added usr_id for TCP-144
         SELECT DISTINCT x.tmstmp,
                         x.sub_end,
                         x.sub_optin_level,
                         x.valid_contract,
                         cd.usr_id
           INTO STRICT vtimestamp,
                vsubend,
                vsuboptinlevel,
                vvalidcontract,
                l_usr_id
           FROM beowner.ctx_data cd
           JOIN user_subscription.info(iusrid => cd.usr_id, ivin => cd.vin) AS x
             ON NULL IS NULL;

         -- TCP-144
         IF l_usr_id IS NULL
         THEN
            RETURN utl.get_constant_value('cnosuchuser');
         END IF;
         --
         IF vsubend < vtimestamp
         THEN
            RETURN utl.get_constant_value('csubscriptionexpired');
         END IF;

         IF vvalidcontract != ctrue
         THEN
            RETURN utl.get_constant_value('c_contract_mismatched');
         END IF;

         IF vsuboptinlevel <= 0
         THEN
            RETURN utl.get_constant_value('cbadoptinlevel');
         END IF;
      EXCEPTION
         WHEN no_data_found THEN
            RETURN utl.get_constant_value('cdbvinnotfound');
      END;

      l_hs_id := trim(both ihs_id); -- TCP-301
      -- TCP-144
      IF COALESCE(l_hs_id, '') = '' AND
         COALESCE(l_push_value::TEXT, '') != ''
      THEN
         RETURN utl.get_constant_value('c_hs_id_required');
      END IF;

      IF COALESCE(l_hs_id, '') != '' AND
         COALESCE(l_push_value::TEXT, '') = ''
      THEN
         RETURN utl.get_constant_value('c_push_value_required');
      END IF;

      IF coalesce(l_push_value, 0) NOT IN (0, 1)
      THEN
         RETURN utl.get_constant_value('c_push_value_required');
      END IF;

      -- TCP-397
      IF l_email_allowed = 'N' AND
         l_email_value != 0
      THEN
         RETURN utl.get_constant_value('c_email_not_allowed');
      END IF;

      IF l_push_allowed = 'N' AND
         l_push_value != 0
      THEN
         RETURN utl.get_constant_value('c_push_not_allowed');
      END IF;

      l_action := utl.set_module_action( l_module_name, ' Getting Push token');

      IF COALESCE(l_hs_id, '') != ''
      THEN
         CALL be.get_push_token_guid(i_usr_id => l_usr_id, i_hs_id => l_hs_id, o_push_token_guid=> l_push_token_guid);
         IF l_push_token_guid IS NULL AND
            l_push_value = 1
         THEN
            RETURN utl.get_constant_value('c_missing_push_token');
         END IF;
      END IF;
      ---
      SELECT subscription_id
        INTO STRICT vsubid
        FROM beowner.subscription
       WHERE (primary_id, vin) = (SELECT usr_id,
                                         vin
                                    FROM beowner.ctx_data);

      l_action := utl.set_action(' Find existing subs notif row');
      BEGIN
         SELECT *
           INTO STRICT l_sn_row
           FROM beowner.subs_notif sn
          WHERE sn.subscription_id = vsubid
                AND sn.notification_id = inotificationid;
         l_subs_notif_id := l_sn_row.subs_notif_id;
      EXCEPTION
         WHEN no_data_found THEN
            l_subs_notif_id := beowner.rand_guid();
      END;

      -- TCP-144
      IF coalesce(l_push_value, 0) = 0
      THEN
         IF l_sn_row.send_push = c_yes -- currently, the notification has push set as yes
            AND
            be.is_push_set_for_different_hs(i_subs_notif_id     => l_subs_notif_id,
                                            i_current_push_guid => l_push_token_guid)
         THEN
            -- push is set for a different handset still
            l_send_push := c_yes;
         ELSE
            l_send_push := c_no;
         END IF;
         -- delete row for current push token, if found
         IF l_push_token_guid IS NOT NULL
         THEN
            DELETE FROM beowner.subs_notif_push_handsets snp
             WHERE subs_notif_id = l_subs_notif_id
                    AND uph_guid = l_push_token_guid;
         END IF;
      ELSIF l_push_value = 1
      THEN
         -- l_push_value will be null if called from portal
         l_send_push := c_yes;
      END IF;

      IF l_email_value = 0 AND
         l_send_push = c_no
      -- neither emails nor push notifications need to be sent
      THEN
         vdelete_subs_notif := crudg_subscription.delete_subs_notif(vsubid,
                                                                    inotificationid); --DI# 1457
         IF vdelete_subs_notif != utl.get_constant_value('csuccess')::INTEGER
         THEN
            RETURN vdelete_subs_notif;
         END IF;
      END IF;

      IF vdelete_subs_notif IS NULL
      -- indicates that subs_notif row was not deleted, since if it was, there's no point of the merge
      THEN
         -- if l_send_push is null, don't touch existing value
         INSERT INTO beowner.subs_notif AS sn (subs_notif_id,
                subscription_id,
                notification_id,
                dow,
                send_push)
            VALUES (l_subs_notif_id,
                vsubid,
                inotificationid,
                l_email_value,
                coalesce(l_send_push, 'N'))
        ON CONFLICT ON CONSTRAINT  subs_notif_ukc
        DO UPDATE SET  dow          = l_email_value,
                       send_push    = coalesce(l_send_push, sn.send_push);  

         -- TCP-144
         IF l_send_push = c_yes AND
            l_push_value = 1
         THEN
            INSERT INTO beowner.subs_notif_push_handsets (snp_guid, subs_notif_id, uph_guid)
                VALUES (beowner.rand_guid(),l_subs_notif_id, l_push_token_guid)
            ON CONFLICT DO NOTHING;
         END IF;
         --
      END IF;

      RETURN utl.get_constant_value('csuccess');
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
         RETURN utl.get_constant_value('cdbpartneridnotvalid');
      WHEN SQLSTATE 'EUSRN' THEN
         RETURN utl.get_constant_value('cnosuchuser');
      WHEN SQLSTATE 'EVINN' THEN
         RETURN utl.get_constant_value('cdbvinnotfound');
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
        RETURN utl.get_constant_value('cinternalerror');
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION be.set_notification_option (ipartnerid text, iloginid text, ivin text, inotificationid text, iemail_value numeric, ipush_value numeric DEFAULT NULL, ihs_id text DEFAULT NULL) FROM PUBLIC;
  
\i cleanup.sql; 
