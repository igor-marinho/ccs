SET bedb.filename = 'function.obfuscate_contract_id.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS be.obfuscate_contract_id(beowner.contrct.extrnl_ctrct_id%TYPE);
CREATE OR REPLACE FUNCTION be.obfuscate_contract_id (i_contract_id beowner.contrct.extrnl_ctrct_id%TYPE) RETURNS text AS
    $BODY$
DECLARE

      l_len_contract_id integer := length(i_contract_id);

BEGIN
    RETURN CASE
               WHEN l_len_contract_id <= 3 THEN i_contract_id
               ELSE
                   lpad(right(i_contract_id, 3), l_len_contract_id, '*') END;

   END;

$BODY$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION be.obfuscate_contract_id (i_contract_id contrct.extrnl_ctrct_id%TYPE) FROM PUBLIC;


\i cleanup.sql;
