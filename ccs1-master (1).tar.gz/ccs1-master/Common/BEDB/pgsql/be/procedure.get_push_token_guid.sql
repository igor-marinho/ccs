SET bedb.filename = 'procedure.get_push_token_guid.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS be.get_push_token_guid (beowner.usr.usr_id%TYPE, beowner.usr_push_handsets.hs_id%TYPE, beowner.usr_push_handsets.uph_guid%TYPE);

CREATE OR REPLACE PROCEDURE be.get_push_token_guid (i_usr_id                  beowner.usr.usr_id%TYPE
                                                   ,i_hs_id                   beowner.usr_push_handsets.hs_id%TYPE
                                                   ,o_push_token_guid   INOUT beowner.usr_push_handsets.uph_guid%TYPE)
AS $body$
BEGIN
      IF COALESCE(i_usr_id::TEXT, '') = ''
      THEN
         RETURN;
      END IF;

      SELECT uph_guid
        INTO STRICT o_push_token_guid
        FROM beowner.usr_push_handsets
       WHERE usr_id = i_usr_id
             AND hs_id = i_hs_id;
   EXCEPTION
      WHEN OTHERS THEN
         -- no push token defined for the user and handset combination
         RETURN;
   END;
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE be.get_push_token_guid (i_usr_id usr.usr_id%TYPE, i_hs_id usr_push_handsets.hs_id%TYPE, o_push_token_guid OUT usr_push_handsets.uph_guid%TYPE) FROM PUBLIC;

\i cleanup.sql; 
