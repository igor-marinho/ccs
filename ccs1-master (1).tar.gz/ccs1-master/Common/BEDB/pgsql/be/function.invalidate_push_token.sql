SET bedb.filename = 'function.invalidate_push_token.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS be.invalidate_push_token(text, text);
   /*  INVALIDATE_PUSH_TOKEN

         Added for TCP-418 to invalidate the provided push token

         Expected Return Values:
           0     : Success
           1     : Unknown Error
           4     : Invalid Parameter (Length/data-type)
           505   : Push token is required    (cnst.c_push_token_required)
           506   : Handset OS is required    (cnst.c_hs_os_required)
           507   : Invalid Handset OS        (cnst.c_invalid_hs_os)
           508   : Invalid Push Token        (cnst.c_invalid_push_token)
   */
CREATE OR REPLACE FUNCTION be.invalidate_push_token(IN i_hs_token text,
                                                    IN i_hs_os text -- iOS, Android
) RETURNS integer AS
$BODY$
DECLARE
      l_action      text;
      l_module_name text := 'invalidate_push_token';

      l_push_token beowner.usr_push_handsets.push_token%TYPE;
      l_hs_os      beowner.usr_push_handsets.hs_os%TYPE;
      l_exception_diagnostics trc.exception_diagnostics;
BEGIN
      l_action := utl.set_module_action(l_module_name,'Validating inputs');

      l_hs_os := trim(both upper(i_hs_os));

      IF l_hs_os IS NULL
      THEN
         RETURN utl.get_constant_value('c_hs_os_required');
      END IF;

      IF NOT utl.is_domain_value_valid(i_domain => utl.get_constant_value('c_domain_hs_os'),
                                       i_value  => l_hs_os)
      THEN
         RETURN utl.get_constant_value('c_invalid_hs_os');
      END IF;

      l_push_token := trim(both i_hs_token);

      IF l_push_token IS NULL
      THEN
         RETURN utl.get_constant_value('c_push_token_required');
      END IF;

      UPDATE beowner.usr_push_handsets
         SET status      = utl.get_constant_value('c_invalid'),
             status_date = CURRENT_TIMESTAMP
       WHERE push_token = l_push_token
             AND hs_os = l_hs_os;

      IF NOT FOUND
      THEN
         RETURN utl.get_constant_value('c_invalid_push_token');
      END IF;

      RETURN utl.get_constant_value('csuccess');
   EXCEPTION
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
         RETURN utl.get_constant_value('cinvalidparams');
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');
   END;
$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION be.invalidate_push_token (i_hs_token text, i_hs_os text ) FROM PUBLIC;

\i cleanup.sql;
