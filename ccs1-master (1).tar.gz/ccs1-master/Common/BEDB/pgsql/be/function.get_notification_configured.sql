SET bedb.filename = 'function.get_notification_configured.sql';

\i set_be_env.sql;

   /* GET_NOTIFICATION_CONFIGURED

       NOTE: Defect 10875

          0    : success
         1     : Unknown Error
         7     : User Not Found
         200   : VIN not found (not your VIN) (cnst.cDbVinNotFound)
         201   : Subscription not found
   */
DROP FUNCTION IF EXISTS be.get_notification_configured(text, text, text);
CREATE OR REPLACE FUNCTION be.get_notification_configured(IN ipartnerid text,
                                                          IN iloginid text,
                                                          IN ivin text,
                                                          OUT o_status_code INTEGER,
                                                          OUT o_result REFCURSOR) AS
   $BODY$
   DECLARE
      l_action      text;
      l_module_name text := 'get_notification_configured';

      vnotifeverset beowner.subscription.notif_ever_set%TYPE;
      l_exception_diagnostics trc.exception_diagnostics;
BEGIN
      o_result := utl.get_dummy_cursor();

      l_action := utl.set_module_action( l_module_name,
                                         ' Setting Context');

      CALL ctx.set(iptnrid => ipartnerid::uuid, iloginid => iloginid, ivin => ivin);

      l_action := utl.set_module_action( l_module_name,
                                       ' Validating Subscription');

      SELECT s.notif_ever_set
        INTO STRICT vnotifeverset
        FROM beowner.subscription s
       WHERE (s.primary_id, s.vin) =
             (SELECT usr_id,
                     vin
                FROM beowner.ctx_data);

      l_action := utl.set_module_action( l_module_name,
                                         ' Opening Result Set');

      CLOSE o_result;
      OPEN o_result FOR
         SELECT iloginid,
                ivin,
                s.notif_ever_set
           FROM beowner.subscription s
          WHERE (s.primary_id, s.vin) =
                (SELECT usr_id,
                        vin
                   FROM beowner.ctx_data);

      o_status_code = utl.get_constant_value('csuccess');
      RETURN;
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
         o_status_code := utl.get_constant_value('cdbpartneridnotvalid');
         RETURN;
      WHEN SQLSTATE 'EUSRN' THEN
         o_status_code := utl.get_constant_value('cnosuchuser');
         RETURN;
      WHEN SQLSTATE 'EVINN' THEN
         o_status_code := utl.get_constant_value('cdbvinnotfound');
      WHEN no_data_found THEN
         o_status_code := utl.get_constant_value('cdbsubscribervinnotfound');
         RETURN;
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         o_result := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cinternalerror');
         RETURN;
   END;

$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION be.get_notification_configured (ipartnerid text, iloginid text, ivin text, oresult OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;  
