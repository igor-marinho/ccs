SET bedb.filename = 'function.u_svc_url_sp.sql';

\i set_be_env.sql;


   /*
    Update service URL
     FUNCTION u_svc_url_sp
               in: i_svc_id, i_url_sequence, i_link, i_admin_portal (Y/N), i_version
               out: integer - error codes defined above

            Required input params : i_svc_id, i_url_sequence, i_link, i_admin_portal (Y/N)
   */
   -- Update service URL
   
DROP FUNCTION IF EXISTS crudg_svc_url.u_svc_url_sp (beowner.svc_url.svc_id%TYPE, 
                                                    INTEGER, 
													beowner.svc_url.link%TYPE, 
													text,
													text);
   
CREATE OR REPLACE FUNCTION crudg_svc_url.u_svc_url_sp (i_svc_id       beowner.svc_url.svc_id%TYPE, 
                                                       i_url_sequence INTEGER, 
													   i_link         beowner.svc_url.link%TYPE, 
													   i_admin_portal text DEFAULT 'Y',
													   i_version      text DEFAULT NULL) RETURNS INTEGER AS $body$
DECLARE
      l_action text;
      l_module_name text := 'u_svc_url_sp';
      l_count INTEGER;
      l_valid_return INTEGER;
      l_link         beowner.svc_url.link%TYPE := trim(both i_link);
      l_exception_diagnostics trc.exception_diagnostics;

BEGIN

      l_action := utl.set_module_action( l_module_name, 'Starting u_svc_url_sp');
	  
      l_valid_return := crudg_svc_url.validate_inputs(i_svc_id       => i_svc_id,
                                                      i_url_sequence => i_url_sequence,
                                                      i_link         => l_link,
                                                      i_admin_portal => i_admin_portal,
                                                      i_action       => 'U'); -- D,I,U,G
													  
      IF l_valid_return != utl.get_constant_value('csuccess')::integer
      THEN
      RETURN l_valid_return;
      END IF;

      UPDATE beowner.svc_url
      SET link = l_link
      WHERE svc_id = i_svc_id
      AND url_sequence = i_url_sequence;

      GET DIAGNOSTICS l_count = ROW_COUNT;
	 
      IF l_count = 0
      THEN
      RETURN utl.get_constant_value('c_url_not_found');
      END IF;

      RETURN utl.get_constant_value('csuccess');
	  
EXCEPTION
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
         RETURN utl.get_constant_value('cinvalidparams');
		 
      WHEN OTHERS THEN

         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => 'Something went really wrong in u_svc_url_sp - i_svc_id=' ||
                                          i_svc_id,
                        iexception_diagnostics => l_exception_diagnostics);

         RETURN utl.get_constant_value('cinternalerror');
   END; -- Delete service URL
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION crudg_svc_url.u_svc_url_sp (i_svc_id svc_url.svc_id%TYPE, i_url_sequence svc_url.url_sequence%TYPE, i_link svc_url.link%TYPE, i_admin_portal text DEFAULT 'Y', i_version text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
