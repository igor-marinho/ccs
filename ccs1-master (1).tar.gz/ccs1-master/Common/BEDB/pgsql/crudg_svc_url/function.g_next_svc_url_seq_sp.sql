SET bedb.filename = 'function.g_next_svc_url_seq_sp.sql';

\i set_be_env.sql;



   --22089: ACL Management Portal - Does not have access to a required database value
   -- New database function that returns the maximum URL sequence for a given service
   -- Ref cursor returned : svc_id, url_sequence, link, admin_portal_managed (Y/N)
   
-- WARNING: parameters order has been changed by Ora2Pg to move parameters with default values at end
-- Original order was: crudg_svc_url.g_next_svc_url_seq_sp(i_svc_id svc_url.svc_id%TYPE, i_admin_portal text DEFAULT 'Y', i_version text DEFAULT NULL, o_result OUT REFCURSOR)
-- You will need to manually reorder parameters in the function calls

DROP FUNCTION IF EXISTS crudg_svc_url.g_next_svc_url_seq_sp (beowner.svc_url.svc_id%TYPE, 															
														     text, 
															 text);

CREATE OR REPLACE FUNCTION crudg_svc_url.g_next_svc_url_seq_sp (i_svc_id beowner.svc_url.svc_id%TYPE, 
																o_status_code OUT INTEGER,
                                                                o_result OUT REFCURSOR, 
																i_admin_portal text DEFAULT 'Y', 
																i_version text DEFAULT NULL) AS $body$
DECLARE

      l_action                    text;
      l_module_name               text := 'g_next_svc_url_seq_sp';
      l_max_url_sequence          INTEGER;
      l_valid_return              INTEGER;
      l_return_count              INTEGER;
	  c_admin_portal_url_seq      INTEGER  := 100;
      l_exception_diagnostics     trc.exception_diagnostics;

BEGIN
     									   
      l_action := utl.set_module_action( l_module_name, 'Starting g_next_svc_url_seq_sp');									   

      o_result := utl.get_dummy_cursor(); -- Jira PU-391
	  
	  l_valid_return := crudg_svc_url.validate_inputs(i_svc_id       => i_svc_id,
                                                      i_url_sequence => NULL,
                                                      i_link         => NULL,
                                                      i_admin_portal => i_admin_portal,
                                                      i_action       => 'G');  -- D,I,U,G
	  
      
      IF l_valid_return != utl.get_constant_value('csuccess')::Integer
	  THEN
      o_status_code := l_valid_return;
	  RETURN;
      END IF;

      SELECT COUNT(1)
      INTO STRICT l_return_count
      FROM beowner.svc_url
      WHERE svc_id = i_svc_id;

      IF COALESCE(l_return_count, 0) = 0	  
      THEN
	     CLOSE o_result;
		 
         OPEN o_result FOR
            SELECT CASE
                      WHEN i_admin_portal = 'Y' THEN
                       c_admin_portal_url_seq
                      WHEN i_admin_portal = 'N' THEN
                       1
                   END;

      ELSE
         IF i_admin_portal = 'Y'
         THEN
              SELECT MAX(s.url_sequence)
              INTO STRICT l_max_url_sequence
              FROM beowner.svc_url s
              WHERE s.svc_id = i_svc_id
              AND s.url_sequence > (c_admin_portal_url_seq - 1);
			
            CLOSE o_result;			

            OPEN o_result FOR
               SELECT CASE
                         WHEN l_max_url_sequence IS NOT NULL THEN
                          l_max_url_sequence + 1
                         WHEN l_max_url_sequence IS NULL THEN
                          c_admin_portal_url_seq
                      END;
         ELSIF i_admin_portal = 'N'
         THEN
		    
			CLOSE o_result;
			
            OPEN o_result FOR
               SELECT (MAX(url_sequence) + 1) next_url_sequence
                 FROM beowner.svc_url
                WHERE svc_id = i_svc_id
                      AND url_sequence < c_admin_portal_url_seq;
         END IF;
      END IF;

      o_status_code := utl.get_constant_value('csuccess');
	  
	  RETURN;
	  
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => 'Something went really wrong in g_next_svc_url_seq_sp - i_svc_id=' ||i_svc_id,
                        iexception_diagnostics => l_exception_diagnostics);
		
		  o_result := utl.get_dummy_cursor();	
		  
		  o_status_code := utl.get_constant_value ('cinternalerror');
		  
          RETURN;

   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION crudg_svc_url.g_next_svc_url_seq_sp (i_svc_id svc_url.svc_id%TYPE, o_result OUT REFCURSOR, i_admin_portal text DEFAULT 'Y', i_version text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
