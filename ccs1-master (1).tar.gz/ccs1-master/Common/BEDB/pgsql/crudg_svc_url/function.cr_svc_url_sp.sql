SET bedb.filename = 'function.cr_svc_url_sp.sql';

\i set_be_env.sql;

   /*
    Create service URL
   FUNCTION cr_svc_url_sp
             in: i_svc_id, i_url_sequence, i_link, i_admin_portal (Y/N), i_version
             out: integer - error codes defined above

          Required input params : i_svc_id, i_url_sequence, i_link, i_admin_portal (Y/N)
 */

   -- Create service URL
   
DROP FUNCTION IF EXISTS crudg_svc_url.cr_svc_url_sp (beowner.svc_url.svc_id%TYPE,
                                                     INTEGER, 
													 beowner.svc_url.link%TYPE, 
													 text, 
													 text);

CREATE OR REPLACE FUNCTION crudg_svc_url.cr_svc_url_sp (i_svc_id       beowner.svc_url.svc_id%TYPE,
                                                        i_url_sequence INTEGER, 
														i_link         beowner.svc_url.link%TYPE, 
														i_admin_portal text DEFAULT 'Y', 
														i_version text DEFAULT NULL) RETURNS INTEGER AS $body$
DECLARE
      
	  l_action       text;
      l_module_name  text := 'cr_svc_url_sp';
      l_valid_return INTEGER;
      l_link         beowner.svc_url.link%TYPE := trim(both i_link);
      l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    									   
      l_action := utl.set_module_action( l_module_name, 'Starting cr_svc_url_sp');
	  
      l_valid_return := crudg_svc_url.validate_inputs(i_svc_id       => i_svc_id,
                                                      i_url_sequence => i_url_sequence,
                                                      i_link         => l_link,
                                                      i_admin_portal => i_admin_portal,
                                                      i_action       => 'I'); -- D,I,U,G
										
      IF l_valid_return != utl.get_constant_value('csuccess')::Integer
      THEN
      RETURN l_valid_return;
      END IF;

      INSERT INTO beowner.svc_url(svc_id, url_sequence, link)
      VALUES (i_svc_id, i_url_sequence, l_link);

      RETURN utl.get_constant_value('csuccess');
	  
EXCEPTION

      WHEN unique_violation THEN
         RETURN utl.get_constant_value('c_existing_svc_seq');
		 
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
         RETURN utl.get_constant_value('cinvalidparams');
		 
      WHEN OTHERS THEN
      
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => 'Something went really wrong in cr_svc_url_sp - i_svc_id=' ||
                                          i_svc_id,
                        iexception_diagnostics => l_exception_diagnostics);

         RETURN utl.get_constant_value('cinternalerror');
   END;

   -- Update service URL
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION crudg_svc_url.cr_svc_url_sp (i_svc_id svc_url.svc_id%TYPE, i_url_sequence svc_url.url_sequence%TYPE, i_link svc_url.link%TYPE, i_admin_portal text DEFAULT 'Y', i_version text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
