SET bedb.filename = 'function.validate_inputs.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS crudg_svc_url.validate_inputs (beowner.svc_url.svc_id%TYPE, 
                                                       INTEGER, 
													   beowner.svc_url.link%TYPE,
													   text, 
													   text);

CREATE OR REPLACE FUNCTION crudg_svc_url.validate_inputs (i_svc_id       beowner.svc_url.svc_id%TYPE, 
                                                          i_url_sequence INTEGER, 
														  i_link         beowner.svc_url.link%TYPE,
														  i_admin_portal text, 
														  i_action text) RETURNS INTEGER AS $body$
DECLARE
      l_action text;
      l_module_name text := 'validate_inputs';
      l_admin_portal varchar(1) := upper(i_admin_portal);
      l_duplicate    integer;
	  l_exception_diagnostics trc.exception_diagnostics;

BEGIN

      l_action := utl.set_module_action( l_module_name, 'Validating inputs');
	  
      IF coalesce(l_admin_portal, '!') NOT IN ('Y', 'N')
      THEN
      RETURN utl.get_constant_value('c_invalid_admin_portal_value');
      END IF;

	  IF COALESCE(i_svc_id, '') = '' 
      THEN
      RETURN utl.get_constant_value('c_svc_id_is_null');
	  
      ELSIF NOT utl.is_service_id_valid(i_svc_id => i_svc_id)
      THEN
      RETURN utl.get_constant_value('c_invalid_svc_id');
      END IF;

      IF i_action != 'G'
      THEN
         
		 IF COALESCE(i_url_sequence::text, '') = '' 
         THEN
         RETURN utl.get_constant_value('c_sequence_is_null');
         END IF;

         IF l_admin_portal = 'Y' AND
            i_url_sequence < 100
         THEN
         RETURN utl.get_constant_value('c_non_admin_portal_url_seq');
         END IF;

         IF i_action != 'D'
         THEN
  
			IF COALESCE(i_link, '') = ''
            THEN
            RETURN utl.get_constant_value('c_url_is_null');
            END IF;

            IF position(' ' in i_link) != 0
            THEN
            RETURN utl.get_constant_value('c_invalid_url_format');
            END IF;

            BEGIN
               SELECT 1
                 INTO STRICT l_duplicate
                 FROM beowner.svc_url
                WHERE svc_id = i_svc_id
                      AND link = i_link
                      AND url_sequence != i_url_sequence;

               RETURN utl.get_constant_value('c_duplicate_svc_url');
            EXCEPTION
               WHEN no_data_found THEN
                  NULL;
            END;
         END IF;
      END IF;

      RETURN utl.get_constant_value('csuccess');
	  
EXCEPTION	  
	  WHEN OTHERS THEN
		 GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => NULL,
                       iexception_diagnostics => l_exception_diagnostics);
		  
		  RETURN utl.get_constant_value('cinternalerror');
          
END;

   -- Create service URL
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION crudg_svc_url.validate_inputs (i_svc_id svc_url.svc_id%TYPE, i_url_sequence svc_url.url_sequence%TYPE, i_link svc_url.link%TYPE, i_admin_portal text, i_action text ) FROM PUBLIC;

\i cleanup.sql;
