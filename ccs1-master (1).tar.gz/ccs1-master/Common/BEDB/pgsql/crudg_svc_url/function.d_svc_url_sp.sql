SET bedb.filename = 'function.d_svc_url_sp.sql';

\i set_be_env.sql;

   /*
    Delete service URL
     FUNCTION u_svc_url_sp
               in: i_svc_id, i_url_sequence, i_admin_portal (Y/N), i_version
               out: integer - error codes defined above

            Required input params : i_svc_id, i_url_sequence, i_admin_portal (Y/N)
       */

CREATE OR REPLACE FUNCTION crudg_svc_url.d_svc_url_sp (i_svc_id svc_url.svc_id%TYPE, i_url_sequence svc_url.url_sequence%TYPE, i_admin_portal text DEFAULT 'Y', i_version text DEFAULT NULL) RETURNS numeric AS $body$
DECLARE
      l_module_name text := 'd_svc_url_sp';

      ora2pg_rowcount int;
l_valid_return cnst.vc;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      PERFORM utl.set_module_action( l_module_name,  
                                        
                                       'Starting d_svc_url_sp');
      l_valid_return := crudg_svc_url.validate_inputs(i_svc_id       => i_svc_id,
                                        i_url_sequence => i_url_sequence,
                                        i_link         => NULL,
                                        i_admin_portal => i_admin_portal,
                                        i_action       => 'D'); -- D,I,U,G
      IF l_valid_return != utl.get_constant_value('csuccess')
      THEN
         RETURN l_valid_return;
      END IF;

      DELETE FROM beowner.svc_url
       WHERE svc_id = i_svc_id
             AND url_sequence = i_url_sequence;

      GET DIAGNOSTICS ora2pg_rowcount = ROW_COUNT;
IF ora2pg_rowcount = 0
      THEN
         RETURN utl.get_constant_value('c_url_not_found');
      END IF;

      RETURN utl.get_constant_value('csuccess');
   EXCEPTION
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation OR
           e_value_error THEN
         RETURN utl.get_constant_value('cinvalidparams');
      WHEN OTHERS THEN
         PERFORM utl.set_module_action( l_module_name,  
                                           
                                          'Something went really wrong in d_svc_url_sp - i_svc_id=' ||
                                          i_svc_id || ' i_url_sequence=' ||
                                          i_url_sequence ||
                                          ' i_admin_portal=' ||
                                          i_admin_portal);
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

        perform trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');
   END;

   -- Get service url info
   -- Ref cursor returned : svc_id, url_sequence, version, admin_portal_managed (Y/N)
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION crudg_svc_url.d_svc_url_sp (i_svc_id svc_url.svc_id%TYPE, i_url_sequence svc_url.url_sequence%TYPE, i_admin_portal text DEFAULT 'Y', i_version text DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
