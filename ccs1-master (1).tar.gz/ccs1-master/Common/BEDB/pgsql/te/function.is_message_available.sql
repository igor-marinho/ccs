SET bedb.filename = 'function.is_message_available.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS te.is_message_available(beowner.oem_notifications.notif_type%TYPE,
												beowner.oem_notifications.start_date%TYPE, 
												beowner.oem_notifications.expiration_date%TYPE);

/*  IS_MESSAGE_AVAILABLE

    Filter function to determine if a message is available
    to a user

*/
CREATE OR REPLACE FUNCTION te.is_message_available (i_notif_type        beowner.oem_notifications.notif_type%TYPE
                                                   ,i_start_date        beowner.oem_notifications.start_date%TYPE
                                                   ,i_expiration_date   beowner.oem_notifications.expiration_date%TYPE)RETURNS INTEGER
AS $body$
BEGIN
      -- Modified for DCS1NOTES-566 to ensure event-driven messages are always included
      IF i_notif_type = utl.get_constant_value('c_notif_type_inbox') AND
         i_start_date <= clock_timestamp() AND
         coalesce(i_expiration_date, clock_timestamp() + interval '1 days') > clock_timestamp()
      THEN
         RETURN 1;
      ELSE
         RETURN 0;
      END IF;
   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
IMMUTABLE;

-- REVOKE ALL ON FUNCTION te.is_message_available (i_notif_type oem_notifications.notif_type%TYPE, i_start_date oem_notifications.start_date%TYPE, i_expiration_date oem_notifications.expiration_date%TYPE) FROM PUBLIC;

\i cleanup.sql;
