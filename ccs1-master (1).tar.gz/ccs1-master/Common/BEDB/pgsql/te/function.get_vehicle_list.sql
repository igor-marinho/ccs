SET bedb.filename = 'function.get_vehicle_list.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS te.get_vehicle_list(text, text);

CREATE OR REPLACE FUNCTION te.get_vehicle_list(ipartnerid text,
                                               iloginid text,
                                               OUT o_status_code integer,
                                               OUT oresults refcursor) AS
$BODY$
/*  GET_VEHICLE_LIST

    For a given PartnerID/LoginID, return the vehicles regsitered, along with
    service information for each vehicle. The ref-cursor is formatted as follows:

      VIN, MAKE, YEAR, NICKNAME, DEVICE_ID, MODEL, OPTIN_SUPPORTED, NOTIFICATIONS_SUPPORTED, COLOR, SERVICE_INFO

    All fields are strings except SERVICE_INFO which is a nested cursor related to the current VIN as follows:

      SVC_ID, NAME, HANDLER, AUTH, EXPIRES_WITH_CONTRACT, CONTRACT_EXPIRY_STATE, ALLOWED_STATUS, SC_CODE, SC_MESSAGE, ACCT_STATUS, SUB_START, SUB_END

      contract_expiry_state returns from contract.get_contract_expiry_state
      --Added contract.get_contract_expiry_state in service_info cursor for --Jira #CR10236-162

    -----
    Expected Return Values:
      0     : success (this can include an empty result set; a cursor with no rows)
      1     : Unknown Error
      7     : No Such User              (cnst.cNoSuchUser)
      213   : Invalid Partner ID    	(cnst.cDbPartneridNotValid)
*/
DECLARE
    l_action                text;
    l_module_name           text := 'get_vehicle_list';

    --Jira #CR10236-162
    v_loginid               beowner.usr.login_id%type;
    v_partnerid             beowner.ptnr.ptnr_id%type;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    oresults := utl.get_dummy_cursor(); -- Jira PU-391
    l_action := utl.set_module_action(l_module_name, ' Setting Context');
    CALL ctx.set(iptnrid => ipartnerid::uuid, iloginid => iloginid);

    --Jira #CR10236-162
    v_loginid := trim(BOTH iloginid);
    v_partnerid := trim(BOTH replace(ipartnerid, '-', '')); --Jira #CR10236-171
    l_action := utl.set_module_action(l_module_name, ' Opening Results');

    --Added contract.get_contract_expiry_state in service_info cursor for --Jira #CR10236-162
    -- Added optin_supported, notifications_supported for Jira CR344-7
    -- Added function for nickname for Jira SBM-56
    -- Added color, order by device_id and modified nested cursor for Jira RTMS-177.
    --    Intentionally not using ANSI syntax in nested cursor to avoid internal Oracle error
    -- Added model_categories mapping for Jira DCS1REFRES-475
    CLOSE oresults;
    OPEN oresults FOR
	        
	 WITH a1 AS (SELECT coalesce (all_usr.parent_id, all_usr.usr_id) primary_id 
				   FROM beowner.ctx_data cd
				   JOIN beowner.usr u
					 ON u.usr_id = cd.usr_id
				   JOIN beowner.usr all_usr
					 ON all_usr.login_id  = u.login_id),
					 
	      a2 AS (SELECT s.vin,s.nickname,s.primary_id
	               FROM beowner.subscription s
	               JOIN a1
	                 ON s.primary_id = a1.primary_id)
	     SELECT s.vin,
	               v.make_id,
	               v.year,
	               coalesce(s.nickname, 
	               			te.generate_nickname(i_model => v.model,
				                                 i_year => v.year,
				                                 i_device_id => v.device_id))nickname,
	               v.device_id,
	               coalesce(mc.category, v.model)                            model,
	               coalesce(dt.conflict_enforced, 'N')                       optin_supported,
	               coalesce(dt.optin_notifications, 'N')                     notifications_supported,
	               v.color,
	               te.get_service_info(v.vin,
	                                   v_loginid,
	                                   ipartnerid,
	                                   s.primary_id) service_info
	                 FROM a2 s
	                 JOIN beowner.vin v
	                      ON v.vin = s.vin
	                 JOIN beowner.device d
	                      ON d.device_id = v.device_id
	                 LEFT JOIN beowner.device_types dt
	                           ON dt.type = d.device_type
	                 LEFT JOIN beowner.model_categories mc
	                           ON mc.model = v.model
	        ORDER BY v.device_id;

    o_status_code := utl.get_constant_value('csuccess');
    RETURN;
	 
EXCEPTION
    WHEN SQLSTATE 'EPTNR' THEN
	    oresults := utl.get_dummy_cursor(); 
        o_status_code := utl.get_constant_value('cdbpartneridnotvalid');
        RETURN;
    WHEN SQLSTATE 'EUSRN' THEN
	    oresults := utl.get_dummy_cursor(); 
        o_status_code := utl.get_constant_value('cnosuchuser');
        RETURN;
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
			l_exception_diagnostics.module_name := l_module_name;
			l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
        oresults := utl.get_dummy_cursor();
        o_status_code := utl.get_constant_value('cinternalerror');
        RETURN;
END;
$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION te.get_vehicle_list (ipartnerid text, iloginid text, oresults OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
