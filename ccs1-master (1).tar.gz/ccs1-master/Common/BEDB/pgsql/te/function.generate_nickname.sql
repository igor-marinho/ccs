SET bedb.filename = 'function.generate_nickname.sql';

\i set_be_env.sql;

/* Added for SBM-56
   GENERATE_NICKNAME

   Returns prefix from device table appended with a random number, if the device has a default nickname prefix defined.
   Else returns model||'-'||year

   Currently only used by te.get_vehicle_list, but can be called by other functions, if required.
*/

/* Added for SBM-56 */
DROP FUNCTION IF EXISTS te.generate_nickname(beowner.vin.model%type, beowner.vin.year%type, beowner.vin.device_id%type);
CREATE OR REPLACE FUNCTION te.generate_nickname(i_model beowner.vin.model%type,
                                                i_year beowner.vin.year%type,
                                                i_device_id beowner.vin.device_id%type) RETURNS text AS
$BODY$
DECLARE

    l_default_nickname_prefix beowner.device.default_nickname_prefix%type;
    l_default_nickname        beowner.subscription.nickname%type := i_model || '-' ||
                                                                    i_year;
    c_nickname_length_cfg     beowner.cfg.name%type              := 'nickname length';
BEGIN
    DECLARE
        l_nickname_suffix_length integer;
    BEGIN
        SELECT default_nickname_prefix
        INTO STRICT l_default_nickname_prefix
        FROM beowner.device
        WHERE device_id = i_device_id;
        IF l_default_nickname_prefix IS NOT NULL
        THEN
            l_nickname_suffix_length := utl.getconfig(c_nickname_length_cfg)::integer -
                                        length(l_default_nickname_prefix);
            IF l_nickname_suffix_length IS NOT NULL
            THEN
                DECLARE
                    low  numeric;
                    high numeric;
                BEGIN
                    low := power(10, l_nickname_suffix_length - 1);
                    high := power(10, l_nickname_suffix_length) - 1;
                    l_default_nickname := l_default_nickname_prefix || trunc(low + random() * (high - low));
                END;
            END IF;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            NULL;
    END;
    RETURN l_default_nickname;
END;

$BODY$
    LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION te.generate_nickname (i_model vin.model%TYPE, i_year vin.year%TYPE, i_device_id vin.device_id%TYPE) FROM PUBLIC;

\i cleanup.sql;
