SET bedb.filename = 'function.get_message_content.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS te.get_message_content (text);
   -------------------------------------------------------------------------------
   /*  GET_MESSAGE_CONTENT
   
       Retrieve content for the specific notification message.
       -----
       Expected Return Values:
         0     : success
         1     : Unknown Error
         600   : Notification Missing  (cnst.c_notif_missing)
   */

CREATE OR REPLACE FUNCTION te.get_message_content (i_on_guid           text
                                                  ,o_status_code   OUT integer
                                                  ,o_content       OUT oem_notifications.content%TYPE)
AS $body$
DECLARE
    l_action TEXT; 
    l_module_name text := 'get_message_content';
    l_exception_diagnostics trc.exception_diagnostics;      
BEGIN
      l_action := utl.set_module_action( l_module_name, ' Opening Results');

      SELECT oem.content
        INTO STRICT o_content
        FROM beowner.oem_notifications oem
       WHERE oem.on_guid = i_on_guid::UUID;

       o_status_code := utl.get_constant_value('csuccess');
    RETURN; 
   EXCEPTION
      WHEN no_data_found THEN
      o_status_code := utl.get_constant_value('c_notif_missing');
    RETURN;

      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
         o_status_code := utl.get_constant_value('cinternalerror');
     RETURN;

   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION te.get_message_content (i_on_guid oem_notifications.on_guid%TYPE, o_content OUT oem_notifications.content%TYPE) FROM PUBLIC;

\i cleanup.sql;
