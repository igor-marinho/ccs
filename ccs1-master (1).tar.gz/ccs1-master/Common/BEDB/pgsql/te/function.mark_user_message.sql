SET bedb.filename = 'function.mark_user_message.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS te.mark_user_message (TEXT, beowner.usr.login_id%TYPE, beowner.oem_notifications.on_guid%TYPE, TEXT);
DROP FUNCTION IF EXISTS te.mark_user_message (TEXT, beowner.usr.login_id%TYPE, TEXT, TEXT);
   /*  MARK_USER_MESSAGE
   
       Mark a specific message as read or deleted
   
       -----
       Expected Return Values:
         0     : success
         1     : Unknown Error
         7     : No Such User          (cnst.cNoSuchUser)
         213   : Invalid Partner ID    (cnst.cDbPartneridNotValid)
         601   : Notification Recipient Missing  (cnst.c_notif_recipient_missing)
         602   : Notification Invalid Status (cnst.c_notif_invalid_status) 
         
   */
CREATE OR REPLACE FUNCTION te.mark_user_message (i_ptnr_id    text
                                                ,i_login_id   beowner.usr.login_id%TYPE
                                                ,i_on_guid    text
                                                ,i_status     text) RETURNS INTEGER 
AS $body$
DECLARE
    l_action TEXT;
    l_module_name text := 'mark_user_message';
    v_onr_guid beowner.oem_notif_recipients.onr_guid%TYPE;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      l_action := utl.set_module_action( l_module_name, ' Setting Context');

      CALL ctx.set(iptnrid => NULLIF(i_ptnr_id, '')::UUID, iloginid => NULLIF(i_login_id, ''));

      BEGIN
         SELECT onr.onr_guid
           INTO STRICT v_onr_guid
           FROM beowner.oem_notif_recipients onr
          WHERE onr.on_guid = NULLIF(i_on_guid, '')::UUID
                AND onr.usr_id = (SELECT cd.usr_id
                                    FROM beowner.ctx_data cd);

         l_action := utl.set_action(' Setting status');

         IF i_status = utl.get_constant_value('c_recipient_status_del')
             THEN
                /*update the deleted_on value to track when a
                message is deleted by a user action. The
                deleted_on column is inteded to track user
                activity only.*/
                UPDATE beowner.oem_notif_recipients onr
                   SET deleted_on = clock_timestamp(),
					   status = 'D'		/*Update relavant status when read_on, sent_on, deleted_on are modified*/
                 WHERE onr.onr_guid = v_onr_guid;

                DELETE FROM beowner.oem_notif_recipients onr
                 WHERE onr.onr_guid = v_onr_guid;

         ELSIF i_status = utl.get_constant_value('c_recipient_status_read')
             THEN
                UPDATE beowner.oem_notif_recipients
                   SET read_on = clock_timestamp(),
                       status = 'R'    /*Update relavant status when read_on, sent_on, deleted_on are modified*/
                 WHERE onr_guid = v_onr_guid;
         ELSE
            RETURN utl.get_constant_value('c_notif_invalid_status');
         END IF;
      EXCEPTION
         WHEN no_data_found THEN
            RETURN utl.get_constant_value('c_notif_recipient_missing');
      END;

      RETURN utl.get_constant_value('csuccess');

   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
         RETURN utl.get_constant_value('cdbpartneridnotvalid');

      WHEN SQLSTATE 'EUSRN' THEN
         RETURN utl.get_constant_value('cnosuchuser');

      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');

   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION te.mark_user_message (i_ptnr_id ptnr.ptnr_id%TYPE, i_login_id usr.login_id%TYPE, i_on_guid oem_notifications.on_guid%TYPE, i_status text) FROM PUBLIC;

\i cleanup.sql;
