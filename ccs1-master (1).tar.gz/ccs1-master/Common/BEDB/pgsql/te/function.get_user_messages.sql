SET bedb.filename = 'function.get_user_messages.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS te.get_user_messages(TEXT,beowner.usr.login_id%TYPE);

   /*  GET_USER_MESSAGES
   
       Retrieve all messages for a given user oem_notifications
       with notif_type = I
       -----
       Expected Return Values:
         0     : success (this can include an empty result set; a cursor with no rows)
         1     : Unknown Error
         7     : No Such User          (cnst.cNoSuchUser)
         213   : Invalid Partner ID    (cnst.cDbPartneridNotValid)
   
   */
CREATE OR REPLACE FUNCTION te.get_user_messages (i_ptnr_id           TEXT
                                                ,i_login_id          beowner.usr.login_id%TYPE
                                                ,o_status_code   OUT INTEGER
                                                ,o_results       OUT refcursor)
AS $body$
DECLARE
	l_action TEXT;
	l_module_name text := 'get_user_messages';
	l_exception_diagnostics trc.exception_diagnostics;      
	g_max_client_rows INTEGER := utl.getconfig(icfgname => utl.GET_constant_value('c_cfg_notif_rows_ret_client'));
BEGIN

    o_results := utl.get_dummy_cursor();

    l_action := utl.set_module_action( l_module_name, ' Setting Context');

    CALL ctx.set(iptnrid => i_ptnr_id::UUID, iloginid => i_login_id);

    l_action := utl.set_action(' Updating sent time');

    CALL te.set_message_sent();

    l_action := utl.set_action(' Opening Results');

    --Jira DCS1NOTES-414: Add logic to limit number of returned messages
    --Using the start_date and notif_seq as a tie breakter for things like automated testing,
    --in practice the created date should be enough
    CLOSE o_results;
    OPEN o_results FOR
       SELECT msg.on_guid,
              msg.subject,
              CASE
                 WHEN msg.status = utl.get_constant_value('c_recipient_status_read') THEN
                  utl.get_constant_value('c_yes')
                 ELSE
                  utl.get_constant_value('c_no')
              END AS READ,
              msg.priority,
              msg.start_date AS message_date
         FROM (SELECT oem.on_guid,
                      oem.subject,
                      onr.status,
                      oem.priority,
                      oem.start_date
                 FROM beowner.oem_notif_recipients onr
                 JOIN beowner.usr u
                   ON (u.usr_id = onr.usr_id)
                 JOIN beowner.ctx_data cd
                   ON (cd.usr_id = u.usr_id)
                 JOIN beowner.oem_notifications oem
                   ON (oem.on_guid = onr.on_guid)
                WHERE (SELECT te.is_message_available(i_notif_type      => oem.notif_type,
                                                      i_start_date      => oem.start_date,
                                                      i_expiration_date => oem.expiration_date)
                         ) = 1
                ORDER BY onr.created_date DESC,
                         oem.start_date   DESC,
                         oem.notif_seq    DESC) msg 
          ORDER BY msg.start_date DESC LIMIT g_max_client_rows;

    o_status_code := utl.get_constant_value('csuccess');
  RETURN;
  
  EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
		 o_results := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cdbpartneridnotvalid');
         RETURN;

      WHEN SQLSTATE 'EUSRN' THEN
		 o_results := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cnosuchuser');
         RETURN;

      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
        o_results := utl.get_dummy_cursor();
        o_status_code := utl.get_constant_value('cinternalerror');
        RETURN;
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION te.get_user_messages (i_ptnr_id ptnr.ptnr_id%TYPE, i_login_id usr.login_id%TYPE, o_results OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
