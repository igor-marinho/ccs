SET bedb.filename = 'function.get_partner_data.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS te.get_partner_data();
/*  GET_PARTNER_DATA

   Returns a "SELECT * FROM PTNR" in oResult.
   No errors are expected.

*/
CREATE OR REPLACE FUNCTION te.get_partner_data(OUT f$result INTEGER, OUT oresult REFCURSOR)
AS
$BODY$
DECLARE
      l_action text;
      l_module_name text := 'get_partner_data';
BEGIN
    
    l_action := utl.set_module_action( l_module_name, ' te.get_partner_data');

    /* there is not really any possible error condition here. */
    OPEN oresult FOR
    SELECT *
      FROM beowner.ptnr;
    f$result := utl.get_constant_value('csuccess');
    RETURN;
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
