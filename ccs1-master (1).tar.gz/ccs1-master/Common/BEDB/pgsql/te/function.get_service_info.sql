SET bedb.filename = 'function.get_service_info.sql';

\i set_be_env.sql;


/*
 nested_service_info_for_get_vehicle_list

 for converting nested cursor in oracle to PG
 */
DROP FUNCTION IF EXISTS te.get_service_info(text, text, text, uuid);
CREATE OR REPLACE FUNCTION te.get_service_info(i_vin text,
                                               i_loginid text,
                                               i_partnerid text,
                                               i_usrid uuid) RETURNS refcursor
AS
$BODY$

DECLARE
    o_result refcursor;

BEGIN

    OPEN o_result FOR
        SELECT svc.svc_id,
               svc.name,
               svc.handler,
               svc.auth,
               svc.expires_with_contract,
               contract.get_contract_expiry_state(i_vin,
                                                  i_loginid,
                                                  svc.svc_id,
                                                  i_partnerid) contract_expiry_state,
               usrs.allowed_status,
               usrs.sc_code,
               usrs.sc_message,
               usrs.acct_status,
               usrs.sub_start,
               usrs.sub_end
        FROM user_subscription.info(i_usrid, i_vin) usrs,
             beowner.svc svc
        WHERE svc.svc_id = usrs.svc_id;

    RETURN o_result;

END;
$BODY$
    LANGUAGE plpgsql
    SECURITY DEFINER
    STABLE;

\i cleanup.sql;
