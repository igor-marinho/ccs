SET bedb.filename = 'procedure.set_message_sent.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS te.set_message_sent();

CREATE OR REPLACE PROCEDURE te.set_message_sent() 
AS $body$
DECLARE
	l_action TEXT;
	l_module_name text := 'set_message_sent';
BEGIN
      l_action := utl.set_module_action( l_module_name, ' Setting messages to sent');

      /*User context must be set before using this procedure*/
      UPDATE beowner.oem_notif_recipients onr
         SET sent_on = clock_timestamp()
		    ,status = CASE WHEN read_on IS NULL 
						THEN 'S' ELSE status
					  END	/*Update relavant status when read_on, sent_on, deleted_on are modified*/
       WHERE onr.sent_on is NULL
             AND onr.on_guid IN (SELECT oem.on_guid
                                   FROM beowner.oem_notifications oem
                                  WHERE (SELECT te.is_message_available(i_notif_type      => oem.notif_type,
                                                                        i_start_date      => oem.start_date,
                                                                        i_expiration_date => oem.expiration_date)
                                           ) = 1)
             AND onr.usr_id = (SELECT cd.usr_id
                                 FROM beowner.ctx_data cd);
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE te.set_message_sent () FROM PUBLIC;

\i cleanup.sql;
