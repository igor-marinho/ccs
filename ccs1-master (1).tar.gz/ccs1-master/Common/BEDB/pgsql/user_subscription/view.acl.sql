SET bedb.filename = 'view.acl.sql';

\i set_be_env.sql;

-- Modified for WI #14078 to remove hard-coded name of context
CREATE OR REPLACE VIEW beowner.acl (rslt)
AS
  select xmlConcat((select xmlElement(name "services",
                  xmlAgg(xmlElement(name "service",
                                    xmlElement(name "name", z.svc_name),
                                    xmlElement(name "serviceId", z.svc_id),
                                    xmlElement(name "handlerName", z.svc_handler),
                                    xmlElement(name "serviceStatus", z.allowed_status),
                                    xmlElement(name "auth", z.auth),
                                    xmlElement(name "result", case
                                                              when z.sc_code is not null
                                                              then xmlElement(name "status", z.sc_code)
                                                              else null
                                                            end,
                                                            case
                                                              when z.sc_message is not null
                                                              then xmlElement(name "message", z.sc_message)
                                                              else null
                                                            end),
                                    (select xmlelement(name "urls", xmlagg(xmlelement(name "url", y.link)))
                                       from beowner.svc_url y
                                      where y.svc_id = z.svc_id)))) as rslt
        from (select distinct
                     first_value("name")         over (partition by svc_id order by ordered_allowed_status range between unbounded preceding and unbounded following) svc_name,
                     first_value(svc_id)         over (partition by svc_id order by ordered_allowed_status range between unbounded preceding and unbounded following) svc_id,
                     first_value(lang_id)        over (partition by svc_id order by ordered_allowed_status range between unbounded preceding and unbounded following) lang_id,
                     first_value(handler)        over (partition by svc_id order by ordered_allowed_status range between unbounded preceding and unbounded following) svc_handler,
                     first_value(allowed_status) over (partition by svc_id order by ordered_allowed_status range between unbounded preceding and unbounded following) allowed_status,
                     first_value(auth)           over (partition by svc_id order by ordered_allowed_status range between unbounded preceding and unbounded following) auth,
                     first_value(sc_code)        over (partition by svc_id order by ordered_allowed_status range between unbounded preceding and unbounded following) sc_code,
                     first_value(sc_message)     over (partition by svc_id order by ordered_allowed_status range between unbounded preceding and unbounded following) sc_message             
            from beowner.ctx_data cd, user_subscription.info(cd.usr_id,null)) as  z),
     (select xmlElement(name "proxyConfig",
                        xmlConcat((select xmlElement(name "blacklist",
                                                     xmlElement(name "urls",
                                                                xmlAgg(xmlElement(name "url", link))))
                                     from beowner.svc_url
                                    where svc_id = '999'),
                                  (select xmlElement(name "whitelist",
                                                     xmlElement(name "urls",
                                                                xmlAgg(xmlElement(name "url", link)))))))
            from beowner.svc_url
            where svc_id = '1000'))::text as rslt;

\i cleanup.sql; 
