SET bedb.filename = 'function.gfalse.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION user_subscription.gfalse() RETURNS varchar as $body$
begin
  return ' '; -- False
END;
$body$
LANGUAGE PLPGSQL
IMMUTABLE;

\i cleanup.sql;
