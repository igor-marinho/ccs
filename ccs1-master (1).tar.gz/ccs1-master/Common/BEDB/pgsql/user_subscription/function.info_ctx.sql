SET bedb.filename = 'function.info_ctx.sql';

\i set_be_env.sql;

/*
   The CONTEXT version. This retrieves the subscription information based on the set context.
   Either USR_ID or VIN can be NULL. This one has slightly more overhead than the prior call,
   but it is not terribly significant.

   Example:

   begin
	 ctx.set(iUsrID => 'FCEC930D78144E3B847B3D223496C17B', iVIN => 'LLPGWY1B710272954');
   end;

   select *
	 from table(user_subscription.info_ctx);

*/
CREATE OR REPLACE FUNCTION user_subscription.info_ctx(IN isvcid TEXT DEFAULT NULL)
RETURNS SETOF user_subscription.recinfo
AS
$BODY$
DECLARE
    vusrid beowner.USR.usr_id%TYPE;
    vvin beowner.VIN.vin%TYPE;
    vtmstmp TIMESTAMP(6) WITH TIME ZONE;
    x2 RECORD;
BEGIN
    SELECT usr_id, vin, tmstmp
      INTO STRICT vusrid, vvin, vtmstmp
      FROM beowner.ctx_data;
    
    
    FOR x2 IN (SELECT *
                 FROM user_subscription.info(
                            iusrid  => vusrid,
                            ivin    => vvin,
                            itmstmp => vtmstmp,
                            isvcid  => isvcid))
    LOOP
        RETURN NEXT x2;
    END LOOP;
    RETURN;
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER ;

\i cleanup.sql;

