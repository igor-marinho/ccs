SET bedb.filename = 'procedure.set_user_config.sql';

\i set_be_env.sql;

   -- OnTime #23201
CREATE OR REPLACE PROCEDURE user_subscription.set_user_config (i_usr_id usr.usr_id%TYPE) AS $body$
DECLARE

      l_make_id make.make_id%TYPE;

BEGIN
      SELECT make_id
        INTO STRICT l_make_id
        FROM usr
       WHERE usr_id = i_usr_id;
      PERFORM set_config('user_subscription.g_user_relation_static_flag', CASE
                                        WHEN utl.get_user_relation_config(i_make_id => l_make_id) =
                                             cnst.c_user_relation_static THEN
                                         current_setting('user_subscription.c_yes')::varchar(1)
                                        ELSE
                                         current_setting('user_subscription.c_no')::varchar(1)
                                     END, false);
   EXCEPTION
      WHEN no_data_found THEN
         PERFORM set_config('user_subscription.g_user_relation_static_flag', current_setting('user_subscription.c_yes')::varchar(1), false); -- if usr ID is null or usr not found, treat as static (old way)
   END;
   -------------------------------------------------------------------------------
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE user_subscription.set_user_config (i_usr_id usr.usr_id%TYPE) FROM PUBLIC;

\i cleanup.sql;
