SET bedb.filename = 'procedure.initstatuscodes.sql';

\i set_be_env.sql;

CREATE OR REPLACE PROCEDURE user_subscription.initstatuscodes () AS $body$
DECLARE

      z rstatusinf;

  cx RECORD;

BEGIN
      FOR cx IN (SELECT code,
                        message,
                        indexed_status
                   FROM status_code
                  WHERE indexed_status IS NOT NULL)
      LOOP
         z.scod := cx.code;
         z.smsg := cx.message;
         current_setting('user_subscription.statusinf')::tstatusinf(cx.indexed_status) := z;
      END LOOP;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE user_subscription.initstatuscodes () FROM PUBLIC;

\i cleanup.sql;
