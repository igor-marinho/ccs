SET bedb.filename = 'function.info.sql';

\i set_be_env.sql;

   /*
       The standard call; this is the preferred version.
       The first argument is USR_ID and the second argument is VIN. Either can be NULL.
       - If VIN is NULL then it retrieves all subscription data for the specified user
       - If USR_ID is NULL then it retrieves all subscription data for the specified VIN
       - If both are specified, it retrieves all subscription data for the specified user and (not OR) vin. This is a more restrictive result set.
       - If both are null, no data is returned
   
       There is a third optional parameter that is a TIMESTAMP WITH TIME ZONE. If specified, you can
       "change the time of the query" to reflect the subscription status based on that particular timestamp.
   
       Example:
   
       select *
         from table(user_subscription.info('FCEC930D78144E3B847B3D223496C17B', 'LLPGWY1B710272954'));
   
   */
   -------------------------------------------------------------------------------
   -- Removed column mac_addr for DCS1E-921   
DROP FUNCTION IF EXISTS user_subscription.info(uuid, text, timestamptz, timestamp);
CREATE OR REPLACE FUNCTION user_subscription.info(IN iusrid uuid,
                                                  IN ivin text,
                                                  IN itmstmp timestamptz DEFAULT clock_timestamp(),
                                                  IN isvcid text DEFAULT NULL)
    RETURNS setof user_subscription.recinfo
AS
$BODY$
DECLARE

    rslt user_subscription.recinfo;
    cx REFCURSOR;
    vsvcinfo user_subscription.svc_info[];
    vconflictinfo INTEGER;
    vconflict beowner.SUBSCRIPTION.conflict%type;
--    /* used as a flag when we go to the next user (if multiple users) */
    voldusrid beowner.USR.usr_id%TYPE := '00000000000000000000000000000000'::UUID;
--    /* list of service credentials */
    vcreds user_subscription.tcredinf;
--    /* variables in main cursor */
    vcontractexpired beowner.CONTRCT.expired%TYPE;
    vsubcontractid beowner.SUBSCRIPTION.contract_id%TYPE;
    vnickname beowner.SUBSCRIPTION.nickname%TYPE;
    vdev_only_bndl beowner.BNDL.dev_only_bndl%type;
--    /* #14921 */
--    /* variables in "services" cursor */
    vcontractrequired beowner.SVC.contract_required%TYPE;
    vallowsecondary beowner.SVC.allow_secondary%TYPE;
    vneverexpires beowner.SVC.never_expires%TYPE;
    valwaysavailable beowner.SVC.always_available%TYPE;
    vsvcinfo_rec user_subscription.svc_info;
    vdeprecated beowner.svc.deprecated%TYPE;
    vcnt INTEGER := 0;
    
BEGIN

    cx := user_subscription.openmaincursor(iusrid := iusrid, ivin := ivin, isvcid := isvcid);
    rslt.tmstmp := itmstmp;

    <<mainloop>>
    LOOP
        FETCH cx into
          rslt.usr_id, rslt.primary_id, rslt.login_id, rslt.make_id, rslt.created, rslt.verified, rslt.lang_id, rslt.locked,
          rslt.pwd, rslt.vin, rslt.bndl_id, rslt.sub_start, rslt.sub_duration, rslt.device_id, rslt.factory_flag, rslt.dealer_flag, rslt.dofu,
          rslt.bundle_name, rslt.bundle_description, rslt.payment_type, rslt.bundle_length, rslt.grace_length,
          rslt.max_users,
          vconflict,
          rslt.cntrct_id, rslt.meid, rslt.cntrct_owner, rslt.cntrct_external_id, vcontractexpired,
          rslt.sub_optin_level, vsubcontractid, rslt.cntrct_tmstmp, vnickname, vdev_only_bndl, vsvcinfo, vconflictinfo;

        EXIT mainloop WHEN (NOT FOUND);

        /* load credentials for the user (if any) */

        IF rslt.usr_id != voldusrid THEN
            voldusrid := rslt.usr_id;
            select *
              from user_subscription.loadcreds(iusrid := voldusrid, isvcid := isvcid, iocreds := vcreds)
              into vcreds;
        END if;

        /* Added for OnTime WI #14078. DOFU should be returned as sub_start for Trial subscriptions, if available */
        rslt.sub_start :=
        CASE
            WHEN rslt.payment_type = 'T' THEN COALESCE(rslt.dofu, rslt.sub_start)
            ELSE rslt.sub_start
        end;
        /* calculate the subscription end time */
        rslt.sub_end :=
        CASE
            WHEN rslt.payment_type = 'P' THEN rslt.sub_start + rslt.sub_duration
        /* payment type = 'S' or 'T' */
            ELSE
            CASE
                WHEN rslt.dofu IS NOT NULL THEN rslt.dofu + rslt.sub_duration
                ELSE rslt.sub_start + rslt.grace_length
            /* grace length will be 0 for Trial subscription, effectively rendering a trial subscription useless without a DOFU */
            end
        END;
        rslt.conflict := null;
        /*
        Work Item 5291: temporarily ignore conflict. Leave code here for now in case we turn it back on.
        
        -- calculate the conflict information
        fetch vConflictInfo into vVinCount; -- this is a "count(*) from dual" so it should always return a row
        
        rslt.conflict := case when vVinCount = 0
                              then null
                              else case when vConflict is not null
                                        then vConflict
                                        else rslt.sub_start
                                   end
                         end;
        */
        /* calculate the "primary" flag */
        rslt.is_primary :=
        CASE rslt.usr_id
            WHEN rslt.primary_id THEN user_subscription.gtrue()
            ELSE user_subscription.gfalse()
        end;
        /*
        Work Item 5291: temporarily ignore conflict. Leave code here for now in case we turn it back on.
        when rslt.payment_type = 'S' and rslt.conflict is not null
           then case when rslt.conflict + rslt.conflict_length < rslt.tmstmp
           then cnst.cStatusConflictExpired
          else cnst.cStatusConflict
        END
        */
        /* calculate the account status */
        rslt.acct_status :=
        /* WI #14078. Future subscriptions should be considered inactive */
        /* Added a second for Jira SBM-294, as precision on sub_start is just seconds, so gets rounded up */
        CASE
            WHEN (rslt.sub_start > rslt.tmstmp + '1 second'::INTERVAL) THEN utl.get_constant_value('cstatusinvalid')
            WHEN rslt.locked = '*' then utl.get_constant_value('cstatuslocked')
            WHEN rslt.bndl_id IS NULL THEN
            CASE
                WHEN rslt.verified IS NOT NULL THEN utl.get_constant_value('cstatusactive')
                ELSE utl.get_constant_value('cstatuspending')
            END
            WHEN rslt.verified IS NULL THEN utl.get_constant_value('cstatuspending')
            WHEN rslt.dofu IS NULL AND rslt.payment_type != 'P' THEN
            CASE
                WHEN rslt.sub_end < rslt.tmstmp THEN utl.get_constant_value('cstatusgraceexpired')
                ELSE utl.get_constant_value('cstatusgrace')
            END
            WHEN rslt.sub_end < rslt.tmstmp THEN utl.get_constant_value('cstatusexpired')
            WHEN rslt.sub_end >= rslt.tmstmp THEN utl.get_constant_value('cstatusactive')
            ELSE utl.get_constant_value('cstatusinvalid')
        END;
        rslt.valid_contract :=
        CASE
            WHEN rslt.cntrct_id = vsubcontractid AND rslt.cntrct_tmstmp IS NOT NULL
            THEN user_subscription.gtrue()
            ELSE user_subscription.gfalse()
        end;
        /* now expand the result for each service */

        <<svcloop>>
        FOREACH vsvcinfo_rec IN ARRAY vsvcinfo
        loop
          rslt.svc_id := vsvcinfo_rec.svc_id;
          rslt.allowed_status := vsvcinfo_rec.allowed_status;
          rslt.name := vsvcinfo_rec.name;
          rslt.description := vsvcinfo_rec.description;
          rslt.handler := vsvcinfo_rec.handler;
          rslt.auth := vsvcinfo_rec.auth;
          rslt.svc_optin_level := vsvcinfo_rec.optin_level;
          vcontractrequired := vsvcinfo_rec.contract_required;
          vallowsecondary := vsvcinfo_rec.allow_secondary;
          vneverexpires := vsvcinfo_rec.never_expires;
          valwaysavailable := vsvcinfo_rec.always_available;
		  vdeprecated := vsvcinfo_rec.deprecated;

          /* calculate credentials for this service */
          select case
                   when coalesce(c.credcount,0) > 0
                   then user_subscription.gtrue()
                   else  user_subscription.gfalse()
                 end as has_creds
            into rslt.credentials 
            from (select rslt.svc_id as svc_id) s
            left
            join unnest(vcreds) c
              on (s.svc_id = c.svc_id);

            /* Jira PPB-28 */
            /* If conflict is not enforced for the VIN's device (hence contract ID would not be available), */
            /* contract should not be required for the service even if it is flagged as such */
            vcontractrequired :=
            CASE
                WHEN vcontractrequired = user_subscription.gtrue()
                 AND utl.is_conflict_enforced(i_device_id := rslt.device_id) = 'Y'
                 THEN user_subscription.gtrue()
                ELSE user_subscription.gfalse()
            end;

            /* calculate the actual allowed status of the service */
            rslt.allowed_status :=
            CASE
                WHEN valwaysavailable = user_subscription.gtrue() THEN '1'
                WHEN vdeprecated = utl.get_constant_value('c_yes') THEN utl.get_constant_value('c_deprecated_service_status')
                WHEN ((vcontractrequired = user_subscription.gtrue() )
                 AND ((rslt.svc_optin_level > rslt.sub_optin_level)
                   OR (rslt.valid_contract = user_subscription.gfalse())))
                   OR (rslt.is_primary = user_subscription.gfalse()
                   AND vallowsecondary = user_subscription.gfalse()) THEN '2'
                WHEN vneverexpires = user_subscription.gtrue() THEN
                CASE
                    WHEN rslt.allowed_status = '3'
                     AND rslt.credentials = user_subscription.gtrue()
                     THEN '1'
                    ELSE rslt.allowed_status
                END
                WHEN rslt.acct_status IN (utl.get_constant_value('cstatuslocked'), utl.get_constant_value('cstatusinvalid'), utl.get_constant_value('cstatusexpired')) THEN '4'
                WHEN rslt.acct_status = utl.get_constant_value('cstatusgraceexpired') THEN '5'
                WHEN rslt.acct_status = utl.get_constant_value('cstatusconflictexpired') THEN '6'
                WHEN rslt.allowed_status = '3' THEN
                CASE rslt.credentials
                    WHEN user_subscription.gtrue() THEN '1'
                    ELSE rslt.allowed_status
                END
                ELSE rslt.allowed_status
            end;

            /* calculate the ordered allowed status */
            rslt.ordered_allowed_status :=
            CASE rslt.allowed_status
                WHEN '3' THEN '1'
                WHEN '1' THEN '2'
                WHEN '4' THEN '3'
                WHEN '5' THEN '4'
                WHEN '6' THEN '5'
                WHEN '2' THEN '6'
                ELSE '7'
            END;
           
            rslt.sc_code := NULL;
            rslt.sc_message := null;
           
            /* add the status-code data, if there is any */
            IF rslt.allowed_status != '1'
            THEN

             select msg_rank.code,
                    msg_rank.message
               INTO strict rslt.sc_code,
                           rslt.sc_message
               from (SELECT msg.code,
                            msg.message,
                            msg.indexed_status,
                            msg.msg_match,
                            min(msg.msg_match) over () as match_min
                       from (select sc.code,
                                    sc.message,
                                    sc.indexed_status,
                                    CASE
                                      when sc.indexed_status = rslt.allowed_status || rslt.lang_id || rslt.svc_id || rslt.make_id
                                      then 1
                                      when sc.indexed_status = rslt.allowed_status || rslt.lang_id || rslt.svc_id || utl.get_constant_value('c_generic_make_id')
                                      then 2
                                      when sc.indexed_status = rslt.allowed_status || rslt.lang_id || rslt.make_id
                                      then 3
                                      when sc.indexed_status = rslt.allowed_status || rslt.lang_id || utl.get_constant_value('c_generic_make_id')
                                      then 4
                                      else null
                                    end as msg_match
                               FROM beowner.status_code sc
                              WHERE sc.indexed_status IS NOT null) msg) msg_rank
                 where msg_match = match_min;    
                 

                BEGIN
                    -- Moved below for REL-154, just to be able to repro the issue
                    IF utl.g_test_mode_on()
                    THEN
                        vcnt := vcnt + 1;

                        IF vcnt = 2
                        THEN
                            RAISE no_data_found;
                        END IF;
                    END IF;

                -- /* Moved exception above for REL-154. Added extra logging */
                EXCEPTION
                    WHEN no_data_found THEN
                        IF COALESCE(utl.getconfig('LOG ACL NO_DATA_FOUND ERRORS'),'N') = 'Y'
                        THEN
                            call trc.log('User=' || rslt.usr_id || ',VIN=' ||
                                rslt.vin || ',Service=' || rslt.svc_id );
                        END IF;
                        RAISE EXCEPTION USING errcode=utl.get_constant_value('cinternalerror');
                END;
            END IF;

            /* finally, send the row back */
            /* Excluded future subscriptions for OnTime WI #14078. Always available services should still be returned */
            /* Added a second for Jira SBM-294, as precision on sub_start is just seconds, so gets rounded up */

            IF rslt.sub_start <= rslt.tmstmp + '1 second'::interval
            OR valwaysavailable = user_subscription.gtrue()
            THEN
                RETURN NEXT rslt;
            END IF;
        END LOOP svcloop;

    END LOOP mainloop;
    CLOSE cx;
    return;
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;

