SET bedb.filename = 'function.loadcreds.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS user_subscription.loadcreds(uuid, text);
CREATE OR REPLACE FUNCTION user_subscription.loadcreds(IN iusrid uuid,
                                                       IN isvcid text,
                                                       OUT ocreds user_subscription.tcredinf)
AS
$BODY$
BEGIN

    ocreds := array_cat(ocreds,
                         (select array_agg(inf.credinf)::user_subscription.tcredinf as tcredinf
                            from (select (ui.svc_id, count(*))::user_subscription.credinf as credinf
                                    from beowner.usr_inf as ui
                                   where ui.usr_id = iusrid
                                     and ui.svc_id = COALESCE(isvcid, ui.svc_id)
                                     and ui.key_id = 'loginID'
                                group by ui.svc_id) as inf));

END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
