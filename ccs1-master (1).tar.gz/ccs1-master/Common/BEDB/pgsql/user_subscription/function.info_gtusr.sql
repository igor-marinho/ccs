SET bedb.filename = 'function.info_gtusr.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS user_subscription.info_gtusr(); 
   /*
       The GT_USR version. This one allows us to look at subscription information for
       multiple users at at time. You first insert into GT_USR (a Global Temporary table)
       then execute the query. It retrieves all subscription data for all specified
       users (and all VINs associated with them)

       Example:

       insert into gt_usr (usr_id)
         select usr_id
           from usr
           where x = y;

       select *
         from table(user_subscription.info_gtusr());

   */

CREATE OR REPLACE FUNCTION user_subscription.info_gtusr () RETURNS SETOF user_subscription.recinfo AS $body$
DECLARE
  cx RECORD;
  x2 RECORD;
BEGIN
      FOR cx IN (SELECT usr_id
                   FROM beowner.gt_usr)
      LOOP
         FOR x2 IN SELECT *
                      FROM user_subscription.info(cx.usr_id, NULL)
         LOOP
                RETURN NEXT x2;
         END LOOP;
      END LOOP;

      RETURN;
   END;
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION user_subscription.info_gtusr () FROM PUBLIC;

\i cleanup.sql;
