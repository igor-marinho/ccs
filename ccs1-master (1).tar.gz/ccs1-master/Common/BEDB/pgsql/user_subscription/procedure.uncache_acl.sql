SET bedb.filename = 'function.uncache_acl.sql';

\i set_be_env.sql;

DROP PROCEDURE if exists user_subscription.uncache_acl(uuid, bool);

CREATE OR REPLACE PROCEDURE user_subscription.uncache_acl (i_usr_id usr.usr_id%TYPE, i_include_secondary boolean DEFAULT TRUE) AS $body$
BEGIN

      IF utl.is_acl_cached() = utl.get_constant_value('c_yes')
      THEN

         DELETE FROM usr_acl
          WHERE usr_id = i_usr_id;

         IF i_include_secondary
         THEN
            DELETE FROM usr_acl a
             WHERE a.usr_id IN (SELECT u.usr_id
                                  FROM usr u
                                 WHERE u.parent_id = i_usr_id);
         END IF;
      END IF;

   END;

$body$
LANGUAGE PLPGSQL
;

\i cleanup.sql;
