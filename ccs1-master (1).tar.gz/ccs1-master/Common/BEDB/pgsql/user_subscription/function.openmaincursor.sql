SET bedb.filename = 'function.openmaincursor.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS user_subscription.openmaincursor(uuid, text, text);
-- Removed column mac_addr for DCS1E-921
-- Removed columns renewal_length,conflict_length for DCS1E-1002
CREATE OR REPLACE FUNCTION user_subscription.openmaincursor(IN iusrid 	uuid DEFAULT NULL,
                                                            IN ivin 	text DEFAULT NULL,
                                                            IN isvcid 	text DEFAULT NULL) RETURNS refcursor
AS $BODY$
DECLARE
    rslt refcursor; -- := 'cursor1'; --postgres can name a cursor, this is called portal name in the docs, and seems to be a descrption used for the underlying postgres network protocol.
    --this name essentially allows the use of the fetch all syntax, i.e. "FETCH ALL cursor1;"
/*
DDCRD-525
When getting ACL information only get data for the given service if one is provided.
*/
/* We're opening the same data, just variations on a theme. */
/* !! The cursor signatures must be the same on all queries !! */
/* if iUsrID and iVIN is filled out, and the user has a valid subscription... */
/*
OnTime WI #15749 - for all selects where user id is provided -
     Subscription select modified to include outer join with subscription_users;
primary_id selected directly from subscription table in the select list
*/
BEGIN

    IF iusrid IS NOT NULL
        AND ivin IS NOT NULL
        AND user_subscription.subscriptioninfoexists(iusrid, ivin) THEN
        IF utl.is_user_relation_static()
        THEN
            OPEN rslt FOR
                SELECT u.usr_id,
                       coalesce(u.parent_id, u.usr_id)                 primary_id,
                       u.login_id,
                       u.make_id,
                       u.created,
                       u.verified,
                       u.lang_id,
                       u.locked,
                       u.pwd,
                       s.vin,
                       s.bndl_id,
                       s.sub_start,
                       s.sub_duration,
                       v.device_id,
                       v.factory_flag,
                       v.dealer_flag,
                       v.dofu,
                       b.name                                          bundle_name,
                       b.description                                   bundle_description,
                       b.payment_type,
                       b.bundle_length,
                       b.grace_length,
                       b.max_users,
                       s.conflict,
                       v.contract_id                                   vin_contract_id,
                       v.meid,
                       c.contract_owner,
                       c.extrnl_ctrct_id,
                       c.expired,
                       s.optin_level,
                       s.contract_id                                   sub_contract_id,
                       s.contract_tmstmp,
                       s.nickname,
                       b.dev_only_bndl,
                       (SELECT COALESCE(array_agg((bs.svc_id,
                                                   bs.allowed_status,
                                                   s1.name,
                                                   s1.description,
                                                   s1.handler,
                                                   s1.auth,
                                                   bs.optin_level,
                                                   s1.contract_required,
                                                   s1.allow_secondary,
                                                   s1.never_expires,
                                                   s1.always_available,
                                                   s1.deprecated)::user_subscription.svc_info), '{}') AS svc_info
                        FROM beowner.bndlsvc bs
                                 JOIN beowner.svc s1
                                      ON s1.svc_id = bs.svc_id
                        WHERE bs.bndl_id = s.bndl_id
                          AND s1.svc_id = coalesce(isvcid, s1.svc_id)) bs,
                       (SELECT COUNT(*) vincount
                        WHERE EXISTS
                                  (SELECT NULL
                                   FROM beowner.subscription ss
                                            JOIN beowner.usr uu
                                                 ON uu.usr_id = ss.primary_id
                                   WHERE ss.vin = v.vin
                                     AND uu.verified IS NOT NULL))     vc
                FROM beowner.usr u
                         JOIN beowner.subscription s
                              ON s.primary_id = coalesce(u.parent_id, u.usr_id)
                         JOIN beowner.vin v
                              ON v.vin = s.vin
                         JOIN beowner.bndl b
                              ON b.bndl_id = s.bndl_id
                         LEFT JOIN beowner.contrct c
                                   ON c.contract_id = v.contract_id
                WHERE u.usr_id = iusrid
                  AND s.vin = ivin;
        ELSE

            OPEN rslt FOR
                SELECT u.usr_id,
                       s.primary_id,
                       u.login_id,
                       u.make_id,
                       u.created,
                       u.verified,
                       u.lang_id,
                       u.locked,
                       u.pwd,
                       s.vin,
                       s.bndl_id,
                       s.sub_start,
                       s.sub_duration,
                       v.device_id,
                       v.factory_flag,
                       v.dealer_flag,
                       v.dofu,
                       b.name                                          bundle_name,
                       b.description                                   bundle_description,
                       b.payment_type,
                       b.bundle_length,
                       b.grace_length,
                       b.max_users,
                       s.conflict,
                       v.contract_id                                   vin_contract_id,
                       v.meid,
                       c.contract_owner,
                       c.extrnl_ctrct_id,
                       c.expired,
                       s.optin_level,
                       s.contract_id                                   sub_contract_id,
                       s.contract_tmstmp,
                       s.nickname,
                       b.dev_only_bndl,
                       (SELECT COALESCE(array_agg((bs.svc_id,
                                                   bs.allowed_status,
                                                   s1.name,
                                                   s1.description,
                                                   s1.handler,
                                                   s1.auth,
                                                   bs.optin_level,
                                                   s1.contract_required,
                                                   s1.allow_secondary,
                                                   s1.never_expires,
                                                   s1.always_available,
                                                   s1.deprecated)::user_subscription.svc_info), '{}') AS svc_info
                        FROM beowner.bndlsvc bs
                                 JOIN beowner.svc s1
                                      ON s1.svc_id = bs.svc_id
                        WHERE bs.bndl_id = s.bndl_id
                          AND s1.svc_id = coalesce(isvcid, s1.svc_id)) bs,
                       (SELECT COUNT(*) vincount
                        WHERE EXISTS
                                  (SELECT NULL
                                   FROM beowner.subscription ss
                                            JOIN beowner.usr uu
                                                 ON uu.usr_id = ss.primary_id
                                   WHERE ss.vin = v.vin
                                     AND uu.verified IS NOT NULL))     vc
                FROM beowner.usr u
                         JOIN (SELECT primary_id usr_id,
                                      sp.*
                               FROM beowner.subscription sp
                               WHERE sp.primary_id = iusrid
                                 AND sp.vin = ivin
                               UNION ALL
                               SELECT su.secondary_id usr_id,
                                      sp.*
                               FROM beowner.subscription_users su,
                                    beowner.subscription sp
                               WHERE su.secondary_id = iusrid
                                 AND sp.subscription_id = su.subscription_id
                                 AND sp.vin = ivin) s
                              ON s.usr_id = u.usr_id
                         JOIN beowner.vin v
                              ON v.vin = s.vin
                         LEFT JOIN beowner.contrct c
                                   ON c.contract_id = v.contract_id
                         JOIN beowner.bndl b
                              ON b.bndl_id = s.bndl_id
                WHERE u.usr_id = iusrid
                  AND s.vin = ivin;
        END IF;
        RETURN rslt;
    END IF;
    /* if the user is supplied, and they have a valid subscription... */

    IF iusrid IS NOT NULL
        AND user_subscription.subscriptioninfoexists(iusrid)
    THEN
        IF utl.is_user_relation_static()
            /* old query */
        THEN

            OPEN rslt FOR
                SELECT u.usr_id,
                       coalesce(u.parent_id, u.usr_id)                 primary_id,
                       u.login_id,
                       u.make_id,
                       u.created,
                       u.verified,
                       u.lang_id,
                       u.locked,
                       u.pwd,
                       s.vin,
                       s.bndl_id,
                       s.sub_start,
                       s.sub_duration,
                       v.device_id,
                       v.factory_flag,
                       v.dealer_flag,
                       v.dofu,
                       b.name                                          bundle_name,
                       b.description                                   bundle_description,
                       b.payment_type,
                       b.bundle_length,
                       b.grace_length,
                       b.max_users,
                       s.conflict,
                       v.contract_id                                   vin_contract_id,
                       v.meid,
                       c.contract_owner,
                       c.extrnl_ctrct_id,
                       c.expired,
                       s.optin_level,
                       s.contract_id                                   sub_contract_id,
                       s.contract_tmstmp,
                       s.nickname,
                       b.dev_only_bndl,
                       (SELECT COALESCE(array_agg((bs.svc_id,
                                                   bs.allowed_status,
                                                   s1.name,
                                                   s1.description,
                                                   s1.handler,
                                                   s1.auth,
                                                   bs.optin_level,
                                                   s1.contract_required,
                                                   s1.allow_secondary,
                                                   s1.never_expires,
                                                   s1.always_available,
                                                   s1.deprecated)::user_subscription.svc_info), '{}') AS svc_info
                        FROM beowner.bndlsvc bs
                                 JOIN beowner.svc s1
                                      ON s1.svc_id = bs.svc_id
                        WHERE bs.bndl_id = s.bndl_id
                          AND s1.svc_id = coalesce(isvcid, s1.svc_id)) bs,
                       (SELECT COUNT(*) vincount
                        WHERE EXISTS
                                  (SELECT NULL
                                   FROM beowner.subscription ss
                                            JOIN beowner.usr uu
                                                 ON uu.usr_id = ss.primary_id
                                   WHERE ss.vin = v.vin
                                     AND uu.verified IS NOT NULL))     vc
                FROM beowner.usr u
                         JOIN beowner.subscription s
                              ON s.primary_id = coalesce(u.parent_id, u.usr_id)
                         JOIN beowner.vin v
                              ON v.vin = s.vin
                         JOIN beowner.bndl b
                              ON b.bndl_id = s.bndl_id
                         LEFT JOIN beowner.contrct c
                                   ON c.contract_id = v.contract_id
                WHERE u.usr_id = iusrid;
            /* new query */
        ELSE

            OPEN rslt FOR
                SELECT u.usr_id,
                       s.primary_id,
                       u.login_id,
                       u.make_id,
                       u.created,
                       u.verified,
                       u.lang_id,
                       u.locked,
                       u.pwd,
                       s.vin,
                       s.bndl_id,
                       s.sub_start,
                       s.sub_duration,
                       v.device_id,
                       v.factory_flag,
                       v.dealer_flag,
                       v.dofu,
                       b.name                                          bundle_name,
                       b.description                                   bundle_description,
                       b.payment_type,
                       b.bundle_length,
                       b.grace_length,
                       b.max_users,
                       s.conflict,
                       v.contract_id                                   vin_contract_id,
                       v.meid,
                       c.contract_owner,
                       c.extrnl_ctrct_id,
                       c.expired,
                       s.optin_level,
                       s.contract_id                                   sub_contract_id,
                       s.contract_tmstmp,
                       s.nickname,
                       b.dev_only_bndl,
                       (SELECT COALESCE(array_agg((bs.svc_id,
                                                   bs.allowed_status,
                                                   s1.name,
                                                   s1.description,
                                                   s1.handler,
                                                   s1.auth,
                                                   bs.optin_level,
                                                   s1.contract_required,
                                                   s1.allow_secondary,
                                                   s1.never_expires,
                                                   s1.always_available,
                                                   s1.deprecated)::user_subscription.svc_info), '{}') AS svc_info
                        FROM beowner.bndlsvc bs
                                 JOIN beowner.svc s1
                                      ON s1.svc_id = bs.svc_id
                        WHERE bs.bndl_id = s.bndl_id
                          AND s1.svc_id = coalesce(isvcid, s1.svc_id)) bs,
                       (SELECT COUNT(*) vincount
                        WHERE EXISTS
                                  (SELECT NULL
                                   FROM beowner.subscription ss
                                            JOIN beowner.usr uu
                                                 ON uu.usr_id = ss.primary_id
                                   WHERE ss.vin = v.vin
                                     AND uu.verified IS NOT NULL))     vc
                FROM beowner.usr u
                         JOIN (SELECT primary_id usr_id,
                                      sp.*
                               FROM beowner.subscription sp
                               WHERE sp.primary_id = iusrid
                               UNION ALL
                               SELECT su.secondary_id usr_id,
                                      sp.*
                               FROM beowner.subscription_users su,
                                    beowner.subscription sp
                               WHERE su.secondary_id = iusrid
                                 AND sp.subscription_id = su.subscription_id) s
                              ON s.usr_id = u.usr_id
                         JOIN beowner.vin v
                              ON v.vin = s.vin
                         JOIN beowner.bndl b
                              ON b.bndl_id = s.bndl_id
                         LEFT JOIN beowner.contrct c
                                   ON c.contract_id = v.contract_id
                WHERE u.usr_id = iusrid;
        END IF;
        RETURN rslt;
    END IF;
    /* if VIN is supplied... */

    IF ivin IS NOT NULL
        /* same query, unchanged earlier */
    THEN

        OPEN rslt FOR
            SELECT u.usr_id,
                   coalesce(u.parent_id, u.usr_id)                 primary_id,
                   u.login_id,
                   u.make_id,
                   u.created,
                   u.verified,
                   u.lang_id,
                   u.locked,
                   u.pwd,
                   s.vin,
                   s.bndl_id,
                   s.sub_start,
                   s.sub_duration,
                   v.device_id,
                   v.factory_flag,
                   v.dealer_flag,
                   v.dofu,
                   b.name                                          bundle_name,
                   b.description                                   bundle_description,
                   b.payment_type,
                   b.bundle_length,
                   b.grace_length,
                   b.max_users,
                   s.conflict,
                   v.contract_id                                   vin_contract_id,
                   v.meid,
                   c.contract_owner,
                   c.extrnl_ctrct_id,
                   c.expired,
                   s.optin_level,
                   s.contract_id                                   sub_contract_id,
                   s.contract_tmstmp,
                   s.nickname,
                   b.dev_only_bndl,
                   (SELECT COALESCE(array_agg((bs.svc_id,
                                               bs.allowed_status,
                                               s1.name,
                                               s1.description,
                                               s1.handler,
                                               s1.auth,
                                               bs.optin_level,
                                               s1.contract_required,
                                               s1.allow_secondary,
                                               s1.never_expires,
                                               s1.always_available,
                                               s1.deprecated)::user_subscription.svc_info), '{}') AS svc_info
                    FROM beowner.bndlsvc bs
                             JOIN beowner.svc s1
                                  ON s1.svc_id = bs.svc_id
                    WHERE bs.bndl_id = s.bndl_id
                      AND s1.svc_id = coalesce(isvcid, s1.svc_id)) bs,
                   (SELECT COUNT(*) vincount
                    WHERE EXISTS
                              (SELECT NULL
                               FROM beowner.subscription ss
                                        JOIN beowner.usr uu
                                             ON uu.usr_id = ss.primary_id
                               WHERE ss.vin = v.vin
                                 AND uu.verified IS NOT NULL))     vc
            FROM beowner.usr u
                     JOIN beowner.subscription s
                          ON s.primary_id = u.usr_id
                     JOIN beowner.vin v
                          ON v.vin = s.vin
                     JOIN beowner.bndl b
                          ON b.bndl_id = s.bndl_id
                     LEFT JOIN beowner.contrct c
                               ON c.contract_id = v.contract_id
            WHERE s.vin = ivin;
        RETURN rslt;
    END IF;
    /* we either have a NULL iUsrID, or the iUsrID doesn't have a subscription. */
    /* this query is the "catch-all" that synthesizes Head-Unit Update and User-Portal ACL access. */
    /* if iUsrID is null or is non-existant, this query returns no rows. */

    IF utl.is_user_relation_static()
        /* old query */
    THEN

        OPEN rslt FOR
            SELECT usr_id,
                   primary_id,
                   login_id,
                   make_id,
                   created,
                   verified,
                   lang_id,
                   locked,
                   pwd,
                   vin,
                   bndl_id,
                   dofu                                      sub_start,
                   all_length                                sub_duration,
                   device_id,
                   flag                                      factory_flag,
                   flag                                      dealer_flag,
                   dofu,
                   bndl_text                                 bundle_name,
                   bndl_text                                 bundle_description,
                   payment_type,
                   all_length                                bundle_length,
                   all_length                                grace_length,
                   max_users,
                   dofu AS                                   conflict,
                   contract_id                               vin_contract_id,
                   meid,
                   contract_owner,
                   extrnl_ctrct_id,
                   expired,
                   optin_level,
                   contract_id                               sub_contract_id,
                   contract_tmstmp,
                   nickname,
                   dev_only_bndl,
                   (SELECT COALESCE(array_agg((svc_id,
                                               '1',
                                               NAME,
                                               description,
                                               handler,
                                               auth,
                                               0,
                                               contract_required,
                                               allow_secondary,
                                               never_expires,
                                               always_available,
                                               deprecated)::user_subscription.svc_info), '{}') AS svc_info
                    FROM beowner.svc
                    WHERE always_available = user_subscription.gtrue()
                      AND svc_id = coalesce(isvcid, svc_id)) bs,
                   (SELECT 0 vincount)                       vc
            FROM (SELECT usr_id,
                         coalesce(parent_id, usr_id)            primary_id,
                         login_id,
                         make_id,
                         created,
                         verified,
                         lang_id,
                         locked,
                         pwd,
                         CAST(NULL AS varchar(17))              vin,
                         CAST(NULL AS uuid)                     bndl_id,
                         CAST(NULL AS interval DAY TO SECOND)   all_length,
                         CAST(NULL AS varchar(1))               bndl_text,
                         CAST(NULL AS varchar(3))               device_id,
                         CAST(NULL AS varchar(1))               flag,
                         CAST(NULL AS timestamp WITH TIME ZONE) dofu,
                         CAST(NULL AS varchar(1))               payment_type,
                         CAST(1 AS integer)                     max_users,
                         CAST(NULL AS bytea)                    contract_id,
                         CAST(NULL AS varchar(20))              contract_owner,
                         CAST(NULL AS varchar(20))              extrnl_ctrct_id,
                         CAST(NULL AS varchar(20))              meid,
                         CAST(NULL AS timestamp WITH TIME ZONE) expired,
                         CAST(0 AS integer)                     optin_level,
                         CAST(NULL AS timestamp WITH TIME ZONE) contract_tmstmp,
                         CAST(NULL AS varchar(60))              nickname,
                         CAST(NULL AS varchar(1))               dev_only_bndl
                  FROM beowner.usr
                  WHERE usr_id = iusrid) u;
    ELSE

        OPEN rslt FOR
            SELECT usr_id,
                   primary_id,
                   login_id,
                   make_id,
                   created,
                   verified,
                   lang_id,
                   locked,
                   pwd,
                   vin,
                   bndl_id,
                   dofu                                      sub_start,
                   all_length                                sub_duration,
                   device_id,
                   flag                                      factory_flag,
                   flag                                      dealer_flag,
                   dofu,
                   bndl_text                                 bundle_name,
                   bndl_text                                 bundle_description,
                   payment_type,
                   all_length                                bundle_length,
                   all_length                                grace_length,
                   max_users,
                   dofu AS                                   conflict,
                   contract_id                               vin_contract_id,
                   meid,
                   contract_owner,
                   extrnl_ctrct_id,
                   expired,
                   optin_level,
                   contract_id                               sub_contract_id,
                   contract_tmstmp,
                   nickname,
                   dev_only_bndl,
                   (SELECT COALESCE(array_agg((svc_id,
                                               '1',
                                               NAME,
                                               description,
                                               handler,
                                               auth,
                                               0,
                                               contract_required,
                                               allow_secondary,
                                               never_expires,
                                               always_available,
                                               deprecated)::user_subscription.svc_info), '{}') AS svc_info
                    FROM beowner.svc
                    WHERE always_available = user_subscription.gtrue()
                      AND svc_id = coalesce(isvcid, svc_id)) bs,
                   (SELECT 0 vincount)                       vc
            FROM (SELECT usr_id,
                         coalesce(su.primary_id, u.usr_id)      primary_id,
                         login_id,
                         make_id,
                         created,
                         verified,
                         lang_id,
                         locked,
                         pwd,
                         CAST(NULL AS varchar(17))              vin,
                         CAST(NULL AS uuid)                     bndl_id,
                         CAST(NULL AS interval DAY TO SECOND)   all_length,
                         CAST(NULL AS varchar(1))               bndl_text,
                         CAST(NULL AS varchar(3))               device_id,
                         CAST(NULL AS varchar(1))               flag,
                         CAST(NULL AS timestamp WITH TIME ZONE) dofu,
                         CAST(NULL AS varchar(1))               payment_type,
                         CAST(1 AS integer)                     max_users,
                         CAST(NULL AS bytea)                    contract_id,
                         CAST(NULL AS varchar(20))              contract_owner,
                         CAST(NULL AS varchar(20))              extrnl_ctrct_id,
                         CAST(NULL AS varchar(20))              meid,
                         CAST(NULL AS timestamp WITH TIME ZONE) expired,
                         CAST(0 AS integer)                     optin_level,
                         CAST(NULL AS timestamp WITH TIME ZONE) contract_tmstmp,
                         CAST(NULL AS varchar(60))              nickname,
                         CAST(NULL AS varchar(1))               dev_only_bndl
                  FROM beowner.usr u
                           LEFT JOIN beowner.subscription_users su
                                     ON (su.secondary_id = iusrid
                                         AND u.usr_id = su.secondary_id)
                  WHERE u.usr_id = iusrid) ud;
    END IF;
    RETURN rslt;
END;
$BODY$
LANGUAGE plpgsql;

\i cleanup.sql;
