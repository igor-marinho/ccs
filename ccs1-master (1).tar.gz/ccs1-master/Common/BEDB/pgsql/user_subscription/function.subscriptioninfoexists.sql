SET bedb.filename = 'function.subscriptioninfoexists.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION user_subscription.subscriptioninfoexists(IN iusrid UUID, IN ivin TEXT)
RETURNS BOOLEAN
AS
$BODY$
DECLARE
    vcount INTEGER;
BEGIN
    
    SELECT
        COUNT(*)
        INTO STRICT vcount
        FROM (SELECT
            NULL
            FROM beowner.usr AS u
            JOIN beowner.subscription AS s
              ON s.primary_id = COALESCE(u.parent_id, u.usr_id)
            WHERE u.usr_id = iusrid
              AND s.vin = ivin
        /* OnTime WI #15749 */
        UNION ALL
        SELECT
            NULL
            FROM beowner.usr AS u
            JOIN beowner.subscription_users AS su
                ON su.secondary_id = u.usr_id
            WHERE case
                    when utl.is_user_relation_static()
                    then utl.get_constant_value('c_yes')
                    else utl.get_constant_value('c_no')
                  end = utl.get_constant_value('c_no')
              AND u.usr_id = iusrid
              AND su.vin = ivin) AS var_sbq;

    RETURN vcount > 0;
    /* OnTime WI #15749 */
END;
$BODY$
LANGUAGE  plpgsql;

CREATE OR REPLACE FUNCTION user_subscription.subscriptioninfoexists(IN iusrid UUID)
RETURNS BOOLEAN
AS
$BODY$
DECLARE
    vcount INTEGER;
BEGIN
    
    SELECT
        COUNT(*)
        INTO STRICT vcount
        FROM (SELECT
            NULL
            FROM beowner.usr AS u
            JOIN beowner.subscription AS s
                ON s.primary_id = COALESCE(u.parent_id, u.usr_id)
            WHERE u.usr_id = iusrid
        /* OnTime WI #15749 */
        UNION ALL
        SELECT
            NULL
            FROM beowner.usr AS u
            JOIN beowner.subscription_users AS su
              ON su.secondary_id = u.usr_id
            WHERE case
                    when utl.is_user_relation_static()
                    then utl.get_constant_value('c_yes')
                    else utl.get_constant_value('c_no')
                  end = utl.get_constant_value('c_no')
              AND u.usr_id = iusrid) AS var_sbq;

    RETURN vcount > 0;
    /* OnTime WI #15749 */
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
