SET bedb.filename = 'function.gtrue.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION user_subscription.gtrue() RETURNS varchar as $body$
begin
  return '*'; -- True
END;
$body$
LANGUAGE PLPGSQL
IMMUTABLE;

\i cleanup.sql;
