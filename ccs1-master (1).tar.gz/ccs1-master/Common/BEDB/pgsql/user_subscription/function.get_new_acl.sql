SET bedb.filename = 'function.get_new_acl.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS user_subscription.get_new_acl();
   -- Jira SBM-124
CREATE OR REPLACE FUNCTION user_subscription.get_new_acl(OUT o_acl_rec beowner.usr_acl)
AS
$BODY$
BEGIN
    SELECT cd.usr_id AS usr_id,
           a.rslt AS acl_xml,
           extensions.digest(a.rslt, 'sha1') AS acl_token
      INTO STRICT o_acl_rec.usr_id, o_acl_rec.acl_xml, o_acl_rec.acl_token
      FROM beowner.acl AS a
      CROSS JOIN beowner.ctx_data AS cd;
END;
$BODY$
LANGUAGE  plpgsql;


\i cleanup.sql;
