SET bedb.filename = 'function.get_acl.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS user_subscription.get_acl(text);
DROP FUNCTION IF EXISTS user_subscription.get_acl(text);

/* Jira SBM-110
  The ctx must be set before using this procedure.
  Rename for Jira SBM-124
*/
CREATE OR REPLACE FUNCTION user_subscription.get_acl(i_acl_token IN beowner.usr_acl.acl_token%TYPE, o_acl_rec OUT BEOWNER.usr_acl, OUT o_status text)
AS
$BODY$
BEGIN

    IF utl.is_acl_cached() = utl.get_constant_value('c_yes')
    THEN
        BEGIN
            SELECT
                ua.usr_id,
                CASE
                    WHEN ua.acl_token = i_acl_token THEN NULL
                    ELSE ua.acl_xml
                END AS acl_xml,
                ua.acl_token
                INTO STRICT o_acl_rec.usr_id, o_acl_rec.acl_xml, o_acl_rec.acl_token
                FROM beowner.usr_acl AS ua
                JOIN beowner.ctx_data AS cd
                    ON (cd.usr_id = ua.usr_id);
            EXCEPTION
                WHEN no_data_found
                then
                
                    select *
                      FROM user_subscription.get_new_acl()
                      INTO o_acl_rec;

                    INSERT INTO beowner.usr_acl
                    VALUES (o_acl_rec.*);
        END;
    ELSE
        SELECT *
          FROM user_subscription.get_new_acl()
         INTO o_acl_rec;
    END if;
    /* Jira CBM-625 */
    /* ACL did not actually change, i.e. 3pp credentials were updated, */
    /* so still return a NULL ACL and 203. */

    IF UPPER(encode(o_acl_rec.acl_token, 'hex')) = UPPER(encode(i_acl_token, 'escape'))
     THEN
        o_acl_rec.acl_xml := NULL;
    END if;
    /* assume processing was sucessful, this may change with future functionality */
    o_status := utl.get_constant_value('csuccess');
RETURN;
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
