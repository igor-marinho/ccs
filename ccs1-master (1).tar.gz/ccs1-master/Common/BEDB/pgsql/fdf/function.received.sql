SET bedb.filename = 'function.received.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS fdf.received("text",uuid);

CREATE OR REPLACE FUNCTION fdf.received(ifilename text, 
										ijoblogid text) 
										RETURNS varchar 
AS $body$
DECLARE
    l_action TEXT;
    l_module_name TEXT := 'received';
	l_joblogid beowner.fdf_job_log.fjl_staging_job_log_guid%TYPE :=  ijoblogid::UUID;
    vcount INTEGER;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      PERFORM set_config('fdf.gresult', utl.get_constant_value('csuccess'), false);
      PERFORM set_config('fdf.gmessage', 'Success', false);

      -- Added calls to debug_log for OnTime #23373
      l_action := utl.set_module_action(l_module_name, ' Updating Source Load Date');

      CALL utl.debug_log('STARTED fdf.received() for job log guid : ' || ijoblogid ||', file : ' || ifilename);

      UPDATE beowner.fdf_staging
         SET fs_source_load_date = clock_timestamp()
       WHERE fs_staging_job_log_guid = l_joblogid
             AND fs_source_load_date IS NULL;

      CALL utl.debug_log('Updated fdf_staging.fs_source_load_date');

      CALL utl.debug_log('Calling scrub');
      CALL fdf.scrub(l_joblogid);

      CALL utl.debug_log('Calling update_log');
      CALL fdf.update_log(l_joblogid);

      CALL utl.debug_log('Calling load_vins');
      vcount := fdf.load_vins(l_joblogid);

      CALL utl.debug_log('Calling load_external_vins');
      vcount := vcount + fdf.load_external_vins(i_job_log_guid => l_joblogid);

      CALL utl.debug_log('Calling save_old_data');
      CALL fdf.save_old_data(l_joblogid);

      IF vcount = 0
      THEN
         l_action := utl.set_action(' No Data Found');
         PERFORM set_config('fdf.gresult', utl.get_constant_value ('cdbnogooddataloadexception'), false);
         PERFORM set_config('fdf.gmessage', 'No usable data was found in this FDF load', false);
      END IF;

      l_action := utl.set_action(' Setting final data for FDF_JOB_LOG');

      CALL utl.debug_log('Final update on fdf_job_log');

      UPDATE fdf_job_log
         SET fjl_status_code = current_setting('fdf.gresult')::INTEGER,
             fjl_process_msg = current_setting('fdf.gmessage'),
             fjl_filename    = ifilename
       WHERE fjl_staging_job_log_guid = l_joblogid;

      CALL utl.debug_log('ENDED fdf.received() for job log guid : ' || ijoblogid ||
                    ' with return value ' || current_setting('fdf.gresult'));

      RETURN current_setting('fdf.gresult');
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

         CALL trc.log(iadditionaldata        => NULL,
                     iexception_diagnostics => l_exception_diagnostics);

         PERFORM ctx.set(iptnrid    =>NULL,
                        iloginid    =>NULL,
                        iusrid      =>NULL,
                        imakeid     =>'TM',
                        ivin        =>NULL,
                        itranid     =>NULL,
                        itrannm     =>NULL,
                        itranstepnm =>NULL,
                        ivendortid  =>NULL); --Ontime #23321
         CALL utl.debug_log('Sending others exception email');

         RETURN utl.get_constant_value('cinternalerror');
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;

-- REVOKE ALL ON FUNCTION fdf.received (ifilename text, ijoblogid fdf_job_log.fjl_staging_job_log_guid%TYPE) FROM PUBLIC;

\i cleanup.sql;
