SET bedb.filename = 'procedure.update_log.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS fdf.update_log(uuid);
CREATE OR REPLACE PROCEDURE fdf.update_log (ijoblogid fdf_job_log.fjl_staging_job_log_guid%TYPE) AS $body$
DECLARE
      l_action text;
      l_module_name text := 'update_log';
	  cfalse VARCHAR(1) := utl.get_constant_value ('cfdffalse');
      ctrue  VARCHAR(1) := utl.get_constant_value ('cfdftrue');
BEGIN
      l_action := utl.set_module_action( l_module_name, ' Updating FDF_JOB_LOG');

      CALL utl.debug_log('Updating fdf_job_log for flags');

      UPDATE fdf_job_log
         SET(fjl_num_of_invalid_vin,
              fjl_num_of_dup_vins_infile,
              fjl_num_of_dup_vins_indb,
              fjl_num_of_invalid_hu_code,
              fjl_num_of_invalid_hu_desc,
              fjl_num_of_ivalid_make,
              fjl_num_of_invalid_model,
              fjl_num_of_invalid_model_code,
              fjl_num_of_invalid_model_year,
              fjl_num_of_invalid_car_color) =
             (SELECT SUM(CASE fs_invalid_vins_flag
                            WHEN ctrue THEN
                             1
                            ELSE
                             0
                         END) num_invalid_vins,
                     SUM(CASE fs_duplicate_vins_infile_flag
                            WHEN ctrue THEN
                             1
                            ELSE
                             0
                         END) num_duplicate_vins_infile,
                     SUM(CASE fs_duplicate_vins_indb_flag
                            WHEN ctrue THEN
                             1
                            ELSE
                             0
                         END) num_duplicate_vins_indb,
                     SUM(CASE fs_invalid_headunit_code_flag
                            WHEN ctrue THEN
                             1
                            ELSE
                             0
                         END) num_invalid_headunit_code,
                     SUM(CASE fs_invalid_headunit_desc_flag
                            WHEN ctrue THEN
                             1
                            ELSE
                             0
                         END) num_invalid_headunit_desc,
                     SUM(CASE fs_invalid_make_flag
                            WHEN ctrue THEN
                             1
                            ELSE
                             0
                         END) num_invalid_make,
                     SUM(CASE fs_invalid_model_flag
                            WHEN ctrue THEN
                             1
                            ELSE
                             0
                         END) num_invalid_model,
                     SUM(CASE fs_invalid_model_code_flag
                            WHEN ctrue THEN
                             1
                            ELSE
                             0
                         END) num_invalid_model_code,
                     SUM(CASE fs_invalid_model_year_flag
                            WHEN ctrue THEN
                             1
                            ELSE
                             0
                         END) num_invalid_model_year,
                     SUM(CASE fs_invalid_vehicle_color_flag
                            WHEN ctrue THEN
                             1
                            ELSE
                             0
                         END) num_invalid_vehicle_color
                FROM fdf_staging
               WHERE fs_staging_job_log_guid = ijoblogid)
       WHERE fjl_staging_job_log_guid = ijoblogid;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE fdf.update_log (ijoblogid fdf_job_log.fjl_staging_job_log_guid%TYPE) FROM PUBLIC;

\i cleanup.sql;
