SET bedb.filename = 'procedure.save_old_data.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS fdf.save_old_data(uuid);
CREATE OR REPLACE PROCEDURE fdf.save_old_data (ijoblogid fdf_job_log.fjl_staging_job_log_guid%TYPE) AS $body$
DECLARE
    l_action TEXT;
    l_module_name text := 'save_old_data';
    vquestionrows integer;
	cfalse VARCHAR(1) := utl.get_constant_value ('cfdffalse');
    ctrue  VARCHAR(1) := utl.get_constant_value ('cfdftrue');
BEGIN
      l_action := utl.set_module_action( l_module_name,' Saving FDF History/Questions');

      CALL utl.debug_log('Inserting into hist or ques');

        INSERT INTO beowner.fdf_staging_ques (fs_record_id
                                             ,fs_vin
                                             ,fs_interface_unique_id
                                             ,fs_interface_line_number
                                             ,fs_headunit_code
                                             ,fs_headunit_desc
                                             ,fs_make
                                             ,fs_model
                                             ,fs_model_code
                                             ,fs_model_year
                                             ,fs_vehicle_color
                                             ,fs_invalid_vins_flag
                                             ,fs_duplicate_vins_infile_flag
                                             ,fs_duplicate_vins_indb_flag
                                             ,fs_invalid_headunit_code_flag
                                             ,fs_invalid_headunit_desc_flag
                                             ,fs_invalid_make_flag
                                             ,fs_invalid_model_flag
                                             ,fs_invalid_model_code_flag
                                             ,fs_invalid_model_year_flag
                                             ,fs_invalid_vehicle_color_flag
                                             ,fs_filler
                                             ,fs_source_load_date
                                             ,fs_staging_job_log_guid
                                             ,fs_meid)
            SELECT fs_record_id
                  ,fs_vin
                  ,fs_interface_unique_id
                  ,fs_interface_line_number
                  ,fs_headunit_code
                  ,fs_headunit_desc
                  ,fs_make
                  ,fs_model
                  ,fs_model_code
                  ,fs_model_year
                  ,fs_vehicle_color
                  ,fs_invalid_vins_flag
                  ,fs_duplicate_vins_infile_flag
                  ,fs_duplicate_vins_indb_flag
                  ,fs_invalid_headunit_code_flag
                  ,fs_invalid_headunit_desc_flag
                  ,fs_invalid_make_flag
                  ,fs_invalid_model_flag
                  ,fs_invalid_model_code_flag
                  ,fs_invalid_model_year_flag
                  ,fs_invalid_vehicle_color_flag
                  ,fs_filler
                  ,fs_source_load_date
                  ,fs_staging_job_log_guid
                  ,fs_meid
              FROM beowner.fdf_staging fs
             WHERE fs_staging_job_log_guid = ijoblogid
			 and (fs_invalid_vins_flag = ctrue
			   OR fs_duplicate_vins_infile_flag = ctrue
			   OR fs_invalid_headunit_code_flag = ctrue
			   OR fs_invalid_make_flag = ctrue
			   OR fs_invalid_model_flag = ctrue
			   OR fs_invalid_model_code_flag = ctrue
			   OR fs_invalid_model_year_flag = ctrue
			   OR fs_invalid_vehicle_color_flag = ctrue)
			 ;

        INSERT INTO beowner.fdf_staging_hist (fs_record_id
                                             ,fs_vin
                                             ,fs_interface_unique_id
                                             ,fs_interface_line_number
                                             ,fs_headunit_code
                                             ,fs_headunit_desc
                                             ,fs_make
                                             ,fs_model
                                             ,fs_model_code
                                             ,fs_model_year
                                             ,fs_vehicle_color
                                             ,fs_invalid_vins_flag
                                             ,fs_duplicate_vins_infile_flag
                                             ,fs_duplicate_vins_indb_flag
                                             ,fs_invalid_headunit_code_flag
                                             ,fs_invalid_headunit_desc_flag
                                             ,fs_invalid_make_flag
                                             ,fs_invalid_model_flag
                                             ,fs_invalid_model_code_flag
                                             ,fs_invalid_model_year_flag
                                             ,fs_invalid_vehicle_color_flag
                                             ,fs_filler
                                             ,fs_source_load_date
                                             ,fs_staging_job_log_guid
                                             ,fs_meid)
            SELECT fs_record_id
                  ,fs_vin
                  ,fs_interface_unique_id
                  ,fs_interface_line_number
                  ,fs_headunit_code
                  ,fs_headunit_desc
                  ,fs_make
                  ,fs_model
                  ,fs_model_code
                  ,fs_model_year
                  ,fs_vehicle_color
                  ,fs_invalid_vins_flag
                  ,fs_duplicate_vins_infile_flag
                  ,fs_duplicate_vins_indb_flag
                  ,fs_invalid_headunit_code_flag
                  ,fs_invalid_headunit_desc_flag
                  ,fs_invalid_make_flag
                  ,fs_invalid_model_flag
                  ,fs_invalid_model_code_flag
                  ,fs_invalid_model_year_flag
                  ,fs_invalid_vehicle_color_flag
                  ,fs_filler
                  ,fs_source_load_date
                  ,fs_staging_job_log_guid
                  ,fs_meid
              FROM beowner.fdf_staging fs
             WHERE fs_staging_job_log_guid = ijoblogid
			 and utl.check_device_external (i_device_id => fs_headunit_code) = utl.get_constant_value('c_no');

      CALL utl.debug_log('Counting from ques');

      SELECT COUNT(*)
        INTO STRICT vquestionrows
        FROM beowner.fdf_staging_ques
       WHERE fs_staging_job_log_guid = ijoblogid;

      IF vquestionrows > 0
      THEN
      PERFORM set_config('fdf.gresult', utl.get_constant_value('cdbrdrprocessduplicatevins'), false);
      PERFORM set_config('fdf.gmessage', 'There ' || CASE vquestionrows
														WHEN 1 THEN
														 'was 1 row'
														ELSE
														 'were ' || vquestionrows || ' rows'
													 END || ' in FDF_STAGE that did not validate for job ' ||
													 ijoblogid::TEXT, false);
      END IF;

      l_action := utl.set_action(' Deleting FDF Job Run');

      CALL utl.debug_log('Deleting from fdf_staging');

      DELETE FROM fdf_staging
       WHERE fs_staging_job_log_guid = ijoblogid;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE fdf.save_old_data (ijoblogid fdf_job_log.fjl_staging_job_log_guid%TYPE) FROM PUBLIC;

\i cleanup.sql;
