SET bedb.filename = 'procedure.scrub.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS fdf.scrub(beowner.fdf_job_log.fjl_staging_job_log_guid%TYPE);
CREATE OR REPLACE PROCEDURE fdf.scrub (ijoblogid beowner.fdf_job_log.fjl_staging_job_log_guid%TYPE) AS $body$
DECLARE
    l_action TEXT;
    l_module_name text := 'scrub';

    c1 CURSOR FOR
	SELECT * FROM beowner.fdf_staging
	 WHERE fs_staging_job_log_guid = ijoblogid
	FOR UPDATE OF  fdf_staging;
   
    l_external_device varchar(1);
	cfalse VARCHAR(1) := utl.get_constant_value ('cfdffalse');
    ctrue  VARCHAR(1) := utl.get_constant_value ('cfdftrue');

BEGIN
    
    l_action := utl.set_module_action(l_module_name, ' Scrubbing individual Rows');

      CALL utl.debug_log('Looping on fdf_staging');

      --Jira TMSCR10655-6: add logic for external vin validation
      FOR cr IN c1
      LOOP
         cr.fs_vin := upper(trim(both cr.fs_vin));
         CALL utl.debug_log('Adjusting values for VIN ' || cr.fs_vin);
         -- this all may not be necessary, but best not to take any chances
         cr.fs_headunit_code := upper(trim(both cr.fs_headunit_code));
         cr.fs_headunit_desc := trim(both cr.fs_headunit_desc);
         -- convert to internal MAKE_ID
         cr.fs_make := CASE upper(trim(both cr.fs_make)) -- if this is run multiple times, it should work
                          WHEN 'TOY' THEN
                           'TM'
                          WHEN 'TM' THEN
                           'TM'
                          WHEN 'LEX' THEN
                           'LX'
                          WHEN 'LX' THEN
                           'LX'
                          ELSE
                           NULL
                       END;
         cr.fs_model := upper(trim(both cr.fs_model));
         cr.fs_model_code := trim(both cr.fs_model_code);
         cr.fs_model_year := trim(both cr.fs_model_year);
         cr.fs_vehicle_color := trim(both cr.fs_vehicle_color);


         /* inverted logic: since the field names are "..invalid..flag", meaning False is good.
         so the below logic follows: If "condition=true" (which is good), return False     */
         CALL utl.debug_log('Setting flags');
         cr.fs_invalid_vins_flag := CASE
                                       WHEN  cr.fs_vin ~ '^[A-Z0-9]{17}$'
                                       THEN
                                        cfalse
                                       ELSE
                                        ctrue
                                    END;

         cr.fs_invalid_make_flag := CASE
                                       WHEN coalesce(length(cr.fs_make), 0) = 2 THEN
                                        cfalse
                                       ELSE
                                        ctrue
                                    END;

         cr.fs_duplicate_vins_infile_flag := cfalse;

         l_external_device := utl.check_device_external(i_device_id => cr.fs_headunit_code);

         IF l_external_device = utl.get_constant_value('c_no')
         THEN
            cr.fs_invalid_headunit_desc_flag := CASE
                                                   WHEN coalesce(cr.fs_headunit_desc, '') != '' THEN
                                                    cfalse
                                                   ELSE
                                                    ctrue
                                                END;
            cr.fs_invalid_model_flag := CASE
                                           WHEN coalesce(cr.fs_model, '') != '' THEN
                                            cfalse
                                           ELSE
                                            ctrue
                                        END;
            cr.fs_invalid_model_code_flag := CASE
                                                WHEN coalesce(length(cr.fs_model_code), 0) = 4 THEN
                                                 cfalse
                                                ELSE
                                                 ctrue
                                             END;
            cr.fs_invalid_model_year_flag := CASE
                                                WHEN cr.fs_model_year ~ '^[0-9]{4}$' 
                                                THEN
                                                 cfalse
                                                ELSE
                                                 ctrue
                                             END;
            cr.fs_invalid_vehicle_color_flag := CASE
                                                   WHEN coalesce(cr.fs_vehicle_color, '') != ''  THEN
                                                    cfalse
                                                   ELSE
                                                    ctrue
                                                END;

            cr.fs_invalid_headunit_code_flag := cfalse;
            cr.fs_duplicate_vins_indb_flag := cfalse;

            CALL utl.debug_log('Updating fdf_staging with first set of flags');

         END IF;

         UPDATE beowner.fdf_staging
            SET 
                 fs_record_id                   = cr.fs_record_id
                ,fs_vin                         = cr.fs_vin
                ,fs_headunit_code               = cr.fs_headunit_code
                ,fs_headunit_desc               = cr.fs_headunit_desc
                ,fs_make                        = cr.fs_make
                ,fs_model                       = cr.fs_model
                ,fs_model_code                  = cr.fs_model_code
                ,fs_model_year                  = cr.fs_model_year
                ,fs_vehicle_color               = cr.fs_vehicle_color
                ,fs_invalid_vins_flag           = cr.fs_invalid_vins_flag
                ,fs_duplicate_vins_infile_flag  = cr.fs_duplicate_vins_infile_flag
                ,fs_duplicate_vins_indb_flag    = cr.fs_duplicate_vins_indb_flag
                ,fs_invalid_headunit_code_flag  = cr.fs_invalid_headunit_code_flag
                ,fs_invalid_headunit_desc_flag  = cr.fs_invalid_headunit_desc_flag
                ,fs_invalid_make_flag           = cr.fs_invalid_make_flag
                ,fs_invalid_model_flag          = cr.fs_invalid_model_flag
                ,fs_invalid_model_code_flag     = cr.fs_invalid_model_code_flag
                ,fs_invalid_model_year_flag     = cr.fs_invalid_model_year_flag
                ,fs_invalid_vehicle_color_flag  = cr.fs_invalid_vehicle_color_flag
          WHERE CURRENT OF c1;
      END LOOP;

      CALL utl.debug_log('After loop on fdf_staging');

	l_action := utl.set_action(' Scrubbing head-unit code');

      -- Modified the 3 updates below for OT 5825 to discontinue use of rowid to avoid issues with replication
      CALL utl.debug_log('Updating fdf_staging with fs_invalid_headunit_code_flag');

      UPDATE beowner.fdf_staging fs
         SET fs_invalid_headunit_code_flag = ctrue
       WHERE fs_staging_job_log_guid = ijoblogid
             AND NOT EXISTS (SELECT 1
                FROM beowner.device d
               WHERE d.device_id = fs.fs_headunit_code)
             AND utl.check_device_external(i_device_id => fs.fs_headunit_code) =
             utl.get_constant_value('c_no');
    
    l_action := utl.set_action(' Scrubbing duplicate vins in file');

      CALL utl.debug_log('Updating fdf_staging with fs_duplicate_vins_infile_flag');

      UPDATE beowner.fdf_staging fs
         SET fs_duplicate_vins_infile_flag = ctrue
       WHERE (fs_vin, fs_interface_line_number) IN (SELECT fs_vin,
                     fs_interface_line_number
                FROM (SELECT fs_vin,
                             fs_interface_line_number,
                             MAX(fs_interface_line_number) over (PARTITION BY fs_vin ORDER BY fs_interface_line_number rows BETWEEN unbounded preceding AND unbounded following) AS max_interface_line_number
                        FROM beowner.fdf_staging
                       WHERE fs_staging_job_log_guid = ijoblogid) alias5
               WHERE fs_interface_line_number <> max_interface_line_number);

    l_action := utl.set_action(' Scrubbing duplicate vins in DB');

      CALL utl.debug_log('Updating fdf_staging with fs_duplicate_vins_indb_flag');

      UPDATE beowner.fdf_staging s
         SET fs_duplicate_vins_indb_flag = ctrue
       WHERE fs_staging_job_log_guid = ijoblogid
             AND EXISTS (SELECT 1
                FROM beowner.vin v
               WHERE v.vin = s.fs_vin
                     AND v.make_id = s.fs_make);
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE fdf.scrub (ijoblogid fdf_job_log.fjl_staging_job_log_guid%TYPE) FROM PUBLIC;

\i cleanup.sql;
