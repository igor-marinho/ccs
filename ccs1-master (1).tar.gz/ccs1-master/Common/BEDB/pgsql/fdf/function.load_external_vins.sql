SET bedb.filename = 'function.load_external_vins.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS fdf.load_external_vins(uuid);

CREATE OR REPLACE FUNCTION fdf.load_external_vins (i_job_log_guid fdf_job_log.fjl_staging_job_log_guid%TYPE) RETURNS INTEGER AS $body$
DECLARE
      l_action text;
      l_module_name text := 'load_external_vins';
      l_vin_merge_count integer;
      cfalse VARCHAR(1) := utl.get_constant_value ('cfdffalse');
      ctrue  VARCHAR(1) := utl.get_constant_value ('cfdftrue');
BEGIN
      l_action := utl.set_module_action( l_module_name, ' Merging External VIN data');

      CALL utl.debug_log('Merging into EXTERNAL_VINS');

      WITH src AS (SELECT vin, max(device_id) AS device_id, max(make_id) AS make_id 
               FROM (SELECT fs.fs_vin AS vin, 
                            LAST_VALUE(fs.fs_headunit_code) OVER (PARTITION BY fs.fs_vin ORDER BY fs.fs_interface_line_number) AS device_id,
                            LAST_VALUE(fs.fs_make) OVER  (PARTITION BY fs.fs_vin ORDER BY fs.fs_interface_line_number) AS make_id
                          FROM fdf_staging fs
                      WHERE fs.fs_staging_job_log_guid = i_job_log_guid
                            AND fs.fs_invalid_vins_flag = cfalse
                            AND fs.fs_invalid_make_flag = cfalse
                            AND fs.fs_duplicate_vins_infile_flag = cfalse
                            AND utl.check_device_external(i_device_id => fs.fs_headunit_code) =
                            utl.get_constant_value ('c_yes')
                     ) stg
            GROUP BY stg.vin) 
        INSERT INTO beowner.external_vins(vin, make_id, device_id) 
            SELECT vin, make_id, device_id FROM src
        ON CONFLICT (vin)
        DO UPDATE SET
            (make_id,device_id ) = (SELECT make_id, device_id FROM src);

      GET DIAGNOSTICS l_vin_merge_count = ROW_COUNT;
      CALL utl.debug_log(l_vin_merge_count || ' External VINs merged');

      RETURN l_vin_merge_count;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION fdf.load_external_vins (i_job_log_guid fdf_job_log.fjl_staging_job_log_guid%TYPE) FROM PUBLIC;

\i cleanup.sql;
