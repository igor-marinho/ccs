SET bedb.filename = 'procedure.load_model_categories.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS fdf.load_model_categories(uuid);

CREATE OR REPLACE PROCEDURE fdf.load_model_categories (ijoblogid fdf_job_log.fjl_staging_job_log_guid%TYPE) AS $body$
DECLARE
      l_action TEXT;
      l_module_name text := 'load_model_categories';
      cfalse VARCHAR(1) := utl.get_constant_value ('cfdffalse');
      l_model_cat_merge_count integer;
      l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      l_action := utl.set_module_action( l_module_name, ' Merging Model Category data');

      CALL utl.debug_log('Merging into Model_Categories');

        WITH
        src
        AS
            (  SELECT fs.fs_model AS model, MAX (mc.category) AS category
                 FROM beowner.fdf_staging fs JOIN beowner.model_categories mc ON (fs.fs_model LIKE mc.category || '%')
                WHERE     fs_staging_job_log_guid = ijoblogid
                      AND fs_invalid_vins_flag = cfalse
                      AND fs_duplicate_vins_infile_flag = cfalse
                      AND fs_invalid_headunit_code_flag = cfalse
                      AND fs_invalid_make_flag = cfalse
                      AND fs_invalid_model_flag = cfalse
                      AND fs_invalid_model_code_flag = cfalse
                      AND fs_invalid_model_year_flag = cfalse
                      AND fs_invalid_vehicle_color_flag = cfalse
             GROUP BY fs.fs_model)
        INSERT INTO beowner.model_categories (model, category)
                 SELECT src.model, src.category FROM src
        ON CONFLICT (model)
        DO NOTHING;

      GET DIAGNOSTICS l_model_cat_merge_count = ROW_COUNT;
      CALL utl.debug_log(l_model_cat_merge_count || ' Model Categories merged');

   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
         CALL trc.log('Failed load for ijoblogid: ' || ijoblogid,
                        iexception_diagnostics => l_exception_diagnostics);      

   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE fdf.load_model_categories (ijoblogid fdf_job_log.fjl_staging_job_log_guid%TYPE) FROM PUBLIC;

\i cleanup.sql;
