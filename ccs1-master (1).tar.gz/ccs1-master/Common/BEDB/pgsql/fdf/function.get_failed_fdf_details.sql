SET bedb.filename = 'function.get_failed_fdf_details.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS fdf.get_failed_fdf_details(timestamp without time zone,timestamp without time zone);
   -- CR10303 changes begin --
   /* get_failed_fdf_details
     OUT CURSOR:
      file_name, line_number, load_date, vin, hu_code, invalid_vin, duplicate_in_file, invalid_make, invalid_model, 
      invalid_model_code, invalid_hu_code, invalid_color, invalid_model_year
     
    Error codes : 
    520 : From and To date are both required
    521 : To date must be greater than From date
    
   */
CREATE OR REPLACE FUNCTION fdf.get_failed_fdf_details (i_from_date         beowner.fdf_staging_ques.fs_source_load_date%TYPE
                                                      ,i_to_date           beowner.fdf_staging_ques.fs_source_load_date%TYPE
                                                      ,o_status_code   OUT INTEGER
                                                      ,rslt            OUT refcursor) 
AS $body$
DECLARE
       l_action TEXT;
       l_module_name text := 'get_failed_fdf_details';
       l_date_validation_return text;
       l_exception_diagnostics trc.exception_diagnostics;

BEGIN

      l_action := utl.set_module_action(l_module_name, 'Validating inputs');

      rslt := utl.get_dummy_cursor();
      l_date_validation_return := utl.validate_dates(i_from_date => i_from_date,
                                                     i_to_date   => i_to_date);
                                                 
      IF l_date_validation_return != utl.get_constant_value ('csuccess')
      THEN
         o_status_code := l_date_validation_return;
         RETURN;
      END IF;

      l_action := utl.set_action('Returning results');
      CLOSE rslt;
      OPEN rslt FOR
         SELECT fjl.fjl_filename file_name,
                fs.fs_interface_line_number line_number,
                fs.fs_source_load_date load_date,
                fs.fs_vin vin,
                fs.fs_headunit_code hu_code,
                utl.convert_flag_to_number(fs.fs_invalid_vins_flag) invalid_vin,
                utl.convert_flag_to_number(fs.fs_duplicate_vins_infile_flag) duplicate_in_file,
                utl.convert_flag_to_number(fs.fs_invalid_make_flag) invalid_make,
                utl.convert_flag_to_number(fs.fs_invalid_model_flag) invalid_model,
                utl.convert_flag_to_number(fs.fs_invalid_model_code_flag) invalid_model_code,
                utl.convert_flag_to_number(fs.fs_invalid_headunit_code_flag) invalid_hu_code,
                utl.convert_flag_to_number(fs.fs_invalid_vehicle_color_flag) invalid_color,
                utl.convert_flag_to_number(fs.fs_invalid_model_year_flag) invalid_model_year
           FROM beowner.fdf_staging_ques fs,
                beowner.fdf_job_log      fjl
          WHERE fjl.fjl_staging_job_log_guid = fs.fs_staging_job_log_guid
                AND fs.fs_source_load_date >= i_from_date
                AND fs.fs_source_load_date < i_to_date
          ORDER BY fs.fs_source_load_date,
                   fs.fs_vin;
               
      o_status_code := utl.get_constant_value ('csuccess');
      RETURN;
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
         CALL trc.log(iadditionaldata =>'Something went wrong in ' || l_module_name,
                        iexception_diagnostics => l_exception_diagnostics);
                   
         rslt := utl.get_dummy_cursor();                        
         o_status_code := utl.get_constant_value('cinternalerror');      
     RETURN; 
   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION fdf.get_failed_fdf_details (i_from_date fdf_staging_ques.fs_source_load_date%TYPE, i_to_date fdf_staging_ques.fs_source_load_date%TYPE, rslt OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
