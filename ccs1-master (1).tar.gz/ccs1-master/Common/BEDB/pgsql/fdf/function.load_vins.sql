SET bedb.filename = 'function.load_vins.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS fdf.load_vins(uuid);

CREATE OR REPLACE FUNCTION fdf.load_vins (ijoblogid beowner.fdf_job_log.fjl_staging_job_log_guid%TYPE) RETURNS INTEGER AS $body$
DECLARE
      l_action TEXT;
      l_module_name TEXT := 'load_vins';
      l_vin_merge_count INTEGER;
      cfalse VARCHAR(1) := utl.get_constant_value ('cfdffalse');
      ctrue  VARCHAR(1) := utl.get_constant_value ('cfdftrue');

BEGIN
      l_action := utl.set_module_action( l_module_name, ' Merging VIN data');

      -- OT 5820, F.ID 2046, added MEID
      CALL utl.debug_log('Merging into VIN');

      WITH
      src
      AS
        (SELECT fs_vin               vin
               ,fs_make              make_id
               ,fs_headunit_code     device_id
               ,fs_model             model
               ,fs_model_code        model_code
               ,fs_model_year        "year"
               ,fs_vehicle_color     color
               ,'1'                  factory_flag
               ,'0'                  dealer_flag
               ,fs_meid
           FROM beowner.fdf_staging fs
          WHERE     fs_staging_job_log_guid = ijoblogid
                AND fs_invalid_vins_flag = cfalse
                AND fs_duplicate_vins_infile_flag = cfalse
                AND fs_invalid_headunit_code_flag = cfalse
                AND fs_invalid_make_flag = cfalse
                AND fs_invalid_model_flag = cfalse
                AND fs_invalid_model_code_flag = cfalse
                AND fs_invalid_model_year_flag = cfalse
                AND fs_invalid_vehicle_color_flag = cfalse
                AND utl.check_device_external (i_device_id => fs.fs_headunit_code) = utl.get_constant_value ('c_no'))
        INSERT INTO beowner.vin
            (vin,
             make_id,
             device_id,
             factory_flag,
             dealer_flag,
             model_code,
             model,
             "year",
             color,
             meid)
         SELECT src.vin,
             src.make_id,
             src.device_id,
             src.factory_flag,
             src.dealer_flag,
             src.model_code,
             src.model,
             src."year",
             src.color,
             src.fs_meid FROM src
             ON CONFLICT (vin)
             DO UPDATE SET (make_id,
                device_id,
                factory_flag,
                --dst.dealer_flag  -- commented out for OT 10761
                model_code,
                model,
                "year",
                color,
                meid)
                = (SELECT src.make_id,
                src.device_id,
                src.factory_flag,
                --src.dealer_flag,
                src.model_code,
                src.model,
                src."year",
                src.color,
                src.fs_meid FROM src);

      GET DIAGNOSTICS l_vin_merge_count = ROW_COUNT;
      CALL utl.debug_log(l_vin_merge_count || ' VINs merged');

      IF l_vin_merge_count > 0
      THEN
         CALL fdf.load_model_categories(ijoblogid => ijoblogid);
      END IF;

      RETURN l_vin_merge_count;
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION fdf.load_vins (ijoblogid fdf_job_log.fjl_staging_job_log_guid%TYPE) FROM PUBLIC;

\i cleanup.sql;
