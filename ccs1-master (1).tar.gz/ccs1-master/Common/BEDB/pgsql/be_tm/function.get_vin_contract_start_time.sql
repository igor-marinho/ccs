SET bedb.filename = 'function.get_vin_contract_start_time.sql';

\i set_be_env.sql;

/*  get_contract_start_time

 Gets the Contract Start Time for TM
 Added for OnTime WI 6115 - [EV1] Opt IN/Opt OUT Imp Phase 2 (DB ID 124 F.ID 3046)

 Inputs:
	i_Partner_Id   Partner Id for the VIN
	i_Login_Id     Login Id for the VIN
	i_Vin          VIN that contract start time applies to

 Output:
	o_start_time   Contract Start time with timezone

 Expected Return Values:
		0     : success
		1     : Unknown Error
		7     : No such User found           (cnst.cNoSuchUser)
		200   : VIN not found (not your VIN) (cnst.cDbVinNotFound)
		201   : Subscriber/VIN not found     (cnst.cdbsubscribervinnotfound)
		213   : Partner Id is not valid      (cnst.cDbPartneridNotValid)
*/
DROP FUNCTION IF EXISTS be_tm.get_vin_contract_start_time(text, text, text);
CREATE OR REPLACE FUNCTION be_tm.get_vin_contract_start_time(i_partner_id text,
                                                             i_login_id text,
                                                             i_vin text,
                                                             OUT o_status_code integer,
                                                             OUT o_start_time text) AS
$BODY$
DECLARE
    l_action                text;
    l_module_name           text := 'get_vin_contract_start_time';
    l_usr_id                beowner.usr.usr_id%type;
    l_vin                   beowner.vin.vin%type;
    v_make_id 				beowner.vin.make_id%type;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    l_action := utl.set_module_action(l_module_name,
                                  ' Setting Context');
                                 
    IF  i_partner_id::uuid = utl.getconfig('Oneapp PTNR ID')::uuid THEN  -- CCS1E4157
   
	SELECT make_id 
	INTO  v_make_id 
	FROM  beowner.vin  
	WHERE  VIN = TRIM(i_vin);
       
    IF v_make_id = 'TM' THEN   
	   	i_partner_id := utl.getconfig('Toyota PTNR ID');
    ELSIF  v_make_id = 'LX' THEN  
	     i_partner_id := utl.getconfig('Lexus PTNR ID');
    ELSE o_status_code:= utl.get_constant_value('cinvalidmake'); 
   		RETURN;
   	END IF;
	   
 	END IF;

    CALL ctx.set(iptnrid => i_partner_id::uuid, iloginid => i_login_id, ivin => i_vin);

    l_action := utl.set_module_action(l_module_name,
                                  ' Validating Operation');

    SELECT usr_id,
           vin
    INTO STRICT l_usr_id,
        l_vin
    FROM beowner.ctx_data;

    IF i_login_id IS NOT NULL
    THEN
        CALL be_tm.validate_vin_subscription(i_usr_id => l_usr_id, i_vin => l_vin);
    END IF;

    BEGIN
        SELECT tvcs.vin_contract_start_time
        INTO STRICT o_start_time
        FROM beowner.tm_vin_contract_start tvcs
        WHERE vin = l_vin;
    EXCEPTION
        WHEN no_data_found THEN
            o_start_time := NULL;
    END;

    o_status_code := utl.get_constant_value('csuccess');
    RETURN;
EXCEPTION
    WHEN SQLSTATE 'EPTNR' THEN
        o_status_code := utl.get_constant_value('cdbpartneridnotvalid');
        RETURN;
    WHEN SQLSTATE 'EUSRN' THEN
        o_status_code := utl.get_constant_value('cnosuchuser');
        RETURN;
    WHEN SQLSTATE 'EVINN' THEN
        o_status_code := utl.get_constant_value('cdbvinnotfound');
    WHEN SQLSTATE 'ENSUB' THEN
        o_status_code := utl.get_constant_value('cdbsubscribervinnotfound');
        RETURN;
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
        
        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
        o_status_code :=  utl.get_constant_value('cinternalerror');
        RETURN;
END;
$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION be_tm.get_vin_contract_start_time (i_partner_id text, i_login_id text, i_vin text, o_start_time OUT text) FROM PUBLIC;

\i cleanup.sql;
