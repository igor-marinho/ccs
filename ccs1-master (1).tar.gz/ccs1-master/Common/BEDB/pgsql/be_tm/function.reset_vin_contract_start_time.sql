SET bedb.filename = 'function.reset_vin_contract_start_time.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS be_tm.reset_vin_contract_start_time(text, text);
/*
FUNCTION reset_vin_contract_start_time
To reset the contract start time

Return Code :
   Success cSuccess  '0'

   Error Codes returned/written to data_fix_results:
     cinternalerror                   1   Internal Error
     cinvalidparams                   4   Invalid Parameters
     cdbvinnotfound                 200   System was passed a VIN which was not found.
   * c_invalid_vin                  234   VIN is null
   * c_batch_not_found              450   No matching batch exists
   * c_batch_not_in_progress        451   Batch is not in progress
   * c_duplicate_detail_error       461   Same vin was provided within the batch.

  * If this error is encountered, it is returned regardless of whether batch guid is provided or not.
    Otherwise, if the batch guid is provided, the error is written to data_fix_results table and utl.get_constant_value('csuccess') (0) is returned.
*/
-- Jira CR10212-125
CREATE OR REPLACE FUNCTION be_tm.reset_vin_contract_start_time(i_vin text,
                                                               i_batch_guid text DEFAULT NULL)
    RETURNS integer AS
$body$
DECLARE
    l_action                text;
    l_module_name           text                                 := 'reset_vin_contract_start_time';
-- Jira CR10212-66
    l_dfd_row               beowner.data_fix_batch_details%rowtype;
    l_called_from           text                                 = 'be_tm.reset_vin_contract_start_time';
    l_detail_guid           beowner.data_fix_batch_details.detail_guid%type;
    l_return_code           integer;
    l_status_returned       beowner.data_fix_results.status%type = utl.get_constant_value('csuccess')::integer;
    c_operation_success     text                                 := 'TSCcontractReset';
    l_result_row            beowner.data_fix_results%rowtype;
    l_make_id               beowner.make.make_id%type;
    l_dofu                  beowner.vin.dofu%type;
    l_vin                   beowner.vin.vin%type;
    l_valid                 boolean;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    l_action := utl.set_module_action(l_module_name,
                                      ' : Validating Vin, batch guid and creating batch details');
    l_vin := upper(i_vin);

    IF coalesce(l_vin, '') = ''
    THEN
        RETURN utl.get_constant_value('c_invalid_vin'); -- can't log No VIN result, so has to be returned
    END IF;

    IF coalesce(i_batch_guid, '') != ''
    THEN
        l_dfd_row.batch_guid := i_batch_guid::uuid;
        l_dfd_row.vin := l_vin;

        CALL data_remediation.insert_batch_details(i_dfd_row => l_dfd_row,
                                                   i_called_from => l_called_from,
                                                   o_detail_guid => l_detail_guid,
                                                   o_status_code => l_return_code);

        IF l_return_code != utl.get_constant_value('csuccess')::integer
        THEN
            RETURN l_return_code; -- can't log this result in this case, so has to be returned
        END IF;
    END IF;

--validate input VIN
    SELECT o_status_code, o_make_id, o_dofu
    INTO l_valid, l_make_id, l_dofu
    FROM utl.is_vin_valid(i_vin => l_vin);


    IF NOT l_valid
    THEN
        l_status_returned := utl.get_constant_value('cdbvinnotfound');
        CALL be_tm.handle_error(i_batch_guid::uuid,
                                l_detail_guid,
                                l_called_from,
                                l_result_row,
                                l_status_returned);
		RETURN utl.get_constant_value('csuccess');		/*RETURN SUCCESS AFTER LOGGING*/
    END IF;

-- Reset the contract start time to null for the VIN provided
    UPDATE beowner.tm_vin_contract_start
    SET vin_contract_start_time = NULL
    WHERE vin = l_vin;

    IF coalesce(i_batch_guid, '') != ''
    THEN
      l_status_returned := c_operation_success;
    END IF;

    CALL be_tm.handle_error(i_batch_guid::uuid,
                            l_detail_guid,
                            l_called_from,
                            l_result_row,
                            l_status_returned);

    RETURN utl.get_constant_value('csuccess');
    SELECT * FROM beowner.constant_values WHERE named_constant LIKE 'e%';

EXCEPTION
    WHEN SQLSTATE 'EDEPR' THEN
        RETURN l_status_returned;

    WHEN SQLSTATE 'ENOTI' THEN
        RETURN utl.get_constant_value('csuccess'); --after logging error, return code will be 0
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
			l_exception_diagnostics.module_name := l_module_name;
			l_exception_diagnostics.action := l_action;
        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);

        RETURN utl.get_constant_value('cinternalerror');

END;
$body$ 
LANGUAGE PLPGSQL
SECURITY DEFINER
;

\i cleanup.sql;
