SET bedb.filename = 'procedure.insert_batch_result_row.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS be_tm.insert_batch_result_row(beowner.data_fix_batches.batch_guid%type,
    beowner.data_fix_results.status%type,
    beowner.data_fix_batch_details.detail_guid%type,
    text,
    INOUT beowner.data_fix_results);
CREATE OR REPLACE PROCEDURE be_tm.insert_batch_result_row(i_batch_guid beowner.data_fix_batches.batch_guid%type,
                                                          i_status_returned beowner.data_fix_results.status%type,
                                                          i_detail_guid beowner.data_fix_batch_details.detail_guid%type,
                                                          i_called_from text,
                                                          INOUT result_row beowner.data_fix_results) AS
$body$
BEGIN
    IF i_batch_guid IS NOT NULL
    THEN
        result_row.detail_guid := i_detail_guid;
        result_row.status := i_status_returned;
        CALL data_remediation.log_detail_result(result_row, i_called_from);
        result_row := NULL;
    END IF;
END;


$body$
    LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE be_tm.insert_batch_result_row () FROM PUBLIC;

\i cleanup.sql;
