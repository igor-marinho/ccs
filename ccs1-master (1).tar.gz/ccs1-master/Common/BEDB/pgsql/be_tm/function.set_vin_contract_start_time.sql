SET bedb.filename = 'function.validate_vin_subscription.sql';

\i set_be_env.sql;

/*  set_contract_start_time

  Sets the Contract Start Time for TM to be used for the duration for the opt in
  Added for OnTime WI 6115 - [EV1] Opt IN/Opt OUT Imp Phase 2 (DB ID 124 F.ID 3046)

  Inputs:
     i_Partner_Id   Partner Id for the VIN
     i_Login_Id     Login Id for the VIN
     i_Vin          VIN that contract start time applies to
     i_start_time   Contract Start time with timezone

  Expected Return Values:
         0     : success
         1     : Unknown Error
         7     : No such User found                  (cnst.cNoSuchUser)
         200   : VIN not found                       (cnst.cDbVinNotFound)
         201   : Subscriber/VIN not found            (cnst.cdbsubscribervinnotfound)
         213   : Partner Id is not valid             (cnst.cDbPartneridNotValid)
         225   : Different TM Contract start time    (cnst.cTMDiffContractStartTime)
*/
DROP FUNCTION IF EXISTS be_tm.set_vin_contract_start_time(text, text, text, text);
CREATE OR REPLACE FUNCTION be_tm.set_vin_contract_start_time(i_partner_id text,
                                                             i_login_id text,
                                                             i_vin text,
                                                             i_start_time text) RETURNS integer AS
$BODY$
DECLARE
    l_action                text;
    l_module_name           text := 'validate_vin_subscription';
    effect_rowcount         int;
    l_usr_id                beowner.usr.usr_id%type;
    l_vin                   beowner.vin.vin%type;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    l_action := utl.set_module_action(l_module_name,
                                      ' Setting Context');

    CALL ctx.set(iptnrid => i_partner_id::uuid, iloginid => i_login_id, ivin => i_vin);

    l_action := utl.set_module_action(l_module_name,
                                      ' Validating Operation');

    /* Commented out for Work Item #7431 (Remove null i_login_id check for be_tm.set_vin_contract_start_time())
   IF i_login_id IS NULL THEN
   THEN
      RAISE err.eusernotfound;
   END IF;
    */
    l_action := utl.set_module_action(l_module_name,
                                      ' Updating data');

    SELECT usr_id,
           vin
    INTO STRICT l_usr_id,
        l_vin
    FROM beowner.ctx_data;

    IF coalesce(i_login_id, '') != ''
    THEN
        CALL be_tm.validate_vin_subscription(i_usr_id => l_usr_id, i_vin => l_vin);
    END IF;

    -- The following statement inserts the start time if no start time has been set for the VIN yet.
    -- If the start time has been set already, then it is updated ONLY if either the time set already or the input time is null or both are same
    -- No update is made if both the values are not null and different
    INSERT INTO beowner.tm_vin_contract_start(vin, vin_contract_start_time)
    VALUES (l_vin, i_start_time)
    ON CONFLICT ON CONSTRAINT pk_tm_vin_cs
        DO UPDATE SET vin_contract_start_time = i_start_time
    WHERE coalesce(beowner.tm_vin_contract_start.vin_contract_start_time, i_start_time)
              = coalesce(i_start_time, beowner.tm_vin_contract_start.vin_contract_start_time);

    GET DIAGNOSTICS effect_rowcount = ROW_COUNT;
    IF effect_rowcount = 0
    THEN
        IF coalesce(i_start_time, '') != ''
        THEN
            RAISE EXCEPTION 'e_different_start_time' USING ERRCODE = utl.get_constant_value('e_different_start_time');
        END IF;
    END IF;

    -- TODO insert into history
    RETURN utl.get_constant_value('csuccess');
EXCEPTION
    WHEN SQLSTATE 'EPTNR' THEN
        RETURN utl.get_constant_value('cdbpartneridnotvalid');
    WHEN SQLSTATE 'EUSRN' THEN
        RETURN utl.get_constant_value('cnosuchuser');
    WHEN SQLSTATE 'EVINN' THEN
        RETURN utl.get_constant_value('cdbvinnotfound');
    WHEN SQLSTATE 'ENSUB' THEN
        RETURN utl.get_constant_value('cdbsubscribervinnotfound');
    WHEN SQLSTATE 'ESTTM' THEN
        RETURN utl.get_constant_value('ctmdiffcontractstarttime');
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
        RETURN utl.get_constant_value('cinternalerror');
END;

$BODY$
    LANGUAGE PLPGSQL
    SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION be_tm.set_vin_contract_start_time (i_partner_id text, i_login_id text, i_vin text, i_start_time text) FROM PUBLIC;

\i cleanup.sql;
