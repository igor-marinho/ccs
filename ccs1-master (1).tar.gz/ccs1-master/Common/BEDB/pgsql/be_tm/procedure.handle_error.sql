SET bedb.filename = 'procedure.handle_error.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS be_tm.handle_error(beowner.data_fix_batches.batch_guid%type,
    beowner.data_fix_batch_details.detail_guid%type,
    text,
    INOUT beowner.data_fix_results,
    INOUT integer);
CREATE OR REPLACE PROCEDURE be_tm.handle_error(i_batch_guid beowner.data_fix_batches.batch_guid%type,
                                               i_detail_guid beowner.data_fix_batch_details.detail_guid%type,
                                               i_called_from text,
                                               INOUT result_row beowner.data_fix_results,
                                               INOUT status_returned beowner.data_fix_results.status%type) AS
$body$
BEGIN
    IF status_returned = utl.get_constant_value('csuccess')
    THEN
        RETURN;
    END IF;

    IF i_batch_guid IS NOT NULL
    THEN
        result_row.status := status_returned;
        CALL be_tm.insert_batch_result_row(i_batch_guid,
                                              status_returned,
                                              i_detail_guid,
                                              i_called_from,
                                              result_row);
        status_returned := utl.get_constant_value('csuccess'); -- since 0 should be returned to portal after logging into RRR
        /*EXCEPTION NOT RAISED AS IT ROLLSBACK THE INSERT OPERATION 
		RAISE EXCEPTION USING ERRCODE = utl.get_constant_value('e_notimplemented');*/
    ELSE
        RAISE EXCEPTION USING ERRCODE = utl.get_constant_value('e_deprecated');
    END IF;

END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE be_tm.handle_error () FROM PUBLIC;

\i cleanup.sql;

