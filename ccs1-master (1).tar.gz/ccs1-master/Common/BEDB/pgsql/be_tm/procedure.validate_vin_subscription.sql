SET bedb.filename = 'procedure.validate_vin_subscription.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS be_tm.validate_vin_subscription(beowner.usr.usr_id%type, beowner.vin.vin%type);
CREATE OR REPLACE PROCEDURE be_tm.validate_vin_subscription(i_usr_id beowner.usr.usr_id%type,
                                                            i_vin beowner.vin.vin%type)
AS
$BODY$
DECLARE

    -- ensure that the given user has a subscription for that vin - regardless of whether it is active or not
    l_subscription_exists integer;

BEGIN
    SELECT 1
    INTO STRICT l_subscription_exists
    FROM beowner.subscription sub
    WHERE sub.primary_id = i_usr_id
      AND sub.vin = i_vin
    LIMIT 1;
EXCEPTION
    WHEN no_data_found THEN
        RAISE EXCEPTION 'e_no_subscription' USING ERRCODE = utl.get_constant_value('e_no_subscription');
END;

$BODY$
    LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE be_tm.validate_vin_subscription (i_usr_id usr.usr_id%TYPE, i_vin vin.vin%TYPE) FROM PUBLIC;

\i cleanup.sql;
