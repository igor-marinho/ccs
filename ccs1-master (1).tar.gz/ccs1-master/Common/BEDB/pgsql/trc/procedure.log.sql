SET bedb.filename = 'procedure.log.sql';

\i set_be_env.sql;

CREATE OR REPLACE PROCEDURE trc.log(iadditionaldata text DEFAULT NULL::text, iexception_diagnostics trc.exception_diagnostics DEFAULT NULL::trc.exception_diagnostics)
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $procedure$
DECLARE
-------------------------------------------------------------------------------
/*
    This package is useful for error tracking and debugging. Note that
    DBMS_APPLICTION_INFO is *not* called in this package; it would defeat
    the purpose of tracing... we want to know what the settings are
    when this package is called.
*/
-------------------------------------------------------------------------------
/*  LOG

      This simply pulls as much information as it can and stuffs it in the "trc" table.

      If this is called during an exception, the error_backtrace and error_stack will be
      useful, otherwise you'll get a good call_stack and other information.

      This is an autonomous procedure, so *every* call to it will create a new row.
      
      UPDATE FOR POSTGRES:
        Since autonomous transactions are only available via dblink in PGaas, this code has
        been reworked to execute using dblink.   Since most of the calls are via exception
        and the transaction will already have been rolled back, and dblink can be expensive
        the code is also conditional on an open transaction.  If one exists, it uses dblink
        if no transaction exists, it directly updates the table avoiding the dblink
        if using dblink, we need to additionally supply session_user, because if we don't 
        dblink will use the connection user (beowner) 
*/

    l_con_count    integer;
    l_InsertQuery   text := format('insert into beowner.trc(additional,callstack,backtrace,errorstack,module,action,sessionuser) values ( %L,%L,%L,%L,%L,%L,%L)',
                                  substring(iadditionaldata,1,250),
                                  substring(iexception_diagnostics.PG_EXCEPTION_CONTEXT,1,2000),
                                  substring(iexception_diagnostics.MESSAGE_TEXT,1,2000),
                                  substring(iexception_diagnostics.returned_sqlstate,1,2000),
                                  coalesce(iexception_diagnostics.module_name, current_setting('application_name',true)),
                                  coalesce(iexception_diagnostics.action, current_setting('bedb.action',true)),
                                  session_user
                                  );

begin

    -- check if we are following an exception,  if so insert via dblink, otherwise do a direct insert 
    if iexception_diagnostics.PG_EXCEPTION_CONTEXT IS NOT null then
        -- check to see if a connection already exists, if so use it
        select count(1)
          into l_con_count
          from extensions.dblink_get_connections()
          where coalesce (array_position(dblink_get_connections, 'trcconn'),0) > 0;
        if l_con_count = 0 then 
            perform extensions.dblink_connect('trcconn','fdlog');
        end if;
        
        perform extensions.dblink_exec('trcconn', l_InsertQuery );
    else
        insert into beowner.trc(additional,callstack,backtrace,errorstack,module,action) values ( 
                                  substring(iadditionaldata,1,250),
                                  substring(iexception_diagnostics.PG_EXCEPTION_CONTEXT,1,2000),
                                  substring(iexception_diagnostics.MESSAGE_TEXT,1,2000),
                                  substring(iexception_diagnostics.returned_sqlstate,1,2000),
                                  coalesce(iexception_diagnostics.module_name, current_setting('application_name',true)),
                                  coalesce(iexception_diagnostics.action,current_setting('bedb.action',true))
                                  );
    end if;

END;
$procedure$
;


\i cleanup.sql;
