SET bedb.filename = 'function.d_usr_sp.sql';

\i set_be_env.sql;

   /* d_usr_sp  error codes returned :
   cInvalidLoginId           constant vc := '16'
        -- The username or password is not correct.
    cInternalError            constant vc := '1' -- Internal Error.
    cInvalidParams            constant vc := '4'
        -- Invalid Parameters (login and user ID are both null in parameters and context)
    c_primary_has_secondaries       constant vc := '283'
        -- Primary User being deleted has secondary users associated to it
   */
   -- Removed columns tos_flag,dwnld_app_flag for DCS1E-921

CREATE OR REPLACE FUNCTION crudg_usr.d_usr_sp(IN iusr_id TEXT DEFAULT NULL, 
                                              IN i_uc_id TEXT DEFAULT NULL, 
                                              IN iuserlogin TEXT DEFAULT NULL, 
                                              IN ipwd TEXT DEFAULT NULL, 
                                              IN ifirst_name TEXT DEFAULT NULL, 
                                              IN ilast_name TEXT DEFAULT NULL, 
                                              IN iversion TEXT DEFAULT NULL, 
                                              IN i_delete_children TEXT DEFAULT 'Y')
RETURNS INTEGER
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'd_usr_sp';
    vusr_id BEOWNER.USR.usr_id%TYPE;
    vuserlogin BEOWNER.USR.login_id%TYPE;
    vmakeid BEOWNER.USR.make_id%TYPE;
    vpwd BEOWNER.USR.pwd%TYPE;
    vlangid BEOWNER.USR.lang_id%TYPE;
    vcreated BEOWNER.USR.created%TYPE;
    vparent_id BEOWNER.USR.parent_id%TYPE := NULL;
    vverified BEOWNER.USR.verified%TYPE;
    vcreate_type BEOWNER.USR.create_type%TYPE;
    vlocked BEOWNER.USR.locked%TYPE;
    vlvl BEOWNER.USR.lvl%TYPE := '0';
    vparentlvl BEOWNER.USR.parentlvl%TYPE := NULL;
    vfname BEOWNER.USR_DEMOG.name_first%TYPE;
    vlname BEOWNER.USR_DEMOG.name_last%TYPE;
    vaddr BEOWNER.USR_DEMOG.addr1%TYPE;
    vphone BEOWNER.USR_PHONE.phone%TYPE;
    vph_type BEOWNER.USR_PHONE.phone_type_id%TYPE;
    vcc BEOWNER.USR_PHONE.cc%TYPE := '001';
    vac BEOWNER.USR_PHONE.ac%TYPE;
    vaddr_type BEOWNER.USR_EMAIL.email_type_id%TYPE;
    vemail BEOWNER.USR_EMAIL.email%TYPE;
    vversion CHARACTER VARYING(100);
    vcnt DOUBLE PRECISION;
    pcnt DOUBLE PRECISION;
    ctvin BEOWNER.VIN.vin%TYPE;
    ctmakeid BEOWNER.VIN.make_id%TYPE;
    ctusrlogid BEOWNER.USR.login_id%TYPE;
    ctusrid BEOWNER.USR.usr_id%TYPE;
    c1 RECORD;
    secondaries_rec RECORD;
    l_exception_diagnostics trc.exception_diagnostics;    

BEGIN

    select utl.set_module_action( l_module_name, 'D_USR_SP') into l_action;

    SELECT
        vin, UPPER(TRIM(make_id)), LOWER(TRIM(usrlogid)), LOWER(TRIM(usr_id::text))
        INTO STRICT ctvin, ctmakeid, ctusrlogid, ctusrid
        FROM beowner.ctx_data;

--    vusr_id := COALESCE(REPLACE(TRIM(iusr_id), '-', '')::UUID, ctusrid);
    vusr_id := COALESCE(TRIM(iusr_id)::UUID, ctusrid);

    IF (COALESCE(iuserlogin, '') = COALESCE(ctusrlogid, '')) THEN
        vuserlogin := COALESCE(LOWER(TRIM(iuserlogin)), ctusrlogid);
    ELSIF (COALESCE(LOWER(TRIM(i_uc_id)), '') = COALESCE(ctusrlogid, '')) THEN
        vuserlogin := COALESCE(LOWER(TRIM(iuserlogin)), ctusrlogid);
    END IF;

    IF ((vuserlogin IS NULL) AND (vusr_id IS NULL)) THEN
        RETURN utl.get_constant_value('cinvalidparams');
    END IF;
    /* fixed for OnTime WI #14078 */

    IF (vusr_id IS NULL) THEN
        BEGIN
            SELECT
                usr_id
                INTO STRICT vusr_id
                FROM beowner.usr
                WHERE make_id = ctmakeid AND login_id = vuserlogin;
            EXCEPTION
                WHEN no_data_found THEN
                    RETURN utl.get_constant_value('cinvalidloginid');
        END;
    END IF;
  
    call utl.dbg(CONCAT_WS('', 'vusr_id = ', vusr_id));

    select utl.set_action( 'Deleting Child data in D_USR_SP usr_id='||vusr_id) into l_action;

    /* OnTime WI #15753 */
--    call crudg_usr.set_make_user_rel_config();

    IF utl.is_user_relation_static()
    /* OnTime WI #14078 and OnTime #19552 - count(*) can't be anything but 1 if the loop below is executed */
    THEN
    FOR c1 IN
        SELECT
            usr_id, 1 AS cnt, '' AS version
            FROM beowner.usr
            WHERE parent_id = vusr_id
        /* OnTime WI #14078 */
        LOOP
            IF i_delete_children = 'N' THEN
                RETURN utl.get_constant_value('c_primary_has_secondaries');
            END IF;

            IF ( crudg_usr.d_usr_children(c1.usr_id, c1.cnt, c1.version) != 0 ) THEN
                RETURN utl.get_constant_value('cinternalerror');
            END IF;
        END LOOP;
    /* user relation is not static */
    ELSE
        call utl.dbg('Not static'::TEXT);

        FOR secondaries_rec IN
        SELECT
            secondary_id, 1 AS cnt, '' AS version
            FROM beowner.subscription_users
            WHERE primary_id = vusr_id
        LOOP
            IF i_delete_children = 'N' THEN
                RETURN utl.get_constant_value('c_primary_has_secondaries');
            END IF;

            IF ( crudg_usr.d_usr_children(iusr_id => secondaries_rec.secondary_id, icnt => secondaries_rec.cnt, iversion => secondaries_rec.version) != 0) THEN
                RETURN utl.get_constant_value('cinternalerror');
            END IF;
        END LOOP;
    END IF;
    
    select utl.set_action( 'Deleting parent data in D_USR_SP usr_id=' || vusr_id|| ' login_id=' || vuserlogin) into l_action;    

    /* OnTime WI #14078 and OnTime #19552 - count(*) can't be anything but 1 if the loop below is executed */

    FOR c1 IN
    SELECT
        usr_id, 1 AS cnt, '' AS version
        FROM beowner.usr
        WHERE usr_id = vusr_id
    LOOP
        IF ( crudg_usr.d_usr_children(c1.usr_id, c1.cnt, c1.version) != 0) THEN
            RETURN utl.get_constant_value('cinternalerror');
        END IF;
    END LOOP;
    RETURN utl.get_constant_value('csuccess');
    /* OnTime WI #15753 */
    EXCEPTION
        WHEN SQLSTATE 'EMAKE' THEN
            RETURN utl.get_constant_value('cinvalidctxmakeid');
        WHEN others THEN
         GET STACKED diagnostics
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,              
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;
            call trc.log(iadditionaldata =>CONCAT_WS('', 'Something went really wrong in D_USR_SP usr_id=', vusr_id, ' login_id=', vuserlogin, ' make_id=', vmakeid, ' pwd=', vpwd, ' created=', vcreated, ' parent_id=', vparent_id, ' verified=', vverified, ' langID=', vlangid, ' create_type=', vcreate_type, ' locked=', vlocked, ' lvl=', vlvl, ' parentlvl=', vparentlvl),
                iexception_diagnostics => l_exception_diagnostics);
            RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
