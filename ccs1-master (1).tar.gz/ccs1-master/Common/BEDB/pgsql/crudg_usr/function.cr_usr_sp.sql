SET bedb.filename = 'function.cr_usr_sp.sql';

\i set_be_env.sql;

   -- Removed columns tos_flag,dwnld_app_flag for DCS1E-921

CREATE OR REPLACE FUNCTION crudg_usr.cr_usr_sp(IN iuserlogin TEXT, IN ipwd TEXT, IN ifirst_name TEXT DEFAULT NULL, IN ilast_name TEXT DEFAULT NULL, IN iphone TEXT DEFAULT NULL, IN iph_type TEXT DEFAULT NULL, IN iaddr TEXT DEFAULT NULL, IN iaddr_type TEXT DEFAULT NULL, IN iemail TEXT DEFAULT NULL, IN iversion TEXT DEFAULT NULL)
RETURNS NUMERIC
AS
$BODY$
DECLARE
      l_module_name text := 'cr_usr_sp';
    vusr_id BEOWNER.USR.usr_id%TYPE;
    vuserlogin BEOWNER.USR.login_id%TYPE;
    vmakeid BEOWNER.USR.make_id%TYPE;
    vpwd BEOWNER.USR.pwd%type;
    vlangid BEOWNER.USR.lang_id%type; -- 
    vcreated BEOWNER.USR.created%TYPE;
    vparent_id BEOWNER.USR.parent_id%TYPE := NULL;
    vverified BEOWNER.USR.verified%TYPE;  --
    vcreate_type BEOWNER.USR.create_type%TYPE;
    vlocked BEOWNER.USR.locked%TYPE;
    vlvl BEOWNER.USR.lvl%TYPE;
    vparentlvl BEOWNER.USR.parentlvl%TYPE := NULL;
    vfname BEOWNER.USR_DEMOG.name_first%TYPE;
    vlname BEOWNER.USR_DEMOG.name_last%TYPE;
    vaddr BEOWNER.USR_DEMOG.addr1%TYPE;
    vphone BEOWNER.USR_PHONE.phone%TYPE;
    vph_type BEOWNER.USR_PHONE.phone_type_id%TYPE;
    vcc BEOWNER.USR_PHONE.cc%TYPE;
    vac BEOWNER.USR_PHONE.ac%TYPE;
    vaddr_type BEOWNER.USR_EMAIL.email_type_id%TYPE;
    vemail BEOWNER.USR_EMAIL.email%TYPE;
    vversion CHARACTER VARYING(100);
    vcnt DOUBLE PRECISION;
    pcnt DOUBLE PRECISION;
    ctvin BEOWNER.VIN.vin%TYPE;
    ctmakeid BEOWNER.VIN.make_id%TYPE;
    ctusrlogid BEOWNER.USR.login_id%TYPE;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN    
    vlvl := '0';
    vcc := '001'
    /* PERFORM utl.set_module_action( l_module_name,   */
    /*   'Starting CR_USR_SP'); */
    /* */;
    SELECT
        vin, UPPER(TRIM(make_id)), LOWER(TRIM(usrlogid))
        INTO STRICT ctvin, ctmakeid, ctusrlogid
        FROM beowner.ctx_data;
    vuserlogin := COALESCE(LOWER(TRIM(iuserlogin)), ctusrlogid);

    IF vuserlogin IS NULL THEN
        RETURN cnst.ginvalidloginid();
    END IF;
    vusr_id := beowner.rand_guid();
    vmakeid := ctmakeid;
    vpwd := COALESCE(TRIM(ipwd), 'q9FRF9FI3vQ6lDV9kG/enOYRvGT6C+sAf4/NvYYTGTE=');
    vcreated := clock_timestamp();
    vparent_id := NULL;
    vverified := clock_timestamp();
    vlangid := cnst.glangenus();
    vcreate_type := 'M';
    vlocked := ' ';
    vlvl := '0';
    vparentlvl := NULL;
    vcnt := 0;
    pcnt := 0;
    vfname := UPPER(TRIM(ifirst_name));
    vlname := UPPER(TRIM(ilast_name));
    vaddr := UPPER(TRIM(iaddr));
    vaddr_type := UPPER(TRIM(iaddr_type));
    vphone := UPPER(TRIM(iphone));
    vph_type := COALESCE(UPPER(TRIM(iph_type)), 'H1');
    pcnt := LENGTH(COALESCE(vphone, 0));

    IF pcnt >= 13 THEN
        vcc := SUBSTR(vphone, 1, 3);
        vac := SUBSTR(vphone, 4, 6);
        vphone := SUBSTR(vphone, 7, TRUNC(pcnt::NUMERIC)::INTEGER);
    ELSIF pcnt = 10 THEN
        vcc := '001';
        vac := SUBSTR(vphone, 1, 3);
        vphone := SUBSTR(vphone, 4, TRUNC(pcnt::NUMERIC)::INTEGER);
    ELSIF pcnt < 10 THEN
        vcc := '001';
        vac := '999';
    END IF;

    IF vmakeid IS NULL THEN
        RAISE USING detail = 'beowner$crudg_usr$einvalidmake', hint = beowner.crudg_usr$einvalidmake();
    END IF;
    SELECT
        COUNT(*)
        INTO STRICT vcnt
        FROM beowner.usr
        WHERE login_id = vuserlogin;

    IF vcnt > 0 THEN
        RETURN cnst.guseralreadyexists();
    END IF
    /* PERFORM utl.set_module_action( l_module_name,   */
    /*   */
    /* 'Starting CR_USR_SP usr_id=' || */
    /* vusr_id || ' login_id=' || vuserlogin || */
    /* ' make_id=' || vmakeid || ' pwd=' || vpwd || */
    /* ' created=' || vcreated || */
    /* ' parent_id=' || vparent_id || */
    /* ' verified=' || vverified || */
    /* ' langID=' || vlangid || */
    /* ' create_type=' || vcreate_type || */
    /* ' locked=' || vlocked || ' lvl=' || vlvl || */
    /* ' parentlvl=' || vparentlvl); */;
    INSERT INTO beowner.usr (usr_id, login_id, make_id, pwd, created, parent_id, verified, lang_id, create_type, locked, lvl, parentlvl)
    VALUES (vusr_id, vuserlogin, vmakeid, vpwd, vcreated, vparent_id, vverified, vlangid, vcreate_type, vlocked, vlvl, vparentlvl);
    INSERT INTO beowner.usr_email (usr_id, email_type_id, email)
    VALUES (vusr_id, vaddr_type, vemail);

    IF (((LENGTH(COALESCE(vfname, 0))) + (LENGTH(COALESCE(vlname, 0))) + (LENGTH(COALESCE(vaddr, 0)))) > 0) THEN
        INSERT INTO beowner.usr_demog (usr_id, name_first, name_last, addr1)
        VALUES (vusr_id, vfname, vlname, vaddr);
    END IF;

    IF pcnt > 0 THEN
        INSERT INTO beowner.usr_phone (usr_id, phone_type_id, cc, ac, phone, ext)
        VALUES (vusr_id, vph_type, vcc, vac, vphone, NULL);
    END IF;
    RETURN utl.get_constant_value('csuccess');
    EXCEPTION
        WHEN others THEN
            GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,              
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

            perform trc.log(iadditionaldata => NULL,
                            iexception_diagnostics => l_exception_diagnostics);
            RETURNutl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql;

CREATE OR REPLACE FUNCTION crudg_usr.cr_usr_sp(IN iuserlogin TEXT, IN i_uc_id TEXT, IN ipwd TEXT, IN ifirst_name TEXT DEFAULT NULL, IN ilast_name TEXT DEFAULT NULL, IN iphone TEXT DEFAULT NULL, IN iph_type TEXT DEFAULT NULL, IN iaddr TEXT DEFAULT NULL, IN iaddr_type TEXT DEFAULT NULL, IN iemail TEXT DEFAULT NULL, IN iversion TEXT DEFAULT NULL)
RETURNS NUMERIC
AS
$BODY$
DECLARE
    vusr_id BEOWNER.USR.usr_id%TYPE;
    v_uc_id BEOWNER.USR.login_id%TYPE;
    vuserlogin BEOWNER.USR.login_id%TYPE;
    vmakeid BEOWNER.USR.make_id%TYPE;
    vpwd BEOWNER.USR.pwd%TYPE;
    vlangid BEOWNER.USR.lang_id%TYPE;
    vcreated BEOWNER.USR.created%TYPE;
    vparent_id BEOWNER.USR.parent_id%TYPE := NULL;
    vverified BEOWNER.USR.verified%TYPE;
    vcreate_type BEOWNER.USR.create_type%TYPE;

    vlocked BEOWNER.USR.locked%TYPE;
    vlvl BEOWNER.USR.lvl%TYPE := '0';
    vparentlvl BEOWNER.USR.parentlvl%TYPE := NULL;
    vfname BEOWNER.USR_DEMOG.name_first%TYPE;
    vlname BEOWNER.USR_DEMOG.name_last%TYPE;
    vaddr BEOWNER.USR_DEMOG.addr1%TYPE;
    vphone BEOWNER.USR_PHONE.phone%TYPE;
    vph_type BEOWNER.USR_PHONE.phone_type_id%TYPE;
    vcc BEOWNER.USR_PHONE.cc%TYPE := '001';
    vac BEOWNER.USR_PHONE.ac%TYPE;
    vaddr_type BEOWNER.USR_EMAIL.email_type_id%TYPE;
    vemail BEOWNER.USR_EMAIL.email%TYPE;
    vversion CHARACTER VARYING(100);
    vcnt DOUBLE PRECISION;
    pcnt DOUBLE PRECISION;
    ctvin BEOWNER.VIN.vin%TYPE;
    ctmakeid BEOWNER.VIN.make_id%TYPE;
    ctusrlogid BEOWNER.USR.login_id%TYPE;
    ctusrid BEOWNER.USR.usr_id%TYPE;
    l_exception_diagnostics trc.exception_diagnostics;
/* PERFORM utl.set_module_action( l_module_name,   */
/*   'Starting CR_USR_SP'); */
/* */
BEGIN
    PERFORM BEOWNER.CNST$Init();
    SELECT
        vin, UPPER(TRIM(make_id)), LOWER(TRIM(usrlogid)), usr_id
        INTO STRICT ctvin, ctmakeid, ctusrlogid, ctusrid
        FROM beowner.ctx_data
    /* */;

    IF (COALESCE(iuserlogin, 0) = COALESCE(ctusrlogid, 0)) THEN
        vuserlogin := COALESCE(LOWER(TRIM(iuserlogin)), ctusrlogid);
    ELSIF (COALESCE(i_uc_id, 0) = COALESCE(ctusrlogid, 0)) THEN
        vuserlogin := COALESCE(LOWER(TRIM(iuserlogin)), ctusrlogid);
    END IF;

    IF ((vuserlogin IS NULL) AND (ctusrid IS NULL)) THEN
        RETURN cnst.ginvalidparams();
    END IF;

    IF (ctusrid IS NULL) THEN
        SELECT
            usr_id
            INTO STRICT vusr_id
            FROM beowner.usr
            WHERE login_id = vuserlogin;
    END IF;
    vusr_id := beowner.rand_guid();
    vmakeid := ctmakeid;
    vpwd := COALESCE(TRIM(ipwd), 'q9FRF9FI3vQ6lDV9kG/enOYRvGT6C+sAf4/NvYYTGTE=');
    vcreated := clock_time();
    vparent_id := NULL;
    vverified := clock_time();
    vlangid := cnst.glangenus();
    vcreate_type := 'M';

    vlocked := ' ';
    vlvl := '0';
    vparentlvl := NULL;
    vcnt := 0;
    pcnt := 0;
    vfname := UPPER(TRIM(ifirst_name));
    vlname := UPPER(TRIM(ilast_name));
    vaddr := UPPER(TRIM(iaddr));
    vphone := UPPER(TRIM(iphone));
    vph_type := COALESCE(UPPER(TRIM(iph_type)), 'H1');
    pcnt := LENGTH(COALESCE(vphone, 0));

    IF (pcnt >= 13) THEN
        vcc := SUBSTR(vphone, 1, 3);
        vac := SUBSTR(vphone, 4, 6);
        vphone := SUBSTR(vphone, 7, TRUNC(pcnt::NUMERIC)::INTEGER);
    ELSIF (pcnt = 10) THEN
        vcc := '001';
        vac := SUBSTR(vphone, 1, 3);
        vphone := SUBSTR(vphone, 4, TRUNC(pcnt::NUMERIC)::INTEGER);
    ELSIF (pcnt < 10) THEN
        vcc := '001';
        vac := '999';
    END IF;

    IF vmakeid IS NULL THEN
        RAISE USING detail = 'beowner$crudg_usr$einvalidmake', hint = beowner.crudg_usr$einvalidmake();
    END IF;
    SELECT
        COUNT(*)
        INTO STRICT vcnt
        FROM beowner.usr
        WHERE login_id = ctusrlogid;

    IF vcnt > 0 THEN
        RETURN cnst.guseralreadyexists();
    END IF
    /* PERFORM utl.set_module_action( l_module_name,   */
    /*   */
    /* 'Starting CR_USR_SP usr_id=' || */
    /* vusr_id || ' login_id=' || vuserlogin || */
    /* ' make_id=' || vmakeid || ' pwd=' || vpwd || */
    /* ' created=' || vcreated || */
    /* ' parent_id=' || vparent_id || */
    /* ' verified=' || vverified || */
    /* ' langID=' || vlangid || */
    /* ' create_type=' || vcreate_type || */
    /* ' locked=' || vlocked || ' lvl=' || vlvl || */
    /* ' parentlvl=' || vparentlvl); */;
    INSERT INTO beowner.usr (usr_id, login_id, make_id, pwd, created, parent_id, verified, lang_id, create_type,  locked, lvl, parentlvl)
    VALUES (vusr_id, vuserlogin, vmakeid, vpwd, vcreated, vparent_id, vverified, vlangid, vcreate_type, vlocked, vlvl, vparentlvl);
    INSERT INTO beowner.usr_email (usr_id, email_type_id, email)
    VALUES (vusr_id, vaddr_type, vemail);

    IF ((LENGTH(COALESCE(vfname, 0))) + (LENGTH(COALESCE(vlname, 0))) + (LENGTH(COALESCE(vaddr, 0)))) > 0 THEN
        INSERT INTO beowner.usr_demog (usr_id, name_first, name_last, addr1)
        VALUES (vusr_id, vfname, vlname, vaddr);
    END IF;

    IF pcnt > 0 THEN
        INSERT INTO beowner.usr_phone (usr_id, phone_type_id, cc, ac, phone, ext)
        VALUES (vusr_id, vph_type, vcc, vac, vphone, NULL);
    END IF;
    RETURN utl.get_constant_value('csuccess');
    EXCEPTION
        WHEN others THEN
           GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,              
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

            perform trc.log(iadditionaldata => NULL,
                            iexception_diagnostics => l_exception_diagnostics);
            RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
