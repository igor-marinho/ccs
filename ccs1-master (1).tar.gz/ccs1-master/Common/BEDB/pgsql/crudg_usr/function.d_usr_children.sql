SET bedb.filename = 'function.d_usr_children.sql';

\i set_be_env.sql;

   /* Commenting out for OnTime WI #15753 as this function is supposed to be a private function
   FUNCTION d_usr_children (iusr_id    IN RAW,
                             icnt       IN NUMBER,
                             iversion   IN VARCHAR2 DEFAULT NULL)
       RETURN INTEGER;
       */

CREATE OR REPLACE FUNCTION crudg_usr.d_usr_children(IN iusr_id UUID, IN icnt INTEGER, IN iversion TEXT DEFAULT NULL)
RETURNS NUMERIC
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'd_usr_children';
    l_exception_diagnostics trc.exception_diagnostics;
    vusr_id BEOWNER.USR.usr_id%TYPE;
    pcnt DOUBLE PRECISION;
    vtransaction_id BEOWNER.USR.transaction_id%TYPE;
    /* OnTime WI #15753 */
    /* Added transaction_id for OnTime WI #14078 */
    vsubs_children_del_return INTEGER;
    subs_to_be_deleted RECORD;
/* OnTime WI #15972 */
/* OnTime WI #15753 */
BEGIN

    SELECT
        transactionid
        INTO STRICT vtransaction_id
        FROM beowner.ctx_data;

    IF (icnt = 0) THEN
        RETURN utl.get_constant_value('csuccess');
    END IF;
    vusr_id := iusr_id;
    
    select utl.set_module_action( l_module_name, 'Starting D_USR_CHILDREN usr_id=' || vusr_id) into l_action;

    DELETE FROM beowner.usr_phone
        WHERE usr_id = vusr_id;
    DELETE FROM beowner.usr_email
        WHERE usr_id = vusr_id;
    DELETE FROM beowner.usr_demog
        WHERE usr_id = vusr_id;
    /* Jira SBM-110 */
    DELETE FROM beowner.usr_acl
        WHERE usr_id = vusr_id;
    /* OnTime WI #15753 */

    IF NOT utl.is_user_relation_static() THEN
        SELECT
            COUNT(*)
            INTO STRICT pcnt
            FROM beowner.subscription_users
            WHERE secondary_id = vusr_id;

        IF (pcnt > 0) THEN
            -- Added conditional transaction update as part of DCS1E-1213
            IF vtransaction_id IS NOT NULL
            THEN
                UPDATE beowner.subscription_users
                SET transaction_id = vtransaction_id
                    WHERE secondary_id = vusr_id;
            END IF; 
            
            DELETE FROM beowner.subscription_users
                WHERE secondary_id = vusr_id;
            pcnt := 0;
        END IF;
    END IF;
    /* OnTime WI #15972 : Delete all the children of subscriptions at the same time */

    FOR subs_to_be_deleted IN
    SELECT
        subscription_id
        FROM beowner.subscription
        WHERE primary_id = vusr_id
    LOOP
        vsubs_children_del_return := crudg_subscription.delete_subs_children(i_subscription_id => subs_to_be_deleted.subscription_id, i_transaction_id => vtransaction_id);

        IF vsubs_children_del_return != utl.get_constant_value('csuccess')::INTEGER THEN
            RETURN vsubs_children_del_return;
        END IF;
        /* OnTime WI #15753 */
        -- Added conditional transaction update as part of DCS1E-1213
        IF vtransaction_id IS NOT NULL
        THEN
            UPDATE beowner.subscription
            SET transaction_id = vtransaction_id
                WHERE subscription_id = subs_to_be_deleted.subscription_id;
        END IF;
        DELETE FROM beowner.subscription
            WHERE subscription_id = subs_to_be_deleted.subscription_id;
    END LOOP;
    DELETE FROM beowner.validation_token
        WHERE usr_id = vusr_id;
    DELETE FROM beowner.usr_inf
        WHERE usr_id = vusr_id;
    /* DI #1475 */
    DELETE FROM beowner.usr_actions
        WHERE usr_id = vusr_id;
    /* TCP-144 */
    DELETE FROM beowner.usr_push_handsets
        WHERE usr_id = vusr_id;
    /* DCS1NOTES-49 */
    DELETE FROM beowner.oem_notif_recipients AS onr
        WHERE onr.usr_id = vusr_id;
    /* OnTime WI #14078, so that history row has right transaction_id */
    -- Added conditional transaction update as part of DCS1E-1213
    IF vtransaction_id IS NOT NULL
    THEN    
        UPDATE beowner.usr
            SET transaction_id = vtransaction_id   /* OnTime WI #15753 */
        WHERE usr_id = vusr_id;
    END IF;

    DELETE FROM beowner.usr
        WHERE usr_id = vusr_id;
    
    select utl.set_action( 'Finished D_USR_CHILDREN usr_id=' ||vusr_id ) into l_action; 

    RETURN utl.get_constant_value('csuccess');
    EXCEPTION
        WHEN others THEN
         GET STACKED diagnostics
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,              
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;
            call trc.log(iadditionaldata => NULL,
                iexception_diagnostics => l_exception_diagnostics);
            RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql;

\i cleanup.sql;
