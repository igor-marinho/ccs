SET bedb.filename = 'function.cr_usr_sp_no_pwd.sql';

\i set_be_env.sql;

-- Removed column tos_flag,dwnld_app_flag for DCS1E-921
DROP FUNCTION IF EXISTS crudg_usr.cr_usr_sp_no_pwd(i_uc_id beowner.usr.login_id%TYPE, beowner.usr_demog.name_first%TYPE, beowner.usr_demog.name_last%TYPE, beowner.usr_phone.phone%TYPE, beowner.usr_phone.phone_type_id%TYPE, beowner.usr_demog.addr1%TYPE, beowner.usr_email.email_type_id%TYPE, beowner.usr_email.email%TYPE, TEXT , beowner.usr.usr_id%TYPE, beowner.usr.create_type%TYPE );
CREATE OR REPLACE FUNCTION crudg_usr.cr_usr_sp_no_pwd(IN i_uc_id TEXT, 
                                                      IN ifirst_name TEXT DEFAULT NULL, 
                                                      IN ilast_name TEXT DEFAULT NULL, 
                                                      IN iphone TEXT DEFAULT NULL, 
                                                      IN iph_type TEXT DEFAULT NULL, 
                                                      IN iaddr TEXT DEFAULT NULL, 
                                                      IN iaddr_type TEXT DEFAULT 'H1', 
                                                      IN iemail TEXT DEFAULT NULL, 
                                                      IN iversion TEXT DEFAULT NULL, 
                                                      IN iparent_id TEXT DEFAULT NULL, 
                                                      IN icreate_type TEXT DEFAULT 'M')
RETURNS INTEGER
AS
$BODY$
/* cr_usr_sp_no_pwd error codes returned :
     cInvalidLoginId           constant vc := '16'
           -- The username or password is not correct.
     cInternalError        constant vc := '1' -- Internal Error.
     cUserAlreadyExists          constant vc := '15'
           -- Attempted to create a new user using an existing userLoginId.
     c_invalid_parent_id       constant vc := '279'
                   -- User with the provided Parent ID doesnï¿½t exist.
     c_parent_is_secondary     constant vc := '280'
           -- Parent ID belongs to a secondary user
     c_primary_has_no_subscriptions constant vc := '281'
           -- Secondary user is being created for a Primary User with no subscriptions
     cDb2ndrySubsLimitReached      constant vc := '220'
           -- The allowable number of secondary subscribers has been reached.
     c_new_secondary_is_primary    constant vc := '291'
           -- The new secondary user being added is already a primary user.
     c_invalid_create_type     constant vc := '295'  -- Invalid User Create Type
     c_invalid_email_type      constant vc := '298'  -- Invalid Email Type
     c_invalid_phone_type      constant vc := '299'  -- Invalid Phone Type
     -- new for WI #15750
     c_incompatible_config_primary constant vc := '347' -- Primary Id cannot be provided to this sproc with the make's user relation config (non-static)
   */

/* parent id and corresponding logic added for OnTime WI #14078 */
DECLARE
    l_action text;
    l_module_name text := 'cr_usr_sp_no_pwd';
    vusr_id BEOWNER.USR.usr_id%TYPE;
    vuserlogin BEOWNER.USR.login_id%TYPE;
    vmakeid BEOWNER.USR.make_id%TYPE;
    vpwd BEOWNER.USR.pwd%TYPE;
    vlangid BEOWNER.USR.lang_id%TYPE;
    vcreated BEOWNER.USR.created%TYPE;
    vparent_id BEOWNER.USR.parent_id%TYPE := iparent_id;
    vverified BEOWNER.USR.verified%TYPE;
    vcreate_type BEOWNER.USR.create_type%TYPE;
    vlocked BEOWNER.USR.locked%TYPE;
    /* modified for WI #14078 */
    vlvl BEOWNER.USR.lvl%TYPE :=
    CASE
        WHEN vparent_id IS NOT NULL THEN '1'
        ELSE '0'
    END;
    vparentlvl BEOWNER.USR.parentlvl%TYPE :=
    CASE
        WHEN vparent_id IS NOT NULL THEN '0'
        ELSE NULL
    END;
    vfname BEOWNER.USR_DEMOG.name_first%TYPE;
    vlname BEOWNER.USR_DEMOG.name_last%TYPE;
    vaddr BEOWNER.USR_DEMOG.addr1%TYPE;
    vphone BEOWNER.USR_PHONE.phone%TYPE;
    vph_type BEOWNER.domain_values.value%TYPE;
    vcc BEOWNER.USR_PHONE.cc%TYPE := '001';
    vac BEOWNER.USR_PHONE.ac%TYPE;
    vaddr_type BEOWNER.domain_values.value%TYPE;
    vemail BEOWNER.USR_EMAIL.email%TYPE;

    vcnt DOUBLE PRECISION;
    pcnt DOUBLE PRECISION;
    ctvin BEOWNER.VIN.vin%TYPE;
    ctmakeid BEOWNER.VIN.make_id%TYPE;
    ctusrlogid BEOWNER.USR.login_id%TYPE;

    /* WI #14078 changes */
    ct_transaction_id BEOWNER.USR.transaction_id%TYPE;
    l_parent_id BEOWNER.USR.parent_id%TYPE;

    l_allowed_secondaries BEOWNER.BNDL.max_users%TYPE;
    l_current_secondaries INTEGER;
    l_parent_make_id BEOWNER.USR.make_id%TYPE;

    l_exception_diagnostics trc.exception_diagnostics;

begin
	select utl.set_module_action( l_module_name, 'Starting CR_USR_SP') into l_action; 
	
	
    SELECT
        vin, UPPER(TRIM(make_id)), LOWER(TRIM(usrlogid)), transactionid
        INTO STRICT ctvin, ctmakeid, ctusrlogid, ct_transaction_id
        FROM beowner.ctx_data;

    vuserlogin := COALESCE(LOWER(TRIM(i_uc_id)), ctusrlogid);

    IF vuserlogin IS NULL THEN
        RETURN utl.get_constant_value('cinvalidloginid');
    END IF;
    vmakeid := ctmakeid;

    IF vmakeid IS NULL THEN
        RETURN utl.get_constant_value('cinvalidctxmakeid');
    END if;

    IF NOT utl.is_user_relation_static() AND vparent_id IS NOT NULL THEN
        RETURN utl.get_constant_value('c_incompatible_config_primary');
    END IF;
    vusr_id := beowner.rand_guid();
    vcreated := clock_timestamp();
    /* vparent_id := NULL; */
    vverified := clock_timestamp();
    vlangid := utl.get_constant_value('clangenus');
    vcreate_type := UPPER(icreate_type);    /* #19679 */
    vlocked := ' ';
    /* vlvl := '0'; */
    /* vparentlvl := NULL; */
    vcnt := 0;
    pcnt := 0;
    vfname := UPPER(TRIM(ifirst_name));
    vlname := UPPER(TRIM(ilast_name));
    vaddr := UPPER(TRIM(iaddr));
    vaddr_type := COALESCE(UPPER(TRIM(iaddr_type)), 'H1');
    /* #20128 */
    vphone := UPPER(TRIM(iphone));
    vph_type := COALESCE(UPPER(TRIM(iph_type)), 'H1');
    pcnt := LENGTH(COALESCE(vphone, '0'));
    vemail := LOWER(TRIM(iemail));

    IF pcnt >= 13 THEN
        vcc := SUBSTR(vphone, 1, 3);
        vac := SUBSTR(vphone, 4, 6);
        vphone := SUBSTR(vphone, 7, TRUNC(pcnt::NUMERIC)::INTEGER);
    ELSIF pcnt = 10 THEN
        vcc := '001';
        vac := SUBSTR(vphone, 1, 3);
        vphone := SUBSTR(vphone, 4, TRUNC(pcnt::NUMERIC)::INTEGER);
    ELSIF pcnt < 10 THEN
        vcc := '001';
        vac := '999';
    END IF
    /* Modified for OnTime WI #14078 to return different error messages based on whether existing user is a primary or secondary user */;

    BEGIN
        SELECT
            parent_id
            INTO STRICT l_parent_id
            FROM beowner.usr
            WHERE make_id = vmakeid AND login_id = vuserlogin;

        IF vparent_id IS NULL OR l_parent_id IS NOT NULL
        /* primary being added or user already exists as secondary */
        THEN
            RETURN utl.get_constant_value('cuseralreadyexists');
        ELSE
            RETURN utl.get_constant_value('c_new_secondary_is_primary');
        END IF;
        EXCEPTION
            WHEN no_data_found THEN
                NULL;
        /* the user doesn't exist already */
    END
    /* check added for #19679, modified for #20128 */;

    IF COALESCE(vcreate_type, '!') NOT IN ('I', 'M', 'O') THEN
        RETURN utl.get_constant_value('c_invalid_create_type');
    END IF;
	
    -- CCS1E-1971
	-- IF NOT utl.is_domain_value_valid(i_domain => cnst.c_domain_email_type,
	--							   i_value  => vaddr_type)
	IF NOT utl.is_domain_value_valid( utl.get_constant_value('c_domain_email_type'), vaddr_type )
	THEN
        RETURN utl.get_constant_value('c_invalid_email_type');
    END IF;
	
    -- CCS1E-1971
    -- IF NOT utl.is_domain_value_valid(i_domain => cnst.c_domain_phone_type,
    --                                 i_value  => vph_type)	
    IF NOT utl.is_domain_value_valid( utl.get_constant_value('c_domain_phone_type'), vph_type)
	THEN
        RETURN utl.get_constant_value('c_invalid_phone_type');
    END IF
    /* OnTime WI #14078 */;

    IF vparent_id IS NOT NULL THEN
        BEGIN
            SELECT
                parent_id, make_id
                INTO STRICT l_parent_id, l_parent_make_id
                FROM beowner.usr
                WHERE usr_id = vparent_id;

            IF l_parent_id IS NOT NULL THEN
                RETURN utl.get_constant_value('c_parent_is_secondary');
            ELSIF vmakeid != l_parent_make_id THEN
                RETURN utl.get_constant_value('c_invalid_parent_make_id');
            END IF;
            EXCEPTION
                WHEN no_data_found THEN
                    RETURN utl.get_constant_value('c_invalid_parent_id');
            /*
            -- uncomment if input param iparent_id is changed to varchar2
            WHEN einvalidhex
            THEN
               RETURN beowner.cnst.c_invalid_parent_id;
            */
        END;
        SELECT
            COUNT(1)
            INTO STRICT vcnt
            FROM beowner.subscription
            WHERE primary_id = vparent_id;

        IF vcnt = 0 THEN
            RETURN utl.get_constant_value('c_primary_has_no_subscriptions');
        END IF;
        SELECT
            CASE MIN(m.secondaries_rule)
                WHEN 'SUM' THEN SUM(b.max_users - 1)
                WHEN 'MINIMUM' THEN MIN(b.max_users - 1)
                ELSE MAX(b.max_users - 1)
            END AS allowed_sec
            INTO STRICT l_allowed_secondaries
            FROM beowner.make AS m, beowner.subscription AS s, beowner.bndl AS b
            WHERE m.make_id = vmakeid AND s.primary_id = vparent_id AND b.bndl_id = s.bndl_id;
        SELECT
            COUNT(u.usr_id) AS current_sec
            INTO STRICT l_current_secondaries
            FROM beowner.usr AS u
            WHERE u.parent_id = vparent_id;

        IF l_allowed_secondaries <= l_current_secondaries
        /* new secondary is not allowed even if they are equal */
        THEN
            RETURN utl.get_constant_value('cdb2ndrysubslimitreached');
        END IF;
    END IF;
    INSERT INTO beowner.usr (usr_id, login_id, make_id, pwd, created, parent_id, verified, lang_id, create_type, locked, lvl, parentlvl, transaction_id)
    VALUES (vusr_id, vuserlogin, vmakeid, vpwd, vcreated, vparent_id, vverified, vlangid, vcreate_type, vlocked, vlvl, vparentlvl, ct_transaction_id);
    INSERT INTO beowner.usr_email (usr_id, email_type_id, email)
    VALUES (vusr_id, vaddr_type, vemail);

    IF ((LENGTH(COALESCE(vfname, '0'))) + (LENGTH(COALESCE(vlname, '0'))) + (LENGTH(COALESCE(vaddr, '0')))) > 0 THEN
        INSERT INTO beowner.usr_demog (usr_id, name_first, name_last, addr1)
        VALUES (vusr_id, vfname, vlname, vaddr);
    END IF;

    IF pcnt > 0 AND vphone IS NOT NULL THEN
        INSERT INTO beowner.usr_phone (usr_id, phone_type_id, cc, ac, phone, ext)
        VALUES (vusr_id, vph_type, vcc, vac, vphone, NULL);
    END IF;
    RETURN utl.get_constant_value('csuccess');
    EXCEPTION
        WHEN others THEN
            GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,              
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;
              
            call trc.log(iadditionaldata => NULL,
                            iexception_diagnostics => l_exception_diagnostics);
            RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
