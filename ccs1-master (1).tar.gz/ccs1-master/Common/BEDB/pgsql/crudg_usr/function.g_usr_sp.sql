SET bedb.filename = 'function.g_usr_sp.sql';

\i set_be_env.sql;

   /* g_usr_sp
    Return Cursor:
      user_id, userlogin, pwd, first_name, last_name, phone, ph_type, addr, addr_type, email,
      version, parent_id, parent_login_id, transaction_id
   
      Error Codes returned:
          cInvalidLoginId   constant vc := '16' -- The username or password is not correct.
          cInternalError    constant vc := '1' -- Internal Error.
   */

CREATE OR REPLACE FUNCTION crudg_usr.g_usr_sp(IN iusr_id TEXT DEFAULT NULL,
                                              IN i_uc_id TEXT DEFAULT NULL,
                                              IN iuserlogin TEXT DEFAULT NULL,
                                              IN ipwd TEXT DEFAULT NULL, 
                                              IN ifirst_name TEXT DEFAULT NULL,
                                              IN ilast_name TEXT DEFAULT NULL,
                                              IN iversion TEXT DEFAULT NULL,
                                              OUT function_status INTEGER,
                                              OUT rslt REFCURSOR)
language plpgsql
SECURITY DEFINER
AS
$BODY$
  /* g_usr_sp
    Return Cursor:
      user_id, userlogin, pwd, first_name, last_name, phone, ph_type, addr, addr_type, email,
      version, parent_id, parent_login_id, transaction_id

      Error Codes returned:
      cInvalidLoginId   constant vc := '16' -- The username or password is not correct.
      cInternalError    constant vc := '1' -- Internal Error.
   */
DECLARE
    l_action text;
    l_module_name text := 'g_usr_sp';
    vuserlogin BEOWNER.USR.login_id%TYPE;
    ctvin BEOWNER.VIN.vin%TYPE;
    ctmakeid BEOWNER.VIN.make_id%TYPE;
    ctusrlogid BEOWNER.USR.login_id%TYPE;
    l_exception_diagnostics trc.exception_diagnostics;

begin

    select utl.set_module_action( l_module_name, 'Starting G_USR_SP') into l_action; 
    

    select vin, UPPER(TRIM(make_id)), LOWER(TRIM(usrlogid))
      INTO STRICT ctvin, ctmakeid, ctusrlogid
      FROM beowner.ctx_data;

    vuserlogin := COALESCE(LOWER(TRIM(iuserlogin)), ctusrlogid);

    IF vuserlogin IS NULL THEN
        vuserlogin := COALESCE(LOWER(TRIM(i_uc_id)), ctusrlogid);
    END IF;

    IF vuserlogin IS NULL AND iusr_id IS NULL THEN
        function_status := utl.get_constant_value('cinvalidloginid');
        rslt := utl.get_dummy_cursor();
        RETURN;
    END IF;

    OPEN rslt for
         SELECT u.usr_id AS user_id,
                u.login_id AS userlogin,
                u.pwd AS pwd,
                ud.name_first AS first_name,
                ud.name_last AS last_name,
                up.phone AS phone,
                up.phone_type_id AS ph_type,
                ud.addr1 AS addr,
                ue.email_type_id AS addr_type,
                ue.email AS email,
                '' AS version,
                u.parent_id,
                pu.login_id parent_login_id,
                u.transaction_id
           FROM beowner.usr u
           left
           join beowner.usr_demog ud
             on (ud.usr_id = u.usr_id)                
           left
           join beowner.usr_phone up
             on (up.usr_id = u.usr_id)
           left
           join beowner.usr_email ue
             on (ue.usr_id = u.usr_id)
           left
           join beowner.usr pu
             on (pu.usr_id = u.parent_id)
          where u.make_id = COALESCE(ctmakeid, u.make_id) -- OnTime #20847
            AND u.login_id = COALESCE(vuserlogin, u.login_id) -- OnTime WI #14078
            AND u.usr_id = COALESCE(iusr_id::uuid, u.usr_id); -- OnTime WI #14078

    function_status := utl.get_constant_value('csuccess');
    RETURN;
    EXCEPTION
        WHEN others THEN
         GET STACKED diagnostics
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,              
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;
            call trc.log(CONCAT_WS('', 'Something went really wrong in G_USR_SP login_id=', vuserlogin),
                iexception_diagnostics => l_exception_diagnostics);
            rslt := utl.get_dummy_cursor();
            function_status := utl.get_constant_value('cinternalerror');
            RETURN;
END;
$BODY$;

\i cleanup.sql;
