SET bedb.filename = 'function.contract_last_owned_by_user.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS contract.contract_last_owned_by_user(beowner.vin.vin%TYPE, beowner.usr.usr_id%TYPE, beowner.contrct.contract_id%TYPE);
   -- Added for #7088 to identify if contract was last owned by the same user, to determine whether user verified email should be sent or not
   -- based on context diagrams third and fourth

CREATE OR REPLACE FUNCTION contract.contract_last_owned_by_user (i_vin           beowner.vin.vin%TYPE
                                                                ,i_usr_id        beowner.usr.usr_id%TYPE
                                                                ,i_contract_id   beowner.contrct.contract_id%TYPE) RETURNS boolean 
AS $body$
DECLARE
      l_user          beowner.usr.usr_id%TYPE;
      l_owned_by_user boolean;
BEGIN
      CALL contract.dbg('vin = ' || i_vin || 'user id = ' || i_usr_id || ' contract id = ' || i_contract_id);

      BEGIN
         SELECT *
           INTO STRICT l_user
           FROM (SELECT src_usr
                   FROM beowner.contrct_log
                  WHERE src_vin = i_vin
                        AND contract_id = i_contract_id
                        AND action = 'X'
                  ORDER BY tmstmp DESC) alias0 LIMIT 1;

         IF l_user != i_usr_id
         THEN
            l_owned_by_user := FALSE;
         ELSE
            l_owned_by_user := TRUE;
         END IF;
      EXCEPTION
         WHEN no_data_found THEN
            l_owned_by_user := FALSE;
      END;

      CALL contract.dbg(CASE WHEN l_owned_by_user THEN 'true' ELSE 'false' END);
      RETURN l_owned_by_user;
   END;
$body$
LANGUAGE PLPGSQL;
-- REVOKE ALL ON FUNCTION contract.contract_last_owned_by_user (i_vin vin.vin%TYPE, i_usr_id usr.usr_id%TYPE, i_contract_id contrct.contract_id%TYPE) FROM PUBLIC;

\i cleanup.sql;
