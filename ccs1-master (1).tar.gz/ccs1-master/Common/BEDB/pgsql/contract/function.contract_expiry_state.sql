SET bedb.filename = 'function.contract_expiry_state.sql';

\i set_be_env.sql;

/*
   Added for Ontime defect# 23856 - CR10236 - SC contract pending notification message is shown until 30 days instead of 30+1 days
   Function contract_expiry_state is only meant for internal use
*/
DROP FUNCTION IF EXISTS contract.contract_expiry_state(timestamp, beowner.vin.vin%type);
CREATE OR REPLACE FUNCTION contract.contract_expiry_state(i_expiry_date timestamp, i_vin beowner.vin.vin%type)
    RETURNS text AS
$BODY$
DECLARE

    --Added for Ontime defect# 23856 - CR10236 - SC contract pending notification message is shown until 30 days instead of 30+1 days
    l_contract_expiry_state char varying(1);
    l_warning_start_days    beowner.bndl.warning_start_days%type;
    l_days_to_expiry        integer;

BEGIN
    l_days_to_expiry := ((date_trunc('day', i_expiry_date)::date + integer '1') - current_date);
    -- Adding one day to expiry day to extend the contract for one day
    -- This code works for where there is one to one relationship between bundle and device
    SELECT b.warning_start_days
    INTO STRICT l_warning_start_days
    FROM beowner.bndl b,
         beowner.vin v
    WHERE v.vin = i_vin
      AND v.device_id = b.device_id
    LIMIT 1;

    SELECT CASE
               WHEN l_days_to_expiry <= l_warning_start_days AND -- Ontime defect# 23856
                    l_days_to_expiry >= 0 THEN
                   utl.get_constant_value('c_contract_pending') --Pending
               WHEN l_days_to_expiry < 0 THEN
                   utl.get_constant_value('c_contract_expired') --Expired
               ELSE
                   utl.get_constant_value('c_contract_active') --Active
               END
    INTO l_contract_expiry_state;

    RETURN l_contract_expiry_state;
END
$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION contract.contract_expiry_state (i_expiry_date timestamp, i_vin beowner.vin.vin%TYPE) FROM PUBLIC;

\i cleanup.sql;
