SET bedb.filename = 'function.get_svc_contract_expiry_state.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS contract.get_svc_contract_expiry_state(beowner.vin.vin%type, beowner.usr.login_id%type, beowner.svc.svc_id%type, text);

/*  GET_SVC_CONTRACT_EXPIRY_STATE

  This sproc to and returns flag to show contract expiry state (contract_expiry_state) and
  service expires with contract flag (expires_with_contract).

input: i_vin            the VIN associated with the contract(required)
       i_PartnerID      the partner ID from the portal(required)
       i_userloginid    the user's login_id(required)
       i_serviceid      the service id (required)

return: integer      0      If successful
                     1      If unknown error (check "trc" table)
                     7      The user was not found [cnst.cNoSuchUser]
                     27     The Login ID provided is null.
                     213    The partnerid is not valid(cnst.cdbpartneridnotvalid)
                     236    Service Id is Null
                     237    Invalid Service Id(c_invalid_svc_id)is feature or service.
                     288     No matching subscriptions were found.
                     421    If the EV/FCV VIN isn't in our database [cnst.c_EV_FCV_vinnotfound]

 */
--New function added for Jira #CR10236-125

CREATE OR REPLACE FUNCTION contract.get_svc_contract_expiry_state(i_vin 			beowner.vin.vin%type,
                                                                  i_userloginid 	beowner.usr.login_id%type,
                                                                  i_serviceid 		beowner.svc.svc_id%type,
                                                                  i_partnerid 		text,
                                                                  OUT o_status_code integer,
                                                                  OUT o_result 		refcursor) AS
$body$
DECLARE
    l_action                text;
    l_module_name           text    := 'get_svc_contract_expiry_state';

    --New function added for Jira #CR10236-125
    --This sproc is for TMS only
    l_validation_return     integer := utl.get_constant_value('csuccess') :: integer;
    l_vin                   beowner.vin.vin%type;
    l_svc_id                beowner.svc.svc_id%type;
    l_userloginid           beowner.usr.login_id%type;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    o_result := utl.get_dummy_cursor();
    l_vin := trim(BOTH upper(i_vin));
    l_userloginid := trim(BOTH i_userloginid);
    l_svc_id := trim(BOTH i_serviceid);

    l_action := utl.set_module_action(l_module_name,
                                      ' Validating inputs');

    -- Removed constant for Jira DCS1E-1307
    l_validation_return := contract.validate_input_params(i_vin => l_vin,
                                                          i_userloginid => l_userloginid,
                                                          i_serviceid => l_svc_id,
                                                          i_partnerid => i_partnerid,
                                                          i_svc_id_required => TRUE);

    IF l_validation_return != utl.get_constant_value('csuccess')::integer THEN
        o_status_code := l_validation_return;
        RETURN;
    END IF;

    l_action := utl.set_module_action(l_module_name,
                                      ' Returning cursor results');

    CLOSE o_result;
    OPEN o_result FOR
        SELECT contract.contract_expiry_state(i_expiry_date => expiry_date,
                                              i_vin => l_vin) contract_expiry_state, -- Ontime defect# 23856,
               expires_with_contract
        FROM (SELECT date_trunc('day', C.expired)::date expiry_date,
                     S.expires_with_contract
              FROM beowner.contrct C,
                   beowner.vin v,
                   beowner.svc S
              WHERE v.vin = l_vin
                AND S.svc_id = l_svc_id
                AND S.expires_with_contract IS NOT NULL
                AND C.contract_id = v.contract_id) alias2;

    o_status_code := utl.get_constant_value('csuccess');
    RETURN;
EXCEPTION
    WHEN SQLSTATE 'EPTNR' THEN
        o_status_code = utl.get_constant_value('cdbpartneridnotvalid');
        RETURN;
    WHEN SQLSTATE 'EUSRN' THEN
        o_status_code = utl.get_constant_value('cnosuchuser');
        RETURN;
    WHEN OTHERS THEN
        l_action = utl.set_module_action(l_module_name,
                                         ' Something went wrong with get_contract_expiry_date');
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
			l_exception_diagnostics.module_name := l_module_name;
			l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
		o_result := utl.get_dummy_cursor();
        o_status_code = utl.get_constant_value('cinternalerror');
        RETURN;
END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION contract.get_svc_contract_expiry_state (i_vin beowner.vin.vin%TYPE, i_userloginid beowner.usr.login_id%TYPE, i_serviceid beowner.svc.svc_id%TYPE, i_partnerid text, o_result OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
