SET bedb.filename = 'function.invalidate_contract.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS contract.invalidate_contract(text, text, BOOLEAN, UUID);
DROP FUNCTION IF EXISTS contract.invalidate_contract(text, text, BOOLEAN, TEXT);
   /*  INVALIDATE_CONTRACT
   
   Disrupts all user contracts for a given VIN
   
   If iClearVinCtrx is NOT NULL (any value), then the ContractID is
   removed from that VIN as well. It is not an error to clear a
   VIN/Contract that does not have a contract assigned.
   
   return: integer 0   if successful
                   1   if unknown error
                   200 if VIN not found                                   */

                        
CREATE OR REPLACE FUNCTION contract.invalidate_contract(IN ivin TEXT, 
                                                        IN iclearvinctrx TEXT DEFAULT NULL, 
                                                        IN icalled_by_utl BOOLEAN DEFAULT TRUE, 
                                                        IN idetail_batch_guid TEXT DEFAULT NULL)
RETURNS INTEGER
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'invalidate_contract';
    vtemplatename beowner.email_info.template_name%TYPE;
    /* Modified for WI #15530 */
    vnamefl CHARACTER VARYING(257);
    vsubject beowner.email_info.subject%TYPE;
    /* Modified for WI #15530 */
    vsubs_count INTEGER;
    /* added for #7088 to determine the number of subscriptions for the VIN */
    vemail_name beowner.email_info.name%TYPE;
    /* Added for WI #15530 */
    vmissing_email_code TEXT;
    vdelsubsnotif INTEGER;
    c1 RECORD;
/* Added for DI#1457 */
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN

    l_action := utl.set_module_action( l_module_name, 'Invalidate Contract Vin');

    /* Below logic added for #7088 to determine which email, if any should be sent */
    SELECT
        COUNT(1)
        INTO STRICT vsubs_count
        FROM beowner.subscription AS s
        WHERE s.vin = ivin;
    /* Below logic was changed for OnTime WI #15530 */

    IF icalled_by_utl
    /* called by utl.checkVinConflict, when VIN is claimed from user portal and conflict is detected */
    THEN
        vemail_name := 'INIT_CONFLICT_NOTIFICATION_OLD_USER';
        vmissing_email_code := utl.get_constant_value('c_conflict_nou_email_missing');
    ELSIF vsubs_count = 1
    /* #7088 - email to be sent ONLY if not in conflict, since if in conflict, email would have been sent earlier when called from utl.checkVinConflict */
    /* #7088 - if not called from utl.checkVinConflict, send different email based on second context diagram */
    THEN
        vemail_name := 'CONTRACT_ID_CHANGE_OWNERSHIP';
        vmissing_email_code := utl.get_constant_value('c_conflict_cico_email_missing');
    ELSE
        vemail_name := NULL;
        vmissing_email_code := NULL;
    END IF
    /* #7088 end */;

    FOR c1 IN
        SELECT a.subscription_id
          ,a.primary_id          AS primary_id
          ,a.contract_id         AS contract_id
          ,a.contract_tmstmp     AS contract_tmstmp
          ,b.device_id           AS device_id
          ,b.model               AS model
          ,c.login_id            AS vemail
          ,d.contract_owner      AS contract_owner
          ,d.extrnl_ctrct_id     AS extrnl_ctrct_id
          ,d.expired             AS expired
          ,ud.name_first
          ,ud.name_last
          ,c.usr_id
          ,c.make_id
      /* #16955 */
      FROM beowner.subscription   a
          ,beowner.vin            b
          ,beowner.contrct        d
          ,beowner.usr_demog      ud
           RIGHT OUTER JOIN beowner.usr  c 
            ON (ud.usr_id = c.usr_id)
     WHERE     d.contract_id = a.contract_id
           AND c.usr_id = a.primary_id
           AND b.vin = a.vin
           AND a.contract_id IS NOT NULL
           AND a.optin_level > 0
           AND a.vin = ivin
    /* logging the old contract information stored in the subscription */
    LOOP
        l_action := utl.set_action( 'Log old Contract Info due to Invalidate Contract Vin');

        INSERT INTO beowner.contrct_log (contract_id
                                ,tmstmp
                                ,action
                                ,src_vin
                                ,src_usr
                                ,contract_tmstmp
                                ,extrnl_ctrct_id
                                ,contract_owner
                                ,expired)
             VALUES (c1.contract_id
                    ,clock_timestamp ()
                    ,'X'
                    ,ivin
                    ,c1.primary_id
                    ,c1.contract_tmstmp
                    ,c1.extrnl_ctrct_id
                    ,c1.contract_owner
                    ,c1.expired);

        /* removing the contract data from conflicting subscribers that have claimed this contract */
        l_action := utl.set_action( 'Set optin_level = 0 and contract_tmstmp to null due to invalidated contract');

        UPDATE beowner.subscription
           SET optin_level = 0
              ,contract_tmstmp = NULL
              ,contract_id = NULL
              ,transaction_id = (SELECT transactionid FROM beowner.ctx_data)
         /* Jira #CR10236-27 */
         WHERE contract_id IS NOT NULL AND subscription_id = c1.subscription_id;
            
        l_action := utl.set_action( 'Creating message for Contract Conflict Loss of EV Services email');

        DECLARE
            vkeyvalues xml;
        BEGIN
            IF (utl.is_conflict_enforced(i_device_id := c1.device_id) = 'Y')
            /* Modified for OnTime WI #15529 */
            THEN
                l_action := utl.set_action( 'New contract received so remove EV notifications due to invalidated contract');
                                                                 
                vnamefl := COALESCE(TRIM(CONCAT_WS('', c1.name_first, ' ', c1.name_last)), utl.get_constant_value('c_pending_user_name'));
                /* #14351 */
                /* added for OnTime Defect 11852 (DB - the user opts in with old contractId doesn't lose the services after updating vin contract with a new contractId.) */
                /* Added for DI#1457 */
                vdelsubsnotif := crudg_subscription.delete_subs_notif(c1.subscription_id);

                IF vdelsubsnotif != utl.get_constant_value('csuccess')::INTEGER THEN
                    --CRITICAL: Cannot do rollback in postgres function 
                    --PERFORM beowner.utl$dorollback();
                    RETURN vdelsubsnotif;
                END IF;
                IF idetail_batch_guid IS NULL
                /* JIRA #CR10212-27 */
                AND vemail_name IS NOT NULL
                /* OnTime WI #15530 */
                /* #7088 - only send email if template name assigned based on logic before the loop */
                THEN
                    l_action := utl.set_action( 'Sending email');  
                    PERFORM ctx.set(iusrid := c1.usr_id::TEXT, imakeid := c1.make_id, ivin := ivin);
                    /* #16955 */
                    SELECT xmlconcat(xmlelement(name entry,
                                       xmlelement(name key,'subscriberName'),
                                       xmlelement(name value,vnamefl)),
                                       xmlelement(name entry,
                                       xmlelement(name key,'vin'),
                                       xmlelement(name value,ivin)))
                      INTO STRICT vkeyvalues;
                              
                    /* Added for OnTime WI #15530 */
                    CALL utl.get_email_info(i_make_id         => c1.make_id,
                                            i_email_name      => vemail_name,
                                            i_device_id       => c1.device_id,
                                            i_vin             => ivin,
                                            i_subscription_id => c1.subscription_id,
                                            o_subject         => vsubject,
                                            o_template_name   => vtemplatename);
                                
                    IF vtemplatename IS NULL AND vmissing_email_code IS NOT NULL THEN
                        RETURN vmissing_email_code;
                    END IF;
  
                PERFORM email.send(ito := c1.vemail, isubject := vsubject, itemplatename := vtemplatename, ikeyvalues := vkeyvalues);
                END IF;
            END IF;
        END;
    END LOOP;
    RETURN 0;
    EXCEPTION
        WHEN others THEN
            GET STACKED diagnostics
              l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
              l_exception_diagnostics.column_name := COLUMN_NAME,
              l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
              l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
              l_exception_diagnostics.message_text := MESSAGE_TEXT,
              l_exception_diagnostics.table_name := TABLE_NAME,
              l_exception_diagnostics.schema_name := SCHEMA_NAME,              
              l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
              l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
              l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;
            CALL trc.log(iadditionaldata => NULL,
                            iexception_diagnostics => l_exception_diagnostics);
            RETURN utl.get_constant_value('cinternalerror');
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;
\i cleanup.sql;
