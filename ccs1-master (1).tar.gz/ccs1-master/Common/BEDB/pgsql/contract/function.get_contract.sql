SET bedb.filename = 'function.get_contract.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS contract.get_contract(text);

   /*  GET_CONTRACT
   
   For a given VIN, returns a single row with the following data:
   
   CONTRACT_ID     -- if NULL, then no Contract ID is associated with this VIN
   CONTRACT_TMSTMP -- A timestamp in ISO format: "2011-12-25T13:59:59Z" - can
                      be NULL if a user is not currently using the contract.
   USR_ID          -- The User GUID. Filled only if valid and not in conflict.
   LOGIN_ID        -- The User LOGIN_ID. Filled only if valid and not in conflict.
   PARTNER_ID      -- TBD: a GUID representing the make/?
   CONFLICT        -- Will be "*" if this contract has a conflict. Will be " " (space)
                      if the contract is not in conflict. This does not mean the
                      user has a valid contract. Will be NULL if there is no
                      Contract ID for this VIN.                           */

CREATE OR REPLACE FUNCTION contract.get_contract (ivin                text
                                                 ,o_status_code   OUT INTEGER
                                                 ,oresult         OUT refcursor) 
AS $body$
DECLARE
    l_action TEXT;
    l_module_name text := 'get_contract';
    vcontractid      beowner.vin.contract_id%TYPE;
    vcontracttmstmp  beowner.subscription.contract_tmstmp%TYPE;
    vusrid           beowner.usr.usr_id%TYPE;
    vloginid         beowner.usr.login_id%TYPE;
    vpartnerid       beowner.ptnr.ptnr_id%TYPE;
    vconflict        beowner.subscription.conflict%TYPE;
    vextrnl_ctrct_id beowner.contrct.extrnl_ctrct_id%TYPE; -- Added for Defect 14822
    vcontrct_owner   beowner.contrct.contract_owner%TYPE; -- Added for defect 14822
    ROWCOUNT INTEGER := 0;
    c1 RECORD;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    l_action := utl.set_module_action( l_module_name, 'Get VIN subscription counts.');
    o_status_code := utl.get_constant_value('csuccess');
    oresult := utl.get_dummy_cursor();
      <<mainloop>>
   -- get the VIN and outer-join with SUBSCRIPTION/USR data.
      -- also get the subscription count of the VIN
      -- and the Database Partner ID
      FOR c1 IN (SELECT v.contract_id     vin_contract_id,
                        s.contract_id     sub_contract_id,
                        s.contract_tmstmp,
                        s.primary_id      usr_id,
                        u.login_id,
                        p.ptnr_id,
                        vc.vincount,
                        s.conflict
                   FROM beowner.vin v
                   LEFT JOIN beowner.subscription s
                     ON v.vin = s.vin
                   LEFT JOIN beowner.usr u
                     ON u.usr_id = s.primary_id
                   JOIN(SELECT COUNT(*) vincount
                          FROM beowner.subscription
                         WHERE vin = ivin) vc
                     ON NULL IS NULL
                   JOIN beowner.ptnr p
                     ON p.make_id = v.make_id
                        AND p.hu_mfr_id = 'DB'
                  WHERE v.vin = ivin)
      LOOP
         ROWCOUNT := ROWCOUNT + 1;
         IF ROWCOUNT = 1
         THEN
            -- this data will be the same for the entire cursor, so only get it once.
            vpartnerid := c1.ptnr_id;
            vconflict := CASE
                            WHEN c1.vin_contract_id IS NOT NULL THEN
                             CASE
                                WHEN c1.vincount > 1 THEN
                                 c1.conflict
                                ELSE
                                 NULL
                             END
                            ELSE
                             NULL
                         END;
            vcontractid := c1.vin_contract_id;
         END IF;
         -- we're done if there isn't any valid data; get out of the loop.
         IF ((vcontractid IS NULL) OR (vconflict IS NOT NULL))
         THEN
            EXIT mainloop;
         END IF;

         -- See if we need to fill in some data. Our flag is CONTRACT_TMSTMP
         IF vcontracttmstmp IS NULL
         THEN
            -- We must test to see if the contract is valid. The test is that the
            -- VIN Contract and Subscription Contract are the same
            -- and there is a timestamp on the contract.
            IF (c1.sub_contract_id = c1.vin_contract_id AND c1.contract_tmstmp IS NOT NULL)
            THEN
               vcontracttmstmp := c1.contract_tmstmp;
               vusrid := c1.usr_id;
               vloginid := c1.login_id;
            END IF;
         END IF;
      END LOOP mainloop;
 
      -- return data if there is anything to return
      IF ROWCOUNT > 0
      THEN
         -- added for Defcet 14822 as they need the external contract ID and the contract owner now to validate the contract
         BEGIN
            SELECT extrnl_ctrct_id,
                   contract_owner
              INTO STRICT vextrnl_ctrct_id,
                   vcontrct_owner
              FROM beowner.contrct bc
             WHERE bc.contract_id = vcontractid;
         EXCEPTION
            WHEN no_data_found THEN
               RETURN;
         END;
 
         CLOSE oresult; 
         OPEN oresult FOR
            SELECT encode(vcontractid, 'escape'),
                   vcontracttmstmp,
                   vusrid,
                   vloginid,
                   vpartnerid,
                   vconflict,
                   vextrnl_ctrct_id, -- Defect 14822
                   vcontrct_owner -- Defect 14822
                   ;
         RETURN;
      ELSE
         RETURN;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.action := l_action;
          l_exception_diagnostics.module_name := l_module_name;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
        oresult := utl.get_dummy_cursor();
        o_status_code := utl.get_constant_value('cinternalerror');
        RETURN;
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION contract.get_contract (ivin text, oresult OUT REFCURSOR) FROM PUBLIC;
\i cleanup.sql;
