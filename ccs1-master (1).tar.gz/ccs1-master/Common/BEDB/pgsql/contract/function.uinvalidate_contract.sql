SET bedb.filename = 'function.uinvalidate_contract.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS contract.uinvalidate_contract(text, text, text);

CREATE OR REPLACE FUNCTION contract.uinvalidate_contract (ivprimaryid   text
                                                         ,ivvin         text
                                                         ,icontractid   text DEFAULT NULL -- #7088 Added parameter since current contract ID is used to determine if the contract owner has changed
                                                          )RETURNS INTEGER 
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'uinvalidate_contract';

    vtemplatename beowner.email_info.template_name%TYPE; -- Modified for WI #15530
    vnamefl       varchar(257);
    l_subject     email_info.subject%TYPE; -- Added for WI #15530
    vdelsubsnotif integer; -- Added for DI#1457
    c1 RECORD;
    l_exception_diagnostics trc.exception_diagnostics;
    c_pending_user_name TEXT := 'Toyota Customer';

BEGIN
      l_action := utl.set_module_action( l_module_name, ' : Invalidate Contract and Usr Conflict Loss');

    FOR c1
        IN (SELECT a.subscription_id
                  ,a.primary_id          primary_id
                  ,a.contract_id         contract_id
                  ,a.contract_tmstmp     contract_tmstmp
                  ,b.device_id           device_id
                  ,b.model               model
                  ,c.login_id            vemail
                  ,d.contract_owner      contract_owner
                  ,d.extrnl_ctrct_id     extrnl_ctrct_id
                  ,d.expired             expired
                  ,ud.name_first
                  ,ud.name_last
                  ,b.make_id                                                                        -- OnTime WI #15530 
                  ,b.vin                                                                            -- OnTime WI #15530
              FROM beowner.subscription a
              JOIN beowner.vin          b
                ON  b.vin = a.vin
              JOIN beowner.usr          c
                ON c.usr_id = a.primary_id
              LEFT JOIN beowner.contrct d
                ON d.contract_id = a.contract_id -- NS added outer-join as this user may not be associated to the contract - OnTime Defect 11110
              LEFT JOIN beowner.usr_demog    ud
                ON ud.usr_id = c.usr_id -- #14351
             WHERE a.primary_id != ivprimaryid::UUID
                   AND a.vin = ivvin      
                -- a.contract_id is not null and        -- NS commented out as this user may not be associated to the contract - OnTime Defect 11110
                -- a.optin_level > 0 and                -- NS commented out as this user may not have opted in - OnTime Defect 11110                   
                )
    LOOP
        -- logging the old contract information stored in the subscription
        l_action := utl.set_action (' : Log old Contract Info due to Invalidate Contract Vin and remove conflicted user from VIN');

        -- added if condition and uncommented code out for Defect #12196, so that more history for the contract is available
        IF c1.contract_id IS NOT NULL
        THEN
            INSERT INTO beowner.contrct_log (contract_id
                                            ,tmstmp
                                            ,action
                                            ,src_vin
                                            ,src_usr
                                            ,contract_tmstmp
                                            ,extrnl_ctrct_id
                                            ,contract_owner
                                            ,expired)
                 VALUES (c1.contract_id
                        ,CURRENT_TIMESTAMP
                        ,'D'
                        ,ivvin
                        ,c1.primary_id
                        ,c1.contract_tmstmp
                        ,c1.extrnl_ctrct_id
                        ,c1.contract_owner
                        ,c1.expired);
        -- NS commented this out as the contract id from the cursor could be null - for OnTime Defect 11110
        END IF;

         l_action := utl.set_action(' Creating token for Contract Conflict Loss of EV Services email');

         vnamefl := coalesce(trim(both c1.name_first || ' ' || c1.name_last), c_pending_user_name); -- #14351
         DECLARE
            vkeyvalues xml;
         BEGIN
            IF (utl.is_conflict_enforced(i_device_id => c1.device_id) = 'Y') -- Modified for OnTime WI #15529
            THEN
               -- removing the conflicting subscriptions that have claimed this vin but no longer have the latest valid contract or no contract at all
               l_action := utl.set_module_action( l_module_name, ' : User has lost conflict so remove subscription record due to invalidated contract');

               -- NS moved this delete up because of referential integrity constraint - for OnTime Defect 11110
               -- Added for DI#1457
               vdelsubsnotif := crudg_subscription.delete_subs_notif(c1.subscription_id);

               IF vdelsubsnotif != utl.get_constant_value('csuccess')::INTEGER
               THEN
                  RETURN vdelsubsnotif;
               END IF;

               DELETE FROM beowner.subscription
                WHERE subscription_id = c1.subscription_id;

               IF NOT
                   contract.user_got_new_contract_first(i_vin             => ivvin,
                                                        i_new_contract_id => icontractid::BYTEA)
               THEN
                  CALL contract.dbg('conflict lost email will be sent');

                  SELECT xmlconcat(XMLELEMENT(name "entry",
                                              XMLELEMENT(name "key",'subscriberName'),
                                              XMLELEMENT(name "value", vnamefl)),
                                   XMLELEMENT(name "entry",
                                              XMLELEMENT(name "key", 'vin'),
                                              XMLELEMENT(name "value", ivvin)))
                    INTO STRICT vkeyvalues
;

                  l_action := utl.set_action(' Sending Contract Conflict Loss of EV Services email');

                  -- added for WI #15530
                  CALL utl.get_email_info(i_make_id         => c1.make_id,
                                          i_email_name      => 'CONFLICT_LOST',
                                          i_device_id       => c1.device_id,
                                          i_vin             => c1.vin,
                                          i_subscription_id => c1.subscription_id,
                                          o_subject         => l_subject,
                                          o_template_name   => vtemplatename);
                                     
                  IF vtemplatename IS NULL
                  THEN
                     RETURN utl.get_constant_value('c_conflict_lost_email_missing');
                  END IF;

                  PERFORM email.send(ito           => c1.vemail,
                                     isubject      => l_subject, -- OnTime #6991
                                     itemplatename => vtemplatename,
                                     ikeyvalues    => vkeyvalues);
               END IF;
            END IF;
         END;
      END LOOP;

      RETURN 0;
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.action := l_action;
          l_exception_diagnostics.module_name := l_module_name;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');
   END;
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION contract.uinvalidate_contract (ivprimaryid text, ivvin text, icontractid text DEFAULT NULL  ) FROM PUBLIC;

\i cleanup.sql;
