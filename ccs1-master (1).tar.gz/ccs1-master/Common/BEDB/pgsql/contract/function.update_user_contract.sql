SET bedb.filename = 'function.update_user_contract.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS contract.update_user_contract(text, text, text, text, text);
   /*  UPDATE_USER_CONTRACT
     
     Associate a user's VIN with a Contract ID. Intended to
     be called from the user portal
     
     Behavior:
       - Overwrites any existing contract info for this user.
     
     input: iPartnerID       the partner ID from the portal
            iLoginID         the user's login_id
            iVIN             the VIN associated with the contract
            iContractOwner   the Contract Owner. As of this writing, "ATX"
            iContractID      the Contract to associate with the VIN.
                             Set to NULL to clear the contract for the VIN.
     
     return: integer      0      if successful
                          1      if unknown error (check "trc" table)
                          7      the user was not found [cnst.cNoSuchUser]
                          200    if the VIN isn't in our database [cnst.cDbVinNotFound]
                          201    the user is not subscribed to this VIN [cnst.cDbSubscriberVinNotFound]
                          213    The partnerid is not valid. (cnst.cdbpartneridnotvalid)
                          264    if the VIN doesn't have a contract id, or the supplied
                                 contract id doesn't match the VIN's contract id   [cnst.cContractNotFound]
                          311    CONFLICT_RES_OLD_USER_VERIFIED email information has not been defined for the VIN's device ID (cnst.c_conflict_rouv_email_missing)
   */

CREATE OR REPLACE FUNCTION contract.update_user_contract (ipartnerid       text
                                                         ,iloginid         text
                                                         ,ivin             text
                                                         ,icontractowner   text
                                                         ,icontractid      text) RETURNS INTEGER 
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'update_user_contract';
    vvin            beowner.vin.vin%TYPE;
    vvincontractid  beowner.vin.contract_id%TYPE;
    vsubcontractid  beowner.subscription.contract_id%TYPE;
    vcontractid     beowner.contrct.contract_id%TYPE;
    vusrid          beowner.usr.usr_id%TYPE;
    vprimaryid      beowner.subscription.primary_id%TYPE;
    vcontracttmstmp beowner.subscription.contract_tmstmp%TYPE;
    vrslt           numeric;
    vtemplatename   beowner.email_info.template_name%TYPE; -- Modified for WI #15530
    -- Added for WI #15530
    vsubject         beowner.email_info.subject%TYPE;
    vdevice_id       beowner.vin.device_id%TYPE;
    vmake_id         beowner.vin.make_id%TYPE;
    vsubscription_id beowner.subscription.subscription_id%TYPE;
    ----
    vnamefl     varchar(257);
    vnoconf     integer;
    vextctrctid beowner.contrct.extrnl_ctrct_id%TYPE; -- #7088, stores the external contract id, to use in contrct_log insert
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      vnoconf := 0;

      l_action := utl.set_module_action( l_module_name, ' : setting context');

      -- with throw exceptions if input data is incorrect
      CALL ctx.set(iptnrid => ipartnerid::UUID, iloginid => iloginid, ivin => ivin);

      l_action := utl.set_action(' : retrieving data');

      -- get the VIN information (without a link to anything else)
      -- will return 0 or 1 row
      -- #7088 fetching external contract id too for contrct_log insert
      WITH xvin AS (SELECT v.vin,
               v.contract_id vin_contract_id,
               v.device_id,
               v.make_id -- OnTime WI #15530
          FROM beowner.vin v
         WHERE v.vin = ivin),
      -- get the USR information (partnerid+loginid)
      -- will return 0 or 1 row
      xusr AS (SELECT u.usr_id
          FROM beowner.ctx_data cd
          JOIN beowner.usr u
            ON u.usr_id = cd.usr_id
               AND u.parent_id IS NULL),
      -- get the SUBSCRIPTION information based on the above queries
      -- will return 0 or 1 row
      xsub AS (SELECT s.primary_id,
               s.contract_id sub_contract_id,
               s.contract_tmstmp,
               s.subscription_id -- OnTime WI #15530
          FROM beowner.subscription s
          JOIN xusr xu
            ON s.primary_id = xu.usr_id
          JOIN xvin xv
            ON s.vin = xv.vin),
      -- get the contract information
      -- will return 0 or 1 row
      xcon AS (SELECT contract_id,
               extrnl_ctrct_id
          FROM beowner.contrct
         WHERE contract_owner = upper(trim(both icontractowner))
               AND extrnl_ctrct_id = upper(trim(both icontractid)))
      SELECT xvin.vin,
             xvin.vin_contract_id,
             xusr.usr_id,
             xcon.contract_id,
             xsub.primary_id,
             xsub.sub_contract_id,
             xsub.contract_tmstmp,
             xcon.extrnl_ctrct_id,
             xvin.device_id, -- OnTime WI #15530
             xvin.make_id, -- OnTime WI #15530
             xsub.subscription_id -- OnTime WI #15530
        INTO STRICT vvin,
             vvincontractid,
             vusrid,
             vcontractid,
             vprimaryid,
             vsubcontractid,
             vcontracttmstmp,
             vextctrctid,
             vdevice_id,
             vmake_id,
             vsubscription_id
      -- this construct guarantees one and only one row
        FROM (SELECT NULL AS single) r
        LEFT JOIN xvin
          ON NULL IS NULL
        LEFT JOIN xusr
          ON NULL IS NULL
        LEFT JOIN xsub
          ON NULL IS NULL
        LEFT JOIN xcon
          ON NULL IS NULL;

      l_action := utl.set_action(' : validating data');

      IF vvin IS NULL
      THEN
         -- the VIN isn't in our database
         RETURN utl.get_constant_value('cdbvinnotfound');
      END IF;

      IF ((vvincontractid IS NULL) OR (vcontractid IS NULL) OR (vvincontractid != vcontractid))
      THEN
         -- the VIN doesn't have a contract, or
         -- the contract itself doesn't exist, or
         -- the supplied contract_id doesn't match the VIN's contract_id
         RETURN utl.get_constant_value('ccontractnotfound');
      END IF;

      IF vusrid IS NULL
      THEN
         -- the user (partnerid+loginid) was not found
         RETURN utl.get_constant_value('cnosuchuser');
      END IF;

      IF vprimaryid IS NULL
      THEN
         -- the user isn't subscribed to the VIN
         RETURN utl.get_constant_value('cdbsubscribervinnotfound');
      END IF;

      SELECT COUNT(*)
        INTO STRICT vnoconf
        FROM beowner.subscription
       WHERE vin = vvin;

      -- IF vcontracttmstmp IS NULL -- commented it out for #12196 (DB - the user can set opt-in level and notification options even without correct contractId)
      -- as it shouldn't define if uinvalidate_contract should be called or not
      -- THEN -- NS changed to is null as timestamp is null at this point - OnTime Defect 11110

   
      -- invalidate the existing contract information
      -- modified for #7088 to also send vcontractid, so that it can be used to determine if the current user owned this contract last
      vrslt := contract.uinvalidate_contract(vprimaryid::TEXT, vvin, encode(vcontractid, 'escape'));

      IF vrslt != 0
      THEN
         RETURN vrslt;
      END IF;

      --   END IF;
      l_action := utl.set_action(' : updating subscription contract data');

      -- #7088 - set conflict null here, as no conflict exists any more
      -- populated contract_tmstmp for #12196 (DB - the user can set opt-in level and notification options even without correct contractId)
      UPDATE beowner.subscription
         SET contract_id     = vcontractid,
             contract_tmstmp = CURRENT_TIMESTAMP,
             conflict         = NULL
       WHERE primary_id = vprimaryid
             AND vin = vvin;

      -- Moved up for #7088, since the email may not be sent, but logging is still needed
      -- Also populated src_user which wasn't being populated earlier.
      INSERT INTO beowner.contrct_log(contract_id,
          tmstmp,
          action,
          src_vin,
          src_usr,
          contract_tmstmp,
          extrnl_ctrct_id,
          contract_owner,
          expired)
      VALUES (vcontractid,
          CURRENT_TIMESTAMP,
          'U',
          ivin,
          vusrid,
          NULL,
          upper(trim(both icontractid)),
          upper(trim(both icontractowner)),
          NULL); -- NS modified to transform input values for OnTime Defect 11110
      -- #7088 Conflict won email is no longer required, but old user verified email needs to be sent
      -- if the same user that owned the contract earlier won the conflict (4th context diagram)
      IF (vnoconf > 1) AND
         contract.contract_last_owned_by_user(i_vin         => ivin,
											  i_usr_id      => vusrid,
											  i_contract_id => vcontractid)
      THEN
         l_action := utl.set_action(' Creating message for Old user verified email');

         SELECT trim(both name_first || ' ' || name_last)
           INTO STRICT vnamefl
           FROM beowner.usr_demog
          WHERE usr_id = vprimaryid;

         DECLARE
            vkeyvalues xml;
         BEGIN
            SELECT xmlconcat(XMLELEMENT(name "entry",
                                        XMLELEMENT(name "key", 'subscriberName'),
                                        XMLELEMENT(name "value", vnamefl)),
                             XMLELEMENT(name "entry",
                                        XMLELEMENT(name "key", 'vin'),
                                        XMLELEMENT(name "value", ivin)))
              INTO STRICT vkeyvalues;

            l_action := utl.set_action(' Send EMAIL about Old user verified to winner');

            -- added for WI #15530

            CALL utl.get_email_info(i_make_id         => vmake_id,
									i_email_name      => 'CONFLICT_RES_OLD_USER_VERIFIED',
									i_device_id       => vdevice_id,
									i_vin             => vvin,
									i_subscription_id => vsubscription_id,
									o_subject         => vsubject,
									o_template_name   => vtemplatename);
                           
            IF vtemplatename IS NULL
            THEN
               RETURN utl.get_constant_value('c_conflict_rouv_email_missing');
            END IF;

            PERFORM email.send(ito           => iloginid,
                               isubject      => vsubject, -- #7088 subject is same as conflict old user email for this email too
                               itemplatename => vtemplatename,
                               ikeyvalues    => vkeyvalues);
         END;
      END IF;

      RETURN utl.get_constant_value('csuccess');
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
         RETURN utl.get_constant_value('cdbpartneridnotvalid');
      WHEN SQLSTATE 'EUSRN' THEN
         RETURN utl.get_constant_value('cnosuchuser');
      WHEN SQLSTATE 'EVINN' THEN
         RETURN utl.get_constant_value('cdbvinnotfound');
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.action := l_action;
          l_exception_diagnostics.module_name := l_module_name;
        call trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION contract.update_user_contract (ipartnerid text, iloginid text, ivin text, icontractowner text, icontractid text) FROM PUBLIC;

   
\i cleanup.sql;
