SET bedb.filename = 'function.get_contract_expiry_date.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS contract.get_contract_expiry_date( beowner.vin.vin%TYPE, beowner.usr.login_id%TYPE, text);

CREATE OR REPLACE FUNCTION contract.get_contract_expiry_date (i_vin             beowner.vin.vin%TYPE
                                                            , i_userloginid     beowner.usr.login_id%TYPE
                                                            , i_partnerid       text
                                                            , o_status_code OUT INTEGER
                                                            , o_result      OUT REFCURSOR)
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'get_contract_expiry_date';
    --New function added for Jira #CR10236-125
    --This sproc is for TMS only
    l_validation_return INTEGER := utl.get_constant_value('csuccess');
    l_vin               beowner.vin.vin%TYPE;
    l_userloginid       beowner.usr.login_id%TYPE;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      l_vin := trim(both upper(i_vin));
      l_userloginid := trim(both i_userloginid);
      l_action := utl.set_module_action( l_module_name, ' Validating inputs');

      -- Removed constant for Jira DCS1E-1307
      l_validation_return := contract.validate_input_params(i_vin             => l_vin,
                                                            i_userloginid     => l_userloginid,
                                                            i_serviceid       => NULL,
                                                            i_partnerid       => i_partnerid,
                                                            i_svc_id_required => FALSE);
      IF l_validation_return != utl.get_constant_value('csuccess')::INTEGER
      THEN
      o_result := utl.get_dummy_cursor();
      o_status_code := l_validation_return;
      RETURN;
      END IF;
      
      l_action := utl.set_module_action(l_module_name, ' Returning cursor results');
      
      OPEN o_result FOR
         SELECT expiry_date,
                contract.contract_expiry_state(i_expiry_date => expiry_date,
                                               i_vin         => l_vin) contract_expiry_state -- Ontime defect# 23856,   
           FROM (SELECT date_trunc('day', c.expired)::TIMESTAMP WITHOUT TIME ZONE expiry_date
                   FROM beowner.contrct c,
                        beowner.vin     v
                  WHERE v.vin = l_vin
                        AND c.contract_id = v.contract_id) alias2;
        
        o_status_code := utl.get_constant_value('csuccess');
      RETURN;
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
          o_result := utl.get_dummy_cursor();
          o_status_code := utl.get_constant_value('cdbpartneridnotvalid');
          RETURN;
      WHEN SQLSTATE 'EUSRN' THEN
          o_result := utl.get_dummy_cursor();
          o_status_code := utl.get_constant_value('cnosuchuser');
          RETURN;
      WHEN OTHERS THEN
         l_action := utl.set_action(' Something went wrong with get_contract_expiry_date');
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.action := l_action;
          l_exception_diagnostics.module_name := l_module_name;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
        o_result := utl.get_dummy_cursor();
        o_status_code :=  utl.get_constant_value('cinternalerror');
   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION contract.get_contract_expiry_date (i_vin beowner.vin.vin%TYPE, i_userloginid beowner.usr.login_id%TYPE, i_partnerid text, o_result OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;

