SET bedb.filename = 'procedure.dbg.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS contract.dbg(TEXT);

CREATE OR REPLACE PROCEDURE contract.dbg (i_text text) 
AS $body$
BEGIN
      IF current_setting('contract.g_debug_on', true)::boolean
      THEN
         RAISE NOTICE '%', i_text;
      END IF;
   END;
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE contract.dbg (i_text text) FROM PUBLIC;
 
\i cleanup.sql;
