SET bedb.filename = 'function.update_vin_contract.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS contract.update_vin_contract (text, text, text, TEXT, beowner.contrct.started%TYPE,beowner.contrct.expired%TYPE,TEXT);

CREATE OR REPLACE FUNCTION contract.update_vin_contract (ivin                 text, 
                                                         icontractowner       text, 
                                                         icontractid          text, 
                                                         iinfo                text, 
                                                         icontractstartdate   beowner.contrct.started%TYPE, --Jira #CR10236-86 --Jira #CR10236-241
                                                         icontractexpirydate  beowner.contrct.expired%TYPE, 
                                                         idetailbatch_guid    TEXT DEFAULT NULL -- OnTime #23935  --Jira #CR10236-27
                                                         ) RETURNS INTEGER
AS $body$
DECLARE
    l_action text;
    l_module_name text := 'update_vin_contract';
       /*  UPDATE_VIN_CONTRACT
   
   Initiate or update a contract ID for a given VIN.
   This call is initiated from ATX.
   
   Added parameter ibatch_guid for Jira CR10212-125   
   
   Behavior:
     - If a Contract ID does not exist for this vin,
       associate it and return the new DateStamp
     - If a Contract ID exists, but is different,
       overwrite and return the new DateStamp
     - If a Contract ID exists, but is the same as
       a prior Contract ID, return 101 (Contract
       already exists) and return the original
       DateStamp associated with the contract.
   
   input: iVIN             the VIN associated with the contract
   
          iContractOwner   the Contract Owner. As of this writing, should be "ATX"
   
          iContractID      the Contract to associate with the VIN.
                           Set to NULL to clear the contract for the VIN.
   
          iInfo         Additional info useful for auditing/debugging.
                        This can be a free-form string or XML document.
                        It should contain information about the process
                        that initiated this call.
          --Jira #CR10236-86
          icontractstartdate       The contract start date
          icontractexpirydate      The contract expiry(end) date
          ibatch_guid              Batch guid for the batch, if applicable
   
   return: integer  0   if successful
                    1   if unknown error
                    200 if VIN not found
                    101 if contract already exists  --101 is not returning anymore with new functionality--Jira #CR10236-86
                    4   if input data is unusable
                    423 Contract started date should be prior to contract expiry date
                    424 Both VIN and CID are required parameters
                    425 Both Start date and Expiry date are required 
         --Jira CR10236-241
                    431 Contract id exists with another VIN
    */

   -- Modified for #7088 to satisfy the context diagrams (4.9.2) in System Requirements
   -- please refer to this document wherever context diagrams are mentioned

    --Jira #CR10236-86
    --Added new functionality for adding contract start date and contract expiry date
    --New code does not call invalidate_contract sproc to invalidate the existing user contract information
    --when it finds vin, cid combination exists
    --and does not return 101 error code either
    --Jira #CR10236-241
    --Modified code for these three scenarios
    --Incomplete UpdateContractID call (no dates)
    --CID already paired with another VIN, without start and end date
    --CID already paired with another VIN, WITH start and end date
    vcontractid         beowner.contrct.contract_id%TYPE;
    vvin                beowner.vin.vin%TYPE;
    vrslt               INTEGER;
    vcontractexpirydate beowner.contrct.expired%TYPE;
    vcontractstartdate  beowner.contrct.started%TYPE;
    vcidmatch           varchar(1);
    ctrue  CONSTANT varchar(1) := '*';
    cfalse CONSTANT varchar(1) := ' ';
    vcount      INTEGER;
    v_row_count INTEGER;
    l_exception_diagnostics trc.exception_diagnostics;


BEGIN
      DECLARE
         vowner      beowner.contrct.contract_owner%TYPE;
         vextctrctid beowner.contrct.extrnl_ctrct_id%TYPE;
         vlogit      INTEGER;
      BEGIN
         l_action := utl.set_module_action( l_module_name, ' : preparing contract data');

         vowner := upper(trim(both icontractowner));
         vextctrctid := upper(trim(both icontractid));
         vcontractid := encode(extensions.digest((vowner || vextctrctid), 'sha1'), 'hex');
         vlogit := 0;
         vvin := upper(trim(both ivin));
         vcontractexpirydate := date_trunc('day', icontractexpirydate);
         vcontractstartdate := date_trunc('day', icontractstartdate);

         l_action := utl.set_module_action( l_module_name, ' : Validating input contract data');

         IF COALESCE(vvin, '') = '' OR
            COALESCE(vextctrctid, '') = ''
         THEN
            RETURN utl.get_constant_value('c_vin_cid_null');
         END IF;

         -- check to see if there is a VIN in the database
         SELECT COUNT(*)
           INTO STRICT vcount
           FROM beowner.vin
          WHERE vin = vvin;

         IF vcount < 1
         THEN
            RETURN utl.get_constant_value('cdbvinnotfound');
         END IF;

         --Validation of start date and expiry date      --Jira #CR10236-241
         IF (vcontractstartdate IS NULL OR vcontractexpirydate IS NULL)
         THEN
            RETURN utl.get_constant_value('c_both_contract_dates_required'); -- Both start date and expiry dates are required
         ELSIF (vcontractstartdate >= vcontractexpirydate) -- OnTime# 23972-CR10236 - Database logic for checking startexpiration date value is inconsistent with Notification Server
         THEN
            RETURN utl.get_constant_value('c_started_should_prior_expiry'); --Start date  should be prior to expiry date
         END IF;

         --Check for existing CID and make sure that it is not paired with another VIN
         --Jira #CR10236-241
         SELECT COUNT(1)
           INTO STRICT v_row_count
           FROM beowner.vin
          WHERE vin <> vvin
                AND contract_id = vcontractid;
         IF v_row_count > 0
         THEN
            RETURN utl.get_constant_value('c_cid_exist_with_other_vin');
         END IF;

         l_action := utl.set_module_action( l_module_name, ' : evaluating existing contract data');

         -- check to see if the contract ID needs changing
         WITH a1 AS (SELECT CASE
                     WHEN coalesce(v.contract_id, '00') = vcontractid THEN
                      ctrue
                     ELSE
                      cfalse
                  END cidmatch
             FROM beowner.vin v
            WHERE v.vin = vvin)
         SELECT a1.cidmatch
           INTO STRICT vcidmatch
        from (select null as single) r
           LEFT JOIN a1
             ON NULL IS NULL;

         l_action := utl.set_module_action( l_module_name, ' : merging contract data');

         SELECT COUNT(*)
           INTO STRICT vlogit
           FROM beowner.contrct
          WHERE contract_id = vcontractid;

         INSERT INTO beowner.contrct (contract_id,
               contract_owner,
               extrnl_ctrct_id,
               started,
               expired)
           SELECT vcontractid         
                 ,vowner           
                 ,vextctrctid      
                 ,vcontractstartdate
                 ,vcontractexpirydate
          ON CONFLICT (contract_id)        
          DO UPDATE 
          SET started = vcontractstartdate,
            expired = vcontractexpirydate;

         l_action := utl.set_module_action( l_module_name, ' : Inserting contract log data');

         IF (vlogit = 0)
         THEN
            INSERT INTO beowner.contrct_log(contract_id,
                tmstmp,
                action,
                src_vin,
                src_usr,
                contract_tmstmp,
                extrnl_ctrct_id,
                contract_owner,
                started,
                expired)
            VALUES (vcontractid,
                CURRENT_TIMESTAMP,
                'I',
                ivin,
                NULL,
                NULL,
                vextctrctid,
                vowner,
                vcontractstartdate,
                vcontractexpirydate);
         ELSE
            INSERT INTO beowner.contrct_log(contract_id,
                tmstmp,
                action,
                src_vin,
                src_usr,
                contract_tmstmp,
                extrnl_ctrct_id,
                contract_owner,
                started,
                expired)
            VALUES (vcontractid,
                CURRENT_TIMESTAMP,
                'U',
                ivin,
                NULL,
                NULL,
                vextctrctid,
                vowner,
                vcontractstartdate,
                vcontractexpirydate);
         END IF;
      END;

      IF vcidmatch = cfalse -- OnTime# 23964: CR10236 - Opt-in level is not retained at DB for renewal of SC contract before existing SC contract expiration
      THEN
         /* invalidate the existing contract information, modified for #7088 to indicate that invalidate contract is not being called from utl.checkVinConflict
         so that change of ownership email is sent instead of conflict old user email - as per second context diagram */
         vrslt := contract.invalidate_contract(ivin               => vvin,
                                               icalled_by_utl     => FALSE,
                                               idetail_batch_guid => idetailbatch_guid); -- JIRA #CR10212-27);
      END IF;

      IF vrslt != 0
      THEN
         RETURN vrslt;
      END IF;

      BEGIN
         --Jira #CR10236-241
         -- finally, update the contract information in the VIN
         UPDATE beowner.vin
            SET contract_id    = vcontractid,
                transaction_id =
                (SELECT transactionid
                   FROM beowner.ctx_data) --Jira #CR10236-27
          WHERE vin = vvin;

      EXCEPTION
         --ideally the process flow expected to never come here.
         --Adding this as precautionary
         WHEN unique_violation THEN
            RETURN utl.get_constant_value('c_cid_exist_with_other_vin');
      END;

      RETURN utl.get_constant_value('csuccess');
   EXCEPTION
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.action := l_action;
          l_exception_diagnostics.module_name := l_module_name;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinvalidparams');
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.action := l_action;
          l_exception_diagnostics.module_name := l_module_name;

        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION contract.update_vin_contract (ivin text, icontractowner text, icontractid text, iinfo text, icontractstartdate beowner.contrct.started%TYPE, icontractexpirydate beowner.contrct.expired%TYPE, idetailbatch_guid data_fix_batch_details.detail_guid%TYPE DEFAULT NULL ) FROM PUBLIC;


\i cleanup.sql;
