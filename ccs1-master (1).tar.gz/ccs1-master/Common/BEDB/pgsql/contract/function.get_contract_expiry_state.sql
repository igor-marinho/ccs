SET bedb.filename = 'function.get_contract_expiry_state.sql';

\i set_be_env.sql;

/*  GET_CONTRACT_EXPIRY_STATE

  This sproc uses GET_CONTRACT_EXPIRY_DATE to return only (contract_expiry_state)

input: i_vin            the VIN associated with the contract(required)
       i_PartnerID      the partner ID from the portal(required)
       i_userloginid    the user's login_id(required)
       i_serviceid      the service id (required)

return: integer      0      If successful
                     1      If unknown error (check "trc" table)
                     7      The user was not found [cnst.cNoSuchUser]
                     27     The Login ID provided is null.
                     213    The partnerid is not valid(cnst.cdbpartneridnotvalid)
                     236    Service Id is Null
                     237    Invalid Service Id(c_invalid_svc_id)is feature or service.
                     288     No matching subscriptions were found.
                     421    If the EV/FCV VIN isn't in our database [cnst.c_EV_FCV_vinnotfound]

 */

DROP FUNCTION IF EXISTS contract.get_contract_expiry_state(beowner.vin.vin%type, beowner.usr.login_id%type, beowner
    .svc.svc_id%type, text);
CREATE OR REPLACE FUNCTION contract.get_contract_expiry_state(i_vin beowner.vin.vin%type,
                                                              i_userloginid beowner.usr.login_id%type,
                                                              i_serviceid beowner.svc.svc_id%type,
                                                              i_partnerid text) RETURNS text AS
$BODY$
DECLARE
    l_action                text;
    l_module_name           text := 'get_contract_expiry_state';

    --New function added for Jira #CR10236-125
    l_retval                integer;
    l_result                refcursor;
    l_contract_expiry_state char varying(1);
    l_expires_with_contract char varying(1);
    --TYPE tblinfo IS TABLE OF recinfo;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    -- Call the function
    SELECT o_status_code, o_result
    INTO
        l_retval, l_result
    FROM contract.get_svc_contract_expiry_state(i_vin => i_vin,
                                                i_userloginid => i_userloginid,
                                                i_serviceid => i_serviceid,
                                                i_partnerid => i_partnerid);

    IF l_retval != utl.get_constant_value('csuccess')::integer
    THEN
        RETURN NULL;
    END IF;

    FETCH l_result
        INTO l_contract_expiry_state, l_expires_with_contract;

    CLOSE l_result;

    RETURN l_contract_expiry_state;
EXCEPTION
    WHEN OTHERS THEN
        l_action := utl.set_module_action(l_module_name,
                                          ' Something went wrong with get_contract_expiry_state');
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;


        CALL trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
        RETURN NULL;
    -- Returning null instead of internal error becasue we don't want to retun error code in calling sproc
END;

$BODY$
    LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION contract.get_contract_expiry_state (i_vin beowner.vin.vin%TYPE, i_userloginid beowner.usr.login_id%TYPE, i_serviceid beowner.svc.svc_id%TYPE, i_partnerid text) FROM PUBLIC;

\i cleanup.sql;
