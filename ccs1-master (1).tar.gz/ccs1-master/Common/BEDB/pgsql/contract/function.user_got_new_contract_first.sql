SET bedb.filename = 'function.user_got_new_contract_first.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS contract.user_got_new_contract_first(beowner.vin.vin%TYPE, beowner.contrct.contract_id%TYPE);

   -- Added for #7088 to determine whether user B went to User Portal or enrolled in Safety connect first
   -- since email processing is different when conflict is ended - based on first and second context diagrams
CREATE OR REPLACE FUNCTION contract.user_got_new_contract_first (i_vin               beowner.vin.vin%TYPE
                                                                ,i_new_contract_id   beowner.contrct.contract_id%TYPE) RETURNS boolean 
AS $body$
DECLARE

      l_old_contract_invalidated beowner.contrct_log.tmstmp%TYPE;
      l_new_contract_received    beowner.contrct_log.tmstmp%TYPE;
      l_got_new_contract_first   boolean;

BEGIN
      CALL contract.dbg('vin = ' || i_vin || ' new contract = ' || i_new_contract_id);

      IF i_new_contract_id IS NULL
      THEN
         l_got_new_contract_first := FALSE;
      ELSE
         SELECT coalesce(MIN(tmstmp), CURRENT_TIMESTAMP)
           INTO STRICT l_new_contract_received
           FROM beowner.contrct_log
          WHERE src_vin = i_vin
                AND contract_id = i_new_contract_id
                AND action = 'I';

         CALL contract.dbg('new contract date = ' || to_char(l_new_contract_received, 'hh24:mi:ss'));

         SELECT MAX(tmstmp)
           INTO STRICT l_old_contract_invalidated
           FROM beowner.contrct_log
          WHERE src_vin = i_vin
                AND contract_id != i_new_contract_id
                AND action = 'X';

         CALL contract.dbg('old contract date = ' || to_char(l_old_contract_invalidated, 'hh24:mi:ss'));

         IF l_old_contract_invalidated IS NULL
         THEN
            -- contract is the same
            l_got_new_contract_first := FALSE;
         ELSE
            l_got_new_contract_first := (l_new_contract_received <
                                        l_old_contract_invalidated);
         END IF;

         RETURN l_got_new_contract_first;
      END IF;
   END;
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION contract.user_got_new_contract_first (i_vin vin.vin%TYPE, i_new_contract_id contrct.contract_id%TYPE) FROM PUBLIC;

\i cleanup.sql;
