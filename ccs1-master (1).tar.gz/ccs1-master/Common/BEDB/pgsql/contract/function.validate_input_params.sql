SET bedb.filename = 'function.validate_input_params.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS contract.validate_input_params(beowner.vin.vin%type, beowner.usr.login_id%type, text, boolean, beowner.svc.svc_id%type);

-- WARNING: parameters order has been changed by Ora2Pg to move parameters with default values at end
-- Original order was: contract.validate_input_params(i_vin beowner.vin.vin%TYPE, i_userloginid beowner.usr.login_id%TYPE, i_serviceid beowner.svc.svc_id%TYPE DEFAULT NULL, i_partnerid text, i_svc_id_required boolean)
-- You will need to manually reorder parameters in the function calls
CREATE OR REPLACE FUNCTION contract.validate_input_params(i_vin 			beowner.vin.vin%type,
                                                          i_userloginid 	beowner.usr.login_id%type,
                                                          i_partnerid 		text,
                                                          i_svc_id_required boolean,
                                                          i_serviceid 		beowner.svc.svc_id%type DEFAULT NULL) RETURNS integer
AS
$BODY$
DECLARE
    l_action      text;
    l_module_name text := 'validate_input_params';
    l_is_valid    boolean;
    l_count       integer;

BEGIN
    IF i_userloginid IS NULL
    THEN
        RETURN utl.get_constant_value('c_null_login_id');
    END IF;

    CALL ctx.set(iptnrid => i_partnerid::UUID, iloginid => i_userloginid, ivin => i_vin);

    l_action := utl.set_module_action(l_module_name, ' Validating VIN');

    --Validating user login id and vin combo
    SELECT COUNT(1)
    INTO STRICT l_count
    FROM beowner.usr u,
         beowner.subscription s,
         beowner.vin v
    WHERE u.login_id = i_userloginid
      AND v.vin = i_vin
      AND s.primary_id = coalesce(u.parent_id, u.usr_id)
      AND v.vin = s.vin
      AND v.make_id = u.make_id;

    IF l_count = 0
    THEN
        RETURN utl.get_constant_value('c_no_such_subscription_exists');
    END IF;

    --Validating Vin for EV/FCV vin
    SELECT COUNT(1)
    INTO STRICT l_count
    FROM beowner.vin v
    WHERE v.vin = i_vin
      AND v.device_id IN (SELECT d.device_id
                          FROM beowner.device d,
                               beowner.device_types dt
                          WHERE d.device_type = dt.type
                            AND dt.conflict_enforced = 'Y');

    IF l_count = 0
    THEN
        RETURN utl.get_constant_value('c_ev_fcv_vinnotfound');
    END IF;

    --Validation for valid service id
    IF i_serviceid IS NULL AND
       i_svc_id_required
    THEN
        RETURN utl.get_constant_value('c_svc_id_is_null');
    ELSIF i_serviceid IS NOT NULL AND
          i_svc_id_required
    THEN
        l_is_valid := utl.is_service_id_valid(i_serviceid);

        IF NOT l_is_valid
        THEN
            RETURN utl.get_constant_value('c_invalid_svc_id');
        END IF;
    END IF;

    RETURN utl.get_constant_value('csuccess');
END;

$BODY$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION contract.validate_input_params (i_vin beowner.vin.vin%TYPE, i_userloginid beowner.usr.login_id%TYPE, i_partnerid text, i_svc_id_required boolean, i_serviceid beowner.svc.svc_id%TYPE DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
