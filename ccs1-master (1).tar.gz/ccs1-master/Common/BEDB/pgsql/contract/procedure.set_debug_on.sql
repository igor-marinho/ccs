SET bedb.filename = 'procedure.set_debug_on.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS contract.set_debug_on ();

CREATE OR REPLACE PROCEDURE contract.set_debug_on () AS $body$
BEGIN
      PERFORM set_config('contract.g_debug_on', 'TRUE', false);
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE contract.set_debug_on () FROM PUBLIC;

\i cleanup.sql;
