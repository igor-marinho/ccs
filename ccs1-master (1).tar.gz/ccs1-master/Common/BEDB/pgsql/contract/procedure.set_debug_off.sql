SET bedb.filename = 'procedure.set_debug_off.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS contract.set_debug_off ();

CREATE OR REPLACE PROCEDURE contract.set_debug_off () AS $body$
BEGIN
      PERFORM set_config('contract.g_debug_on', 'FALSE', false);
   END;

$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE contract.set_debug_off () FROM PUBLIC;
\i cleanup.sql;
