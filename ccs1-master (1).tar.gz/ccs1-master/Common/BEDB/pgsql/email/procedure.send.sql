SET bedb.filename = 'procedure.send.sql';

\i set_be_env.sql;

DROP FUNCTION if exists email.send(text, text, text, xml, text, text, text, text);

CREATE OR REPLACE Function email.send ( iTo text, iSubject text, iTemplateName text, iKeyValues xml, iFrom text default 'noreply@myentune.com', iCC text default null, iBCC text default null, iReplyTo text default null)
 RETURNS xml
as
$body$
/* XSD for email messages
<xs:schema version="1.0" targetNamespace="http://www.tweddletech.com/SmtpCore" xmlns:tns="http://www.tweddletech.com/SmtpCore" xmlns:xs="http://www.w3.org/2001/XMLSchema">
  <xs:element name="SmtpMessage" type="tns:smtpMessage"/>
  <xs:complexType name="smtpMessage">
    <xs:sequence>
      <xs:element name="bcc" type="xs:string" nillable="true" minOccurs="0" maxOccurs="unbounded"/>
      <xs:element name="cc" type="xs:string" nillable="true" minOccurs="0" maxOccurs="unbounded"/>
      <xs:element name="from" type="xs:string"/>
      <xs:element name="htmlText" type="xs:string" minOccurs="0"/>
      <xs:element name="htmlTextTemplateName" type="xs:string" minOccurs="0"/>
      <xs:element name="plainText" type="xs:string" minOccurs="0"/>
      <xs:element name="plainTextTemplateName" type="xs:string" minOccurs="0"/>
      <xs:element name="replyTo" type="xs:string" minOccurs="0"/>
      <xs:element name="subject" type="xs:string" minOccurs="0"/>
      <xs:element name="templateModel">
        <xs:complexType>
          <xs:sequence>
            <xs:element name="entry" minOccurs="0" maxOccurs="unbounded">
              <xs:complexType>
                <xs:sequence>
                  <xs:element name="key" minOccurs="0" type="xs:string"/>
                  <xs:element name="value" minOccurs="0" type="xs:string"/>
                </xs:sequence>
              </xs:complexType>
            </xs:element>
          </xs:sequence>
        </xs:complexType>
      </xs:element>
      <xs:element name="to" type="xs:string" nillable="true" minOccurs="0" maxOccurs="unbounded"/>
    </xs:sequence>
  </xs:complexType>
</xs:schema>
*/
DECLARE
  l_module_name text := 'send';
  x xml;
  l_make_id beowner.make.make_id%type;
  l_message_type beowner.message_queue.message_type%type;

BEGIN

  PERFORM utl.set_module_action( l_module_name, ' Creating XML');
  
  select ei.make_id
        ,ei.aq_mailq
        ,XMLELEMENT(name "ns2:SmtpMessage", xmlAttributes('http://www.tweddletech.com/SmtpCore' as "xmlns:ns2"),
                    xmlForest(iBCC as "bcc"), -- returns no element if null
                    xmlForest(iCC as "cc"),   -- returns no element if null
                    xmlForest(coalesce (ei.noreplyaddr, iFrom) as "from"),
                    XMLELEMENT(name "htmlTextTemplateName", iTemplateName||'.html'),
                    XMLELEMENT(name "plainTextTemplateName", iTemplateName||'.text'),
                    XMLELEMENT(name "replyTo", iReplyTo),
                    XMLELEMENT(name "subject", iSubject),
                    XMLELEMENT(name "templateModel", iKeyValues),
                    XMLELEMENT(name "to", iTo))
    into strict l_make_id
               ,l_message_type
               ,x
    from beowner.emailq_info ei
    join beowner.ctx_data cd
      on ei.make_id = cd.make_id;

  PERFORM utl.set_module_action( l_module_name,  ' Enqueuing message');

  perform utl.enqueue_message(i_make_id => l_make_id
                             ,i_payload => x::text
                             ,i_message_type => l_message_type);

  return x;
END;
$body$
LANGUAGE PLPGSQL
;

DROP FUNCTION if exists email.send(text, text, text,text, text, text, text);

CREATE OR REPLACE FUNCTION email.send ( iTo text, iSubject text, iText text , iFrom text default 'noreply@myentune.com', iCC text default null, iBCC text default null, iReplyTo text default null)
 RETURNS xml
as
$body$
DECLARE
  l_module_name text := 'module_name_here';
  x xml;
  l_make_id beowner.make.make_id%type;
  l_message_type beowner.message_queue.message_type%type;

BEGIN

  PERFORM utl.set_module_action( l_module_name,  ' Creating XML');
  
  select ei.make_id
        ,ei.aq_mailq
        ,XMLELEMENT(name "ns2:SmtpMessage", xmlAttributes('http://www.tweddletech.com/SmtpCore' as "xmlns:ns2"),
            		    xmlForest(iBCC as "bcc"), -- returns no element if null
            		    xmlForest(iCC as "cc"),   -- returns no element if null
            		    xmlForest(coalesce (ei.noreplyaddr, iFrom) as "from"),
            		    XMLELEMENT(name "plainText", iText),
           	 	      XMLELEMENT(name "replyTo", iReplyTo),
           		      XMLELEMENT(name "subject", iSubject),
           		      XMLELEMENT(name "templateModel", null),
           		      XMLELEMENT(name "to", iTo))
    into strict l_make_id
               ,l_message_type
               ,x
    from beowner.emailq_info ei
    join beowner.ctx_data cd
      on ei.make_id = cd.make_id;

  PERFORM utl.set_module_action( l_module_name,  ' Enqueuing message');

  perform utl.enqueue_message(i_make_id => l_make_id
                             ,i_payload => x::text
                             ,i_message_type => l_message_type);

  return x;
END;
$body$
LANGUAGE PLPGSQL
;

\i cleanup.sql;
