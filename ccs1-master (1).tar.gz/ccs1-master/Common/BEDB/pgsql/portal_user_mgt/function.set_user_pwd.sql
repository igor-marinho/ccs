SET bedb.filename = 'function.set_user_pwd.sql';

\i set_be_env.sql;

/* set_user_pwd
  Stores/resets a new user/pwd for one of the portals.
  Return : status code - 0 if success. Else, error code:

      cinternalerror                1     Internal Error
      c_null_pwd                    24    Pwd provided is null
      c_portal_user_is_null         458   No portal user login was provided
      c_portal_code_is_null         651   Portal code provided is null
      c_invalid_portal_code         652   Unknown portal code
*/
DROP FUNCTION IF EXISTS portal_user_mgt.set_user_pwd(beowner.portal_users.portal_code%type,
    beowner.portal_users.user_login%type,
    beowner.portal_users.pwd%type,
    beowner.portal_users.role%type,
    beowner.portal_users.name%type);
CREATE OR REPLACE FUNCTION portal_user_mgt.set_user_pwd(i_portal_code beowner.portal_users.portal_code%type,
                                                        i_user_login beowner.portal_users.user_login%type,
                                                        i_encrypted_pwd beowner.portal_users.pwd%type,
                                                        i_role beowner.portal_users.role%type DEFAULT utl.get_constant_value('c_admin_role'),
                                                        i_name beowner.portal_users.name%type DEFAULT NULL)
    RETURNS integer AS
$body$
DECLARE
    l_action                text;
    l_module_name           text                                  := 'set_user_pwd';
    l_validation_return     integer;
    l_pu_guid               beowner.portal_users.pu_guid%type;
    l_portal_code           beowner.portal_users.portal_code%type := upper(i_portal_code);
    l_user_login            beowner.portal_users.user_login%type  := lower(i_user_login);
    l_role                  beowner.portal_users.role%type        := upper(i_role);
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    l_action := utl.set_module_action(l_module_name, 'Validating parameters');

    SELECT o_status_code, o_pu_guid
    INTO l_validation_return, l_pu_guid
    FROM portal_user_mgt.validate_portal_user(i_portal_code => l_portal_code,
                                              i_user_login => l_user_login,
                                              i_existing_user => FALSE);

    IF l_validation_return != utl.get_constant_value('csuccess')::integer
    THEN
        RETURN l_validation_return;
    END IF;

    IF coalesce(i_encrypted_pwd, '') = ''
    THEN
        RETURN utl.get_constant_value('c_null_pwd');
    END IF;

    l_action := utl.set_module_action(l_module_name, 'Merging portal user');

    INSERT INTO beowner.portal_users(pu_guid, portal_code, user_login, role, pwd, name)
    VALUES (beowner.rand_guid(),
            l_portal_code,
            l_user_login,
            coalesce(l_role, utl.get_constant_value('c_admin_role')),
            i_encrypted_pwd,
            i_name)
    ON CONFLICT ON CONSTRAINT portal_users_ukc
        DO UPDATE SET pwd  = i_encrypted_pwd,
                      role = coalesce(l_role, utl.get_constant_value('c_admin_role')),
                      name = coalesce(i_name, beowner.portal_users.name);


    RETURN utl.get_constant_value('csuccess');

EXCEPTION
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

        CALL trc.log(i_portal_code || ',' || i_user_login);
        RETURN utl.get_constant_value('cinternalerror');
END;

$body$
    LANGUAGE PLPGSQL
    SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION portal_user_mgt.set_user_pwd (i_portal_code portal_users.portal_code%TYPE, i_user_login portal_users.user_login%TYPE, i_encrypted_pwd portal_users.pwd%TYPE, i_role portal_users.role%TYPE DEFAULT cnst.c_admin_role, i_name portal_users.name%TYPE DEFAULT NULL) FROM PUBLIC;

\i cleanup.sql;
