SET bedb.filename = 'function.validate_portal_user.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS portal_user_mgt.validate_portal_user(beowner.portal_users.portal_code%type,
															 beowner.portal_users.user_login%type,
															 boolean);
CREATE OR REPLACE FUNCTION portal_user_mgt.validate_portal_user(i_portal_code beowner.portal_users.portal_code%type,
                                                                i_user_login beowner.portal_users.user_login%type,
                                                                i_existing_user boolean,
                                                                OUT o_status_code integer,
                                                                OUT o_pu_guid beowner.portal_users.pu_guid%type) AS
$body$
BEGIN

    IF coalesce(i_user_login, '') = ''
    THEN
        o_status_code := utl.get_constant_value('c_portal_user_is_null');
        RETURN;
    END IF;

    IF coalesce(i_portal_code, '') = ''
    THEN
        o_status_code := utl.get_constant_value('c_portal_code_is_null');
        RETURN;
    ELSIF NOT utl.is_domain_value_valid(i_domain => utl.get_constant_value('c_domain_portal_code'),
                                        i_value => i_portal_code)
    THEN
        o_status_code := utl.get_constant_value('c_invalid_portal_code');
        RETURN;
    END IF;

    IF i_existing_user
    THEN
        SELECT pu_guid
        INTO STRICT o_pu_guid
        FROM beowner.portal_users pu
        WHERE pu.portal_code = i_portal_code
          AND pu.user_login = i_user_login;
    END IF;
	o_status_code = utl.get_constant_value('csuccess');
    RETURN ;

EXCEPTION
    WHEN no_data_found THEN
	o_status_code = utl.get_constant_value('cnosuchuser');
        RETURN;
END;

$body$
LANGUAGE PLPGSQL
STABLE;
-- REVOKE ALL ON FUNCTION portal_user_mgt.validate_portal_user (i_portal_code portal_users.portal_code%TYPE, i_user_login portal_users.user_login%TYPE, i_existing_user boolean, o_pu_guid OUT portal_users.pu_guid%TYPE) FROM PUBLIC;

\i cleanup.sql;
