SET bedb.filename = 'function.delete_user.sql';

\i set_be_env.sql;

/*
  delete_user
 Deletes the user and its credentials

 Return : status code 0 if success. Else, error code:

          cinternalerror                1     Internal Error
          cnosuchuser                   7     User does not exist
          c_portal_user_is_null         458   No portal user login was provided
          c_portal_code_is_null         651   Portal code provided is null
          c_invalid_portal_code         652   Unknown portal code
 */
DROP FUNCTION IF EXISTS portal_user_mgt.delete_user(beowner.portal_users.portal_code%type,
    beowner.portal_users.user_login%type);
CREATE OR REPLACE FUNCTION portal_user_mgt.delete_user(i_portal_code beowner.portal_users.portal_code%type,
                                                       i_user_login beowner.portal_users.user_login%type)
    RETURNS integer AS
$body$
DECLARE
    l_action                text;
    l_module_name           text                                  := 'delete_user';
    l_portal_code           beowner.portal_users.portal_code%type := upper(i_portal_code);
    l_user_login            beowner.portal_users.user_login%type  := lower(i_user_login);
    l_validation_return     integer;
    l_pu_guid               beowner.portal_users.pu_guid%type;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    l_action := utl.set_module_action(l_module_name, 'Validating parameters');

    SELECT o_status_code, o_pu_guid
    INTO l_validation_return, l_pu_guid
    FROM portal_user_mgt.validate_portal_user(i_portal_code => l_portal_code,
                                              i_user_login => l_user_login,
                                              i_existing_user => TRUE);

    IF l_validation_return != utl.get_constant_value('csuccess')::integer
    THEN
        RETURN l_validation_return;
    END IF;

    l_action := utl.set_module_action(l_module_name, 'Deleting user');

    DELETE
    FROM beowner.portal_users
    WHERE pu_guid = l_pu_guid;

    RETURN utl.get_constant_value('csuccess');
EXCEPTION
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => i_portal_code || ',' || i_user_login,
                     iexception_diagnostics => l_exception_diagnostics);
        RETURN utl.get_constant_value('cinternalerror');
END;

$body$
    LANGUAGE PLPGSQL
    SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION portal_user_mgt.delete_user (i_portal_code portal_users.portal_code%TYPE, i_user_login portal_users.user_login%TYPE) FROM PUBLIC;

\i cleanup.sql;
