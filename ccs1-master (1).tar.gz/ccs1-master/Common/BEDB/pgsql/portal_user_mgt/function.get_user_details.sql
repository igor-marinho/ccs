SET bedb.filename = 'function.get_user_details.sql';

\i set_be_env.sql;

   /* get_user_details
   Return the details for the provided user.
   
   Ref cursor columns : user_login, pwd, role, name
   
   Return : status code - 0 if success. Else, error code:
              
            cinternalerror                1     Internal Error
            cnosuchuser                   7     User does not exist
            c_portal_user_is_null         458   No portal user login was provided
            c_portal_code_is_null         651   Portal code provided is null
            c_invalid_portal_code         652   Unknown portal code
    */

CREATE OR REPLACE FUNCTION portal_user_mgt.get_user_details(i_portal_code beowner.portal_users.portal_code%type,
                                                            i_user_login beowner.portal_users.user_login%type,
                                                            OUT o_status_code integer,
                                                            OUT o_user_details_cur refcursor) AS
$body$
DECLARE
    l_action                text;
    l_module_name           text                                  := 'get_user_details';
    l_portal_code           beowner.portal_users.portal_code%type := upper(i_portal_code);
    l_user_login            beowner.portal_users.user_login%type  := lower(i_user_login);
    l_validation_return     integer;
    l_pu_guid               beowner.portal_users.pu_guid%type;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    l_action := utl.set_module_action(l_module_name, 'Validating parameters');

    o_user_details_cur := utl.get_dummy_cursor();
    SELECT x.o_status_code, x.o_pu_guid
    INTO l_validation_return, l_pu_guid
    FROM portal_user_mgt.validate_portal_user(i_portal_code => l_portal_code,
                                              i_user_login => l_user_login,
                                              i_existing_user => TRUE) x;

    IF l_validation_return != utl.get_constant_value('csuccess')::integer
    THEN
        o_status_code = l_validation_return;
        RETURN;
    END IF;

    l_action := utl.set_module_action(l_module_name, 'Returning details');
    CLOSE o_user_details_cur;
    OPEN o_user_details_cur FOR
        SELECT user_login,
               pwd,
               ROLE,
               NAME,
               pu_guid
        FROM beowner.portal_users
        WHERE pu_guid = l_pu_guid;

    o_status_code := utl.get_constant_value('csuccess');
    RETURN;
EXCEPTION
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;

        CALL trc.log(i_portal_code || ',' || i_user_login,
                     iexception_diagnostics => l_exception_diagnostics);
        o_user_details_cur := utl.get_dummy_cursor();
        o_status_code := utl.get_constant_value('cinternalerror');
        RETURN;
END;

$body$ LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION portal_user_mgt.get_user_details (i_portal_code portal_users.portal_code%TYPE, i_user_login portal_users.user_login%TYPE, o_user_details_cur OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
