SET bedb.filename = 'function.get_batch_rrr.sql';

\i set_be_env.sql;
   
DROP FUNCTION IF EXISTS data_remediation.get_batch_rrr(TEXT);

CREATE OR REPLACE FUNCTION data_remediation.get_batch_rrr (i_batch_guid TEXT,
                                                           o_status_code OUT Integer,  
                                                           o_result OUT REFCURSOR) AS $body$

 /*  get_batch_rrr - return the RRR data for the batch
      Added for CR10212-65
       To be called by the portal after all the VINs in the batch have been processed.
          In : i_batch_guid
          Out : Ref cursor with columns:
               batch_status, vin, primary_directive, secondary_directive, status, old_device_id, new_device_id, dofu, old_account_status, new_account_status, 
               user_login_id, old_ext_contract_id, new_ext_contract_id, contract_start, contract_expiry
                
      Return : status code
           cSuccess                     0     Success (i.e. batch is valid and marked as complete)
   
         Error Codes:
           cinternalerror               1     Internal Error
           c_batch_not_found          450     No matching batch exists    
           c_batch_guid_is_null       452     No batch guid was provided.
           c_batch_is_in_progress     463     Batch is in progress currently, can't return RRR yet
     
   */

DECLARE

      l_action text;
      l_module_name text := 'get_batch_rrr';
      l_status beowner.data_fix_batches.status%TYPE;
      l_exception_diagnostics trc.exception_diagnostics;
      l_batch_guid uuid := i_batch_guid::uuid;

BEGIN

      l_action := utl.set_module_action( l_module_name, 'Validating inputs');
	  
      o_result := utl.get_dummy_cursor();

	  IF COALESCE(l_batch_guid::text, '') = ''
      THEN
      o_status_code := utl.get_constant_value('c_batch_guid_is_null');
	  RETURN;
      END IF;
	  
      BEGIN
         SELECT status
         INTO STRICT l_status
         FROM beowner.data_fix_batches
         WHERE batch_guid = l_batch_guid;

         IF l_status = utl.get_constant_value('c_batch_started')
         THEN
		 o_status_code := utl.get_constant_value('c_batch_is_in_progress');
         RETURN;
         END IF;
      
	  EXCEPTION
         WHEN no_data_found THEN
		 o_status_code := utl.get_constant_value('c_batch_not_found');
         RETURN;
      END;
      
	  l_action := utl.set_action('Returning results');
	  
	  CLOSE o_result;
	  
      OPEN o_result FOR	  
	       SELECT batch_status, vin,
               primary_directive,
               secondary_directive,
               status,
               old_device_id,
               new_device_id,dofu,
               old_account_status,
               new_account_status,
               user_login_id,
               old_ext_contract_id,
               new_ext_contract_id,
               contract_start,
               contract_expiry 
	       FROM		   
		(SELECT 'Batch Status' batch_status,
                'VIN' vin,
                'Primary Directive' primary_directive,
                'Secondary Directive' secondary_directive,
                'Status/Error' status,
                'VIN Bundle Before' old_device_id,
                'VIN Bundle After' new_device_id,
                'DOFU' dofu,
                'Account State Before' old_account_status,
                'Account State After' new_account_status,
                'Account Primary Email' user_login_id,
                'Contract ID Before' old_ext_contract_id,
                'Contract ID After' new_ext_contract_id,
                'Safety Connect Start Date' contract_start,
                'Safety Connect Expiry Date' contract_expiry,
		 1 sort_by         
                UNION
                SELECT *
                FROM (SELECT b.status batch_status,
                        d.vin,
                        b.directive primary_directive,
                        CASE WHEN b.report_only_flag=utl.get_constant_value('c_report_batch_flag') THEN utl.get_constant_value('c_report_flag_text')
						ELSE NULL END  secondary_directive,
                        coalesce(r.status, d.error_code, b.error_code) status,
                        r.old_device_id,
                        d.device_id new_device_id,
                        d.dofu,
                        r.old_account_status,
                        r.new_account_status,
                        r.user_login_id,
                        r.old_ext_contract_id,
                        r.new_ext_contract_id,
                        d.contract_start,
                        d.contract_expiry,
			2 sort_by
                      FROM beowner.data_fix_batches b
                      LEFT OUTER JOIN beowner.data_fix_batch_details d ON (b.batch_guid = d.batch_guid)
                      LEFT OUTER JOIN beowner.data_fix_results r ON (d.detail_guid = r.detail_guid)
                      WHERE b.batch_guid = l_batch_guid   ORDER BY coalesce(r.processed_on,d.submitted_on,b.completed_date)) as alias2) 
		as alias ORDER by alias.sort_by;
									
      o_status_code := utl.get_constant_value('csuccess');
      RETURN;
	  
EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
		  
		  CALL trc.log('Something went wrong in ' || l_module_name,
                        iexception_diagnostics => l_exception_diagnostics);
		
		  o_result := utl.get_dummy_cursor();	
		  o_status_code := utl.get_constant_value ('cinternalerror');		  
          RETURN;
END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION data_remediation.get_batch_rrr (i_batch_guid data_fix_batches.batch_guid%TYPE, o_result OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;
