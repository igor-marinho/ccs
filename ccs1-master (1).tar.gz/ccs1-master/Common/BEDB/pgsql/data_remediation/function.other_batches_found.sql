SET bedb.filename = 'function.other_batches_found.sql';

\i set_be_env.sql;

   -- checkes if any other batches exist with the status passed in (optional)
DROP FUNCTION IF EXISTS data_remediation.other_batches_found(beowner.data_fix_batches.status%TYPE);
CREATE OR REPLACE FUNCTION data_remediation.other_batches_found (i_status beowner.data_fix_batches.status%TYPE) RETURNS boolean AS $body$
DECLARE

      l_batch_exists integer;

BEGIN
      SELECT 1
        INTO STRICT l_batch_exists
        FROM beowner.data_fix_batches
       WHERE status = coalesce(i_status, status)  LIMIT 1;

      RETURN TRUE;
   EXCEPTION
      WHEN no_data_found THEN
         RETURN FALSE;
   END;

   -- checks if there are any other active (non-sniped) DB sessions for the batch user
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION data_remediation.other_batches_found (i_status data_fix_batches.status%TYPE) FROM PUBLIC;

\i cleanup.sql;
