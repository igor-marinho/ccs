SET bedb.filename = 'procedure.get_cid_contractid.sql';

\i set_be_env.sql;
DROP PROCEDURE IF EXISTS data_remediation.get_cid_contractid(beowner.vin.vin%type,
    INOUT beowner.contrct.extrnl_ctrct_id%type,
    INOUT beowner.contrct.contract_id%type);
CREATE OR REPLACE PROCEDURE data_remediation.get_cid_contractid(IN i_vin beowner.vin.vin%type,
                                                                INOUT io_cid beowner.contrct.extrnl_ctrct_id%type,
                                                                INOUT io_new_contract_id beowner.contrct.contract_id%type) AS
$body$
BEGIN
    SELECT c.extrnl_ctrct_id,
           c.contract_id
    INTO STRICT io_cid,
        io_new_contract_id
    FROM beowner.vin v,
         beowner.contrct c
    WHERE v.vin = i_vin
      AND v.contract_id = c.contract_id;
EXCEPTION
    WHEN no_data_found THEN
        NULL;
END;


$body$
    LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE data_remediation.get_cid_contractid () FROM PUBLIC;

\i cleanup.sql;
