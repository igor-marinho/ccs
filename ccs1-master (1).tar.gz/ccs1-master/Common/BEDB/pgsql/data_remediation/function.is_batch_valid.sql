SET bedb.filename = 'function.is_batch_valid.sql';

\i set_be_env.sql;

/* is_batch_valid : Indicates whether the batch is valid - it should exist and be in started status

Return Code :
    cSuccess                   0     Success (i.e. batch is valid)

    Error Codes returned :
      cinternalerror               1     Internal Error
      c_batch_not_found          450     No matching batch exists
      c_batch_not_in_progress    451     Batch is not in progress
      c_batch_guid_is_null       452     No batch guid was provided.

  */
DROP FUNCTION IF EXISTS data_remediation.is_batch_valid(beowner.data_fix_batches.batch_guid%type);
CREATE OR REPLACE FUNCTION data_remediation.is_batch_valid(i_batch_guid beowner.data_fix_batches.batch_guid%type)
    RETURNS integer AS
$body$
DECLARE
    l_action    text;
    l_module_name           text := 'is_batch_valid';
    l_batch_guid            beowner.data_fix_batches.batch_guid%type;
    l_status                beowner.data_fix_batches.status%type;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    l_action := utl.set_module_action(l_module_name, 'Validating inputs');

    IF i_batch_guid IS NULL
    THEN
        RETURN utl.get_constant_value('c_batch_guid_is_null');
    END IF;

    SELECT batch_guid,
           status
    INTO STRICT l_batch_guid,
        l_status
    FROM beowner.data_fix_batches
    WHERE batch_guid = i_batch_guid;

    IF l_status != utl.get_constant_value('c_batch_started')
    THEN
        RETURN utl.get_constant_value('c_batch_not_in_progress');
    END IF;

    RETURN utl.get_constant_value('csuccess');
EXCEPTION
    WHEN no_data_found THEN
        RETURN utl.get_constant_value('c_batch_not_found');
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;
        CALL trc.log('Something went wrong in ' || l_module_name,
                        iexception_diagnostics => l_exception_diagnostics);
        RETURN utl.get_constant_value('cinternalerror');
END;

$body$
    LANGUAGE PLPGSQL
;
-- REVOKE ALL ON FUNCTION data_remediation.is_batch_valid (i_batch_guid data_fix_batches.batch_guid%TYPE) FROM PUBLIC;

\i cleanup.sql;
