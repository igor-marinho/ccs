SET bedb.filename = 'function.active_sessions_found.sql';

\i set_be_env.sql;

-- checks if there are any other active (non-sniped) DB sessions for the batch user
DROP FUNCTION IF EXISTS data_remediation.active_sessions_found();
CREATE OR REPLACE FUNCTION data_remediation.active_sessions_found() RETURNS boolean AS
$body$
DECLARE

    l_active_sessions_found integer;
    c_batch_user            text := 'BATCHUSER';
    c_active_status         text := 'ACTIVE';

BEGIN
    SELECT 1
    INTO STRICT l_active_sessions_found
    FROM pg_stat_activity
    WHERE upper(usename) = c_batch_user
      AND upper(state) = c_active_status
    LIMIT 1;

    RETURN TRUE;
EXCEPTION
    WHEN no_data_found THEN
        RETURN FALSE;
END;
$body$
    LANGUAGE PLPGSQL
    STABLE;
-- REVOKE ALL ON FUNCTION data_remediation.active_sessions_found () FROM PUBLIC;

\i cleanup.sql;
