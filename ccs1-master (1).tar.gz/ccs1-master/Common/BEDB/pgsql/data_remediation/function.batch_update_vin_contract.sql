SET bedb.filename = 'function.batch_update_vin_contract.sql';

\i set_be_env.sql;

/*
--JIRA #CR10212-27 Update ContractID - Build out functionality
return: integer  0   if successful
                 1   if unknown error
                 200 if VIN not found
                 234 VIN is null
                 4   if input data is unusable
                 423 Contract started date should be prior to contract expiry date
                 424 Both VIN and CID are required parameters
                 425 Both Start date and Expiry date are required
                 431 Contract id exists with another VIN

*/
DROP FUNCTION IF EXISTS data_remediation.batch_update_vin_contract(beowner.vin.vin%type,
     beowner.contrct.contract_owner%type,
     beowner.contrct.extrnl_ctrct_id%type,
     beowner.contrct.started%type,
     beowner.contrct.expired%type,
     text);
CREATE OR REPLACE FUNCTION data_remediation.batch_update_vin_contract(i_vin IN beowner.vin.vin%type,
                                                     i_contract_owner IN beowner.contrct.contract_owner%type,
                                                     i_contract_id IN beowner.contrct.extrnl_ctrct_id%type,
                                                     i_contract_startdate IN beowner.contrct.started%type,
                                                     i_contract_expirydate IN beowner.contrct.expired%type,
                                                     i_batch_guid IN text)
    RETURNS integer AS
$body$
DECLARE
    l_action                text;
    l_module_name           text := 'batch_update_vin_contract';
    --JIRA #CR10212-27 Update ContractID - Build out functionality
    l_dfd_row               beowner.data_fix_batch_details%rowtype;
    l_status_returned       beowner.data_fix_results.status%type;
    l_result_row            beowner.data_fix_results%rowtype;
    l_called_from           text = 'data_remediation.batch_update_vin_contract';
    l_cid                   beowner.contrct.extrnl_ctrct_id%type;
    l_old_ext_cid           beowner.contrct.extrnl_ctrct_id%type;
    l_new_ext_cid           beowner.contrct.extrnl_ctrct_id%type;
    l_new_contract_id       beowner.contrct.contract_id%type;
    l_detail_guid           beowner.data_fix_batch_details.detail_guid%type;
    l_status_code           integer;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN


    l_action := utl.set_module_action(l_module_name,
                                      ' : Validating Vin, batch guid and creating batch details');
    IF coalesce(i_vin, '') = ''
    THEN
        RETURN utl.get_constant_value('c_invalid_vin'); -- can't log No VIN result, so has to be returned
    END IF;

    l_dfd_row.batch_guid := i_batch_guid;
    l_dfd_row.vin := i_vin;
    l_dfd_row.ext_contract_id := i_contract_id;
    l_dfd_row.contract_start := to_char((i_contract_startdate),
                                        'yyyy-mm-dd"T"HH24:MI:SS TZH:TZM');
    l_dfd_row.contract_expiry := to_char((i_contract_expirydate),
                                         'yyyy-mm-dd"T"HH24:MI:SS TZH:TZM');

    CALL data_remediation.insert_batch_details(i_dfd_row => l_dfd_row,
                                               i_called_from => l_called_from,
                                               o_detail_guid => l_detail_guid,
                                               o_status_code => l_status_code);

    IF l_status_code != utl.get_constant_value('csuccess')::integer
    THEN
        RETURN l_status_code; -- can't log this result in this case, so has to be returned
    END IF;

    -- Get prior contract ID (if it exists) for input VIN
    CALL data_remediation.get_cid_contractid(i_vin, l_cid, l_new_contract_id);
    l_old_ext_cid := l_cid;

    -- Call update_vin_contract function
    l_status_returned := contract.update_vin_contract(ivin => i_vin::text,
                                                      icontractowner => i_contract_owner::text,
                                                      icontractid => i_contract_id::text,
                                                      iinfo => NULL::text,
                                                      icontractstartdate => i_contract_startdate,
                                                      icontractexpirydate => i_contract_expirydate,
                                                      idetailbatch_guid => l_detail_guid::text);

    -- Get new contract ID for input VIN
    CALL data_remediation.get_cid_contractid(i_vin, l_cid, l_new_contract_id);
    l_new_ext_cid := l_cid;

    l_result_row.detail_guid := l_detail_guid;
    l_result_row.status := l_status_returned;
    l_result_row.old_ext_contract_id := l_old_ext_cid;
    l_result_row.new_ext_contract_id := l_new_ext_cid;
    l_result_row.contract_id := l_new_contract_id;

    CALL data_remediation.log_detail_result(i_result_row => l_result_row,
                                       i_called_from => l_called_from);

    RETURN utl.get_constant_value('csuccess');
EXCEPTION
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
         RETURN utl.get_constant_value('cinvalidparams');
      WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

         CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');

   END;

$body$ LANGUAGE plpgsql
SECURITY DEFINER ;

\i cleanup.sql;
