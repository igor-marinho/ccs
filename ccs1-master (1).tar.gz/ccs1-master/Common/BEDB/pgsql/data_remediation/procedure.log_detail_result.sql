SET bedb.filename = 'procedure.log_detail_result.sql';

\i set_be_env.sql;

   /* log_detail_result : Logs the results for a specific batch detail line. Could be called multiple times for the same detail line.
   
    To be called from individual sprocs called for directives.
    AUTONOMOUS TRANSACTION - commit happens internally (only) for the changes made
   */

DROP PROCEDURE IF EXISTS data_remediation.log_detail_result(beowner.data_fix_results, text );

CREATE OR REPLACE PROCEDURE data_remediation.log_detail_result (i_result_row beowner.data_fix_results, 
                                                                i_called_from text)
AS $body$
DECLARE

l_action text;
l_module_name text := 'log_detail_result';
l_result_row beowner.data_fix_results := i_result_row;
l_exception_diagnostics trc.exception_diagnostics;
l_query     text;
l_con_count integer;

BEGIN
      -- module should not be set here, so that the calling module is retained
      -- no validations needed, as they should occur in the calling sproc
      l_action := utl.set_module_action(l_module_name, 'Inserting result row into data_fix_results');
      
      l_result_row.processed_on := clock_timestamp();

      l_result_row.result_guid := beowner.rand_guid();

    l_query := format('INSERT INTO beowner.data_fix_results VALUES (%L,%L,%L,%L,%L,%L,%L,%L,%L,%L,%L,%L,%L,%L,%L)'
                        ,l_result_row.result_guid
                        ,l_result_row.detail_guid
                        ,l_result_row.processed_on
                        ,l_result_row.status
                        ,l_result_row.user_login_id
                        ,l_result_row.usr_id
                        ,l_result_row.subscription_id
                        ,l_result_row.old_device_id
                        ,l_result_row.old_rdr_status
                        ,l_result_row.new_rdr_status
                        ,l_result_row.old_account_status
                        ,l_result_row.new_account_status
                        ,l_result_row.old_ext_contract_id
                        ,l_result_row.new_ext_contract_id
                        ,l_result_row.contract_id);
                   
         select count(1)
          into l_con_count
          from extensions.dblink_get_connections()
          where coalesce (array_position(dblink_get_connections, 'dbinsert'),0) > 0;
        if l_con_count = 0 then 
            perform extensions.dblink_connect('dbinsert','fdlog');
        end if;

        perform extensions.dblink_exec('dbinsert', l_query );
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
          
          CALL trc.log('Something went wrong in LOG_DETAIL_RESULT when called from ' || i_called_from,
                        iexception_diagnostics => l_exception_diagnostics);

   END;
  
$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE data_remediation.log_detail_result (i_result_row data_fix_results, i_called_from text) FROM PUBLIC;

\i cleanup.sql;

