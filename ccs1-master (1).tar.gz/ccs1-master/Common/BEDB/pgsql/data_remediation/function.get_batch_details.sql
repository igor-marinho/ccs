SET bedb.filename = 'function.get_batch_details.sql';

\i set_be_env.sql;

/*
 get_batch_details : Returns all batches that exist for the provided search text (case-insensitive).
 To be called by the portal. Excludes any batches with a non-null make.

 Out : Refcursor with these columns :
     batch_guid, file_name, directive, report_only_flag, status, portal_user, started_date

 AUTONOMOUS TRANSACTION - commit happens internally (only) for the changes made

Return Code :
Success : cSuccess  0

Error Codes returned :
  cinternalerror             1    Internal Error
  c_search_text_is_null    459    No search text was provided.

*/

DROP FUNCTION IF EXISTS data_remediation.get_batch_details(text, OUT integer, OUT refcursor);
CREATE OR REPLACE FUNCTION data_remediation.get_batch_details(i_search_text text,
                                                              OUT o_status_code integer,
                                                              OUT o_result refcursor)
AS
$body$
DECLARE
    l_action                text;
    l_module_name           text := 'get_batch_details';
    l_search_text           text := i_search_text;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    l_action := utl.set_module_action(l_module_name, 'Validating inputs');

    o_result := utl.get_dummy_cursor();

    IF coalesce(l_search_text, '') = ''
    THEN
        o_status_code := utl.get_constant_value('c_search_text_is_null');
        RETURN;
    ELSE
        l_search_text := '%' || replace(upper(l_search_text),'\','\\') || '%';
    END IF;

    l_action := utl.set_module_action(l_module_name, 'Returning result');

    -- the left-hand clause should be exactly like the index (dfb_search_text_idx), so shouldn't be changed unless the index is changed too
    --Jira DCS1NOTES-81: exclude make_id from being returned
    CLOSE o_result;
    OPEN o_result FOR
        SELECT batch_guid,
               file_name,
               directive,
               report_only_flag,
               status,
               portal_user,
               started_date
        FROM beowner.data_fix_batches
        WHERE file_name || portal_user || status || directive like l_search_text
        AND make_id IS NULL
        ORDER BY started_date DESC;

    o_status_code := utl.get_constant_value('csuccess');
    RETURN;
EXCEPTION
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;
        CALL trc.log('Something went wrong in ' || l_module_name,
                     iexception_diagnostics => l_exception_diagnostics);
        o_status_code := utl.get_constant_value('cinternalerror');
        o_result := utl.get_dummy_cursor();
        RETURN;
END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;

-- REVOKE ALL ON FUNCTION data_remediation.get_batch_details (i_search_text text, o_result OUT REFCURSOR) FROM PUBLIC;

\i cleanup.sql;


