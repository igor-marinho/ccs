SET bedb.filename = 'function.batch_rdr_vin.sql';

\i set_be_env.sql;

   /*
   Return Code :
   Success cSuccess  '0'
   
   Error Codes returned :
     cinternalerror           1      -- Internal Error
     cinvalidparams           4      -- Invalid Params. if input data is unusable
     c_invalid_vin            234    -- VIN is null.
     cDbVinNotFound           200    -- System was passed a VIN which was not found.
     c_vin_already_rdred      226    -- VIN has already been RDRed
     c_vin_dofu_null          474    -- Dofu is null
   
   */

DROP FUNCTION IF EXISTS data_remediation.batch_rdr_vin (beowner.vin.vin%TYPE,
                                                        beowner.vin.dofu%TYPE,
                                                        TEXT);

CREATE OR REPLACE FUNCTION data_remediation.batch_rdr_vin(i_vin        IN beowner.vin.vin%TYPE,
                                                          i_dofu       IN beowner.vin.dofu%TYPE,
                                                          i_batch_guid IN TEXT)
RETURNS INTEGER AS $body$

DECLARE
 
      l_action text;
	  l_module_name text := 'batch_rdr_vin';
      -- Jira CR10212-133
      -- Modified for Jira CR10212-194 to straighten out the logic so that RRR data is logged, as long as VIN is provided
      l_dfd_row            beowner.data_fix_batch_details%ROWTYPE;
      l_called_from        TEXT := 'data_remediation.batch_rdr_vin';
      l_detail_guid        beowner.data_fix_batch_details.detail_guid%TYPE;
      l_status_code        INTEGER;
      l_status_returned    beowner.data_fix_results.status%TYPE := utl.get_constant_value('csuccess');
      l_old_account_status beowner.data_fix_results.old_account_status%TYPE;
      l_new_account_status beowner.data_fix_results.new_account_status%TYPE;
      l_result_row         beowner.data_fix_results%ROWTYPE;
      l_make_id            beowner.vin.make_id%TYPE;
      l_dofu               beowner.vin.dofu%TYPE;
      l_vin                beowner.vin.vin%TYPE;
      l_login_id           beowner.usr.login_id%TYPE;
      l_usr_id             beowner.usr.usr_id%TYPE;
      l_vin_accounts       INTEGER := 0;
      l_valid              BOOLEAN;
	  l_batch_guid         beowner.data_fix_batches.batch_guid%TYPE := i_batch_guid::uuid;
      vin_accounts         record;
	  l_exception_diagnostics trc.exception_diagnostics;
	  
   BEGIN

	  l_action := utl.set_module_action( l_module_name, 'Validating inputs');

      l_vin := upper(i_vin);

	  IF COALESCE(l_vin, '') = '' 
      THEN
      RETURN utl.get_constant_value('c_invalid_vin'); -- can't log No VIN result, so has to be returned
      END IF;

      l_dfd_row.batch_guid := l_batch_guid;
      l_dfd_row.vin := l_vin;
      l_dfd_row.dofu := to_char(i_dofu, 'mm/dd/yyyy');

      CALL data_remediation.insert_batch_details(i_dfd_row     => l_dfd_row,
                                                 i_called_from => l_called_from,
                                                 o_detail_guid => l_detail_guid,
                                                 o_status_code => l_status_code);

      IF l_status_code != utl.get_constant_value('csuccess')::integer
      THEN
      RETURN l_status_code; -- can't log this result in this case, so has to be returned
      END IF;

      --validate DOFU
	  IF COALESCE(i_dofu::text, '') = ''
      THEN
      l_status_returned := utl.get_constant_value('c_vin_dofu_null');
	  
      CALL data_remediation.handle_error(i_status_returned => l_status_returned,
                                         i_called_from     => l_called_from,
				                         i_detail_guid     => l_detail_guid,
                                         i_vin_accounts    => l_vin_accounts,
										 o_status_code     => l_status_code);
										 
	  RETURN l_status_code;
	  
      END IF;

      --validate input VIN
                                 
      select o_status_code,o_make_id,o_dofu into l_valid,l_make_id,l_dofu from utl.is_vin_valid(i_vin => l_vin);
     
      IF NOT l_valid
      THEN
      l_status_returned := utl.get_constant_value('cdbvinnotfound');
	  
      CALL data_remediation.handle_error(i_status_returned => l_status_returned,
                                         i_called_from     => l_called_from,
				                         i_detail_guid     => l_detail_guid,
                                         i_vin_accounts    => l_vin_accounts,
										 o_status_code     => l_status_code);
	 
	  RETURN l_status_code;
	  
      END IF;

	  IF COALESCE(l_dofu::text, '') != ''
      THEN
      l_status_returned := utl.get_constant_value('c_vin_already_rdred');
      ELSE
         -- calling crudg_vin.u_vin_sp only if DOFU on VIN is null
      l_status_returned := crudg_vin.u_vin_sp(ivin        => l_vin,
                                              idofu       => i_dofu,
                                              ibatch_guid => l_batch_guid);
      END IF;

      SELECT COUNT(1)
        INTO l_vin_accounts
        FROM beowner.subscription s
       WHERE s.vin = l_vin;

      IF l_vin_accounts = 0
      THEN
      l_login_id := utl.get_constant_value('c_no_account_text'); -- NO_ACCOUNT
	  
      CALL data_remediation.handle_error(i_status_returned => l_status_returned,
                                         i_called_from     => l_called_from,
				                         i_detail_guid     => l_detail_guid,
                                         i_vin_accounts    => l_vin_accounts,
										 o_status_code     => l_status_code,
										 i_login_id        => l_login_id); -- not technically an error, but nothing else to do, so exit after logging to RRR
										 
      RETURN l_status_code;
	  
      END IF;

      IF l_vin_accounts > 0
      THEN
         IF COALESCE(l_dofu::text, '') != ''
         THEN
            l_old_account_status := utl.get_constant_value('c_active_subs_text'); -- ACTIVE
            l_new_account_status := utl.get_constant_value('c_active_subs_text'); -- ACTIVE
         ELSE
            l_old_account_status := utl.get_constant_value('c_grace_subs_text'); -- GRACE
            l_new_account_status := CASE
                                       WHEN l_status_returned = utl.get_constant_value('csuccess') THEN
                                       utl.get_constant_value('c_active_subs_text') -- ACTIVE
                                       ELSE
                                        utl.get_constant_value('c_grace_subs_text')
                                    END;
         END IF;
      END IF;

      FOR vin_accounts IN (SELECT DISTINCT u.usr_id,
                                           u.login_id
                             FROM beowner.subscription s,
                                  beowner.usr u
                            WHERE s.vin = l_vin
                                  AND s.primary_id = u.usr_id)
      LOOP
         l_usr_id := vin_accounts.usr_id;
         l_login_id := vin_accounts.login_id;

         CALL data_remediation.handle_error(i_status_returned => l_status_returned,
                                         i_called_from     => l_called_from,
				                         i_detail_guid     => l_detail_guid,
                                         i_vin_accounts    => l_vin_accounts,
										 o_status_code     => l_status_code,
										 i_usr_id          => l_usr_id,
										 i_login_id        => l_login_id,
										 i_old_account_status => l_old_account_status,
										 i_new_account_status => l_new_account_status); --Handle_error is just to insert status rows in RRR table
      END LOOP;

      RETURN utl.get_constant_value('csuccess');

   EXCEPTION
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
         l_status_returned := utl.get_constant_value('cinvalidparams');
         RETURN l_status_returned;

      WHEN OTHERS THEN	  
	  GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
		  
		  CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
						
         l_status_returned := utl.get_constant_value('cinternalerror');
         RETURN l_status_returned;

 END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
\i cleanup.sql;
