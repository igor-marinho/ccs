SET bedb.filename = 'function.insert_batch_header.sql';

\i set_be_env.sql;

   /*
    insert_batch_header : inserts higher level batch row.
     To be called once per batch by the portal, at the very beginning.
     Returns batch guid, which needs to be passed to the directive sprocs.
   
   Return Code :
   Success : cSuccess  0
   
   Error Codes returned :
     cinternalerror                   1    Internal Error
     cinvalidmake                    22    Invalid Make ID
     c_file_name_is_null            455    No file name was provided.
     c_directive_is_null            456    No directive was provided.
     c_invalid_report_flag          457    Report Only flag was not Y or N.
     c_portal_user_is_null          458    No portal user login was provided.
     c_another_batch_in_progress    462    Some other batch is currently in progress.
     c_notif_cannot_change          604    Error indicating that a notification can no longer be modified
   */

DROP FUNCTION IF EXISTS data_remediation.insert_batch_header(beowner.data_fix_batches.file_name%type,
                                                            beowner.data_fix_batches.directive%type,
                                                            beowner.data_fix_batches.report_only_flag%type,
                                                            beowner.data_fix_batches.portal_user%type,
                                                            beowner.make.make_id%type);
CREATE OR REPLACE FUNCTION data_remediation.insert_batch_header(i_file_name beowner.data_fix_batches.file_name%type,
                                                                i_directive beowner.data_fix_batches.directive%type,
                                                                i_report_only_flag beowner.data_fix_batches.report_only_flag%type,
                                                                i_portal_user beowner.data_fix_batches.portal_user%type,
                                                                i_make_id beowner.make.make_id%type DEFAULT NULL,
                                                                OUT o_status_code integer,
                                                                OUT o_batch_guid  text)
AS
$body$
DECLARE
    l_action                text;
    l_module_name           text                                           := 'module_name_here';
    l_file_name             beowner.data_fix_batches.file_name%type        := upper(i_file_name);
    l_directive             beowner.data_fix_batches.directive%type        := upper(i_directive);
    l_report_only_flag      beowner.data_fix_batches.report_only_flag%type := upper(i_report_only_flag);
    l_portal_user           beowner.data_fix_batches.portal_user%type      := upper(i_portal_user);
    l_batch_guid            beowner.data_fix_batches.batch_guid%type;
    l_ctx_return            integer;
    l_cnt                   integer;
    --Jira DCS1NOTES-47: add new make id parameter
    l_make_id               beowner.make.make_id%type;
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    l_action := utl.set_module_action(l_module_name, 'Validating inputs');

    IF coalesce(l_file_name, '') = ''
    THEN
        o_status_code := utl.get_constant_value('c_file_name_is_null');
        RETURN;
    END IF;

    IF coalesce(l_directive, '') = ''
    THEN
        o_status_code := utl.get_constant_value('c_directive_is_null');
        RETURN;
    END IF;

    IF coalesce(l_report_only_flag, '!') NOT IN
       (utl.get_constant_value('c_report_batch_flag'), utl.get_constant_value('c_execute_batch_flag'))
    THEN
        o_status_code := utl.get_constant_value('c_invalid_report_flag');
        RETURN;
    END IF;

    IF coalesce(l_portal_user, '') = ''
    THEN
        o_status_code := utl.get_constant_value('c_portal_user_is_null');
        RETURN;
    END IF;

    --Make is an optional paramter, only check for valid make and on guid
    --if make is provided
    l_make_id := upper(i_make_id);

    IF coalesce(l_make_id, '') != '' AND
       NOT utl.is_make_valid(i_make_id => l_make_id)
    THEN
        o_status_code := utl.get_constant_value('cinvalidmake');
        RETURN;
    END IF;

    IF data_remediation.other_batches_found(i_status => utl.get_constant_value('c_batch_started'))
    THEN
        -- there are some batches in progress. Only one batch is supposed to be running at any given point
        -- check to see if there are any active sessions for the user BATCHUSER
        IF data_remediation.active_sessions_found()
        THEN
            --  another batch is actively in progress
            o_status_code := utl.get_constant_value('c_another_batch_in_progress');
            RETURN;
        ELSE
            -- else mark the existing batch/es as PARTIAL first, as those sessions were probably rolled back mid-way
            UPDATE beowner.data_fix_batches
            SET status         = utl.get_constant_value('c_batch_partial'),
                completed_date = CURRENT_TIMESTAMP
            WHERE status = utl.get_constant_value('c_batch_started');

            GET DIAGNOSTICS l_cnt = ROW_COUNT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;
            CALL trc.log(l_cnt || ' batches updated as partial.', l_exception_diagnostics);
        END IF;
    END IF;

    l_batch_guid := beowner.rand_guid();
    l_action := utl.set_module_action(l_module_name, 'Setting context');

    l_ctx_return := ctx.set(itranid => utl.get_constant_value('c_batch_prefix') || l_batch_guid);

    IF l_ctx_return != utl.get_constant_value('csuccess')::integer
    THEN
        o_status_code = l_ctx_return;
    END IF;

    l_action := utl.set_module_action(l_module_name, 'Inserting row');

    INSERT INTO beowner.data_fix_batches(batch_guid,
                                         file_name,
                                         directive,
                                         report_only_flag,
                                         status,
                                         portal_user,
                                         make_id)
    VALUES (l_batch_guid,
            l_file_name,
            l_directive,
            l_report_only_flag,
            utl.get_constant_value('c_batch_started'),
            l_portal_user,
            l_make_id);


    o_batch_guid := l_batch_guid;
    o_status_code := utl.get_constant_value('csuccess');
    RETURN;
EXCEPTION
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;

        CALL trc.log('Something went wrong in ' || l_module_name,
                     iexception_diagnostics => l_exception_diagnostics);
        o_status_code := utl.get_constant_value('cinternalerror');
        RETURN;
END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;

\i cleanup.sql;
