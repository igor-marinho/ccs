SET bedb.filename = 'function.mark_batch_complete.sql';

\i set_be_env.sql;
/*  mark_batch_complete : marks the batch as complete

  To be called by the portal after all the VINs in the batch have been processed.

 Return Code :
      cSuccess                   0     Success (i.e. batch is valid and marked as complete)

      Error Codes returned :
        cinternalerror               1     Internal Error
        c_batch_not_found          450     No matching batch exists
        c_batch_not_in_progress    451     Batch is not in progress
        c_batch_guid_is_null       452     No batch guid was provided.
*/
DROP FUNCTION IF EXISTS data_remediation.mark_batch_complete(text);
CREATE OR REPLACE FUNCTION data_remediation.mark_batch_complete(i_batch_guid text) RETURNS integer AS
$body$
DECLARE
    l_action                text;
    l_module_name           text := 'mark_batch_complete';
    l_batch_state           integer;
    l_batch_guid            uuid := i_batch_guid::uuid;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
    l_action := utl.set_module_action(l_module_name, 'Validating inputs');

    l_batch_state := data_remediation.is_batch_valid(i_batch_guid => l_batch_guid);

    IF l_batch_state != utl.get_constant_value('csuccess')::integer
    THEN
        RETURN l_batch_state;
    END IF;

    UPDATE beowner.data_fix_batches
    SET status         = utl.get_constant_value('c_batch_complete'),
        completed_date = CURRENT_TIMESTAMP
    WHERE batch_guid = l_batch_guid;

    RETURN utl.get_constant_value('csuccess');
EXCEPTION
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
        l_exception_diagnostics.module_name := l_module_name;
        l_exception_diagnostics.action := l_action;

        CALL trc.log('Something went wrong in ' || l_module_name,
                        iexception_diagnostics => l_exception_diagnostics);
        RETURN utl.get_constant_value('cinternalerror');
END;


$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION data_remediation.mark_batch_complete (i_batch_guid data_fix_batches.batch_guid%TYPE) FROM PUBLIC;

\i cleanup.sql;
