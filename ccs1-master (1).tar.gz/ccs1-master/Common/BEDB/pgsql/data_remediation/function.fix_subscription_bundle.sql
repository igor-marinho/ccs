SET bedb.filename = 'function.fix_subscription_bundle.sql';

\i set_be_env.sql;

/* Added for Jira CR10212-218 to overload procedure support_tools.fix_subscription_bundle since DR portal had trouble calling a procedure

Fix the bundle on the VIN's subscriptions to match the device_id on the VIN.
Also fix the device ID on the VIN if it isn't same as the one passed.

They can get out of sync when an incorrectly coded FDF is sent and a subscription is created based on an RDR
  or manual subscription and the FDF is then resubmitted with the correct HU code (Device ID).

Error codes returned: (0 is returned for success)
       cInternalError                     1 Internal Error.
       cdeviceiddoesnotexist             38 The Device ID does not exist in the Device table
       c_invalid_vin                    234 VIN is null.
       cDbVinNotFound                   200 System was passed a VIN which was not found.
       c_too_many_incorrect_subs        332 There are multiple incorrect subscriptions for the same VIN and user.
       c_device_id_is_null              475 Device ID not provided
       c_device_bndl_already_correct    476 device ID on VIN and Bundle on subscription already correct
       c_device_make_is_different       477 New device ID provided for VIN is for a different make

*/
DROP FUNCTION IF EXISTS data_remediation.fix_subscription_bundle(beowner.vin.vin%type,
    beowner.vin.device_id%type,
    text);
CREATE OR REPLACE FUNCTION data_remediation.fix_subscription_bundle(i_vin beowner.vin.vin%type,
                                                                    i_device_id beowner.vin.device_id%type,
                                                                    i_batch_guid text)
    RETURNS integer AS
$body$
DECLARE

    l_return_code integer;

BEGIN
    CALL support_tools.fix_subscription_bundle(i_vin,
                                               i_device_id,
                                               l_return_code,
                                               i_batch_guid);
    RETURN l_return_code;
END;

$body$
    LANGUAGE PLPGSQL
    SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION data_remediation.fix_subscription_bundle (i_vin vin.vin%TYPE, i_device_id vin.device_id%TYPE, i_batch_guid data_fix_batches.batch_guid%TYPE) FROM PUBLIC;

\i cleanup.sql;
