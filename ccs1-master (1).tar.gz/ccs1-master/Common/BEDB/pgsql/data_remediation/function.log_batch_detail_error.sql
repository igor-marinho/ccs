SET bedb.filename = 'function.log_batch_detail_error.sql';

\i set_be_env.sql;

   -----------------------------------------------------------------------------------------------
   /* log_batch_detail_error : logs detail error code from 3P or data-type validations
   
       AUTONOMOUS TRANSACTION - commit happens internally (only) for the changes made
   
       To be called by the portal to log any line-item related error/s.
   
      Return Code :
         cSuccess                   0     Success (i.e. batch is valid and marked as complete)
   
         Error Codes returned :
           cinternalerror               1     Internal Error
           cinvalidparams               4     Data type errors preventing from inserting detail row.
           c_batch_not_found          450     No matching batch exists
           c_batch_not_in_progress    451     Batch is not in progress
           c_batch_guid_is_null       452     No batch guid was provided.
           c_error_code_is_null       460     No error code was provided.
           c_duplicate_detail_error   461     Same combination of vin and error code was provided within the batch.
   */

DROP FUNCTION IF EXISTS data_remediation.log_batch_detail_error(TEXT, 
                                                                beowner.data_fix_batch_details.vin%TYPE, 
																beowner.data_fix_batch_details.device_id%TYPE, 
																beowner.data_fix_batch_details.dofu%TYPE, 
																beowner.data_fix_batch_details.ext_contract_id%TYPE, 
																beowner.data_fix_batch_details.contract_start%TYPE, 
																beowner.data_fix_batch_details.contract_expiry%TYPE, 
																beowner.data_fix_batch_details.vin_contract_start_time%TYPE, 
																beowner.data_fix_batch_details.error_code%TYPE);

CREATE OR REPLACE FUNCTION data_remediation.log_batch_detail_error (i_batch_guid              TEXT, 
                                                                    i_vin                     beowner.data_fix_batch_details.vin%TYPE, 
																	i_device_id               beowner.data_fix_batch_details.device_id%TYPE, 
																	i_dofu                    beowner.data_fix_batch_details.dofu%TYPE, 
																	i_contract_id             beowner.data_fix_batch_details.ext_contract_id%TYPE, 
																	i_contract_start          beowner.data_fix_batch_details.contract_start%TYPE, 
																	i_contract_expiry         beowner.data_fix_batch_details.contract_expiry%TYPE, 
																	i_vin_contract_start_time beowner.data_fix_batch_details.vin_contract_start_time%TYPE, 
																	i_error_code              beowner.data_fix_batch_details.error_code%TYPE) RETURNS INTEGER AS $body$
DECLARE
      l_action text;
      l_module_name text := 'log_batch_detail_error';
      l_error_code  beowner.data_fix_batch_details.error_code%TYPE;
      l_dfd_row     beowner.data_fix_batch_details;
      l_detail_guid beowner.data_fix_batch_details.detail_guid%TYPE;
      l_return_code INTEGER;
      l_exception_diagnostics trc.exception_diagnostics;
BEGIN
	  
	  l_action := utl.set_module_action( l_module_name, 'Validating inputs');

      l_error_code := i_error_code;
     
	  IF COALESCE(l_error_code, '') = ''
      THEN
      RETURN utl.get_constant_value('c_error_code_is_null');
      END IF;

      l_dfd_row.batch_guid := i_batch_guid::uuid;
      l_dfd_row.vin := i_vin;
      l_dfd_row.device_id := i_device_id;
      l_dfd_row.dofu := i_dofu;
      l_dfd_row.ext_contract_id := i_contract_id;
      l_dfd_row.contract_start := i_contract_start;
      l_dfd_row.contract_expiry := i_contract_expiry;
      l_dfd_row.vin_contract_start_time := i_vin_contract_start_time;
      l_dfd_row.error_code := l_error_code;

      CALL data_remediation.insert_batch_details(i_dfd_row     => l_dfd_row,
	                                             i_called_from => l_module_name,
											     o_status_code => l_return_code,
											     o_detail_guid => l_detail_guid
											    );

      RETURN l_return_code;
	  
   EXCEPTION
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
         RETURN utl.get_constant_value('cinvalidparams');
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
		  
		  l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          
          CALL trc.log('Something went wrong in ' || l_module_name,
                        iexception_diagnostics => l_exception_diagnostics);
						
          RETURN utl.get_constant_value('cinternalerror');
   END;


$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION data_remediation.log_batch_detail_error (i_batch_guid data_fix_batches.batch_guid%TYPE, i_vin data_fix_batch_details.vin%TYPE, i_device_id data_fix_batch_details.device_id%TYPE, i_dofu data_fix_batch_details.dofu%TYPE, i_contract_id data_fix_batch_details.ext_contract_id%TYPE, i_contract_start data_fix_batch_details.contract_start%TYPE, i_contract_expiry data_fix_batch_details.contract_expiry%TYPE, i_vin_contract_start_time data_fix_batch_details.vin_contract_start_time%TYPE, i_error_code data_fix_batch_details.error_code%TYPE) FROM PUBLIC;

\i cleanup.sql;
