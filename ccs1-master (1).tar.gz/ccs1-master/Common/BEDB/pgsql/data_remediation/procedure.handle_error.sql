SET bedb.filename = 'procedure.handle_error.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS data_remediation.handle_error(beowner.data_fix_results.status%TYPE,
                                                       Text,
                                                       beowner.data_fix_batch_details.detail_guid%type,
                                                       Integer,
                                                       Integer,														   
                                                       beowner.usr.usr_id%TYPE,
                                                       beowner.usr.login_id%TYPE,
                                                       beowner.data_fix_results.old_account_status%TYPE,
                                                       beowner.data_fix_results.new_account_status%TYPE);

CREATE OR REPLACE PROCEDURE data_remediation.handle_error (
                                                           i_status_returned    beowner.data_fix_results.status%TYPE,
                                                           i_called_from        text,
                                                           i_detail_guid        beowner.data_fix_batch_details.detail_guid%type,
                                                           i_vin_accounts       integer,
                                                           o_status_code        INOUT Integer,														   
                                                           i_usr_id             beowner.usr.usr_id%TYPE default null,
                                                           i_login_id           beowner.usr.login_id%TYPE default null,
                                                           i_old_account_status beowner.data_fix_results.old_account_status%TYPE default null,
                                                           i_new_account_status beowner.data_fix_results.new_account_status%TYPE default null) AS $body$

DECLARE

l_result_row beowner.data_fix_results;
l_status_returned beowner.data_fix_results.status%TYPE := i_status_returned;
l_vin_accounts integer := i_vin_accounts;
l_called_from text := i_called_from;
c_rdr_received_set text := 'RDR_RECEIVED_SET';

BEGIN


         l_result_row.detail_guid := i_detail_guid;
         l_result_row.usr_id := i_usr_id;
         l_result_row.user_login_id := i_login_id;
         l_result_row.old_account_status := i_old_account_status;
         l_result_row.new_account_status := i_new_account_status;
		 
         l_result_row.status := CASE
                                   WHEN l_status_returned = utl.get_constant_value('csuccess') THEN c_rdr_received_set                              
                                   ELSE
                                   l_status_returned
                                END;
         CALL data_remediation.insert_batch_result_row(i_result_row => l_result_row,
		                                               i_called_from => l_called_from);

         IF l_vin_accounts = 0
         THEN
            l_status_returned := utl.get_constant_value('csuccess'); -- since 0 should be returned to portal after logging into RRR
            
			o_status_code :=  l_status_returned;
			
			--RAISE e_success; -- return, nothing more needs to be done
        /* ELSE
           RETURN; */
         END IF;
END;
$body$
LANGUAGE PLPGSQL
;
   
\i cleanup.sql;
