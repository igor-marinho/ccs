SET bedb.filename = 'function.add_notification_vins.sql';

\i set_be_env.sql;

   /* Added for Jira DCS1NOTES-48
   
   Adds new VINs for a batch.
   
   Error codes returned: (0 is returned for success)
   
          cInternalError                     1 Internal Error.
          c_invalid_vin                    234 VIN is null.
          c_batch_not_found                450 Batch doesn't exist.
          c_batch_guid_is_null             452 No batch guid was provided.
            
          Only logged in the data_fix_results table:
          cdbvinnotfound                   200 System was passed a VIN which was not found. (not returned
          c_notif_batch_invalid_make       603 Error for VINs that do not match the make ID on a batch
         
   */

DROP FUNCTION IF EXISTS data_remediation.add_notification_vins (TEXT,
                                                                beowner.vin.vin%TYPE);

CREATE OR REPLACE FUNCTION data_remediation.add_notification_vins (i_batch_guid TEXT,
                                                                   i_vin        beowner.vin.vin%TYPE) RETURNS INTEGER AS $body$
DECLARE
      
	  l_action          text;
      l_module_name     text := 'add_notification_vins';
      l_make_id         beowner.make.make_id%TYPE;
      l_batch_make_id   beowner.make.make_id%TYPE;
      l_dofu            beowner.vin.dofu%TYPE;
      l_vin             beowner.vin.vin%TYPE;
      l_status_code     integer;
	  l_valid           BOOLEAN;
      l_dfd_row         beowner.data_fix_batch_details;
      l_result_row      beowner.data_fix_results;
	  l_batch_guid      beowner.data_fix_batches.batch_guid%TYPE := i_batch_guid::uuid;
      l_exception_diagnostics trc.exception_diagnostics;


BEGIN
      --Jira DCS1NOTES-48: Add new add_notification_vins procedure
      	  
	  l_action := utl.set_module_action( l_module_name, 'Adding Notification vins');

	  IF COALESCE(i_vin, '') = ''
      THEN
      RETURN utl.get_constant_value('c_invalid_vin');
      END IF;

	  IF COALESCE(i_batch_guid, '') = ''
      THEN
      RETURN utl.get_constant_value('c_batch_guid_is_null');
      END IF;

      BEGIN
         SELECT dfb.make_id
           INTO STRICT l_batch_make_id
           FROM beowner.data_fix_batches dfb
          WHERE dfb.batch_guid = l_batch_guid
                AND dfb.make_id IS NOT NULL;

      EXCEPTION
         WHEN no_data_found THEN
            RETURN utl.get_constant_value('c_batch_not_found');
      END;

      l_dfd_row.batch_guid := l_batch_guid;
      l_dfd_row.vin := i_vin;

	  
	  CALL data_remediation.insert_batch_details (i_dfd_row  => l_dfd_row,
	                                              i_called_from => l_module_name,
												  o_detail_guid => l_result_row.detail_guid,
												  o_status_code => l_status_code);

      IF l_status_code != utl.get_constant_value('csuccess')::integer
      THEN
      RETURN l_status_code; -- can't log this result in this case, so has to be returned
      END IF;

      l_vin := upper(i_vin);
	  
	  SELECT O_STATUS_CODE, O_MAKE_ID, O_DOFU INTO l_valid,l_make_id,l_dofu from utl.is_vin_valid(i_vin => l_vin);

      IF NOT l_valid
      THEN
      l_result_row.status := utl.get_constant_value('cdbvinnotfound');
      ELSIF l_batch_make_id <> l_make_id
      THEN
      l_result_row.status := utl.get_constant_value('c_notif_batch_invalid_make');
      ELSE
      l_result_row.status := utl.get_constant_value('csuccess');
      END IF;

      CALL data_remediation.log_detail_result(i_result_row  => l_result_row,
                                              i_called_from => l_module_name);

      RETURN utl.get_constant_value('csuccess');

   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

          CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
        
          RETURN utl.get_constant_value('cinternalerror');

   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION data_remediation.add_notification_vins (i_batch_guid data_fix_batches.batch_guid%TYPE, i_vin vin.vin%TYPE) FROM PUBLIC;

\i cleanup.sql;
