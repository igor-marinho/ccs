SET bedb.filename = 'function.log_batch_header_error.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS data_remediation.log_batch_header_error (TEXT,
                                                                 beowner.data_fix_batches.error_code%TYPE);
   /* log_batch_header_error : logs error at the batch level.
   
      To be called by the portal to log any file-related (batch-level) error.
   
      AUTONOMOUS TRANSACTION - commit happens internally (only) for the changes made
   
       Return Code :
          cSuccess                   0     Success (i.e. batch is valid and marked as complete)
   
          Error Codes returned :
            cinternalerror               1     Internal Error
            cinvalidparams               4     Data type errors preventing from inserting header row.
            c_batch_not_found          450     No matching batch exists
            c_batch_not_in_progress    451     Batch is not in progress
            c_batch_guid_is_null       452     No batch guid was provided.
            c_error_code_is_null       460     No error code was provided.
   */
CREATE OR REPLACE FUNCTION data_remediation.log_batch_header_error (i_batch_guid TEXT,
                                                                    i_error_code beowner.data_fix_batches.error_code%TYPE) RETURNS INTEGER 
AS $body$
DECLARE
      l_action text;
      l_module_name text := 'log_batch_header_error';
      l_error_code  beowner.data_fix_batches.error_code%TYPE;
      l_batch_state INTEGER;
      l_batch_guid beowner.data_fix_batches.batch_guid%type;
      l_exception_diagnostics trc.exception_diagnostics;

BEGIN

      l_action := utl.set_module_action( l_module_name, 'Validating inputs');

      l_error_code := upper(i_error_code);
     
      l_batch_guid := (CASE WHEN i_batch_guid = '' THEN NULL ELSE i_batch_guid END)::UUID;
      
      l_batch_state := data_remediation.is_batch_valid(i_batch_guid => l_batch_guid);

      IF l_batch_state != utl.get_constant_value('csuccess')::integer
      THEN
      RETURN l_batch_state;
      END IF;

      IF COALESCE(l_error_code, '') = ''
      THEN
      RETURN utl.get_constant_value('c_error_code_is_null');
      END IF;

      UPDATE beowner.data_fix_batches
         SET status         = utl.get_constant_value('c_batch_error'),
             ERROR_CODE     = l_error_code,
             completed_date = CURRENT_TIMESTAMP
       WHERE batch_guid = l_batch_guid;


      RETURN utl.get_constant_value('csuccess');
   EXCEPTION
      WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
         RETURN beowner.utl.get_constant_value('cinvalidparams');
      
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
          
          CALL trc.log('Something went wrong in ' || l_module_name,
                        iexception_diagnostics => l_exception_diagnostics);
                        
         RETURN utl.get_constant_value('cinternalerror');
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;

\i cleanup.sql;
