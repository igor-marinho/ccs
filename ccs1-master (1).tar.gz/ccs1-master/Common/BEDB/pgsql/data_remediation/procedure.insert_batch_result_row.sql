SET bedb.filename = 'procedure.insert_batch_result_row.sql';

\i set_be_env.sql;

DROP PROCEDURE IF EXISTS data_remediation.insert_batch_result_row(beowner.data_fix_results, text);

CREATE OR REPLACE PROCEDURE data_remediation.insert_batch_result_row (i_result_row beowner.data_fix_results,
                                                                      i_called_from text) AS $body$

DECLARE

l_result_row beowner.data_fix_results := i_result_row;
l_called_from text;

BEGIN
     

         CALL data_remediation.log_detail_result(i_result_row  => l_result_row,
                                                 i_called_from => l_called_from);
         l_result_row := NULL;
        
      END;


$body$
LANGUAGE PLPGSQL
;
-- REVOKE ALL ON PROCEDURE data_remediation.insert_batch_result_row () FROM PUBLIC;

\i cleanup.sql;
