SET bedb.filename = 'procedure.insert_batch_details.sql';

\i set_be_env.sql;
/*
   insert_batch_details : Insert details of line items, as passed to the directive sproc or by calling layer for detail error
*/
DROP PROCEDURE IF EXISTS data_remediation.insert_batch_details(beowner.data_fix_batch_details,
															   text,
															   beowner.data_fix_batch_details.detail_guid%type,
															   integer);
CREATE OR REPLACE PROCEDURE data_remediation.insert_batch_details(i_dfd_row beowner.data_fix_batch_details,
                                                                  i_called_from text,
                                                                  INOUT o_detail_guid beowner.data_fix_batch_details.detail_guid%type,
                                                                  INOUT o_status_code integer) AS
$body$
DECLARE
    l_action                text;
    l_module_name           text                                   := 'insert_batch_details';
    l_dfd_row               beowner.data_fix_batch_details%rowtype := i_dfd_row;
    l_batch_state           integer;
    l_exception_diagnostics trc.exception_diagnostics;
	l_query                   text;
    l_con_count               integer;
BEGIN
   -- module should not be set here, so that the calling module is retained
    -- no validations needed, as they should occur in the calling sproc
    l_dfd_row.submitted_on := CURRENT_TIMESTAMP;
    l_dfd_row.error_code := upper(l_dfd_row.error_code);

    l_action := utl.set_module_action(l_module_name, 'Validating batch guid');

    l_batch_state := data_remediation.is_batch_valid(i_batch_guid => l_dfd_row.batch_guid);

    IF l_batch_state != utl.get_constant_value('csuccess')::integer
    THEN
        o_status_code := l_batch_state;
        RETURN;
    END IF;

      l_dfd_row.detail_guid := beowner.rand_guid();

      l_action := utl.set_module_action(l_module_name, 'Inserting batch details');

      l_query := format('INSERT INTO beowner.data_fix_batch_details VALUES (%L,%L,%L,%L,%L,%L,%L,%L,%L,%L,%L)',
                             l_dfd_row.detail_guid
                            ,l_dfd_row.batch_guid
                            ,l_dfd_row.submitted_on
                            ,l_dfd_row.vin
                            ,l_dfd_row.device_id
                            ,l_dfd_row.dofu
                            ,l_dfd_row.ext_contract_id
                            ,l_dfd_row.contract_start
                            ,l_dfd_row.contract_expiry
                            ,l_dfd_row.vin_contract_start_time
                            ,l_dfd_row.error_code);

         SELECT count(1)
          into l_con_count
          from extensions.dblink_get_connections()
          where coalesce (array_position(dblink_get_connections, 'dbinsert'),0) > 0;
        IF l_con_count = 0 then 
            perform extensions.dblink_connect('dbinsert','fdlog');
        END IF;

        perform extensions.dblink_exec('dbinsert', l_query );

    o_status_code := utl.get_constant_value('csuccess');
    o_detail_guid := l_dfd_row.detail_guid;

EXCEPTION
    WHEN unique_violation THEN
        o_status_code := utl.get_constant_value('c_duplicate_detail_error');
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
         o_status_code := utl.get_constant_value('cinvalidparams');
      WHEN OTHERS THEN
         GET STACKED DIAGNOSTICS
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
         CALL trc.log('Something went wrong in INSERT_BATCH_DETAILS when called from ' || i_called_from,
                        iexception_diagnostics => l_exception_diagnostics);
         o_status_code := utl.get_constant_value('cinternalerror');
   END;
$body$ 
LANGUAGE PLPGSQL
;

\i cleanup.sql;
