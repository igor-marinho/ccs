SET bedb.filename = 'function.be_delete_linked_credentials.sql';

\i set_be_env.sql;

   /*
    * be_delete_linked_credentials
    * Provides a mechanism for "unlinked" previously linked credentials.
    * Input parameters
    *   - i_user_login_id - A valid EMail address or Login ID
    *   - i_service_id - A valid service ID
        Output parameters:
          status_code_0     - Output variable
          success -  status_code of '0' if there is success in deleting the record from the USR_INF table.
          failure - '1' Internal error (see "TRC" table for details when this occurs).
          failure - '213' - partner ID in context not valid
          failure - '18' - Credentials not found - nothing to delete
          failure - '16' - Invalid login ID supplied
          failure - '14' - No such service - Invalid service ID supplied
    */
DROP FUNCTION IF EXISTS be_linked_credentials.be_delete_linked_credentials(text, text);
CREATE OR REPLACE FUNCTION be_linked_credentials.be_delete_linked_credentials(i_user_login_id IN TEXT,
                                                                              i_service_id    IN TEXT)
RETURNS INTEGER AS $$
DECLARE
    l_action text;
    l_module_name text := 'be_delete_linked_credentials';
    l_partner_id VARCHAR(80);
    l_usr_id     VARCHAR(80);
    l_make_id    VARCHAR(8);
    l_rowcount   int; 
BEGIN
   
    l_action := utl.set_module_action( l_module_name, 'Validating inputs');

   
    SELECT partnerid,
           make_id
      INTO l_partner_id,
           l_make_id
      FROM beowner.ctx_data;
   
    IF l_partner_id IS NULL
    THEN
        RETURN utl.get_constant_value('cdbpartneridnotvalid');
    ELSE
        l_usr_id := be_linked_credentials.user_exists(i_user_login_id => i_user_login_id,
                        i_make_id       => l_make_id);
        IF l_usr_id IS NULL
         THEN
            RETURN utl.get_constant_value('cinvalidloginid');
         ELSIF NOT utl.is_service_id_valid(i_svc_id => i_service_id)
         THEN
            RETURN utl.get_constant_value('cnosuchservice');
         END IF;
         
        l_action := utl.set_action( 'Deleting usr_inf rows');

        BEGIN
            DELETE FROM beowner.usr_inf
             WHERE usr_id = l_usr_id::uuid
               AND svc_id = i_service_id;

            GET DIAGNOSTICS l_rowcount = ROW_COUNT;
        
            IF (l_rowcount = 0)
            THEN
               RETURN utl.get_constant_value('cusersnocredentials');
            ELSE
               RETURN utl.get_constant_value('csuccess');
            END IF;
        EXCEPTION
        WHEN OTHERS THEN
           RETURN utl.get_constant_value('cinternalerror');
        END;
    END IF;
END;
$$ LANGUAGE plpgsql
SECURITY DEFINER;

\i cleanup.sql;
