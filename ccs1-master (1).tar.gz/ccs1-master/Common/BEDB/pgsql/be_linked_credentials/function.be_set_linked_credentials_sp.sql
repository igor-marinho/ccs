SET bedb.filename = 'function.be_set_linked_credentials_sp.sql';

\i set_be_env.sql;

   /*
   New function added for WIs #14509 and #14510
   Additional error code for this version :
     c_invalid_cred_provider        constant vc := '296'    ; -- Invalid Credentials Provider

   Added iprovider_account_created for WI #14786, with new error code:
     c_invalid_provider_ac_created  constant vc := '300'    ; -- Invalid Value for Provider Account created flag
   */

   -- Added for WI #14509 and #14510
   -- Overloaded function with same name, which now calls this new function
   -- Added provider to this one
   -- Added iprovider_account_created for WI #14786
DROP FUNCTION IF EXISTS be_linked_credentials.be_set_linked_credentials_sp (TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT, TEXT);

CREATE OR REPLACE FUNCTION be_linked_credentials.be_set_linked_credentials_sp (iuserloginid text, 
                                                                               ipartnerid text, 
                                                                               iserviceid text, 
                                                                               iserviceloginid text, 
                                                                               iservicepassword text, 
                                                                               iservicetoken text, 
                                                                               iprovider text, 
                                                                               iprovider_account_created text DEFAULT NULL) RETURNS INTEGER AS $body$
DECLARE
    l_action text;
    l_module_name text := 'be_set_linked_credentials_sp';
    vusrid                    beowner.usr.usr_id%TYPE;
    salt BYTEA := '34BAE43F05830D394F4FBAEA58225D8A'::BYTEA;
    key_bytes_raw BYTEA;                              -- stores 256-bit encryption key 
    encryption_type text := 'aes-cbc/pad:pkcs'::TEXT; -- total encryption type
    lprovider                 beowner.usr_inf.provider%TYPE := upper(iprovider);
    lprovider_account_created beowner.usr_inf.provider_account_created%TYPE := upper(iprovider_account_created);
    l_count                   integer;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN

    l_action := utl.set_module_action( l_module_name, 'Setting Context');

    call ctx.set(iptnrid := ipartnerid::uuid, iloginid := iuserloginid);

    SELECT usr_id
      INTO STRICT vusrid
      FROM beowner.ctx_data;

    -- validate provider
    IF lprovider IS NOT NULL
    THEN
        SELECT COUNT(1)
        INTO STRICT l_count
        FROM beowner.credential_providers
        WHERE provider = lprovider;

        IF l_count = 0
        THEN
            RETURN utl.get_constant_value('c_invalid_cred_provider');
        END IF;
    END IF;

    -- WI #14786
    IF coalesce(lprovider_account_created, 'N') NOT IN ('N', 'Y')
    THEN
        RETURN utl.get_constant_value('c_invalid_provider_ac_created');
    END IF;

    l_action := utl.set_action('Merging Credentials');

    key_bytes_raw := decode(REPLACE(vusrid::TEXT,'-',''), 'hex') || decode(convert_from(salt,'SQL_ASCII'),'hex');

    IF utl.is_service_id_valid(i_svc_id => iserviceid)
    THEN
     -- Added Provider for WI #14509 and #14510
     -- For 19374
     -- Removed all references to val column for WI #14512
        INSERT INTO beowner.usr_inf (usr_id, svc_id,key_id,enval,provider,provider_account_created)
            SELECT usr_id,
                   svc_id,
                   key_id,
                   enval::bytea,
                   provider,
                   provider_account_created
                  FROM (SELECT vusrid                    usr_id,
                               iserviceid                svc_id,
                               lprovider                 provider,
                               lprovider_account_created provider_account_created
                          ) param
                  JOIN(SELECT 'loginID' key_id,
                               extensions.encrypt(trim(BOTH iserviceloginid)::bytea,
                                                        key_bytes_raw,
                                                        encryption_type) enval  
                              
                      UNION ALL
                      SELECT 'pwd' key_id,
                              extensions.encrypt(trim(BOTH iservicepassword)::bytea,
                                                       key_bytes_raw,
                                                       encryption_type)  enval
                      UNION ALL
                      SELECT 'token' key_id,
                              extensions.encrypt(trim(BOTH iservicetoken)::bytea,
                                                        key_bytes_raw,
                                                        encryption_type)  enval
                 ) crypt ON 1 = 1
            ON CONFLICT (usr_id,svc_id,key_id)
            DO UPDATE set enval = EXCLUDED.enval,
                            provider = EXCLUDED.provider,
                            provider_account_created = EXCLUDED.provider_account_created;

         --utl.doCommit;
         RETURN utl.get_constant_value('csuccess');
      ELSE
         RETURN utl.get_constant_value('c_invalid_svc_id');
      END IF;
   EXCEPTION
      WHEN SQLSTATE 'EPTNR' THEN
         RETURN utl.get_constant_value('cdbpartneridnotvalid');
      WHEN SQLSTATE 'EUSRN' THEN
         RETURN utl.get_constant_value('cnosuchuser');
      WHEN SQLSTATE 'EVINN' THEN
         RETURN utl.get_constant_value('cdbvinnotfound');
      WHEN OTHERS THEN
         GET STACKED diagnostics
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,              
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;
        call trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');
   END;

$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION be_linked_credentials.be_set_linked_credentials_sp (iuserloginid text, ipartnerid text, iserviceid text, iserviceloginid text, iservicepassword text, iservicetoken text, iprovider text, iprovider_account_created text DEFAULT NULL) FROM PUBLIC


/*  Title:        BE_SET_LINKED_CREDENTIALS_SP
   Version:      1.0
   Date:         March 13, 2012
   Author:       George Trowbridge
   Description:  The purpose is to create a new record 3rd party credentials entry
                 in the
                 credentials and subscribers_Credentials tables to reflect the
                 information passed to this procedure from the calling
                 application.  There is first a validation of the email_address
                 and the password in the subscribers table.  Then a record is
                 created in the credentials table, next a record is created in
                 the subscribers_credentials table to create the relationship.

   Input parameters:
     userLoginId       - subscriber email address
     userPassword      - subscriber password
     service_loginid   - user id for the given service
     service_password  - password for the given service
     token             - token for the given service if necessary
     service_api_number- This is the api number of the service.  The API number
                         is data driven and will be from the services table in
                         the future.
     partnerid_i       - partner id

   Output parameters:
     status_code_0     - Output variable
     success -  status_code of '0' if there is success in creating the new
                records in the credentials and subscribers_credentials tables.
     failure - '1' if there is failure in the routine.
     failure - '4' - invalid parameter(s)
     failure - '2' - user does not exist
     failure - '7' - userid not on file

*/
DROP FUNCTION IF EXISTS be_linked_credentials.be_set_linked_credentials_sp (TEXT, TEXT, TEXT, TEXT, TEXT, TEXT);

CREATE OR REPLACE FUNCTION be_linked_credentials.be_set_linked_credentials_sp (iuserloginid text, 
                                                                               ipartnerid text, 
                                                                               iserviceid text, 
                                                                               iserviceloginid text, 
                                                                               iservicepassword text, 
                                                                               iservicetoken text) RETURNS INTEGER AS $body$
BEGIN
      RETURN be_linked_credentials.be_set_linked_credentials_sp(iuserloginid     => iuserloginid,
                                          ipartnerid       => ipartnerid,
                                          iserviceid       => iserviceid,
                                          iserviceloginid  => iserviceloginid,
                                          iservicepassword => iservicepassword,
                                          iservicetoken    => iservicetoken,
                                          iprovider        => NULL);
   END;


$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION be_linked_credentials.be_set_linked_credentials_sp (iuserloginid text, ipartnerid text, iserviceid text, iserviceloginid text, iservicepassword text, iservicetoken text) FROM PUBLIC;

\i cleanup.sql;
