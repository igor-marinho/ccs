SET bedb.filename = 'function.be_get_linked_credentials_sp.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS be_linked_credentials.be_get_linked_credentials_sp(TEXT,TEXT);

CREATE OR REPLACE FUNCTION be_linked_credentials.be_get_linked_credentials_sp (iuserloginid        text
                                                                              ,ipartnerid          text
                                                                              ,o_status_code   OUT INTEGER
                                                                              ,oresultset      OUT refcursor
                                                                              )
AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'be_linked_credentials';
    vusrid BEOWNER.usr.usr_id%TYPE;
    salt BYTEA := '34BAE43F05830D394F4FBAEA58225D8A'::BYTEA;
    key_bytes_raw BYTEA;                              -- stores 256-bit encryption key 
    encryption_type text := 'aes-cbc/pad:pkcs'::TEXT; -- total encryption type
    
    vcnt SMALLINT;
    vsvcid TEXT;
    vconst CHARACTER VARYING(1) := '+';
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN
    
    vsvcid := NULL;
    
    l_action := utl.set_module_action( l_module_name, 'Setting Context');

    oresultset := utl.get_dummy_cursor();
   
    call ctx.set(iptnrid := ipartnerid::uuid, iloginid := iuserloginid);
    l_action := utl.set_action( 'Checking for existing credentials');
   
    SELECT usr_id
      INTO STRICT vusrid
      FROM beowner.ctx_data;
     
    key_bytes_raw := decode(REPLACE(vusrid::TEXT,'-',''), 'hex') || decode(convert_from(salt,'SQL_ASCII'),'hex');
   
    SELECT COUNT(*)
      INTO STRICT vcnt
      FROM beowner.creds
     WHERE CASE
            WHEN vsvcid IS NULL THEN vconst
            ELSE svc_id
        END = CASE
                WHEN vsvcid IS NULL THEN vconst
                ELSE vsvcid
              END;

    IF vcnt = 0
    THEN
        l_action := utl.set_action('Returning no credentials');

        o_status_code := utl.get_constant_value('cusersnocredentials');
        RETURN;
       
    /* Defect 13007 instead of passing back through the refcursor pass the status back through the returned value */
    END IF;
   
    /* vcnt := be_set_linked_creds_sp (vusrid); Commented out for WI #14512, as it is no longer needed. */
   
    l_action := utl.set_action('Returing credentials');

    -- need to close the dummy cursor before opening result cursor
    CLOSE oresultset;
    OPEN oresultset FOR
        SELECT svc_id serviceid,
            encode(CASE WHEN loginid IS NULL OR loginid = '' 
                     THEN loginid
                     ELSE extensions.decrypt( decode(convert_from(loginid, 'SQL_ASCII'),'hex'),
                                              key_bytes_raw,
                                              encryption_type
                                            )  
                   END, 'escape') AS serviceloginid,
            encode(CASE WHEN pwd IS NULL OR pwd  = '' 
                     THEN pwd 
                     ELSE extensions.decrypt( decode(convert_from(pwd, 'SQL_ASCII'),'hex'),
                                              key_bytes_raw,
                                              encryption_type
                                            )  
                  END, 'escape') AS servicepassword,
            encode(CASE WHEN token IS NULL OR token = '' 
                     THEN token
                     ELSE extensions.decrypt( decode(convert_from(token, 'SQL_ASCII'),'hex'),
                                              key_bytes_raw,
                                              encryption_type
                                            )  
                  END, 'escape') AS servicetoken,
              provider    
        FROM beowner.ecreds
        WHERE CASE
              WHEN vsvcid IS NULL
              THEN vconst
              ELSE svc_id
            END = CASE
                    WHEN vsvcid IS NULL
                    THEN vconst
                    ELSE vsvcid
                  END;
                         
    o_status_code := utl.get_constant_value('csuccess');
   
    RETURN;
   
    EXCEPTION
      WHEN SQLSTATE 'EPTNR'
      THEN
         oresultset := utl.get_dummy_cursor();
         o_status_code :=  utl.get_constant_value('cdbpartneridnotvalid');
         RETURN;
        
      WHEN SQLSTATE 'EUSRN' 
      THEN
         oresultset := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cnosuchuser');
         RETURN ;
        
      WHEN OTHERS
      THEN
         GET STACKED diagnostics
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,              
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;
        call trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
        oresultset := utl.get_dummy_cursor();
        o_status_code := utl.get_constant_value('cinternalerror');
        RETURN;
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

--+============================
DROP FUNCTION IF EXISTS be_linked_credentials.be_get_linked_credentials_sp(TEXT,  TEXT, TEXT);

CREATE OR REPLACE FUNCTION be_linked_credentials.be_get_linked_credentials_sp (iuserloginid       text
                                                                              ,ipartnerid         text
                                                                              ,iserviceid         text
                                                                              ,o_status_code  OUT INTEGER
                                                                              ,oresultset     OUT refcursor)
AS                                                                              
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'be_linked_credentials';
    vusrid BEOWNER.usr.usr_id%TYPE;
    salt BYTEA := '34BAE43F05830D394F4FBAEA58225D8A'::BYTEA;
    key_bytes_raw BYTEA;                              -- stores 256-bit encryption key 
    encryption_type text := 'aes-cbc/pad:pkcs'::TEXT; -- total encryption type
    
    vcnt SMALLINT;
    vsvcid TEXT;
    vconst CHARACTER VARYING(1) := '+';
    l_exception_diagnostics trc.exception_diagnostics;
BEGIN

    -- Defect 13552 check for plus sign passed in to indicate passing results back through stored procedure instead of a function so the 
    -- status code has to be passed as the first argument in the result set for each service in the result set 

    IF iserviceid = '+' THEN
        vsvcid := NULL;
    ELSE
        vsvcid := iserviceid;
    END IF;
    
    l_action := utl.set_module_action( l_module_name, 'Setting Context');
    
    oresultset := utl.get_dummy_cursor();
   
    call ctx.set(iptnrid := ipartnerid::uuid, iloginid := iuserloginid);

    SELECT
        usr_id
        INTO STRICT vusrid
        FROM beowner.ctx_data;
        
    key_bytes_raw := decode(REPLACE(vusrid::TEXT,'-',''), 'hex') || decode(convert_from(salt,'SQL_ASCII'),'hex');

    l_action := utl.set_action( 'Checking for existing credentials');
    
    SELECT
        COUNT(*)
        INTO STRICT vcnt
        FROM beowner.creds
        WHERE
        CASE
            WHEN vsvcid IS NULL THEN vconst
            ELSE svc_id
        END =
        CASE
            WHEN vsvcid IS NULL THEN vconst
            ELSE vsvcid
        END;

    IF vcnt = 0 THEN
        l_action := utl.set_action( 'Returning no credentials');

        o_status_code := utl.get_constant_value('cusersnocredentials');
        RETURN;
    -- Defect 13007 instead of passing back through the refcursor pass the status back through the returned value 
    END IF;
    -- vcnt := be_set_linked_creds_sp (vusrid);  Commented out for WI #14512, as it is no longer needed. 
    l_action := utl.set_action('Returing credentials');

    -- Defect 13552 if the serviceid is a plus then all services for a user will be returned 
    -- need to close the dummy cursor before opening result cursor
    CLOSE oresultset;
    IF iserviceid = '+' 
    THEN
        OPEN oresultset FOR
            SELECT '0',
                    svc_id serviceid,
                    encode(CASE WHEN loginid IS NULL OR loginid = '' 
                             THEN loginid
                             ELSE extensions.decrypt( decode(convert_from(loginid, 'SQL_ASCII'),'hex'),
                                                      key_bytes_raw,
                                                      encryption_type
                                                    )  
                           END, 'escape') AS serviceloginid,
                    encode(CASE WHEN pwd IS NULL OR pwd  = '' 
                             THEN pwd 
                             ELSE extensions.decrypt( decode(convert_from(pwd, 'SQL_ASCII'),'hex'),
                                                      key_bytes_raw,
                                                      encryption_type
                                                    )  
                          END, 'escape') AS servicepassword,
                    encode(CASE WHEN token IS NULL OR token = '' 
                             THEN token
                             ELSE extensions.decrypt( decode(convert_from(token, 'SQL_ASCII'),'hex'),
                                                      key_bytes_raw,
                                                      encryption_type
                                                    )  
                          END, 'escape') AS servicetoken,
                      provider
              FROM beowner.ecreds
             WHERE CASE
                      WHEN vsvcid IS NULL 
                        THEN vconst
                        ELSE svc_id
                   END = CASE
                      WHEN vsvcid IS NULL 
                        THEN vconst
                        ELSE vsvcid
                      END ;
    ELSE
        OPEN oresultset FOR
            SELECT svc_id serviceid,
                    encode(CASE WHEN loginid IS NULL OR loginid = '' 
                             THEN loginid
                             ELSE extensions.decrypt( decode(convert_from(loginid, 'SQL_ASCII'),'hex'),
                                                      key_bytes_raw,
                                                      encryption_type
                                                    )  
                           END, 'escape') AS serviceloginid,
                    encode(CASE WHEN pwd IS NULL OR pwd  = '' 
                             THEN pwd 
                             ELSE extensions.decrypt( decode(convert_from(pwd, 'SQL_ASCII'),'hex'),
                                                      key_bytes_raw,
                                                      encryption_type
                                                    )  
                          END, 'escape') AS servicepassword,
                    encode(CASE WHEN token IS NULL OR token = '' 
                             THEN token
                             ELSE extensions.decrypt( decode(convert_from(token, 'SQL_ASCII'),'hex'),
                                                      key_bytes_raw,
                                                      encryption_type
                                                    )  
                          END, 'escape') AS servicetoken,
                    provider
            FROM beowner.ecreds
                     WHERE CASE
                              WHEN vsvcid IS NULL 
                                THEN vconst
                                ELSE svc_id
                           END = CASE
                              WHEN vsvcid IS NULL 
                                THEN vconst
                              ELSE vsvcid
                           END ;
    END IF;
    o_status_code := utl.get_constant_value('csuccess');
    RETURN;

    EXCEPTION
      WHEN SQLSTATE 'EPTNR'
      THEN
         oresultset := utl.get_dummy_cursor();
         o_status_code :=  utl.get_constant_value('cdbpartneridnotvalid');
         RETURN;
        
      WHEN SQLSTATE 'EUSRN' 
      THEN
         oresultset := utl.get_dummy_cursor();
         o_status_code := utl.get_constant_value('cnosuchuser');
         RETURN ;

      WHEN OTHERS
      THEN
         GET STACKED diagnostics
            l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
            l_exception_diagnostics.column_name := COLUMN_NAME,
            l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
            l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
            l_exception_diagnostics.message_text := MESSAGE_TEXT,
            l_exception_diagnostics.table_name := TABLE_NAME,
            l_exception_diagnostics.schema_name := SCHEMA_NAME,              
            l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
            l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
            l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
            l_exception_diagnostics.module_name := l_module_name;
            l_exception_diagnostics.action := l_action;
        call trc.log(iadditionaldata => NULL,
                     iexception_diagnostics => l_exception_diagnostics);
        oresultset := utl.get_dummy_cursor();                 
        o_status_code := utl.get_constant_value('cinternalerror');
        RETURN;
END;
$BODY$
LANGUAGE  plpgsql
SECURITY DEFINER;

\i cleanup.sql;
