SET bedb.filename = 'function.user_exists.sql';

\i set_be_env.sql;

DROP FUNCTION IF EXISTS be_linked_credentials.user_exists ( text, text );
CREATE OR REPLACE FUNCTION be_linked_credentials.user_exists (i_user_login_id text, 
                                                              i_make_id text) RETURNS TEXT AS $body$
DECLARE 
    l_usr_id TEXT;
BEGIN
    SELECT usr_id
      INTO STRICT l_usr_id
     FROM beowner.usr
    WHERE login_id = trim(both lower(i_user_login_id))
      AND make_id = i_make_id;

    RETURN l_usr_id;

EXCEPTION
 WHEN no_data_found THEN
    RETURN NULL;
END;

$body$
LANGUAGE PLPGSQL
 STABLE;
-- REVOKE ALL ON FUNCTION be_linked_credentials.user_exists (i_user_login_id text, i_make_id text, o_usr_id OUT text) FROM PUBLIC;

\i cleanup.sql;
