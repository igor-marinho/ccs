SET bedb.filename = 'function.g_bundle.sql';

\i set_be_env.sql;
DROP FUNCTION IF EXISTS crudg_bundle.g_bundle(TEXT,TEXT,TEXT);
   -- Removed Function cr_bundle for DCS1E-605
   -- Removed Function u_bundle for DCS1E-605
   -- Removed Function d_bundle for DCS1E-605
   -- rst cursor columns :bndl_id, name, description, device_id, make_id, payment_type, max_users, bundle_length, grace_length, 
   -- end_date, version
   -- Removed columns bundle_price, renewal_price, renewal_length, conflict_length, avail_date for DCS1E-1002
CREATE OR REPLACE FUNCTION crudg_bundle.g_bundle (ibndl_id       text DEFAULT NULL
                                                 ,iname          text DEFAULT NULL
                                                 ,iversion       text DEFAULT NULL
                                                 ,f_status   OUT INTEGER
                                                 ,rslt       OUT refcursor)
AS $body$
DECLARE
      l_action text;
      l_module_name text := 'g_bundle';
      bcnt     bigint := 0;
      vbndl_id beowner.bndl.bndl_id%TYPE;
      vname    beowner.bndl.name%TYPE;
      l_exception_diagnostics trc.exception_diagnostics;
BEGIN
      rslt := utl.get_dummy_cursor(); -- Jira PU-391
      vbndl_id := trim(both ibndl_id)::uuid;
      vname := upper(trim(both iname));

      l_action := utl.set_module_action( l_module_name,  'Verifying Bndl counts');

      SELECT COUNT(*)
        INTO STRICT bcnt
        FROM beowner.bndl
       WHERE (bndl_id = vbndl_id)
             OR (upper(trim(both NAME)) = vname);

      IF bcnt = 0
      THEN
         CLOSE rslt;
         OPEN rslt FOR
            SELECT bndl_id,
                   NAME,
                   description, /*make_id,*/
                   payment_type,
                   max_users,
                   bundle_length,
                   grace_length,
                   end_date --,version
              FROM beowner.bndl;
      ELSE
        CLOSE rslt;
        OPEN rslt FOR
            SELECT bndl_id,
                   NAME,
                   description, /*make_id,*/
                   payment_type,
                   max_users,
                   bundle_length,
                   grace_length,
                   end_date --,version
              FROM beowner.bndl
             WHERE (bndl_id = vbndl_id)
                   OR (upper(trim(both NAME)) = vname);
      END IF;

      f_status := utl.get_constant_value('csuccess');
  RETURN;
   EXCEPTION
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,              
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
          
          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;
      
        CALL trc.log(iadditionaldata => 'Something beowner.g_bundle went really wrong!' ||
                                          ' ibndl_id=' || ibndl_id ||
                                          ' iname=' || iname ||
                                          ' version=' || iversion,
                        iexception_diagnostics => l_exception_diagnostics);
         f_status := utl.get_constant_value('cinternalerror');
     RETURN; 
   END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;
-- REVOKE ALL ON FUNCTION crudg_bundle.g_bundle ( rslt OUT REFCURSOR ,ibndl_id text DEFAULT NULL, iname text DEFAULT NULL, iversion text DEFAULT NULL) FROM PUBLIC;
\i cleanup.sql;
