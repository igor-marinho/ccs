SET bedb.filename = 'function.g_make.sql';

\i set_be_env.sql;

drop function if exists crudg_make.g_make(text);

CREATE OR REPLACE FUNCTION crudg_make.g_make (i_version text DEFAULT null,
                                              o_status_code out integer,                                                    
                                              o_result OUT REFCURSOR)
AS $body$
   /*  
   Return all the makes with their description
   utl.get_constant_value('csuccess') (0) is returned if the operation was successful
   
   Error codes returned:
   cInternalError                 '1'       Unknown Internal error
   c_no_makes_found             '420'       No makes exist in the DB
   */
DECLARE
  l_module_name text := 'g_make';
  l_action TEXT;
  
  l_make_count integer;
  l_exception_diagnostics trc.exception_diagnostics;

BEGIN
  
  o_result := utl.get_dummy_cursor();

  l_action := utl.set_module_action(l_module_name,
                                   'Getting count');
 
  SELECT COUNT(1)
    INTO STRICT l_make_count
    FROM beowner.make;
  
  IF l_make_count = 0
  then
    o_status_code := utl.get_constant_value('c_no_makes_found');    
  else
  
    CLOSE o_result;

    OPEN o_result FOR
    SELECT make_id,
           description
      FROM beowner.make
     ORDER BY 1;
   
    o_status_code := utl.get_constant_value('csuccess');
  END IF;
  
EXCEPTION
  WHEN others
  THEN
    GET STACKED diagnostics
      l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
      l_exception_diagnostics.column_name := COLUMN_NAME,
      l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
      l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
      l_exception_diagnostics.message_text := MESSAGE_TEXT,
      l_exception_diagnostics.table_name := TABLE_NAME,
      l_exception_diagnostics.schema_name := SCHEMA_NAME,              
      l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
      l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
      l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
    
    l_exception_diagnostics.module_name := l_module_name;
    l_exception_diagnostics.action := l_action;
    
    o_result := utl.get_dummy_cursor();

    call trc.log('Something went wrong in ' || l_module_name,
                 iexception_diagnostics => l_exception_diagnostics);
                  
    o_status_code := utl.get_constant_value('cinternalerror')::integer;
 
END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER
;

\i cleanup.sql;
