SET bedb.filename = 'merge_cfg.sql';

\i set_be_env.sql;

INSERT INTO beowner.cfg(name, value) VALUES
('OEM notif job keep days', '30' )
ON CONFLICT ON CONSTRAINT pk_cfg
DO UPDATE SET
value = '30';

INSERT INTO beowner.cfg(name, value) VALUES
('message queue keep days', '30' )
ON CONFLICT ON CONSTRAINT pk_cfg
DO UPDATE SET
value = '30';

\i cleanup.sql;
