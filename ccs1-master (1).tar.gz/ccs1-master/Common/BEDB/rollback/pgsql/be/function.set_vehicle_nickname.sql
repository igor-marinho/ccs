SET bedb.filename = 'function.set_vehicle_nickname.sql';

\i set_be_env.sql;


   -------------------------------------------------------------------------------
/* set_vehicle_nickname
        Sets the nickname for the vehicle (VIN) provided.
        Inputs:
        iPartnerId   Partner Id for the VIN
        iLoginId     Login Id for the VIN
        iVin         VIN that the nickname will be set for
        iNickname    Nickname that needs to be set for the VIN provided
        iNeedUnique  Indicates if Nickname Uniqueness is required per Login Id - 0/1 -- OT 6108
                       0 is existing behaviour (default), which indicates that no check for uniqueness needs to be done
                       If set to 1, will return an error if the nickname is not unique for the login Id provided
     Expected Return Values:
            0     : success
            1     : Unknown Error
            7     : No such User found           (cnst.cNoSuchUser)
            200   : VIN not found (not your VIN) (cnst.cDbVinNotFound)
            201   : Subscriber/VIN not found     (cnst.cdbsubscribervinnotfound)
            213   : Partner Id is not valid      (cnst.cDbPartneridNotValid)
            224   : Duplicate Nickname for User  (cDuplicateNickNameForUser)

   */
DROP FUNCTION IF EXISTS be.set_vehicle_nickname(TEXT, TEXT, TEXT, TEXT, INTEGER);
CREATE OR REPLACE FUNCTION be.set_vehicle_nickname(IN ipartnerid TEXT,
                                                      IN iloginid TEXT,
                                                      IN ivin TEXT,
                                                      IN inickname TEXT,
                                                      IN ineedunique INTEGER DEFAULT 0) -- added for OT 6108 - Vehicle
																						-- Specific Support for multi EV Vehicle Services (DB ID -- 64 F.ID 3043)
       RETURNS INTEGER AS
$BODY$
DECLARE
    l_action text;
    l_module_name text := 'set_vehicle_nickname';
    vfound           boolean;
    vcountduplicates integer;
    l_exception_diagnostics trc.exception_diagnostics;

BEGIN
      l_action := utl.set_module_action(l_module_name, ' Setting Context');

      CALL ctx.set(iloginid => iloginid, ivin => ivin, iptnrid => ipartnerid::uuid);

      -- Block below added for OT 6108
      IF ineedunique = 1
      THEN
         l_action := utl.set_module_action(l_module_name, ' checking nickname uniqueness');

         SELECT COUNT(1)
         INTO STRICT vcountduplicates
         FROM beowner.subscription
         WHERE (primary_id) =
               (SELECT usr_id
                FROM beowner.ctx_data)
           AND vin != upper(trim(BOTH ivin));

         IF vcountduplicates > 0
         THEN
            RAISE EXCEPTION 'eduplicate4vin' USING ERRCODE = utl.get_constant_value('e_duplicate4vin');
         END IF;
      END IF;

      l_action := utl.set_module_action(l_module_name, ' updating nickname');

      UPDATE beowner.subscription
      SET nickname = inickname
      WHERE (primary_id, vin) = (SELECT usr_id,
                                        vin
                                 FROM beowner.ctx_data);

      vfound := FOUND;


      RETURN CASE WHEN vfound THEN utl.get_constant_value('csuccess')
                  ELSE utl.get_constant_value
                      ('cdbsubscribervinnotfound') END;
   EXCEPTION
      WHEN SQLSTATE 'EVINN' THEN
         RETURN utl.get_constant_value('cdbvinnotfound');
      WHEN SQLSTATE 'EPTNR' THEN
         RETURN utl.get_constant_value('cdbpartneridnotvalid');
      WHEN SQLSTATE 'EUSRN' THEN
         RETURN utl.get_constant_value('cnosuchuser');
      WHEN SQLSTATE 'ED4VN' THEN
         RETURN utl.get_constant_value('cduplicatenicknameforuser');
      WHEN OTHERS THEN
         GET STACKED diagnostics
          l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
          l_exception_diagnostics.column_name := COLUMN_NAME,
          l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
          l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
          l_exception_diagnostics.message_text := MESSAGE_TEXT,
          l_exception_diagnostics.table_name := TABLE_NAME,
          l_exception_diagnostics.schema_name := SCHEMA_NAME,
          l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
          l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
          l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;

          l_exception_diagnostics.module_name := l_module_name;
          l_exception_diagnostics.action := l_action;

        CALL trc.log(iadditionaldata => NULL,
                        iexception_diagnostics => l_exception_diagnostics);
         RETURN utl.get_constant_value('cinternalerror');
   END;

$BODY$
LANGUAGE PLPGSQL
SECURITY DEFINER;
-- REVOKE ALL ON FUNCTION be.set_vehicle_nickname (ipartnerid text, iloginid text, ivin text, inickname text, ineedunique numeric DEFAULT 0 ) FROM PUBLIC;

\i cleanup.sql;
