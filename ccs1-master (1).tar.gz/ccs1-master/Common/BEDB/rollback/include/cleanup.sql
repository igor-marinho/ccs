-- to be called at the end of each .sql script
-- will most likely contain other commands in the future

\echo
\echo Completed script :filename 
\echo

\unset filename

reset role;
