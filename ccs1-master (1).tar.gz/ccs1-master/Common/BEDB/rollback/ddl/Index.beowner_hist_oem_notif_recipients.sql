SET bedb.filename = 'Index.beowner_hist_oem_notif_recipients.sql';

\i set_be_env.sql;

DROP INDEX IF EXISTS honr_usr_id_idx;

\i cleanup.sql;