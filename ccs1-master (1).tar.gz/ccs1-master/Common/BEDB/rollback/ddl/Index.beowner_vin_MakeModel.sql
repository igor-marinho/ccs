SET bedb.filename = 'index.beowner_vin_MakeModel.sql';

\i set_be_env.sql;

drop index if exists idx_mk_mdl_vin;

\i cleanup.sql;
