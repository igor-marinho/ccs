
DROP USER IF EXISTS read_only;


do
$$
DECLARE 

begin
	
		if exists (SELECT * FROM PG_CATALOG.PG_ROLES WHERE upper(ROLNAME) = 'READONLY' ) then
	
		EXECUTE 'DROP OWNED BY readonly ';
	
		end if;
end;
$$;


DROP ROLE IF EXISTS readonly; 


