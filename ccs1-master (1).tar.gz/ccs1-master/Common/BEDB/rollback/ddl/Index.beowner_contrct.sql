SET bedb.filename = 'Index.beowner_contrct.sql';

\i set_be_env.sql;

DROP INDEX IF EXISTS idx_extrnl_contrct_id;

\i cleanup.sql;
