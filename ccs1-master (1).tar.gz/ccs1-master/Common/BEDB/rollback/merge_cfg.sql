SET bedb.filename = 'merge_cfg.sql';

\i set_be_env.sql;

delete
 from beowner.cfg
where name = 'OEM notif job keep days';

delete
 from beowner.cfg
where name =  'message queue keep days';

\i cleanup.sql;
