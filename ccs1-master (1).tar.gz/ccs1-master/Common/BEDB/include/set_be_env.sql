-- to be called at the beginning of each .sql script that needs to be executed as user beowner
-- will most likely contain other commands in the future

set role beowner;
SET search_path TO beowner;

select clock_timestamp() as start_file \gset
select current_setting('bedb.filename') as filename \gset

\echo
\echo Starting script :filename  at :start_file
\echo
