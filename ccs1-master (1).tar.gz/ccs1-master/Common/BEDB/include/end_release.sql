--SET SERVEROUTPUT ON
\echo Running end release...

-- PROMPT Purging DBA_RECYCLEBIN...
-- PURGE DBA_RECYCLEBIN;

-- PROMPT GRANT EXECUTE ON sys.DBMS_CRYPTO TO beowner;
--Added to fix issues in new environments
-- GRANT EXECUTE ON sys.DBMS_CRYPTO TO beowner;

--Jira DDCRD-584
-- PROMPT Dropping public synonyms that no longer point to valid objects....
-- DECLARE
  -- v_text CLOB;
-- BEGIN
   -- FOR syn IN (SELECT s.synonym_name,
                      -- 'DROP PUBLIC SYNONYM "' || s.synonym_name || '"' AS stmt
                 -- FROM dba_synonyms s
                -- WHERE s.owner = 'PUBLIC'
                      -- AND s.table_owner LIKE '%OWNER'
                      -- AND NOT EXISTS
                -- (SELECT 'X'
                         -- FROM dba_objects o
                        -- WHERE o.owner = s.table_owner
                              -- AND o.object_name = s.table_name))
   -- LOOP
      -- utl.log_it('Dropping public synonym: ' || syn.synonym_name);
      -- EXECUTE IMMEDIATE syn.stmt;
   -- END LOOP;
-- END;
-- /

--Added due to defect 17907 - this section creates/recreates public synonyms for all of the TGT owner schemas new and used tables, views, procedures
--DDCRD-307: Clean up to deal with duplicate synonym names. Give precedence to BEOWNER schema objects when
--there are any collisions.
-- PROMPT Re/Create public synonyms...
-- DECLARE
   -- str   VARCHAR2 (4000);
--also added PACKAGE
-- BEGIN
   -- FOR c
      -- IN (SELECT 'create or replace public synonym "' || object_name || '" for "' ||
                 -- owner || '"."' || object_name || '"' AS str
            -- FROM (SELECT owner,
                         -- object_name,
                         -- object_type,
                         -- row_number() OVER (PARTITION BY object_name
                                            -- ORDER BY CASE
                                                       -- WHEN owner = 'BEOWNER' THEN 1
                                                       -- ELSE 2
                                                     -- END) AS rn
                    -- FROM dba_objects
                   -- WHERE owner LIKE '%OWNER'
                         -- AND object_type IN ('PROCEDURE', 'VIEW', 'TABLE', 'PACKAGE', 'TYPE', 'FUNCTION'))
           -- WHERE rn = 1
           -- ORDER BY CASE object_type
                       -- WHEN 'TABLE' THEN
                        -- 111
                       -- WHEN 'VIEW' THEN
                        -- 112
                       -- WHEN 'PROCEDURE' THEN
                        -- 113
                    -- END)
   -- LOOP
      -- EXECUTE IMMEDIATE c.str;
   -- END LOOP;
-- END;
-- /
--End Added due to defect 17907 - this section creates/recreates public synonyms for all of the TGT owner schemas new and used tables, views, procedure

--OnTime #22334 - to prevent Java objects and their dependents from becoming invalid
-- PROMPT Compile Schemas...
-- DECLARE
   -- x        EXCEPTION;
   -- PRAGMA EXCEPTION_INIT (x, -06550);
   -- l_text   VARCHAR2 (400);
-- BEGIN
--   JIRA PU-16 Oracle 12c upgrade - DB Dev work for compatibility
   -- BEGIN
      -- EXECUTE IMMEDIATE ('begin sys.dbms_java_dev.enable; end;');
   -- EXCEPTION
      -- WHEN x
      -- THEN
         -- l_text :=
            -- 'dbms_java_dev.enable is not installed. Can be ignored.';
   -- END;

   -- FOR schema IN (SELECT username
                    -- FROM all_users
                   -- WHERE username LIKE '%OWNER')
   -- LOOP
      -- DBMS_UTILITY.compile_schema (schema.username);
   -- END LOOP;

--   JIRA PU-16 Oracle 12c upgrade - DB Dev work for compatibility
   -- BEGIN
      -- EXECUTE IMMEDIATE ('begin sys.dbms_java_dev.disable; end;');
   -- EXCEPTION
      -- WHEN x
      -- THEN
         -- l_text :=
            -- 'dbms_java_dev.disable is not installed. Can be ignored.';
   -- END;
-- END;
-- /

--Defect 17907       this section recompiles the all of the public synonyms that are made invalid by the above recompile
-- PROMPT Recompile all invalid public synonyms...
-- DECLARE
   -- str   VARCHAR2 (4000);
-- BEGIN
   -- FOR c
      -- IN (SELECT 'alter public synonym ' || object_name || ' compile' str
            -- FROM dba_objects
           -- WHERE     object_type = 'SYNONYM'
                 -- AND owner = 'PUBLIC'
                 -- AND status = 'INVALID')
   -- LOOP
      -- EXECUTE IMMEDIATE c.str;
   -- END LOOP;
-- END;
-- /

--End Added for Defect 17907 this section recompiles the all of the public synonyms that are made invalid by the above recompile

--Jira SBM-509: Recreate any synonyms that have a timestamp not in sync with the parent object, see Oracle support note 835792.1
-- PROMPT Checking for out of sync synonyms...
--Refresh package state due to the recompilation in order to avoid Oracle error 04068
-- exec DBMS_SESSION.RESET_PACKAGE;
-- SET SERVEROUTPUT ON
-- BEGIN
   -- FOR rec IN (SELECT 'DROP PUBLIC SYNONYM "' || obj_parent.object_name || '"' AS stmt_d,
                      -- 'create or replace public synonym "' ||
                      -- obj_parent.object_name || '" for "' || obj_parent.owner ||
                      -- '"."' || obj_parent.object_name || '"' AS stmt_c,
                      -- obj_parent.object_name
                 -- FROM sys.obj$ do
                 -- JOIN sys.dependency$ d
                   -- ON (d.d_obj# = do.obj#)
                 -- JOIN sys.obj$ po
                   -- ON (d.p_obj# = po.obj#)
                 -- JOIN sys.dba_objects obj_parent
                   -- ON (obj_parent.object_id = po.obj#)
                 -- JOIN sys.dba_objects obj_child
                   -- ON (obj_child.object_id = do.obj#)
                -- WHERE do.status = 1 /*dependent is valid*/
                      -- AND po.status = 1 /*parent is valid*/
                      -- AND po.stime != d.p_timestamp /*parent timestamp not match*/
                      -- AND obj_parent.owner LIKE '%OWNER'
                      -- AND obj_child.object_type = 'SYNONYM')
   -- LOOP

      -- utl.log_it('Recreating the synonym for ' || rec.object_name ||
                           -- ' as it has a mismatched timestamp');
     
      -- EXECUTE IMMEDIATE rec.stmt_d;
      -- EXECUTE IMMEDIATE rec.stmt_c;
   -- END LOOP;
-- END;
-- /

-- PROMPT The following query for Errors should return NO ROWS !

-- COLUMN text FORMAT a50
-- COLUMN owner FORMAT a10
-- COLUMN name FORMAT a20
-- COLUMN type FORMAT a14

--JIRA PU-16 Oracle 12c upgrade - DB Dev work for compatibility

-- SELECT * FROM TABLE (beowner.utl.get_dba_errors);

--Changes for SBM-868

--Setting term off temporarily as utlrp shows a lot of information, that is not needed 

-- PROMPT Calling utlrp
-- PROMPT 
-- SET TERM OFF

-- @utlrp.sql

-- SET TERM ON 
-- COL OBJECT_NAME FORMAT a30
-- SET LINESIZE 200

-- PROMPT The following query for invalid objects should return NO ROWS !

-- set echo off

-- SELECT owner,
       -- object_name,
       -- object_type,
       -- status
  -- FROM dba_objects
 -- WHERE status = 'INVALID';

-- EXIT;

\echo End release complete
