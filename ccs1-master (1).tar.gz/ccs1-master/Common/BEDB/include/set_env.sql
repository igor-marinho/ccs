-- to be called at the beginning of each .sql script.  This does not change user
-- will most likely contain other commands in the future

select clock_timestamp() as start_file \gset
select current_setting('bedb.filename') as filename \gset

\echo
\echo Starting script :filename  at :start_file
\echo
