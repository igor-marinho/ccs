-- to be called at the end of each .sql script
-- will most likely contain other commands in the future

select clock_timestamp() as end_file \gset

\echo
\echo Completed script :filename at :end_file
\echo

\unset filename
SET bedb.filename = '';
SET logdb.filename = '';
reset role;
