SET logdb.filename = 'function.addtelog_sp.sql';

\i set_telog_env.sql

DROP FUNCTION IF EXISTS addlogging.addtelog_sp (TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TIMESTAMP WITH TIME ZONE,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT,
                                                 TEXT);

   -- For Jira DDCRD-510 : 
   --    Removed allheaders_i, devicemanufacturer_i, hu_mfr_i, hu_model_i, along with writes to header_log.
   --    Added user_agent to TELOG
CREATE OR REPLACE FUNCTION addlogging.addtelog_sp(IN useragent_i            TEXT,
                                                   IN userloginid_i         TEXT,
                                                   IN serviceid_i           TEXT,
                                                   IN servicetype_i         TEXT,
                                                   IN telog_i               TEXT,
                                                   IN devicelatitude_i      TEXT,
                                                   IN devicelongitude_i     TEXT,
                                                   IN partnerid_i           TEXT,
                                                   IN striketime_i          TIMESTAMP WITH TIME ZONE,
                                                   IN duration_i            TEXT,
                                                   IN status_i              TEXT,
                                                   IN mdeviceid_i           TEXT,
                                                   IN hdeviceid_i           TEXT,
                                                   IN command_i             TEXT,
                                                   IN transaction_id_i      TEXT,
                                                   IN tel_3pp_id_i          TEXT,
                                                   IN tel_connection_time_i TEXT,
                                                   IN tel_client_content_i  TEXT,
                                                   IN tel_vin_i             TEXT,
                                                   IN make_i                TEXT,
                                                   IN country_i             TEXT,
                                                   IN region_i              TEXT DEFAULT NULL,
                                                   IN muniqueid_i           TEXT DEFAULT NULL,
                                                   IN huniqueid_i           TEXT DEFAULT NULL,
                                                   OUT recordset_o          REFCURSOR )
AS 
$body$
DECLARE
l_telog_rec telogowner.telog%ROWTYPE;
v_err_msg   TEXT;
v_sql_code  INTEGER;
   
BEGIN
    l_telog_rec.pkguid := beowner.rand_guid(); -- Jira PU-132
    l_telog_rec.tel_email_address1 := TRIM(lower(userloginid_i)); -- Defect 17930
    l_telog_rec.tel_log := telog_i;
    l_telog_rec.tel_serviceid := serviceid_i;
    l_telog_rec.tel_created_date := clock_timestamp();
    l_telog_rec.tel_created_by := 'TELOG';
    l_telog_rec.tel_status := status_i;
    l_telog_rec.tel_type := servicetype_i;
    l_telog_rec.tel_device_latitude := NULL;
    l_telog_rec.tel_device_longitude := NULL;
    l_telog_rec.tel_partnerid := partnerid_i;
    l_telog_rec.tel_strike_time := coalesce(striketime_i, clock_timestamp()); -- Ontime # 22291
    l_telog_rec.tel_duration := duration_i;
    --mlu added three more parameter and assigned to local variables
    l_telog_rec.tel_mdeviceid := mdeviceid_i;
    l_telog_rec.tel_hdeviceid := hdeviceid_i;
    l_telog_rec.tel_command := command_i;
    l_telog_rec.tel_transaction_id := transaction_id_i;
    l_telog_rec.tel_3pp_id := tel_3pp_id_i;
    l_telog_rec.tel_connection_time := tel_connection_time_i;
    l_telog_rec.tel_client_content := tel_client_content_i;
    l_telog_rec.tel_vin := tel_vin_i;
    l_telog_rec.tel_hu_make := make_i;
    l_telog_rec.tel_hu_country := country_i;
    l_telog_rec.tel_hu_region := region_i;
    -- DI 955, OnTime WI #13557
    l_telog_rec.tel_huniqueid := huniqueid_i;
    l_telog_rec.tel_muniqueid := muniqueid_i;
   
    -- Jira DDCRD-910
    l_telog_rec.user_agent := useragent_i;

    INSERT INTO telogowner.telog
    VALUES (l_telog_rec.*);

--    log_utl.docommit; -- DI #1500  Ontime WI # 16207

    OPEN recordset_o FOR
        SELECT '0';
        
EXCEPTION
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
        OPEN recordset_o FOR
            SELECT '4';

    WHEN unique_violation THEN
        OPEN recordset_o FOR
            SELECT '1';

    WHEN OTHERS THEN
        GET STACKED diagnostics
            v_err_msg := MESSAGE_TEXT,
            v_sql_code := RETURNED_SQLSTATE;
        OPEN recordset_o FOR
            SELECT '1';

        INSERT INTO telogowner.sql_error_log
        VALUES ('ADDTELOG_SP', v_sql_code, SUBSTR(v_err_msg,1,100), clock_timestamp(), session_user);
      
--         log_utl.docommit; -- DI #1500  Ontime WI # 16207
END ;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;

\i cleanup.sql;
