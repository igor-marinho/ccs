SET logdb.filename = 'function.addbulk_telog_sp.sql';

\i set_telog_env.sql

DROP FUNCTION IF EXISTS addlogging.addbulk_telog_sp(addlogging.telogtype[]);
DROP FUNCTION IF EXISTS addlogging.addbulk_telog_sp(addlogging.telogtype[], text);

CREATE OR REPLACE FUNCTION addlogging.addbulk_telog_sp(arr addlogging.telogtype[],
                                                       make_id text default null,
                                                       OUT recordset_o refcursor)
AS 
$body$
DECLARE
l_telog_rec addlogging.telogtype;
v_err_msg   TEXT;
v_sql_code  INTEGER;
   
BEGIN

   INSERT INTO telogowner.telog (tel_email_address1,
                                  tel_password,
                                  tel_status,
                                  tel_serviceid,
                                  tel_log,
                                  tel_created_date,
                                  tel_created_by,
                                  tel_type,
                                  tel_device_latitude,
                                  tel_device_longitude,
                                  tel_partnerid,
                                  tel_strike_time,
                                  tel_duration,
                                  tel_mdeviceid,
                                  tel_hdeviceid,
                                  tel_command,
                                  tel_transaction_id,
                                  tel_3pp_id,
                                  tel_connection_time,
                                  tel_client_content,
                                  tel_vin,
                                  tel_hu_make,
                                  tel_hu_country,
                                  tel_hu_region,
                                  pkguid,
                                  tel_muniqueid,
                                  tel_huniqueid,
                                  user_agent)                                    
                 SELECT TRIM(lower((t.c).tel_email_address1)),
                 null,
				 (t.c).tel_status,
				 (t.c).tel_serviceid,
				 (t.c).tel_log,
				 clock_timestamp(),
				 'TELOG',
				 (t.c).tel_type,
				 null,
				 null,
				 (t.c).tel_partnerid,
				 coalesce((t.c).tel_strike_time, clock_timestamp()),
				 (t.c).tel_duration,
				 (t.c).tel_mdeviceid,
				 (t.c).tel_hdeviceid,
				 (t.c).tel_command,
				 (t.c).tel_transaction_id,
				 (t.c).tel_3pp_id,
				 (t.c).tel_connection_time,
				 (t.c).tel_client_content,
				 (t.c).tel_vin,
				 (t.c).tel_hu_make,
				 (t.c).tel_hu_country,
				 (t.c).tel_hu_region,
				 beowner.rand_guid(),
				 (t.c).tel_muniqueid,
				 (t.c).tel_huniqueid,
				 (t.c).user_agent       
   from (select unnest(arr) as c) t;
          
    OPEN recordset_o FOR
    SELECT '0';
        
EXCEPTION
    WHEN string_data_right_truncation OR numeric_value_out_of_range OR invalid_text_representation THEN
        OPEN recordset_o FOR
        SELECT '4';

    WHEN unique_violation THEN
        OPEN recordset_o FOR
        SELECT '1';

    WHEN OTHERS THEN
        GET STACKED diagnostics
            v_err_msg := MESSAGE_TEXT,
            v_sql_code := RETURNED_SQLSTATE;
			
        OPEN recordset_o FOR
        SELECT '1';

        INSERT INTO telogowner.sql_error_log
        VALUES ('ADDTELOG_SP', v_sql_code, SUBSTR(v_err_msg,1,100), clock_timestamp(), session_user);
      

END ;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;

\i cleanup.sql;
