SET bedb.filename = 'merge_cfg.sql';

\i set_be_env.sql;

DELETE FROM beowner.cfg WHERE name ='Oneapp PTNR ID';

\i cleanup.sql;


