SET bedb.filename = 'merge_cfg.sql';

\i set_be_env.sql;

INSERT INTO beowner.cfg(name, value) VALUES
('Oneapp PTNR ID', '00000000-0000-0000-0000-000000000000')
ON CONFLICT ON CONSTRAINT pk_cfg
DO UPDATE SET
value = '00000000-0000-0000-0000-000000000000';

\i cleanup.sql;


