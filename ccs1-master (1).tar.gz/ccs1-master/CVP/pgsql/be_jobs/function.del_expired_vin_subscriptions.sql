SET bedb.filename = 'function.del_expired_vin_subscriptions.sql';

\i set_be_env.sql;

drop function if exists be_jobs.del_expired_vin_subscriptions();

CREATE OR REPLACE FUNCTION be_jobs.del_expired_vin_subscriptions()
RETURNS INTEGER
AS
$body$
DECLARE
      l_action TEXT;
      l_module_name text := 'del_expired_vin_subscriptions';
      l_result_code    TEXT;
      l_context_result TEXT;
      l_ptnr_id        beowner.ptnr.ptnr_id%TYPE;
      l_vendor_tid     beowner.vin_subscription.vendor_tid%TYPE;
      l_exception_diagnostics trc.exception_diagnostics;
      expired_vin_subscriptions CURSOR FOR 
         SELECT vs_id::TEXT,
                vin
           FROM beowner.vin_subscription
          WHERE sub_end_date + interval '1' day < current_date; -- Subscription is technically expired on 00:00hrs of the
      -- day following the date indicated in SUB_END_DATE.
      -- Provide a buffer of one day before considering
      -- the subscription to be finally expired and, thus,
      -- a candidate for deletion.
      
      l_return INTEGER := utl.get_constant_value('csuccess')::integer;

BEGIN
      FOR i IN expired_vin_subscriptions
      LOOP
         BEGIN        
            l_ptnr_id := be_jobs.get_ptnr_id(i_vin => i.vin);
            l_vendor_tid := 'DEL_SUB_JOB' || beowner.rand_guid();
            l_action := utl.set_module_action( l_module_name, ' Setting Context');
            l_context_result := ctx.set(iptnrid     => l_ptnr_id::TEXT,
                                        iloginid    => NULL,
                                        iusrid      => NULL,
                                        imakeid     => NULL,
                                        ivin        => i.vin,
                                        itranid     => NULL,
                                        itrannm     => NULL,
                                        itranstepnm => NULL,
                                        ivendortid  => l_vendor_tid);
                                      
            IF l_context_result != utl.get_constant_value ('csuccess')
            THEN
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;

              l_return := utl.get_constant_value('cinternalerror')::integer;                   
            
              CALL trc.log(iadditionaldata => 'Context failure code => ' || l_context_result|| ' for vin ' || i.vin,
                           iexception_diagnostics => l_exception_diagnostics);
            END IF;
          
            l_action := utl.set_module_action( l_module_name, ' Deleting Subscription');
            l_result_code := crudg_subscription.d_subscription(isubscription_id => i.vs_id,
                                                               ivin             => i.vin,
                                                               iversion         => NULL);
         
            -- Jira SBM-189 : If subscription was deleted in the other instance in the interim, ignore the errors (47, 48)
         
            IF l_result_code != utl.get_constant_value ('csuccess') AND
               l_result_code NOT IN (utl.get_constant_value ('cinvalidsubscriptionid'), utl.get_constant_value ('cvinsubscriptiondoesnotexist'))
            THEN

              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;
  
              l_return := utl.get_constant_value('cinternalerror')::integer;
            
              CALL trc.log(iadditionaldata => 'Failure code => ' || l_result_code|| ' for subscription_id ' || i.vs_id,
                           iexception_diagnostics => l_exception_diagnostics);
            END IF;
            
            l_action := utl.set_action(' Unsetting Context');
            l_context_result := ctx.unset();
            IF l_context_result != utl.get_constant_value ('csuccess')
            THEN
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;
            
              l_return := utl.get_constant_value('cinternalerror')::integer;            
            
              CALL trc.log(iadditionaldata => 'Ctx unsetting failed return code => ' || l_context_result,
                           iexception_diagnostics => l_exception_diagnostics);
            END IF;
         EXCEPTION
            WHEN OTHERS then
              GET STACKED diagnostics
                l_exception_diagnostics.returned_sqlstate := RETURNED_SQLSTATE,
                l_exception_diagnostics.column_name := COLUMN_NAME,
                l_exception_diagnostics.constraint_name := CONSTRAINT_NAME,
                l_exception_diagnostics.pg_datatype_name := PG_DATATYPE_NAME,
                l_exception_diagnostics.message_text := MESSAGE_TEXT,
                l_exception_diagnostics.table_name := TABLE_NAME,
                l_exception_diagnostics.schema_name := SCHEMA_NAME,              
                l_exception_diagnostics.pg_exception_detail := PG_EXCEPTION_DETAIL,
                l_exception_diagnostics.pg_exception_hint := PG_EXCEPTION_HINT,
                l_exception_diagnostics.pg_exception_context := PG_EXCEPTION_CONTEXT;
    
              l_exception_diagnostics.module_name := l_module_name;
              l_exception_diagnostics.action := l_action;
            
              CALL trc.log(iadditionaldata => 'Unexpected error - subscription_id ' || i.vs_id,
                           iexception_diagnostics => l_exception_diagnostics);
                         
              return utl.get_constant_value('cinternalerror')::integer;            
                          
         END;
      END LOOP;
    
      return l_return;
            
END;
$body$
LANGUAGE PLPGSQL
SECURITY DEFINER;

\i cleanup.sql;
