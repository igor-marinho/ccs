SET bedb.filename = 'function.get_ptnr_id.sql';

\i set_be_env.sql;

CREATE OR REPLACE FUNCTION be_jobs.get_ptnr_id(i_vin IN beowner.vin.vin%TYPE)RETURNS beowner.ptnr.ptnr_id%TYPE 
AS 
$body$
DECLARE
r_reply beowner.ptnr.ptnr_id%TYPE;
 BEGIN
    SELECT ptnr_id
      INTO r_reply
      FROM beowner.ptnr
     WHERE make_id IN (SELECT make_id
                         FROM beowner.vin
                        WHERE vin = i_vin)
                    LIMIT 1;
  RETURN r_reply;
EXCEPTION
WHEN OTHERS THEN
  r_reply := NULL;
  RETURN r_reply;
END 
$body$
LANGUAGE plpgsql;

\i cleanup.sql;
